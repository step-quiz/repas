/* codi.js — codi de verificació de repàs-ESO: generació i lectura.

   Les dues meitats viuen al mateix fitxer a propòsit. Si el generador i el
   lector són fitxers diferents, tard o d'hora divergeixen i el resultat és el
   pitjor possible: codis que es llegeixen malament sense que res avisi.
   L'analitzador carrega aquest mateix fitxer.

   ── QUÈ PORTA EL CODI ──────────────────────────────────────────────────────

   Un codi és una fotografia COMPLETA del progrés de l'alumne en un o més
   fulls, en el moment de generar-lo. No és un tiquet d'una sessió: és
   acumulatiu, i cada codi nou substitueix l'anterior. Això encaixa amb com
   s'usa repàs-ESO —treball propi, a estones, durant setmanes— i té dues
   conseqüències bones: si l'alumne s'oblida d'enviar-ne un, el següent ja
   conté tot el que faltava; i el professorat només ha de mirar l'últim.

   ── FORMAT ────────────────────────────────────────────────────────────────

     RC4 SSS DDD HH MMM  [ per cada full: G + grups de 4 ]  [ DIAG ] EEEEEEEEE [ META ] [ DATES ] KK

     RC4   3   marca i versió (RC1, RC2 i RC3 es continuen llegint)
     SSS   3   salt aleatori
     DDD   3   dia (dies des de l'1/9/2025)
     HH    2   hora (minuts/2 des de mitjanit)
     MMM   3   màscara: bits 0-11 = fulls presents, bit 12 = hi ha diagnòstic,
               bit 13 = hi ha bloc META, bit 14 = hi ha bloc DATES
     G     1   nombre de grups d'aquest full
     ····  4   un grup = 7 ítems en base 7 (base 6 fins a RC3)
     DIAG  9   15 destreses del test inicial, en base 8 (si el bit 12 és actiu)
     EEEE  9   les 3 etiquetes d'error més repetides (índex 2 car. + compte 1)
     META  8   com s'ha fet la feina (si el bit 13 és actiu):
                 MMM  minuts de feina activa
                 I    importacions de codi (0-31)
                 NN   exercicis que venen d'una importació (0-1023)
                 R    exercicis repetits un cop ja tancats (0-31)
                 S    vegades que s'ha reiniciat un full (0-31)
     ORIG  6   només si I > 0: dia (3) + salt (3) de l'ÚLTIM codi importat
     DATES     (si el bit 14 és actiu) el primer intent de cada exercici de
               les últimes setmanes, en l'ordre en què es van fer:
                 FF  finestra en dies · GG nombre de dies amb feina
                 per dia, del més antic al més recent:
                   DD dies abans del codi · NN exercicis d'aquell dia
                   per exercici, en ordre: F full (1) + PP posició (2)
     KK    2   dos caràcters de control

   ── PER QUÈ HI HA EL BLOC META ────────────────────────────────────────────

   Fins a RC2 el codi deia QUÈ s'havia fet i com havia anat, i no deia res de
   COM s'havia fet. Dues coses molt diferents hi arribaven idèntiques: un
   trimestre de feina propi i el codi d'un company importat i continuat des
   d'allà. El bloc META no acusa ningú —importar un codi és una funció
   legítima i necessària en un carro de Chromebooks— però fa que la
   diferència es vegi, que és tot el que un sistema sense servidor pot fer
   honestament.

   `ORIG` és la peça que ho tanca: com que hi viatja el dia i el salt del codi
   importat, i el salt és aleatori de 3 caràcters, l'analitzador pot creuar-lo
   amb els codis que ja té al full de respostes i dir de qui era. Si era d'un
   altre alumne, ho sap del cert; si era d'ell mateix, també, i llavors calla.

   Estat de cada ítem: 0 per fer · 1 net · 2 al segon intent · 3 amb una
   pista · 4 fallat · 5 començat sense respondre · 6 amb dues pistes o més.
   L'estat 6 és de RC4: fins a RC3 "pista" volia dir qualsevol nombre de
   pistes, i per això un codi antic es llegeix com a una sola pista.

   ── PER QUÈ HI HA RC4 ───────────────────────────────────────────────────

   El mini-examen de 3 setmanes demana dues coses que RC3 no podia dir:
   si l'alumne va obrir una pista o dues (no penalitzen igual), i QUAN va
   fer cada exercici (l'examen d'un tram només pot sortir de la feina
   d'aquelles tres setmanes, i només compten els 20 primers). Fins ara la
   data es deduïa comparant enviaments, i un codi enviat tard posava la
   feina al tram equivocat. Set estats caben en quatre caràcters igual que
   sis (7^7 < 32^4), així que el sostre de 217 ítems per full no es mou.

   Els grups finals que són tot zeros no s'escriuen: un alumne que ha fet els
   20 primers exercicis d'un full de 140 no arrossega 120 zeros.

   ── ELS DOS CARÀCTERS DE CONTROL ──────────────────────────────────────────

   La lletra del DNI és una suma mod 23 pensada per a 8 xifres. Aquí la
   càrrega pot passar dels 400 caràcters i cal alguna cosa més, per dos
   motius:

   1. Una suma SENSE pesos no detecta mai una transposició. Si en copiar
      s'intercanvien dos caràcters, la suma no es mou. Amb càrregues llargues
      això passa sovint, així que la suma va pesada per la posició.
   2. El mòdul ha de ser més gran que l'alfabet. Amb 32 caràcters i mòdul 31,
      el "0" i la "Z" valen el mateix (0 i 31 són congruents) i confondre'ls
      no trencaria res.

   Per això el control és un sol valor de 0 a 1020 escrit en dos caràcters:

     K = ( Σ (i+1)·valor(car_i) )  mod 1021        (1021 és primer)
     K'= ( 317·K + 613 )           mod 1021        (barreja, com fa el DNI)

   Com que 1021 és primer i més gran que qualsevol valor de caràcter i que la
   llargada del codi, això detecta **totes** les substitucions d'un caràcter i
   **totes** les transposicions de dos, sense excepció. Un canvi a l'atzar
   se n'escapa amb probabilitat 1/1021.

   ── I LA CADENA D'ESTATS? ─────────────────────────────────────────────────

   El forat clàssic d'aquests codis és que el control cobreix la nota però no
   el detall pregunta a pregunta, i llavors es pot retocar el detall sense
   trencar res. Aquí no hi ha aquest forat per construcció: el control es
   calcula sobre TOTS els caràcters del codi, detall inclòs. A més, la nota no
   s'hi guarda: es deriva dels estats en llegir-lo, de manera que no hi ha dos
   nombres que puguin contradir-se.
*/
window.RE_CODI = (function () {
  "use strict";

  /* Alfabet sense I, L, O ni U: evita confondre 1/I/L i 0/O en llegir un codi
     a mà o dictar-lo, i evita que hi surtin paraules per casualitat. */
  var ALF = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

  var EPOCA = Date.UTC(2025, 8, 1);           /* 1 de setembre de 2025 */

  /* La data ocupa 3 caràcters (32768 dies, fins al 2115). A la versió RC1
     n'ocupava 2, i això topava als 1024 dies: a partir del 20 de juny de 2028
     tots els codis haurien dit la mateixa data, en silenci i sense que res
     avisés, i l'anàlisi per trimestres hauria quedat inservible. Costava un
     caràcter arreglar-ho. El lector accepta les dues versions. */
  var CAR_DIA = { RC1: 2, RC2: 3, RC3: 3, RC4: 3 };
  var BASE = { RC1: 6, RC2: 6, RC3: 6, RC4: 7 };
  var VERSIO = "RC4";
  /* Quants dies enrere es data el primer intent: 12 setmanes. Cobreixen un
     trimestre sencer de trams des del seu últim dia (el més llarg, el primer,
     en fa 77 amb les setmanes de descans), així que un alumne que només
     envia el codi a final de trimestre encara hi porta la data de tot. Més
     enllà, l'exercici viatja sense data i no compta per a cap tram. */
  var FINESTRA_DATES = 84;

  /* ── ELS DOS SOSTRES DEL FORMAT, ESCRITS ─────────────────────────────────

     Tots dos eren implícits i tots dos fallaven EN SILENCI, que és la pitjor
     manera possible en un projecte que després qualifica amb això:

     · MAX_ITEMS. El nombre de grups d'un full va en UN caràcter base32, o
       sigui 31 grups com a màxim, o sigui 217 ítems. Amb 218, `enc(32, 1)`
       dona "0" i el lector es creu que el full no porta cap grup: el codi
       surt ÍNTEGRE i amb la feina sencera a zero. El Full 1 ja va per 140.

     · MAX_FULLS. La màscara té els fulls als bits 0-11 i el diagnòstic al
       bit 12. Un Full 13 activaria el bit 12: el full desapareixeria i el
       lector es trobaria un diagnòstic fantasma. També íntegre.

     Passar-ne demana un format nou (RC4), no un pedaç: aquí només es
     comprova, i si no hi cabem s'atura en comptes d'emetre un codi dolent.
     `build_codi.py` fa la mateixa comprovació en compilar, perquè el problema
     es vegi mentre s'afegeix contingut i no el dia que un alumne enviï el
     codi. */
  var GRUPS_MAX = 31;
  var MAX_ITEMS = GRUPS_MAX * 7;        /* 217 */
  var MAX_FULLS = 12;
  var ESTATS = ["", "net", "segon", "pista", "fallat", "vist", "pistes"];
  /* `pista` val MÉS que `segon`, no menys. Amb 6 la taula premiava
     endevinar per damunt de demanar ajuda: amb quatre opcions i dos intents,
     provar a l'atzar acaba en `segon` la meitat de les vegades (7 punts),
     mentre que llegir la pista i respondre bé en donava 6 garantits. Com que
     d'aquests estats en surt una nota, l'alumne que calcula aprenia a no
     demanar mai una pista, que és exactament el contrari del que volem.
     Ara: a la primera (10) > una pista (9,5) > dues pistes o més (8) > al
     segon intent (7). La primera pista gairebé no penalitza a posta: és
     repàs d'ESO i hi ha coses que no es recorden. */
  var PES = { net: 10, pista: 9.5, pistes: 8, segon: 7, fallat: 0, vist: 0, "": 0 };

  /* ── NOTA DE FEINA D'UN TRAM DE 3 SETMANES ───────────────────────────────

     `estats` són els dels exercicis del tram EN L'ORDRE EN QUÈ ES VAN FER.
     Només compten els `maxim` primers (20). Cada un aporta el seu valor
     sobre 10 (a la primera 1, una pista 0,95, dues 0,8, segon intent 0,7,
     fallat 0), i amb la suma x:

         nota = min(10, 8 · ∛(x/10))

     10 exercicis a la primera fan un 8 i 20 fan un 10. Un exercici fallat
     no suma, però tampoc no resta: fer-ne un de més no pot baixar mai la
     nota, que és el que convé si no es vol que evitin els difícils. */
  function notaTram(estats, maxim, valors) {
    var max = maxim > 0 ? maxim : 20, v = valors || PES;
    var compten = (estats || []).slice(0, max), x = 0;
    compten.forEach(function (e) { x += (+v[e] || 0) / 10; });
    var nota = x > 0 ? Math.min(10, 8 * Math.pow(x / 10, 1 / 3)) : 0;
    return { n: (estats || []).length, compten: compten.length, x: x, nota: nota };
  }

  function val(c) { return ALF.indexOf(c); }

  /* Dia (dies des de l'època) d'una data, segons el calendari LOCAL: un
     exercici fet a les 00:30 és d'aquell dia, no del d'abans en UTC. */
  function diaDe(d) {
    return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - EPOCA) / 86400000);
  }
  /* I a la inversa: el migdia local d'aquell dia, que no depèn de l'hora. */
  function dataDeDia(n) {
    var u = new Date(EPOCA + n * 86400000);
    return new Date(u.getUTCFullYear(), u.getUTCMonth(), u.getUTCDate(), 12, 0, 0, 0);
  }

  /* Enter -> n caràcters base32, amb zeros al davant. */
  function enc(num, n) {
    var s = "";
    for (var i = 0; i < n; i++) { s = ALF.charAt(num % 32) + s; num = Math.floor(num / 32); }
    return s;
  }
  function dec(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) n = n * 32 + val(s.charAt(i));
    return n;
  }

  /* Normalitza el que ha enganxat una persona: fora espais i guions, i les
     confusions típiques de teclat cap al caràcter que sí que és a l'alfabet. */
  function neteja(raw) {
    return String(raw || "").toUpperCase()
      .replace(/[\s\-–—_.]/g, "")
      .replace(/[IL]/g, "1").replace(/O/g, "0").replace(/U/g, "V");
  }

  var P = 1021, MULT = 317, DESPL = 613;

  function control(cos) {
    var k = 0;
    for (var i = 0; i < cos.length; i++) {
      var v = val(cos.charAt(i));
      if (v < 0) return null;                 /* caràcter fora de l'alfabet */
      k = (k + (i + 1) * v) % P;
    }
    return enc((MULT * k + DESPL) % P, 2);
  }

  /* Presentació: grups de 5, que és el que la gent pot comparar d'un cop d'ull. */
  function formata(s) { return (s.match(/.{1,5}/g) || []).join("-"); }

  // ── GENERACIÓ ────────────────────────────────────────────────────────────

  /* fulls: [{n, estats:[...]}] amb estats en l'ordre de RE_TAULES.fulls[n].items
     diag:  [{estat, encert}] × 15, o null
     errs:  [[etiqueta, compte], ...] ja ordenat de més a menys */
  function genera(opcions) {
    var T = window.RE_TAULES;
    var fulls = (opcions.fulls || []).filter(function (f) {
      return f.estats.some(function (e) { return e; });
    }).sort(function (a, b) { return a.n - b.n; });
    var diag = opcions.diag || null;
    var errs = opcions.errs || [];
    var ara = opcions.ara ? new Date(opcions.ara) : new Date();

    var salt = "";
    for (var i = 0; i < 3; i++) salt += ALF.charAt(Math.floor(Math.random() * 32));

    var dia = Math.max(0, Math.min(32767, diaDe(ara)));
    var hora = Math.min(719, Math.floor((ara.getHours() * 60 + ara.getMinutes()) / 2));

    var meta = opcions.meta || null;

    /* Els sostres es comproven ABANS d'escriure res: val més petar aquí, on
       hi ha algú mirant, que emetre un codi que es llegeix malament i es dona
       per bo. */
    fulls.forEach(function (f) {
      if (f.n < 1 || f.n > MAX_FULLS) {
        throw new Error("RE_CODI: el format RC3 només té lloc per a "
          + MAX_FULLS + " fulls i se n'ha demanat el " + f.n
          + ". Amb més fulls cal un format nou (RC4): el bit del full "
          + (MAX_FULLS + 1) + " és el del diagnòstic.");
      }
      if (f.estats.length > MAX_ITEMS) {
        throw new Error("RE_CODI: el full " + f.n + " té " + f.estats.length
          + " ítems i el format RC3 n'admet " + MAX_ITEMS
          + " (31 grups de 7). Amb més cal un format nou (RC4).");
      }
    });

    var ambDates = fulls.some(function (f) { return !!f.dates; });
    var mask = 0;
    fulls.forEach(function (f) { mask |= (1 << (f.n - 1)); });
    if (diag) mask |= (1 << 12);
    if (meta) mask |= (1 << 13);
    if (ambDates) mask |= (1 << 14);

    var cos = VERSIO + salt + enc(dia, CAR_DIA[VERSIO]) + enc(hora, 2) + enc(mask, 3);

    fulls.forEach(function (f) {
      var codis = f.estats.map(function (e) { return Math.max(0, ESTATS.indexOf(e || "")); });
      var base = BASE[VERSIO];
      /* Els grups finals buits no s'escriuen. */
      var ultim = -1;
      codis.forEach(function (v, i) { if (v) ultim = i; });
      var grups = Math.ceil((ultim + 1) / 7);
      cos += enc(grups, 1);
      for (var g = 0; g < grups; g++) {
        var num = 0;
        for (var k = 0; k < 7; k++) num = num * base + (codis[g * 7 + k] || 0);
        cos += enc(num, 4);
      }
    });

    if (diag) {
      /* 15 destreses en base 8: estat 0-3 (× 2) més encert 0/1. Però 45 bits
         no caben en un Number sencer amb multiplicacions successives, així
         que es parteix en dos trossos de 8 i 7 destreses. */
      var d1 = 0, d2 = 0;
      for (var j1 = 0; j1 < 8; j1++) {
        var p1 = diag[j1] || {};
        d1 = d1 * 8 + ((Math.max(0, Math.min(3, p1.estat | 0))) * 2 + (p1.encert ? 1 : 0));
      }
      for (var j2 = 8; j2 < 15; j2++) {
        var p2 = diag[j2] || {};
        d2 = d2 * 8 + ((Math.max(0, Math.min(3, p2.estat | 0))) * 2 + (p2.encert ? 1 : 0));
      }
      cos += enc(d1, 5) + enc(d2, 5);
    }

    for (var m = 0; m < 3; m++) {
      var par = errs[m];
      if (par) {
        var idx = T.etiquetes.indexOf(par[0]);
        cos += (idx < 0) ? "ZZ0" : enc(idx, 2) + enc(Math.min(31, par[1]), 1);
      } else {
        cos += "ZZ0";
      }
    }

    if (meta) {
      var top = function (x, m) { return Math.max(0, Math.min(m, Math.floor(x || 0))); };
      var nImp = top(meta.imports, 31);
      cos += enc(top(meta.minuts, 32767), 3)
           + enc(nImp, 1)
           + enc(top(meta.itemsImportats, 1023), 2)
           + enc(top(meta.repeticions, 31), 1)
           + enc(top(meta.esborrats, 31), 1);
      if (nImp > 0) {
        var o = meta.origen || {};
        var salt = String(o.salt || "000").toUpperCase().slice(0, 3);
        if (salt.length < 3 || salt.split("").some(function (c) { return val(c) < 0; })) salt = "000";
        cos += enc(top(o.dia, 32767), 3) + salt;
      }
    }

    if (ambDates) {
      /* Només els exercicis fets (ni els per fer ni els oberts sense
         respondre) que tenen data i cauen dins de la finestra. S'escriuen en
         ordre cronològic perquè l'analitzador sàpiga quins són els 20
         primers de cada tram. */
      var feta = [];
      fulls.forEach(function (f) {
        (f.dates || []).forEach(function (t, i) {
          var e = f.estats[i];
          if (!t || !e || e === "vist") return;
          var off = dia - diaDe(new Date(t));
          if (off < 0) off = 0;              /* rellotge avançat: compta com avui */
          if (off > FINESTRA_DATES) return;
          feta.push({ n: f.n, i: i, t: +t, off: off });
        });
      });
      feta.sort(function (a, b) { return a.t - b.t || a.n - b.n || a.i - b.i; });
      var dies = [];
      feta.forEach(function (x) {
        var g = dies[dies.length - 1];
        if (!g || g.off !== x.off) { g = { off: x.off, items: [] }; dies.push(g); }
        g.items.push(x);
      });
      cos += enc(FINESTRA_DATES, 2) + enc(dies.length, 2);
      dies.forEach(function (g) {
        cos += enc(g.off, 2) + enc(g.items.length, 2);
        g.items.forEach(function (x) { cos += enc(x.n, 1) + enc(x.i, 2); });
      });
    }

    return formata(cos + control(cos));
  }

  // ── LECTURA ──────────────────────────────────────────────────────────────

  function llegeix(raw) {
    var T = window.RE_TAULES;
    var s = neteja(raw);
    if (!s) return { ok: false, error: "Codi buit" };
    var versio = s.slice(0, 3);
    if (!CAR_DIA[versio]) {
      return { ok: false, error: "No sembla un codi de repàs-ESO (ha de començar per RC4, o per RC3, RC2 o RC1 si és antic)" };
    }
    if (s.length < 15) return { ok: false, error: "Codi massa curt" };

    var cos = s.slice(0, -2), kk = s.slice(-2);
    var esperat = control(cos);
    if (esperat === null) return { ok: false, error: "El codi porta caràcters que no hi haurien de ser" };
    var integre = (esperat === kk);

    var p = 3;
    var salt = s.slice(p, p + 3); p += 3;
    var dia = dec(s.slice(p, p + CAR_DIA[versio])); p += CAR_DIA[versio];
    var hora = dec(s.slice(p, p + 2)); p += 2;
    var mask = dec(s.slice(p, p + 3)); p += 3;

    var data = new Date(EPOCA + dia * 86400000);
    var minuts = hora * 2;

    var fulls = [], r, base = BASE[versio];
    for (var n = 1; n <= MAX_FULLS; n++) {
      if (!(mask & (1 << (n - 1)))) continue;
      if (p >= cos.length) return { ok: false, error: "El codi s'acaba abans d'hora" };
      var grups = dec(s.charAt(p)); p += 1;
      var codis = [];
      for (var g = 0; g < grups; g++) {
        var num = dec(s.slice(p, p + 4)); p += 4;
        var tros = [];
        for (var k = 0; k < 7; k++) { tros.unshift(num % base); num = Math.floor(num / base); }
        codis = codis.concat(tros);
      }
      var taula = T.fulls[n] || T.fulls[String(n)];
      if (!taula) return { ok: false, error: "El codi parla del full " + n + ", que no conec" };
      var items = taula.items.map(function (id, i) {
        return { id: id, estat: ESTATS[codis[i] || 0], dif: +taula.dif.charAt(i) };
      });
      fulls.push({ n: n, titol: taula.titol, blocs: taula.blocs, items: items });
    }

    var diag = null;
    if (mask & (1 << 12)) {
      var d1 = dec(s.slice(p, p + 5)); p += 5;
      var d2 = dec(s.slice(p, p + 5)); p += 5;
      diag = [];
      var b1 = [], b2 = [];
      for (var i1 = 0; i1 < 8; i1++) { b1.unshift(d1 % 8); d1 = Math.floor(d1 / 8); }
      for (var i2 = 0; i2 < 7; i2++) { b2.unshift(d2 % 8); d2 = Math.floor(d2 / 8); }
      b1.concat(b2).forEach(function (v, i) {
        diag.push({
          prova: (T.proves[i] || {}).id || "?",
          tema: (T.proves[i] || {}).tema || "?",
          estat: v >> 1, encert: !!(v & 1)
        });
      });
    }

    var errs = [];
    for (var m = 0; m < 3 && p + 2 < cos.length + 1; m++) {
      var tros3 = s.slice(p, p + 3); p += 3;
      if (tros3.slice(0, 2) === "ZZ") continue;
      var idx = dec(tros3.slice(0, 2)), cnt = dec(tros3.charAt(2));
      if (T.etiquetes[idx]) errs.push({ etiqueta: T.etiquetes[idx], compte: cnt });
    }

    /* El bloc META és opcional i porta la seva pròpia marca a la màscara: els
       codis RC1/RC2 anteriors no en tenen i s'han de continuar llegint igual,
       sense inventar-los cap dada. `meta: null` vol dir "aquest codi no ho
       diu", que no és el mateix que "val zero". */
    var meta = null;
    if (mask & (1 << 13)) {
      if (p + 8 > cos.length) return { ok: false, error: "El codi s'acaba abans d'hora" };
      meta = {
        minuts: dec(s.slice(p, p + 3)),
        imports: dec(s.charAt(p + 3)),
        itemsImportats: dec(s.slice(p + 4, p + 6)),
        repeticions: dec(s.charAt(p + 6)),
        esborrats: dec(s.charAt(p + 7)),
        origen: null
      };
      p += 8;
      if (meta.imports > 0 && p + 6 <= cos.length) {
        var oDia = dec(s.slice(p, p + 3)), oSalt = s.slice(p + 3, p + 6); p += 6;
        meta.origen = { dia: oDia, salt: oSalt, data: new Date(EPOCA + oDia * 86400000) };
      }
    }

    /* Bloc DATES (només RC4). `dates: null` vol dir "aquest codi no porta
       dates" i l'analitzador les haurà de deduir dels enviaments; si el bloc
       hi és, un exercici fet que no hi surti és d'abans de la finestra. */
    var dates = null;
    if (versio === "RC4" && (mask & (1 << 14))) {
      var curt = { ok: false, error: "El codi s'acaba abans d'hora" };
      if (p + 4 > cos.length) return curt;
      var fin = dec(s.slice(p, p + 2)), nDies = dec(s.slice(p + 2, p + 4)); p += 4;
      dates = { finestra: fin, desde: dataDeDia(dia - fin), ignorats: 0 };
      var perFull = {};
      fulls.forEach(function (f) { perFull[f.n] = f; });
      var ordre = 0;
      for (var g2 = 0; g2 < nDies; g2++) {
        if (p + 4 > cos.length) return curt;
        var off = dec(s.slice(p, p + 2)), nIt = dec(s.slice(p + 2, p + 4)); p += 4;
        if (p + 3 * nIt > cos.length) return curt;
        var dItem = dataDeDia(dia - off);
        for (var q = 0; q < nIt; q++) {
          var fx = perFull[dec(s.charAt(p))], ix = fx && fx.items[dec(s.slice(p + 1, p + 3))];
          p += 3;
          if (ix && ix.estat && ix.estat !== "vist" && !ix.feta) {
            ix.feta = dItem;
            ix.ordre = ordre++;
          } else {
            dates.ignorats++;
          }
        }
      }
    }

    r = {
      ok: true, integre: integre, salt: salt, versio: versio,
      data: data, hora: Math.floor(minuts / 60), minut: minuts % 60,
      fulls: fulls, diag: diag, errs: errs, meta: meta, dates: dates,
      error: integre ? null : "Els caràcters de control no quadren: el codi s'ha copiat malament o s'ha modificat"
    };
    r.resum = resum(r);
    return r;
  }

  /* Recompte i nota. La nota NO viatja dins del codi: es deriva aquí dels
     estats. Així no hi pot haver un codi on la nota i el detall es
     contradiguin, que és per on s'esmuny la manipulació en aquests sistemes. */
  function resum(r) {
    var c = { net: 0, segon: 0, pista: 0, pistes: 0, fallat: 0, vist: 0 }, punts = 0, fets = 0;
    var perDif = { 1: 0, 2: 0, 3: 0, 4: 0 };   /* trivial, directa, encadenada, completa */
    r.fulls.forEach(function (f) {
      f.items.forEach(function (it) {
        if (!it.estat) return;
        c[it.estat]++;
        if (it.estat !== "vist") { fets++; punts += PES[it.estat]; perDif[it.dif]++; }
      });
    });
    return {
      comptes: c, fets: fets, perDif: perDif,
      nota: fets ? Number((punts / (10 * fets) * 10).toFixed(1)) : null
    };
  }

  // ── RECOLLIDA DE L'ESTAT DES DEL NAVEGADOR ───────────────────────────────

  /* Munta l'argument de genera() a partir del que hi ha a localStorage.
     `quins` és una llista de números de full, o null per a tots. */
  /* Empremta d'un codi ja llegit: el que cal per reconèixer-lo més tard des
     d'un altre codi que digui "d'aquí ve la meva feina importada". Dia i salt
     n'hi ha prou: el salt són 3 caràcters aleatoris (32.768 combinacions) i
     només s'ha de distingir entre els codis d'una classe. */
  function empremta(p) {
    if (!p || !p.ok) return null;
    return {
      dia: Math.round((p.data.getTime() - EPOCA) / 86400000),
      salt: p.salt
    };
  }

  function recull(quins) {
    var T = window.RE_TAULES, fulls = [], compte = {};
    var llista = quins || Object.keys(T.fulls).map(Number).sort(function (a, b) { return a - b; });
    var importats = 0, repeticions = 0;

    llista.forEach(function (n) {
      var taula = T.fulls[n] || T.fulls[String(n)];
      if (!taula) return;
      var p = window.RE.llegeix(n).items || {};
      var dates = [];
      var estats = taula.items.map(function (id) {
        var it = p[id] || {};
        if (it.imp && it.estat) importats++;
        repeticions += (it.rep || 0);
        dates.push(it.tf || 0);
        /* Es compta l'historial sencer (`errs`), no només l'error pendent:
           un error rectificat al segon intent segueix sent un error comès, i
           si es repeteix el professorat l'ha de veure. `err` és el format
           antic i només s'usa si l'ítem encara no té historial. */
        var errsIt = it.errs && it.errs.length ? it.errs : (it.err ? [it.err] : []);
        errsIt.forEach(function (e) { compte[e] = (compte[e] || 0) + 1; });
        /* El registre desa "pista" tant si se n'ha obert una com dues o
           tres: no ha canviat de vocabulari. On es distingeix és aquí, amb
           el comptador de pistes obertes. */
        if (it.estat === "pista" && (it.npis || 0) >= 2) return "pistes";
        return it.estat || "";
      });
      fulls.push({ n: n, estats: estats, dates: dates });
    });

    var errs = Object.keys(compte)
      .map(function (e) { return [e, compte[e]]; })
      .sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); })
      .slice(0, 3);

    var diag = null;
    if (window.RE_DIAG && typeof window.RE_DIAG.llegeix === "function") {
      var d = window.RE_DIAG.llegeix();
      if (d && d.situacions) {
        var ordre = { domino: 0, oblidat: 1, no_entes: 2, mai: 3 };
        diag = T.proves.map(function (pr) {
          var s = d.situacions.filter(function (x) { return x.prova === pr.id; })[0];
          return s ? { estat: ordre[s.estat] || 0, encert: !!s.encert } : { estat: 3, encert: false };
        });
      }
    }
    var g = (window.RE.meta && window.RE.meta()) || {};
    var meta = {
      minuts: g.min || Math.floor((g.seg || 0) / 60),
      imports: g.imp || 0,
      itemsImportats: importats,
      repeticions: repeticions,
      esborrats: g.esb || 0,
      origen: g.orig || null
    };

    return { fulls: fulls, errs: errs, diag: diag, meta: meta };
  }

  return {
    genera: genera, llegeix: llegeix, recull: recull, empremta: empremta,
    neteja: neteja, formata: formata, ESTATS: ESTATS, PES: PES,
    notaTram: notaTram, FINESTRA_DATES: FINESTRA_DATES, dataDeDia: dataDeDia,
    /* Els sostres del format, exportats perquè el build i les proves els
       comprovin contra el banc de debò en lloc de repetir el número. */
    MAX_ITEMS: MAX_ITEMS, MAX_FULLS: MAX_FULLS
  };
})();
