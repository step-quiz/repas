/* tests/analitzador.test.js — proves de l'analitzador del professorat.

   Aquestes SÍ que necessiten un DOM, perquè el que es prova és el
   comportament de la pàgina, no una funció. La dependència (`jsdom`) no és
   del projecte sinó de les proves, i si no hi és les proves se salten amb un
   avís en comptes de petar:

       npm install --no-save jsdom
       node tests/analitzador.test.js

   Sense jsdom, `tests/executa.sh` continua i la resta de proves corren
   igualment. */
"use strict";
const fs = require("fs"), path = require("path");

let JSDOM;
try {
  JSDOM = require("jsdom").JSDOM;
} catch (e) {
  console.log("\n\x1b[33m⊘ Proves de l'analitzador saltades: falta jsdom.\x1b[0m");
  console.log("  Per passar-les:  npm install --no-save jsdom\n");
  process.exit(0);
}

const { assert, seccio, prova, resum } = require("./arnes.js");
const ARREL = path.join(__dirname, "..");
const HTML = fs.readFileSync(path.join(ARREL, "analitzador-repas.html"), "utf8");

function obre() {
  const dom = new JSDOM(HTML, { runScripts: "dangerously", url: "file:///a.html" });
  return { w: dom.window, d: dom.window.document };
}

/* Un full de respostes fabricat amb el mateix motor que fa servir l'app: els
   codis són reals i validen. */
function fabrica(w, files) {
  let tsv = "Marca de temps\tAdreça electrònica\tGrup\tCodi\n";
  files.forEach(f => { tsv += f.join("\t") + "\n"; });
  return tsv;
}
function codiDe(w, quins, quants, quan) {
  const T = w.RE_TAULES;
  return w.RE_CODI.genera({
    fulls: quins.map(n => ({
      n, estats: T.fulls[n].items.map((_, i) =>
        (i < quants ? ["net", "net", "segon", "pista", "fallat"][i % 5] : ""))
    })),
    ara: quan
  });
}
const marca = d =>
  `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()} ` +
  `${("0" + d.getHours()).slice(-2)}:${("0" + d.getMinutes()).slice(-2)}:00`;

// ─────────────────────────────────────────────────────────────────────────
seccio("Càrrega d'un full de respostes");

{
  const { w, d } = obre();
  const ara = new Date(2026, 9, 20, 18, 0);
  const c1 = codiDe(w, [4], 30, ara);
  const c2 = codiDe(w, [4, 7], 20, ara);
  d.getElementById("entrada").value = fabrica(w, [
    [marca(ara), "anna@e.cat", "1rA", c1],
    [marca(ara), "bru@e.cat", "1rA", c2],
    /* codi propi i diferent: així el retard es veu sense que el ⇄ hi entri */
    [marca(new Date(2026, 9, 20, 21, 30)), "cesc@e.cat", "1rB", codiDe(w, [11], 15, ara)],
    [marca(ara), "dina@e.cat", "1rB", c1.slice(0, 20) + "X" + c1.slice(21)],
  ]);
  d.getElementById("btn-llegeix").click();

  prova("llegeix les quatre files", () => {
    assert.strictEqual(d.querySelectorAll("#t-env tbody tr.clic").length, 4);
  });
  prova("detecta el codi mal copiat", () => {
    assert.strictEqual(d.querySelectorAll("#t-env .marca.mal").length, 1);
  });
  prova("avisa de l'enviament tardà", () => {
    assert.strictEqual(d.querySelectorAll("#t-env .marca.avis").length, 1);
  });
  prova("el correu surt encara que no sigui a la primera columna", () => {
    assert.ok(/anna/.test(d.getElementById("t-env").textContent));
  });
  prova("detecta el format de data del full", () => {
    assert.ok(/mes\/dia\/any/.test(d.getElementById("estat-carrega").textContent));
  });
  prova("el detall diu quins exercicis s'han fallat, amb identificador", () => {
    const tr = d.querySelectorAll("#t-env tbody tr.clic")[0];
    tr.dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
    const t = d.querySelector("#t-env tr.detall").textContent.replace(/\s+/g, " ");
    assert.ok(/fallats:\s*6\d[a-f]/.test(t), "no hi surten els identificadors");
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Feina mínima demanada");

{
  const { w, d } = obre();
  const ara = new Date(2026, 9, 20, 18, 0);
  d.getElementById("entrada").value = fabrica(w, [
    [marca(ara), "poc@e.cat", "1rA", codiDe(w, [4], 3, ara)],
    [marca(ara), "molt@e.cat", "1rA", codiDe(w, [4], 40, ara)],
  ]);
  d.getElementById("btn-llegeix").click();
  d.getElementById("f-min").value = "10";
  d.getElementById("f-min").dispatchEvent(new w.Event("input"));

  prova("marca en vermell qui no arriba al mínim", () => {
    assert.strictEqual(d.querySelectorAll("#t-alumnes .poca").length, 1);
  });
  prova("la nota de qui ha fet poc surt amb asterisc", () => {
    assert.ok(/\*/.test(d.getElementById("t-alumnes").textContent));
  });
  prova("el filtre de feina insuficient l'aïlla", () => {
    d.getElementById("f-estat").value = "poca";
    d.getElementById("f-estat").dispatchEvent(new w.Event("change"));
    assert.strictEqual(d.querySelectorAll("#t-env tr.clic").length, 1);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Progrés del trimestre");

{
  const { w, d } = obre();
  const T = w.RE_TAULES, ids = T.fulls[4].items;
  const INI = new Date(2026, 8, 21);
  const files = [];
  /* regular: 6 exercicis cada setmana durant 10 setmanes */
  let est = {};
  for (let s = 0; s < 10; s++) {
    for (let k = 0; k < 6; k++) est[ids[s * 6 + k]] = s < 5 ? "pista" : "net";
    const t = new Date(INI); t.setDate(t.getDate() + s * 7 + 1); t.setHours(18, 0);
    files.push([marca(t), "regular@e.cat", "1rA",
      w.RE_CODI.genera({ fulls: [{ n: 4, estats: ids.map(i => est[i] || "") }], ara: t })]);
  }
  /* concentrat: 55 exercicis en tres dies de la mateixa setmana */
  est = {};
  for (let dia = 0; dia < 3; dia++) {
    for (let k = 0; k < 18; k++) est[ids[dia * 18 + k]] = "net";
    const t = new Date(INI); t.setDate(t.getDate() + 40 + dia); t.setHours(23, 0);
    files.push([marca(t), "cop@e.cat", "1rA",
      w.RE_CODI.genera({ fulls: [{ n: 4, estats: ids.map(i => est[i] || "") }], ara: t })]);
  }
  d.getElementById("entrada").value = fabrica(w, files);
  d.getElementById("btn-llegeix").click();
  d.querySelectorAll(".pestanya")[1].click();

  prova("no calcula res fins que es prem el botó", () => {
    assert.ok(/Digues quin període/.test(d.getElementById("p-resultats").textContent));
  });

  d.getElementById("p-ini").value = "2026-09-21";
  d.getElementById("p-fi").value = "2026-12-05";
  d.getElementById("p-setm").value = "11";
  d.getElementById("p-exerc").value = "60";
  d.getElementById("p-accepta").click();

  const nota = nom => {
    let r = null;
    d.querySelectorAll("#t-progres tbody tr.clic").forEach(tr => {
      const c = tr.querySelectorAll("td");
      if (c[0].textContent.trim() === nom) r = parseFloat(c[8].textContent.replace(",", "."));
    });
    return r;
  };

  prova("la capçalera diu amb quines condicions s'ha calculat", () => {
    const t = d.querySelector(".capçalera-res").textContent.replace(/\s+/g, " ");
    assert.ok(/21\/09\/2026 – 05\/12\/2026/.test(t));
    assert.ok(/11 setmanes/.test(t) && /60 exercicis/.test(t));
  });

  prova("qui ve cada setmana treu més nota que qui ho fa tot de cop", () => {
    assert.ok(nota("regular") > nota("cop"),
      "regular=" + nota("regular") + " cop=" + nota("cop"));
  });

  prova("el resum avisa de la feina concentrada", () => {
    assert.ok(/Feina concentrada en pocs dies/.test(d.getElementById("p-resultats").textContent));
  });

  prova("canviar un paràmetre no recalcula tot sol", () => {
    const abans = nota("cop");
    d.getElementById("p-exerc").value = "200";
    d.getElementById("p-exerc").dispatchEvent(new w.Event("input"));
    assert.strictEqual(nota("cop"), abans);
    assert.ok(d.getElementById("p-accepta").className.includes("pendent"));
    d.getElementById("p-accepta").click();
    assert.ok(nota("cop") < abans);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Pèrdua del progrés del navegador");

{
  const { w, d } = obre();
  const T = w.RE_TAULES, ids = T.fulls[4].items;
  const cod = (q, dia) => w.RE_CODI.genera({
    fulls: [{ n: 4, estats: ids.map((_, i) => (i < q ? "net" : "")) }],
    ara: new Date(2026, 9, dia, 18, 0)
  });
  const files = [[20, 12], [27, 28], [30, 40], [31, 6], [48, 13]].map(
    ([dia, q]) => [marca(new Date(2026, 9, dia, 18, 5)), "perdut@e.cat", "1rA", cod(q, dia)]);
  d.getElementById("entrada").value = fabrica(w, files);
  d.getElementById("btn-llegeix").click();
  d.querySelectorAll(".pestanya")[1].click();
  d.getElementById("p-ini").value = "2026-10-01";
  d.getElementById("p-fi").value = "2026-11-30";
  d.getElementById("p-setm").value = "8";
  d.getElementById("p-exerc").value = "40";
  d.getElementById("p-accepta").click();

  prova("no compta dues vegades el que l'alumne refà", () => {
    const c = d.querySelectorAll("#t-progres tbody tr.clic")[0].querySelectorAll("td");
    assert.strictEqual(c[4].textContent.trim().split(" ")[0], "40",
      "hauria de comptar 40 exercicis, no els refets");
  });
  prova("avisa que ha perdut el progrés", () => {
    assert.ok(/Han perdut el progrés del navegador/.test(
      d.getElementById("p-resultats").textContent));
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Codis compartits entre alumnes");

{
  const { w, d } = obre();
  const ara = new Date(2026, 9, 20, 18, 0);
  const compartit = codiDe(w, [4], 25, ara);
  const propi = codiDe(w, [4], 12, ara);
  d.getElementById("entrada").value = fabrica(w, [
    [marca(ara), "anna@e.cat", "1rA", compartit],
    [marca(ara), "bru@e.cat", "1rA", compartit],
    [marca(ara), "cesc@e.cat", "1rB", propi],
    [marca(ara), "cesc@e.cat", "1rB", propi],   /* reenviament propi: no compta */
  ]);
  d.getElementById("btn-llegeix").click();

  prova("marca el codi que apareix sota dos correus", () => {
    assert.strictEqual(d.querySelectorAll("#t-env .marca.compartit").length, 2);
  });

  prova("el reenviament del propi codi NO es marca", () => {
    const files = [...d.querySelectorAll("#t-env tbody tr.clic")];
    const cesc = files.filter(tr => /cesc/.test(tr.textContent));
    assert.strictEqual(cesc.length, 2);
    cesc.forEach(tr => assert.ok(!tr.querySelector(".marca.compartit"),
      "un alumne que reenvia el seu codi no fa res sospitós"));
  });

  prova("el resum diu qui comparteix amb qui", () => {
    const t = d.getElementById("avis-compartits").textContent;
    assert.ok(/anna = bru|bru = anna/.test(t), t.slice(0, 120));
  });

  prova("un codi trencat es marca com a trencat encara que estigui repetit", () => {
    /* La integritat mana sobre l'origen: si el ⇄ tapés el ✗, es perdria la
       marca que de veritat diu que hi ha un problema amb el codi. */
    const { w: w2, d: d2 } = obre();
    const ara2 = new Date(2026, 9, 20, 18, 0);
    const bo = codiDe(w2, [4], 25, ara2);
    const trencat = bo.slice(0, 20) + "X" + bo.slice(21);
    d2.getElementById("entrada").value = fabrica(w2, [
      [marca(ara2), "u@e.cat", "1rA", trencat],
      [marca(ara2), "dos@e.cat", "1rA", trencat],
    ]);
    d2.getElementById("btn-llegeix").click();
    assert.strictEqual(d2.querySelectorAll("#t-env .marca.mal").length, 2);
    assert.strictEqual(d2.querySelectorAll("#t-env .marca.compartit").length, 0);
  });

  prova("el filtre aïlla els codis repetits", () => {
    d.getElementById("f-estat").value = "compartit";
    d.getElementById("f-estat").dispatchEvent(new w.Event("change"));
    assert.strictEqual(d.querySelectorAll("#t-env tr.clic").length, 2);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Honestedat sobre el que el ✓ no verifica");

{
  const { d } = obre();
  const t = d.getElementById("v-ajuda").textContent.replace(/\s+/g, " ");

  prova("l'ajuda diu explícitament què NO verifica", () => {
    assert.ok(/El que NO verifica: qui ha fet la feina/.test(t));
  });

  prova("adverteix dels tres forats coneguts", () => {
    assert.ok(/al navegador d'un altre/.test(t), "falta el forat del navegador compartit");
    assert.ok(/fabrica un codi des de la consola/.test(t), "falta el forat de la consola");
    assert.ok(/amb ajuda al costat/.test(t), "falta el forat de l'ajuda externa");
  });

  prova("no promet garantir l'autoria", () => {
    assert.ok(/no per garantir l'autoria/.test(t));
    assert.ok(/eina de seguiment/.test(t));
  });
}


// ═════════════════════════════════════════════════════════════════════════
// PROVA ESCRITA
// ═════════════════════════════════════════════════════════════════════════

/* Obre la pestanya i hi enganxa un codi. Torna una funció que genera la
   prova i retorna els ids que hi han sortit. */
function provaEscrita(w, d, codi, ajust) {
  d.querySelectorAll(".pestanya").forEach(b => { if (b.dataset.mode === "prova") b.click(); });
  const camp = d.getElementById("pr-codi");
  camp.value = codi;
  camp.dispatchEvent(new w.Event("input"));
  // el camp de codi va amb debounce de 300 ms; les proves no esperen rellotge,
  // així que es força el refresc igual que fa el canvi de llindar.
  if (ajust) ajust(d, w);
  d.getElementById("pr-min-bloc").dispatchEvent(new w.Event("change"));
  d.getElementById("pr-genera").click();
  return idsProva(w, d);
}

/* Els ids no s'escriuen al DOM de l'examen (l'alumne no els ha de veure):
   es recuperen creuant encapçalament + enunciat contra RE_BANC. */
function idsProva(w, d) {
  const index = {};
  Object.keys(w.RE_BANC).forEach(id => {
    const b = w.RE_BANC[id];
    index[(b.encapcalament || "") + "|" + b.enunciat] = id;
  });
  return [...d.querySelectorAll("#pr-examen .pr-preg")].map(p => {
    const cap = p.querySelector(".cap").textContent.replace(/^\s*\d+\.\s*/, "").trim();
    const en = p.querySelector(".enun").textContent;
    return index[cap + "|" + en] || index["|" + en] || "?";
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — només exercicis que l'alumne ha fet de veritat");

{
  /* Aquesta és LA comprovació d'aquesta pestanya, i es fa amb el Full 9 a
     propòsit. El projecte manté dos ordres dels ítems: el de presentació
     (data/fullN.js) i l'append-only del codi (codi-ordre.json). Al Full 9 no
     coincideixen en 42 de 47 posicions, perquè el 170f-170i es van recuperar
     després i van al final de l'ordre de codificació. Qualsevol implementació
     que indexi el banc per POSICIÓ en lloc de per ID passa desapercebuda a
     onze fulls i falla al novè, posant a l'examen exercicis que l'alumne no
     ha vist mai. */
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const estats = T.fulls[9].items.map((_, i) => (i < 14 ? (i % 4 === 0 ? "fallat" : "net") : ""));
  const fets = T.fulls[9].items.slice(0, 14);
  const codi = w.RE_CODI.genera({ fulls: [{ n: 9, estats }] });
  const ids = provaEscrita(w, d, codi, dd => { dd.getElementById("pr-min-bloc").value = "1"; });

  prova("la prova no és buida", () => {
    assert.ok(ids.length > 0, "no s'ha generat cap pregunta");
  });
  prova("cap pregunta és d'un exercici que l'alumne no ha treballat", () => {
    const fora = ids.filter(x => fets.indexOf(x) < 0);
    assert.deepEqual(fora, [], "exercicis que no ha fet mai: " + fora.join(", "));
  });
  prova("cap pregunta s'ha quedat sense identificar", () => {
    assert.equal(ids.filter(x => x === "?").length, 0);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — la mida triada es respecta");

{
  /* Amb un mínim d'una pregunta per bloc, un alumne que ha treballat els dotze
     fulls té 56 blocs admesos i una prova "curta" se n'anava a 56. */
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const fulls = [];
  for (let n = 1; n <= 12; n++) {
    const t = T.fulls[n], e = new Array(t.items.length).fill("");
    t.blocs.forEach(b => b[1].slice(0, 6).forEach(i => { e[i] = "net"; }));
    fulls.push({ n, estats: e });
  }
  const codi = w.RE_CODI.genera({ fulls });
  const ids = provaEscrita(w, d, codi, dd => {
    dd.querySelector('input[name="pr-mida"][value="curta"]').checked = true;
  });

  prova("una prova curta són 2 preguntes encara que hi hagi 56 blocs", () => {
    assert.equal(ids.length, 2, "n'han sortit " + ids.length);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — varietat dins d'un bloc");

{
  /* Un bloc es desglossa en apartats del mateix exercici mare (1a…1f). Agafar
     "els primers per prioritat" donava proves com 1a,1b,1c,1d,1e,1f,2a,2b:
     vuit preguntes, dos problemes. */
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const t = T.fulls[1], e = new Array(t.items.length).fill("");
  t.blocs[0][1].forEach(i => { e[i] = "net"; });
  const codi = w.RE_CODI.genera({ fulls: [{ n: 1, estats: e }] });
  /* La llarga, que ara són 4 preguntes (abans 20): amb la curta, de 2, no
     hi ha prou preguntes perquè la repetició es pugui veure. */
  const ids = provaEscrita(w, d, codi, dd => {
    dd.querySelector('input[name="pr-mida"][value="llarga"]').checked = true;
  });
  const mares = new Set(ids.map(i => i.match(/^\d+/)[0]));

  prova("no s'esgota la prova amb apartats del mateix exercici mare", () => {
    assert.strictEqual(ids.length, 4, "la llarga són 4 preguntes: " + ids.join(", "));
    assert.strictEqual(mares.size, ids.length,
      "es repeteix exercici mare quan encara en quedaven de nous: " + ids.join(", "));
  });

  prova("«torna a triar exercicis» dona una selecció diferent", () => {
    /* Amb ordre estricte per estat la selecció era determinista i el botó no
       feia res. Es prova unes quantes vegades perquè és aleatori. */
    let diferent = false;
    for (let k = 0; k < 8 && !diferent; k++) {
      d.getElementById("pr-regenera").click();
      if (idsProva(w, d).join(",") !== ids.join(",")) diferent = true;
    }
    assert.ok(diferent, "la selecció no canvia mai entre generacions");
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — un codi que no és íntegre no genera res");

{
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const ALF = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
  const e = T.fulls[1].items.map((_, i) => (i < 20 ? "net" : ""));
  const net = w.RE_CODI.genera({ fulls: [{ n: 1, estats: e }] }).replace(/-/g, "");
  const dolent = net.slice(0, 10) + ALF[(ALF.indexOf(net[10]) + 1) % 32] + net.slice(11);

  prova("el codi de prova és realment llegible però no íntegre", () => {
    const r = w.RE_CODI.llegeix(dolent);
    assert.ok(r.ok && !r.integre, "el cas de prova no és el que toca");
  });

  const ids = provaEscrita(w, d, dolent);
  prova("no es compon cap prova", () => {
    assert.equal(ids.length, 0, "s'han generat " + ids.length + " preguntes");
  });
  prova("s'explica per què, en lloc de deixar-ho en blanc", () => {
    assert.ok(/integritat/.test(d.getElementById("pr-estat").textContent));
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — es diu quan la prova surt més curta del que s'ha triat");

{
  const { w, d } = obre();
  const T = w.RE_TAULES;
  /* Dos exercicis fets i la llarga, de 4 preguntes (abans eren 5 i 20). */
  const e = T.fulls[1].items.map((_, i) => (i < 2 ? "net" : ""));
  const codi = w.RE_CODI.genera({ fulls: [{ n: 1, estats: e }] });
  const ids = provaEscrita(w, d, codi, dd => {
    dd.getElementById("pr-min-bloc").value = "1";
    dd.querySelector('input[name="pr-mida"][value="llarga"]').checked = true;
  });

  prova("no s'inventa preguntes que l'alumne no ha treballat", () => {
    assert.ok(ids.length <= 2, "n'han sortit " + ids.length + " amb 2 exercicis fets");
  });
  prova("avisa que se n'han demanat 4 i n'han sortit menys", () => {
    const t = d.getElementById("pr-estat").textContent;
    assert.ok(/4/.test(t) && /no hi ha prou exercicis/.test(t),
      "cap avís: «" + t + "»");
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — l'enunciat s'entén fora del seu full");

{
  /* Uns quants apartats no porten encapçalament perquè el porta el primer
     germà del mateix exercici (ex_text=""). Dins del full es llegeixen
     seguits i no passa res; en una prova on l'exercici surt sol, l'enunciat
     es quedava en "16 cm". El banc l'hereta del germà. */
  const { w } = obre();
  const B = w.RE_BANC;
  prova("cap ítem del banc es queda sense enunciat aprofitable", () => {
    const buits = Object.keys(B).filter(id => {
      const b = B[id];
      return !b.encapcalament && b.enunciat.replace(/\$[^$]*\$/g, "").trim().length < 12
        && !b.figura;
    });
    assert.deepEqual(buits, [], "enunciats incomprensibles sols: " + buits.join(", "));
  });
  prova("el 127b hereta l'encapçalament del 127a", () => {
    assert.equal(B["127b"].encapcalament, B["127a"].encapcalament);
    assert.ok(B["127b"].encapcalament.length > 20);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — el full de correcció no s'imprimeix amb l'examen");

{
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const e = T.fulls[4].items.map((_, i) => (i < 20 ? "net" : ""));
  provaEscrita(w, d, w.RE_CODI.genera({ fulls: [{ n: 4, estats: e }] }));

  prova("són dues seccions separades amb botó d'impressió propi", () => {
    assert.ok(d.getElementById("pr-examen"), "falta la secció de l'examen");
    assert.ok(d.getElementById("pr-correccio"), "falta el full de correcció");
    assert.ok(d.getElementById("pr-imprimeix"));
    assert.ok(d.getElementById("pr-imprimeix-clau"));
  });
  prova("l'examen no porta les respostes", () => {
    assert.ok(!/Resposta:/.test(d.getElementById("pr-examen").textContent));
  });
  prova("el full de correcció sí", () => {
    assert.ok(/Resposta:/.test(d.getElementById("pr-correccio").textContent));
  });
  prova("imprimir l'examen deixa fora la correcció", () => {
    let imprès = false;
    w.print = () => { imprès = true; };
    d.getElementById("pr-imprimeix").click();
    assert.ok(imprès);
    assert.equal(d.body.getAttribute("data-imprimeix"), "examen");
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Prova escrita — les figures de geometria arriben a l'examen");

{
  const { w, d } = obre();
  const T = w.RE_TAULES;
  const e = T.fulls[9].items.map((_, i) => (i < 20 ? "net" : ""));
  provaEscrita(w, d, w.RE_CODI.genera({ fulls: [{ n: 9, estats: e }] }));
  prova("hi ha SVG a la prova generada", () => {
    assert.ok(d.querySelectorAll("#pr-examen .figura svg").length > 0,
      "cap figura ha arribat a l'examen");
  });
}


// ─────────────────────────────────────────────────────────────────────────
seccio("Exàmens: tria de mode i memòria");

/* Deixa la pestanya d'exàmens oberta amb un full de respostes carregat. */
function obreExamens(w, d, tsv) {
  d.getElementById("entrada").value = tsv;
  d.getElementById("btn-llegeix").click();
  Array.prototype.slice.call(d.querySelectorAll(".pestanya"))
    .filter(b => b.dataset.mode === "prova")[0].click();
}

{
  const { w, d } = obre();
  const ara = new Date(2026, 9, 20, 18, 0);
  obreExamens(w, d, fabrica(w, [[marca(ara), "a@x.cat", "4tA",
    codiDe(w, [4], 20, ara)]]));

  prova("en entrar es veu la tria, cap dels dos modes", () => {
    assert.ok(!d.getElementById("pr-tria").hidden);
    assert.ok(d.getElementById("pr-lot").hidden);
    assert.ok(d.getElementById("pr-individual").hidden);
  });

  prova("triant l'estàndard es veu aquest panell i no l'altre", () => {
    d.getElementById("pr-va-lot").click();
    assert.ok(d.getElementById("pr-tria").hidden);
    assert.ok(!d.getElementById("pr-lot").hidden);
    assert.ok(d.getElementById("pr-individual").hidden);
  });

  prova("tornar a la pestanya recorda el mode, no torna a preguntar", () => {
    Array.prototype.slice.call(d.querySelectorAll(".pestanya"))
      .filter(b => b.dataset.mode === "full")[0].click();
    Array.prototype.slice.call(d.querySelectorAll(".pestanya"))
      .filter(b => b.dataset.mode === "prova")[0].click();
    assert.ok(d.getElementById("pr-tria").hidden, "torna a preguntar el mode");
    assert.ok(!d.getElementById("pr-lot").hidden);
  });

  prova("el botó de tornar sí que torna a la tria", () => {
    d.getElementById("pr-torna-1").click();
    assert.ok(!d.getElementById("pr-tria").hidden);
  });

  prova("el mode personalitzat continua sent el d'abans", () => {
    d.getElementById("pr-va-individual").click();
    assert.ok(!d.getElementById("pr-individual").hidden);
    assert.ok(d.getElementById("pr-alumne"), "falta el selector d'alumne");
    assert.ok(d.getElementById("pr-genera"), "falta el botó de generar");
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Exàmens: la taula de la classe");

/* Dos alumnes: un que treballa els tres trams i un que gairebé no fa res a
   l'últim, que és el que ha de sortir avisat. */
function classeDeProva(w) {
  const INICI = new Date(2026, 8, 14);
  const dia = n => {
    const d = new Date(INICI.getTime() + n * 86400000);
    d.setHours(18, 0, 0, 0);
    return d;
  };
  const f = [];
  [[19, 12], [40, 24], [61, 36]].forEach(([n, q]) => {
    f.push([marca(dia(n)), "prou@x.cat", "4tA", codiDe(w, [4], q, dia(n))]);
  });
  [[19, 12], [40, 24], [61, 26]].forEach(([n, q]) => {
    f.push([marca(dia(n)), "just@x.cat", "4tA", codiDe(w, [4], q, dia(n))]);
  });
  return fabrica(w, f);
}

{
  const { w, d } = obre();
  obreExamens(w, d, classeDeProva(w));
  d.getElementById("pr-va-lot").click();
  /* Els trams ja no surten d'una data d'inici que es teclejava (`#lot-inici`,
     que va desaparèixer quan el calendari es va passar a `js/calendari.js`):
     obrir la pestanya ja omple el desplegable amb els nou trams del curs.
     Les dates de `classeDeProva()` cauen exactament als trams 0, 1 i 2, i
     aquí s'examina del tercer. */
  const trams = d.getElementById("lot-periode");
  assert.ok(trams.options.length >= 3,
    "el desplegable de trams no s'ha omplert en obrir la pestanya");
  trams.value = "2";
  d.getElementById("lot-genera").click();

  const files = () => Array.prototype.slice.call(
    d.querySelectorAll("#lot-taula tbody tr"));

  prova("hi ha una fila per alumne", () => {
    assert.strictEqual(files().length, 2, d.getElementById("lot-taula").textContent);
  });

  prova("la columna del tram mostra els exercicis nous d'aquell tram", () => {
    const tr = files().filter(r => /prou/.test(r.textContent))[0];
    assert.ok(/^12\b/.test(tr.children[2].textContent.trim()),
      tr.children[2].textContent);
  });

  prova("qui no arriba al mínim surt marcat amb «sota»", () => {
    const tr = files().filter(r => /just/.test(r.textContent))[0];
    assert.ok(/sota/.test(tr.children[2].textContent), tr.children[2].textContent);
  });

  prova("qui hi arriba no surt marcat", () => {
    const tr = files().filter(r => /prou/.test(r.textContent))[0];
    assert.ok(!/sota/.test(tr.children[2].textContent), tr.children[2].textContent);
  });

  prova("tot i l'avís, l'examen es genera igualment", () => {
    const caps = Array.prototype.slice.call(
      d.querySelectorAll("#pr-examen .pr-alumne"));
    assert.strictEqual(caps.length, 2, "esperava dos exàmens");
  });

  prova("l'avís surt al full de correcció...", () => {
    assert.ok(/mínim/.test(d.getElementById("pr-correccio").textContent),
      "el motiu no consta a la correcció");
  });

  prova("...i mai a l'examen de l'alumne", () => {
    assert.ok(!/mínim/.test(d.getElementById("pr-examen").textContent),
      "l'avís s'ha colat a l'examen que rep l'alumne");
  });

  prova("clicar una fila la marca i ofereix imprimir-la sola", () => {
    files()[0].click();
    assert.ok(files()[0].classList.contains("tria"));
    assert.ok(d.getElementById("lot-un-ex"), "falta el botó d'imprimir-ne un");
  });

  prova("cada full sap de quin alumne és", () => {
    const amb = Array.prototype.slice.call(
      d.querySelectorAll("#pr-examen .pr-alumne[data-alumne]"));
    assert.strictEqual(amb.length, 2);
  });
}


// ─────────────────────────────────────────────────────────────────────────
seccio("Exàmens: ningú no desapareix en silenci");

{
  const { w, d } = obre();
  const INICI = new Date(2026, 8, 14);
  const dia = n => { const x = new Date(INICI.getTime() + n * 86400000);
    x.setHours(18, 0, 0, 0); return x; };
  const bo = codiDe(w, [4], 20, dia(61));
  const trencat = bo.slice(0, 12) + (bo[12] === "X" ? "Y" : "X") + bo.slice(13);
  obreExamens(w, d, fabrica(w, [
    [marca(dia(19)), "sana@x.cat", "4tA", codiDe(w, [4], 12, dia(19))],
    [marca(dia(61)), "sana@x.cat", "4tA", bo],
    [marca(dia(61)), "rota@x.cat", "4tA", trencat]
  ]));
  d.getElementById("pr-va-lot").click();
  d.getElementById("lot-periode").value = "2";
  d.getElementById("lot-genera").click();
  const text = d.getElementById("lot-taula")
    ? d.getElementById("lot-taula").textContent : "";

  prova("l'alumne amb el codi il·legible surt a la taula", () => {
    assert.ok(/rota/.test(text),
      "ha desaparegut de la llista sense dir res: " + text);
  });

  prova("i se'n diu el motiu", () => {
    const tot = d.getElementById("lot-resum").textContent;
    /* En singular quan només n'hi ha un: «1 enviament seu no s'ha pogut
       llegir». */
    assert.ok(/no s'ha(n)? pogut llegir/.test(tot), tot.slice(0, 300));
  });

  prova("l'alumne amb codis bons no en queda afectat", () => {
    assert.ok(/sana/.test(text));
    assert.ok(d.querySelectorAll("#pr-examen .pr-alumne").length >= 1);
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("Exàmens: només el tram examinat, els 20 últims i la nota de feina");

/* Abans hi havia una secció que vigilava els pesos 3-2-1 entre trams. Els
   pesos ja no existeixen: l'examen d'un tram surt només de la feina d'aquell
   tram, per data exacta del primer intent (codis RC4). */
{
  const { w, d } = obre();
  const T = w.RE_TAULES, L = w.RE_CALENDARI.llista();
  const dia = (t, k) => { const x = new Date(L[t].inici.getTime() + k * 86400000); x.setHours(18, 0, 0, 0); return x; };
  const ids = T.fulls[4].items;
  /* 12 exercicis al tram 1 i 25 al tram 2, tots amb data i en ordre. Dels 25,
     els 5 primers són a la primera i els 20 últims al segon intent: així la
     nota diu QUINS 20 s'han comptat i amb quins valors, i no només quants. */
  const estats = ids.map((_, i) => (i < 17 ? "net" : (i < 37 ? "segon" : "")));
  const dates = ids.map((_, i) => (i < 12 ? dia(0, i).getTime() : (i < 37 ? dia(1, Math.floor((i - 12) * 18 / 25)).getTime() + i : 0)));
  const codi = w.RE_CODI.genera({ fulls: [{ n: 4, estats, dates }], ara: dia(1, 20) });
  obreExamens(w, d, fabrica(w, [[marca(dia(1, 20)), "tot@x.cat", "4tA", codi]]));
  d.getElementById("pr-va-lot").click();
  d.getElementById("lot-periode").value = "1";
  d.getElementById("lot-genera").click();
  const fila = d.querySelector("#lot-taula tbody tr");

  prova("compta els 25 del tram i diu que només en compten els 20 últims", () => {
    assert.ok(/^25\b/.test(fila.children[2].textContent.trim()), fila.children[2].textContent);
    assert.ok(/20 últims/.test(fila.children[2].textContent), fila.children[2].textContent);
    /* La columna «Com» pinta un punt per exercici comptat, amb l'id al títol:
       han de ser exactament els 20 més recents del tram, i en ordre. */
    const comptats = Array.prototype.slice.call(fila.children[3].querySelectorAll(".pt"))
      .map(p => p.getAttribute("title").split(" · ")[0]);
    /* Es comparen com a text: `ids` ve del window de jsdom, i una llista
       d'un altre realm no és mai deepStrictEqual a una d'aquest. */
    assert.strictEqual(comptats.join(" "), ids.slice(17, 37).join(" "));
  });
  prova("la nota surt dels 20 últims i dels valors per defecte (10 · 9,5 · 8,5 · 7,5)", () => {
    assert.strictEqual(d.getElementById("lot-v-pista").value, "9,5");
    assert.strictEqual(d.getElementById("lot-v-pistes").value, "8,5");
    assert.strictEqual(d.getElementById("lot-v-segon").value, "7,5");
    /* 20 segons intents a 0,75: x = 15 i 8·∛1,5 = 9,16. Amb els 20 primers
       (5 nets i 15 segons intents) sortiria un 9,4; amb el segon intent a 7,
       un 8,9. */
    assert.strictEqual(fila.children[4].textContent.trim(), "9,2");
  });
  const idsExamen = idsProva(w, d);
  prova("cap pregunta és del tram anterior ni de fora dels 20 últims", () => {
    const permesos = new Set(ids.slice(17, 37));
    assert.ok(idsExamen.length === 3, "la mida per defecte (mitjana) són 3: " + idsExamen.join(","));
    assert.ok(idsExamen.every(id => permesos.has(id)), idsExamen.join(","));
  });
  prova("hi ha un botó per baixar les notes", () => {
    assert.ok(d.getElementById("lot-csv"));
  });
  prova("els pesos entre trams ja no hi són", () => {
    assert.ok(!d.getElementById("lot-pesos"));
  });
}

// ─────────────────────────────────────────────────────────────────────────
seccio("El full de respostes no pot injectar res a la pàgina");

/* El `grup` i el nom surten d'un formulari que omple l'alumne. Si entren en
   un `innerHTML` sense escapar, l'alumne executa codi dins de la pàgina que
   porta el banc, tots els codis de la classe i les notes que s'estan posant.
   No hauria de caldre robar res: bastaria repintar la taula de notes.

   Aquestes proves són de forma, no de comportament: comproven que el text
   hostil arribi al DOM com a TEXT i no com a etiqueta. */
{
  const { w, d } = obre();
  const ara = new Date(2026, 9, 20, 18, 0);
  const HOSTIL = '<img src=x onerror="window.TOCAT=1">';
  d.getElementById("entrada").value = fabrica(w, [
    [marca(ara), "mar@ins.cat", HOSTIL, codiDe(w, [1], 12, ara)],
    [marca(ara), '"><script>window.TOCAT=2<\/script>', "4A", codiDe(w, [2], 8, ara)],
  ]);
  d.getElementById("btn-llegeix").click();

  prova("un nom o grup amb HTML no executa res", () => {
    assert.strictEqual(w.TOCAT, undefined);
    assert.strictEqual(d.querySelectorAll('img[src="x"]').length, 0);
  });

  prova("el text hostil es veu tal qual, com a text", () => {
    /* No es compara literalment amb HOSTIL: el lector de CSV consumeix les
       cometes del camp (RFC-4180), així que el valor desat no és idèntic al
       que s'ha enganxat. El que importa és que l'etiqueta arribi al DOM com
       a TEXT, i es vegi. */
    const t = d.body.textContent;
    assert.ok(t.indexOf("img src=x") >= 0,
      "el grup hostil hauria de sortir escrit a la taula, com a text");
  });

  prova("cap <script> del full de respostes arriba al DOM", () => {
    const dolents = Array.prototype.filter.call(
      d.querySelectorAll("script"), s => /window\.TOCAT/.test(s.textContent));
    assert.strictEqual(dolents.length, 0);
  });

  prova("escapa() també serveix dins d'un atribut", () => {
    /* Viu dins de la IIFE de la pàgina, així que s'extreu del fitxer. Només
       amb & i < n'hi hauria prou per al text, però escapa() s'usa a
       `data-alumne="..."`, i allà una cometa doble se n'escapa. */
    const m = HTML.match(/function escapa\(s\)\s*\{[\s\S]*?\n  \}/);
    assert.ok(m, "no s'ha trobat escapa() al fitxer");
    const e = new Function(m[0] + "; return escapa;")();
    assert.strictEqual(e('a"b'), "a&quot;b");
    assert.strictEqual(e("a'b"), "a&#39;b");
    assert.strictEqual(e("<b>&"), "&lt;b&gt;&amp;");
  });
}


process.exit(resum() ? 0 : 1);
