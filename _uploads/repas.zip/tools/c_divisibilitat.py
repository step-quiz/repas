# -*- coding: utf-8 -*-
"""Bloc B — Divisibilitat: descomposició, m.c.d. i m.c.m.
Exercicis 5–17 del Full 1 (26 ítems)."""

from datetime import date, timedelta
from lib import Q, D, tria, mcd, mcm, tex_factors, fx, factors, dificultats

# --------------------------------------------------------------------
# Dificultat de cada exercici (1 trivial, 2 directa, 3 encadenada,
# 4 completa). Vegeu l'escala completa i la frontera entre nivells
# a lib.py.
# Full 1 · divisibilitat
# Vegeu l'escala completa a lib.py. L'itinerari fa servir aquest camp
# per graduar el recorregut, de manera que canviar-hi un número canvia
# l'ordre en què l'alumne es troba els exercicis.
# --------------------------------------------------------------------
dificultats({
      5: 2,  # descomposició factorial directa
      6: 2,  # m.c.d. de dos nombres; 7, de tres (mateix procediment)
      7: 2,
      8: 3,  # a l'inrevés: donat el m.c.d., quin nombre encaixa
      9: 2,  # m.c.m., igual que el m.c.d. però amb l'altre criteri
     10: 2,
     11: 3,  # a l'inrevés amb dues condicions alhora
     12: 4,  # problemes amb context: primer cal decidir si toca m.c.d. o m.c.m.
     13: 4,
     14: 4,
     15: 4,
     16: 4,
     17: 4,
})


B = "divisibilitat"

# ---------------------------------------------------------------- generadors

def _llista(ns):
    return ", ".join(("$%d$" % n) for n in ns)


def _pistes_generiques(ns, regla):
    """Pistes per defecte dels ítems de m.c.d. i m.c.m. La primera diu amb
    quins nombres es treballa (el signe no hi compta) i la segona dona les
    descomposicions de l'apartat i la regla, de manera que només queda
    triar els factors."""
    negatius = any(n < 0 for n in ns)
    p1 = "Descompon cada nombre en factors primers."
    if negatius:
        vals = ["$%d$" % abs(n) for n in ns]
        p1 += (" El signe no hi compta: treballa amb %s i %s."
               % (", ".join(vals[:-1]), vals[-1]))
    desc = ", ".join("$%d=%s$" % (abs(n), tex_factors(n, sign=False))
                     for n in ns)
    return [p1, "%s. %s" % (desc, regla)]


def item_mcd(qid, ex, ap, ns, ex_text, enunciat, pistes=None):
    """Ítem de m.c.d. amb distractors del catàleg d'errors habituals.

    `pistes` substitueix les genèriques. Als problemes cal: allà la
    dificultat és decidir si es busca un divisor o un múltiple, i la pista
    genèrica («agafa els factors comuns») se la salta."""
    c = mcd(*ns)
    m = mcm(*ns)
    prod = 1
    for n in ns:
        prod *= abs(n)
    comuns = set(p for p, _ in factors(ns[0]))
    for n in ns[1:]:
        comuns &= set(p for p, _ in factors(n))
    radical = 1
    for p in sorted(comuns):
        radical *= p
    cands = [
        D(m, "MCM_EN_LLOC_DE_MCD",
          "Això és el m.c.m., el múltiple més petit. El m.c.d. és un divisor: "
          "ha de ser més petit o igual que tots els nombres."),
        D(radical, "EXPONENT_MINIM",
          "Has agafat els factors comuns però amb exponent $1$. Cal agafar-los "
          "elevats al MENOR exponent amb què apareixen, que aquí no és $1$."),
        D(prod, "PRODUCTE",
          "Has multiplicat els nombres. El m.c.d. és el divisor comú més gran, "
          "no el producte."),
        D(min(abs(n) for n in ns), "EL_MES_PETIT",
          "El més petit dels nombres només és el m.c.d. si divideix tots els altres."),
        D(max(abs(n) for n in ns), "EL_MES_GRAN",
          "El m.c.d. ha de dividir tots els nombres: no pot ser el més gran de tots."),
    ]
    desc = " · ".join("$%d = %s$" % (abs(n), tex_factors(n, sign=False)) for n in ns)
    Q(qid, ex, ap, B, tipus="A", enunciat=enunciat, correcta=c, distractors=tria(c, cands),
      pistes=pistes or _pistes_generiques(
          ns, "Agafa NOMÉS els factors comuns, elevats al menor exponent."),
      resolucio=["Descomposicions: " + desc,
       "Factors comuns amb el menor exponent: $\\operatorname{m.c.d.} = %s$" % (
           tex_factors(c, sign=False) if c > 1 else "1"),
       "$\\operatorname{m.c.d.} = %d$" % c],
      ex_text=ex_text,
      nota=("El signe no afecta el m.c.d.: es treballa amb els valors "
            "absoluts.") if any(n < 0 for n in ns) else "")


def item_mcm(qid, ex, ap, ns, ex_text, enunciat, pistes=None):
    c = mcm(*ns)
    d = mcd(*ns)
    prod = 1
    for n in ns:
        prod *= abs(n)
    cands = [
        D(d, "MCD_EN_LLOC_DE_MCM",
          "Això és el m.c.d., el divisor comú més gran. El m.c.m. és un múltiple: "
          "ha de ser més gran o igual que tots els nombres."),
        D(prod, "PRODUCTE",
          "Multiplicar-los sempre dóna un múltiple comú, però no el més petit "
          "(només coincideix si el m.c.d. és $1$)."),
        D(max(abs(n) for n in ns), "EL_MES_GRAN",
          "El més gran només és el m.c.m. si és múltiple de tots els altres."),
        D(sum(abs(n) for n in ns), "SUMA",
          "Has sumat els nombres; el m.c.m. no té res a veure amb la suma."),
        D(min(abs(n) for n in ns), "EL_MES_PETIT",
          "El m.c.m. ha de ser múltiple de tots: no pot ser més petit que cap d'ells."),
    ]
    desc = " · ".join("$%d = %s$" % (abs(n), tex_factors(n, sign=False)) for n in ns)
    Q(qid, ex, ap, B, tipus="A", enunciat=enunciat, correcta=c, distractors=tria(c, cands),
      pistes=pistes or _pistes_generiques(
          ns, "Agafa TOTS els factors, comuns i no comuns, elevats al major "
              "exponent."),
      resolucio=["Descomposicions: " + desc,
       "Tots els factors amb el major exponent: $\\operatorname{m.c.m.} = %s$"
       % tex_factors(c, sign=False),
       "$\\operatorname{m.c.m.} = %d$" % c],
      ex_text=ex_text,
      nota=("El signe no afecta el m.c.m.: es treballa amb els valors "
            "absoluts.") if any(n < 0 for n in ns) else "")


# ================================================================ Exercici 5
E5 = "Fes la descomposició factorial de:"

_p1, _v1 = fx((2, 1), (5, 2), (7, 1), (11, 1))
assert _v1 == 3850
_d1a, _ = fx((2, 1), (5, 1), (7, 1), (11, 1))
_d1b, _ = fx((2, 2), (5, 2), (7, 1), (11, 1))
Q("5a", 5, "a", B, tipus="A", enunciat=r"$3850$", correcta=_p1,
  distractors=[D(_d1a, "EXPONENT_OBLIDAT",
     r"Falta un $5$: $3850$ es divideix dues vegades entre $5$, no una. "
     r"Comprova-ho multiplicant."),
   D(r"2\cdot 5^{2}\cdot 77", "FACTOR_NO_PRIMER",
     r"$77$ no és primer: $77 = 7\cdot 11$. La descomposició ha d'arribar a primers."),
   D(_d1b, "EXPONENT_EXCES",
     r"$3850$ només és parell una vegada: després de dividir entre $2$ queda $1925$, imparell.")],
  pistes=["Divideix successivament pels primers més petits: $2$, $3$, $5$, $7$, $11$…",
   "$3850 : 2 = 1925$, i $1925$ acaba en $5$."],
  resolucio=[r"$3850 = 2\cdot 1925$", r"$1925 = 5\cdot 385 = 5\cdot 5\cdot 77$",
   r"$77 = 7\cdot 11$", r"$3850 = 2\cdot 5^{2}\cdot 7\cdot 11$"],
  ex_text=E5)

_p2, _v2 = fx((2, 4), (3, 3))
assert _v2 == 432
_d2b, _ = fx((2, 3), (3, 4))
Q("5b", 5, "b", B, tipus="A", enunciat=r"$-432$", correcta="-" + _p2,
  distractors=[D(_p2, "SIGNE_PERDUT",
     "El nombre és negatiu: la descomposició ha de dur el signe $-$ al davant, "
     "perquè cap factor primer és negatiu."),
   D("-" + _d2b, "EXPONENTS_INTERCANVIATS",
     r"Has intercanviat els exponents: $2^{3}\cdot 3^{4} = 648$, no $432$."),
   D(r"-2^{4}\cdot 9", "FACTOR_NO_PRIMER",
     r"$9$ no és primer: $9 = 3^{2}$. I a més en falta un: $432 = 2^{4}\cdot 3^{3}$.")],
  pistes=["Treu primer el signe i descompon $432$.",
   "$432 : 2 = 216 : 2 = 108 : 2 = 54 : 2 = 27$."],
  resolucio=[r"$432 = 2^{4}\cdot 27$", r"$27 = 3^{3}$",
   r"$-432 = -2^{4}\cdot 3^{3}$"],
  ex_text=E5)

_p3, _v3 = fx((3, 1), (11, 1), (17, 1))
assert _v3 == 561
Q("5c", 5, "c", B, tipus="A", enunciat=r"$-561$", correcta="-" + _p3,
  distractors=[D(_p3, "SIGNE_PERDUT",
     "El nombre és negatiu: cal escriure el signe $-$ davant de la descomposició."),
   D(r"-3\cdot 187", "FACTOR_NO_PRIMER",
     r"$187$ no és primer: $187 = 11\cdot 17$."),
   D(r"-3\cdot 11\cdot 19", "PRIMER_INCORRECTE",
     r"$3\cdot 11\cdot 19 = 627$, no $561$. Comprova sempre multiplicant.")],
  pistes=["$561$ no és parell; prova amb el $3$ (suma de xifres $5+6+1=12$).",
   "$561 : 3 = 187$, i $187$ es divideix entre $11$."],
  resolucio=[r"$561 = 3\cdot 187$", r"$187 = 11\cdot 17$",
   r"$-561 = -3\cdot 11\cdot 17$"],
  ex_text=E5)

# ============================================================== Exercicis 6-7
E6 = "Calcula el màxim comú divisor de cada parell de nombres."
item_mcd("6a", 6, "a", [45, -27], E6, r"$45$ i $-27$")
item_mcd("6b", 6, "b", [-28, 21], E6, r"$-28$ i $21$")
item_mcd("6c", 6, "c", [-18, 12], E6, r"$-18$ i $12$")

E7 = "Troba el màxim comú divisor."
item_mcd("7a", 7, "a", [6, -8, 12], E7, r"$6$, $-8$, $12$")
item_mcd("7b", 7, "b", [16, 20, -28], E7, r"$16$, $20$, $-28$")
item_mcd("7c", 7, "c", [40, -10, 25], E7, r"$40$, $-10$, $25$")

# ================================================================ Exercici 8
assert mcd(18, 12) == 6 and mcd(12, 12) == 12 and mcd(24, 12) == 12 and mcd(9, 12) == 3
Q("8", 8, "", B, tipus="B",
  enunciat=r"Si $\operatorname{m.c.d.}(x, 12) = 6$, quin d'aquests valors pot tenir $x$?",
  correcta="18",
  distractors=[D("12", "MULTIPLE_MASSA_GRAN",
     r"Amb $x=12$: $\operatorname{m.c.d.}(12,12) = 12$, no $6$."),
   D("24", "MULTIPLE_MASSA_GRAN",
     r"Amb $x=24$: com que $24$ és múltiple de $12$, el m.c.d. és $12$."),
   D("9", "NO_MULTIPLE_DE_6",
     r"Amb $x=9$: $\operatorname{m.c.d.}(9,12) = 3$. Perquè doni $6$, $x$ ha de ser múltiple de $6$.")],
  pistes=[r"$x$ ha de ser múltiple de $6$ (si no, el $6$ no el divideix).",
   r"Però $x$ no pot ser múltiple de $12$: llavors el m.c.d. seria $12$."],
  resolucio=[r"$12 = 2^{2}\cdot 3$ i cal que el m.c.d. sigui $6 = 2\cdot 3$.",
   r"$x$ ha de tenir el factor $2$ i el factor $3$, però NO $2^{2}$.",
   r"Serveixen $x = 6, 18, 30, 42\dots$ (múltiples de $6$ que no ho són de $12$). "
   r"Amb $x = 18$: $\operatorname{m.c.d.}(18,12) = 6$."],
  ex_text="Divisibilitat: condicions sobre el m.c.d.",
  nota="Hi ha infinites solucions; l'exercici en demana una de vàlida.")

# ============================================================= Exercicis 9-10
E9 = "Calcula el mínim comú múltiple."
item_mcm("9a", 9, "a", [-12, 18], E9, r"$-12$ i $18$")
item_mcm("9b", 9, "b", [15, -45], E9, r"$15$ i $-45$")
item_mcm("9c", 9, "c", [27, -18], E9, r"$27$ i $-18$")
item_mcm("9d", 9, "d", [-42, 14], E9, r"$-42$ i $14$")

E10 = "Busca el mínim comú múltiple dels nombres següents."
item_mcm("10a", 10, "a", [12, -9, 10], E10, r"$12$, $-9$, $10$")
item_mcm("10b", 10, "b", [-4, 18, 27], E10, r"$-4$, $18$, $27$")
item_mcm("10c", 10, "c", [-8, 30, 24], E10, r"$-8$, $30$, $24$")
item_mcm("10d", 10, "d", [5, -10, 25], E10, r"$5$, $-10$, $25$")

# =============================================================== Exercici 11
assert (mcd(12, 18), mcm(12, 18)) == (6, 36)
assert (mcd(6, 12), mcm(6, 12)) == (6, 12)
assert mcd(18, 36) == 18
assert (mcd(6, 30), mcm(6, 30)) == (6, 30)
Q("11", 11, "", B, tipus="B",
  enunciat=r"Quin d'aquests parells de nombres té $\operatorname{m.c.d.} = 6$ i "
  r"$\operatorname{m.c.m.} = 36$?",
  correcta=r"$12$ i $18$",
  distractors=[D(r"$6$ i $12$", "MCM_INCORRECTE",
     r"El m.c.d. sí que és $6$, però el m.c.m. és $12$, no $36$."),
   D(r"$18$ i $36$", "MCD_INCORRECTE",
     r"El m.c.m. sí que és $36$, però el m.c.d. és $18$, no $6$."),
   D(r"$6$ i $30$", "CAP_DELS_DOS",
     r"El m.c.d. és $6$, però el m.c.m. és $30$: el $30$ no és múltiple de… "
     r"revisa que el m.c.m. ha de contenir $2^{2}\cdot 3^{2}$.")],
  pistes=[r"Es compleix sempre que $\operatorname{m.c.d.}\cdot\operatorname{m.c.m.} = a\cdot b$.",
   r"Aquí $6\cdot 36 = 216$, o sigui que el producte dels dos nombres ha de ser $216$."],
  resolucio=[r"$\operatorname{m.c.d.}(a,b)\cdot \operatorname{m.c.m.}(a,b) = a\cdot b = 6\cdot 36 = 216$",
   r"$12\cdot 18 = 216$ \quad i \quad $\operatorname{m.c.d.}(12,18) = 6$, "
   r"$\operatorname{m.c.m.}(12,18) = 36$",
   r"També serveix el parell $6$ i $36$."],
  ex_text=r"Troba dos nombres amb $\operatorname{m.c.d.} = 6$ i $\operatorname{m.c.m.} = 36$.",
  # La nota no pot dir quines són les parelles: abans hi deia «12 i 18», que
  # és la resposta. Que n'hi ha més d'una sí que cal dir-ho.
  nota="Hi ha més d'una parella que ho compleix, però entre les opcions "
       "només n'hi ha una.")

# =============================================================== Exercici 12
E12 = "Resol aquests problemes."
item_mcd("12a", 12, "a", [4, 6, 9], E12,
         r"Volem tallar tres cordes de $4$, $6$ i $9$ m en trossos iguals. "
         r"Quina és la longitud, en metres, dels trossos més grans que es poden fer?",
         pistes=[r"Els trossos han de cabre un nombre exacte de vegades a cada "
                 r"corda: la seva longitud ha de DIVIDIR $4$, $6$ i $9$. El més "
                 r"gran possible és el m.c.d.",
                 r"$4=2^2$, $6=2\cdot3$ i $9=3^2$: hi ha cap factor primer que "
                 r"surti als tres alhora? Recorda que l'$1$ divideix qualsevol "
                 r"nombre."])
item_mcm("12b", 12, "b", [4, 6, 9], E12,
         r"Els llibres d'una prestatgeria es poden col·locar en piles de $4$, $6$ i $9$ "
         r"llibres sense que en sobri cap. Quina és la quantitat més petita de llibres "
         r"que hi pot haver?",
         pistes=[r"El nombre de llibres s'ha de poder repartir en piles de $4$, "
                 r"de $6$ i de $9$ sense que en sobri cap: ha de ser MÚLTIPLE "
                 r"dels tres alhora. El més petit és el m.c.m.",
                 r"$4=2^2$, $6=2\cdot3$ i $9=3^2$: agafa cada factor primer que "
                 r"hi surti, amb l'exponent més gran."])

# =============================================================== Exercici 13
_c13 = mcd(432, 128)
assert _c13 == 16 and (432 // 16) * (128 // 16) == 216
assert (432 // 8) * (128 // 8) == 864
assert (432 // 4) * (128 // 4) == 3456
Q("13", 13, "", B, tipus="A",
  enunciat=r"El passadís fa $432$ cm de llarg i $128$ cm d'ample. Hi volem posar rajoles "
  r"quadrades de la mida més gran possible, sense haver-ne de tallar cap. "
  r"Quina mida tenen i quantes en calen?",
  correcta=r"$16$ cm de costat; $216$ rajoles",
  distractors=[D(r"$8$ cm de costat; $864$ rajoles", "DIVISOR_NO_MAXIM",
     r"$8$ divideix els dos costats, però no és el divisor comú MÉS GRAN: el $16$ també hi cap."),
   D(r"$16$ cm de costat; $27$ rajoles", "NOMES_UNA_DIMENSIO",
     r"$27$ és el nombre de rajoles del llarg. Cal multiplicar-lo per les $8$ files de l'ample."),
   D(r"$4$ cm de costat; $3456$ rajoles", "DIVISOR_NO_MAXIM",
     r"$4$ és divisor comú, però n'hi ha de més grans: el màxim és $16$.")],
  pistes=[r"La mida de la rajola ha de dividir exactament els dos costats: busca el m.c.d.",
   r"$432 = 2^{4}\cdot 3^{3}$ i $128 = 2^{7}$."],
  resolucio=[r"$\operatorname{m.c.d.}(432,128) = 2^{4} = 16$ cm de costat",
   r"Al llarg: $432:16 = 27$ rajoles. A l'ample: $128:16 = 8$ rajoles.",
   r"$27\cdot 8 = 216$ rajoles"],
  ex_text="Problema d'aplicació del m.c.d.")

# =============================================================== Exercici 14
assert mcm(8, 9, 12) == 72
Q("14", 14, "", B, tipus="A",
  enunciat=r"L'Àlex té aproximadament $150$ fotografies. Les pot enganxar en grups de $8$, "
  r"de $9$ o de $12$ sense que li'n sobri cap. Quantes fotografies té?",
  correcta="144",
  distractors=[D("72", "PRIMER_MULTIPLE",
     r"$72$ és el m.c.m., però l'enunciat diu «aproximadament $150$»: cal el múltiple "
     r"de $72$ més proper a $150$."),
   D("216", "MULTIPLE_LLUNYA",
     r"$216$ també serveix com a múltiple comú, però $144$ és molt més a prop de $150$."),
   D("150", "LITERAL",
     r"$150$ no és múltiple de $8$ ni de $9$ ni de $12$: l'enunciat diu «aproximadament».")],
  pistes=[r"El nombre ha de ser múltiple de $8$, de $9$ i de $12$ alhora.",
   r"Calcula el m.c.m. i després busca'n el múltiple més proper a $150$."],
  resolucio=[r"$8 = 2^{3}$, $9 = 3^{2}$, $12 = 2^{2}\cdot 3$",
   r"$\operatorname{m.c.m.} = 2^{3}\cdot 3^{2} = 72$",
   r"Múltiples de $72$: $72$, $144$, $216$… El més proper a $150$ és $144$."],
  ex_text="Problema d'aplicació del m.c.m.")

# =============================================================== Exercici 15
assert mcm(30, 18) == 90
Q("15", 15, "", B, tipus="A",
  enunciat=r"Per una via passa un tren cap a Girona cada $30$ minuts i un altre cap a València "
  r"cada $18$ minuts. Si s'han creuat a les $10{:}00$, a quina hora es tornaran a creuar?",
  correcta=r"$11{:}30$",
  distractors=[D(r"$10{:}06$", "MCD_EN_LLOC_DE_MCM",
     r"$6$ minuts és el m.c.d. Cal el primer instant que és múltiple dels dos períodes: el m.c.m."),
   D(r"$10{:}48$", "SUMA",
     r"Has sumat $30+18$. Els dos trens no se sincronitzen sumant els períodes."),
   D(r"$19{:}00$", "PRODUCTE",
     r"$30\cdot 18 = 540$ min sí que és un múltiple comú, però no el més petit.")],
  pistes=[r"Busca cada quants minuts coincideixen: ha de ser múltiple de $30$ i de $18$.",
   r"$\operatorname{m.c.m.}(30,18) = 90$ minuts."],
  resolucio=[r"$30 = 2\cdot 3\cdot 5$ i $18 = 2\cdot 3^{2}$",
   r"$\operatorname{m.c.m.} = 2\cdot 3^{2}\cdot 5 = 90$ minuts $= 1$ h $30$ min",
   r"$10{:}00 + 1$ h $30$ min $= 11{:}30$"],
  ex_text="Problema d'aplicació del m.c.m.")

# =============================================================== Exercici 16
_d0 = date(2025, 10, 2)
_ok = _d0 + timedelta(days=mcm(15, 20))
_x1 = _d0 + timedelta(days=mcd(15, 20))
_x2 = _d0 + timedelta(days=35)
_x3 = _d0 + timedelta(days=300)
_MESOS = ["gener", "febrer", "març", "abril", "maig", "juny", "juliol",
          "agost", "setembre", "octubre", "novembre", "desembre"]
_fmt = lambda d: "%d d'%s" % (d.day, _MESOS[d.month - 1]) \
    if _MESOS[d.month - 1][0] in "aeiou" else "%d de %s" % (d.day, _MESOS[d.month - 1])
assert mcm(15, 20) == 60 and _fmt(_ok) == "1 de desembre"
Q("16", 16, "", B, tipus="A",
  enunciat=r"En Lluís viatja a Barcelona cada $15$ dies i la seva germana Marta cada $20$ dies. "
  r"Si l'última vegada que hi van coincidir va ser el $2$ d'octubre, quin dia hi "
  r"tornaran a coincidir?",
  correcta=_fmt(_ok),
  distractors=[D(_fmt(_x1), "MCD_EN_LLOC_DE_MCM",
     r"$5$ dies és el m.c.d. La coincidència arriba al cap d'un múltiple comú de $15$ i $20$."),
   D(_fmt(_x2), "SUMA",
     r"Has sumat $15+20 = 35$ dies, però $35$ no és múltiple de $20$."),
   D(_fmt(_x3), "PRODUCTE",
     r"$15\cdot 20 = 300$ dies és múltiple comú, però no el més petit.")],
  pistes=[r"Han de passar un nombre de dies que sigui múltiple de $15$ i de $20$.",
   r"$\operatorname{m.c.m.}(15,20) = 60$ dies."],
  resolucio=[r"$15 = 3\cdot 5$ i $20 = 2^{2}\cdot 5$",
   r"$\operatorname{m.c.m.} = 2^{2}\cdot 3\cdot 5 = 60$ dies",
   r"$60$ dies després del $2$ d'octubre: $29$ dies fins al $31$ d'octubre, "
   r"$30$ més fins al $30$ de novembre i $1$ més $\rightarrow$ l'1 de desembre."],
  ex_text="Problema d'aplicació del m.c.m.")

# =============================================================== Exercici 17
item_mcm("17", 17, "", [12, 18],
         "Problema d'aplicació del m.c.m.",
         r"En una carretera hi ha fanals cada $12$ m en un lateral i cada $18$ m a "
         r"l'altre. El primer fanal de cada lateral està a la mateixa altura. Quants "
         r"metres cal recórrer per trobar dos fanals l'un davant de l'altre?",
         pistes=[r"Els fanals d'un lateral són a $12$, $24$… metres de l'inici, i "
                 r"els de l'altre a $18$… Tornen a quedar l'un davant de l'altre "
                 r"a una distància MÚLTIPLE de $12$ i de $18$ alhora: la primera "
                 r"vegada és el m.c.m.",
                 r"$12=2^2\cdot3$ i $18=2\cdot3^2$: agafa cada factor primer amb "
                 r"l'exponent més gran."])


# =====================================================================
# NIVELL TRIVIAL (exercici 340)
# =====================================================================
# Aquest bloc SÍ que tenia exercicis d'un sol pas: l'exercici 5 (descompon
# 3850, -432, -561) és tan directe com es pot ser. El problema és un altre,
# i és el que va fer néixer el nivell trivial: 3850 = 2·5²·7·11 són quatre
# primers i un quadrat, i -561 = -3·11·17 demana provar fins al 17. Un sol
# pas, sí, però amb una càrrega de càlcul que fa que fallar no vulgui dir
# «no sé què és una descomposició factorial» sinó «m'he perdut dividint».
#
# El 340 aïlla la definició: números de dues xifres que es reconeixen de
# vista. Si aquí falla, el que no hi és és el concepte.

dificultats({
    340: 1,  # descomposició factorial de números de dues xifres
})


E340 = "Fes la descomposició factorial de:"

_t1, _v1 = fx((2, 2), (3, 1))
assert _v1 == 12

Q("340a", 340, "a", B, tipus="A", enunciat=r"$12$", correcta=_t1,
  distractors=[D(r"2\cdot 6", "FACTOR_NO_PRIMER",
     r"$6$ no és primer: $6=2\cdot 3$. La descomposició ha d'arribar a "
     r"primers i aturar-se allà."),
   D(r"2\cdot 3", "EXPONENT_OBLIDAT",
     r"Et falta un $2$: $2\cdot 3=6$, no $12$. El $12$ es divideix DUES "
     r"vegades entre $2$ ($12:2=6$ i $6:2=3$), i per això va $2^{2}$."),
   D(r"3\cdot 4", "FACTOR_NO_PRIMER",
     r"$4$ no és primer: $4=2^{2}$.")],
  pistes=["Divideix entre $2$ tantes vegades com puguis, i després prova amb $3$.",
   "$12:2=6$ i $6:2=3$: dues vegades el $2$, i queda un $3$."],
  resolucio=[r"$12=2\cdot 6=2\cdot 2\cdot 3=2^{2}\cdot 3$"],
  ex_text=E340)

_t2, _v2 = fx((2, 1), (3, 2))
assert _v2 == 18

Q("340b", 340, "b", B, tipus="A", enunciat=r"$18$", correcta=_t2,
  distractors=[D(r"2\cdot 9", "FACTOR_NO_PRIMER",
     r"$9$ no és primer: $9=3^{2}$."),
   D(r"2\cdot 3", "EXPONENT_OBLIDAT",
     r"$2\cdot 3=6$, no $18$. Després de dividir entre $2$ queda $9$, que "
     r"encara es divideix dues vegades entre $3$."),
   D(r"2^{2}\cdot 3", "EXPONENT_EXCES",
     r"$18$ només és parell una vegada: $18:2=9$, i $9$ és imparell.")],
  pistes=["Comença pel $2$ i després continua amb el $3$.",
   "$18:2=9$, i $9=3\\cdot 3$."],
  resolucio=[r"$18=2\cdot 9=2\cdot 3\cdot 3=2\cdot 3^{2}$"],
  ex_text=E340)

_t3, _v3 = fx((5, 2), )
assert _v3 == 25

Q("340c", 340, "c", B, tipus="A", enunciat=r"$25$", correcta=_t3,
  distractors=[D(r"5\cdot 20", "FACTOR_NO_PRIMER",
     r"$20$ no és primer, i a més $5\cdot 20=100$."),
   D(r"5", "EXPONENT_OBLIDAT",
     r"Un $5$ sol val $5$, no $25$. El $25$ és $5\cdot 5$."),
   D(r"3\cdot 5", "FACTOR_MAL_TRIAT",
     r"$3$ no divideix $25$: prova-ho i veuràs que no dona exacte. "
     r"Comprova sempre multiplicant els factors.")],
  pistes=["$25$ no és parell i no és múltiple de $3$: prova amb el $5$.",
   "$25:5=5$, i el $5$ ja és primer."],
  resolucio=[r"$25=5\cdot 5=5^{2}$"],
  ex_text=E340)

_t4, _v4 = fx((2, 3), (5, 1))
assert _v4 == 40

Q("340d", 340, "d", B, tipus="A", enunciat=r"$40$", correcta=_t4,
  distractors=[D(r"2^{2}\cdot 10", "FACTOR_NO_PRIMER",
     r"$10$ no és primer: $10=2\cdot 5$, de manera que encara hi surt un $2$ "
     r"més."),
   D(r"2^{2}\cdot 5", "EXPONENT_OBLIDAT",
     r"$2^{2}\cdot 5=20$, no $40$. El $40$ es divideix TRES vegades entre "
     r"$2$: $40\to 20\to 10\to 5$."),
   D(r"2^{4}\cdot 5", "EXPONENT_EXCES",
     r"$2^{4}\cdot 5=80$. Compta les divisions: $40:2=20$, $20:2=10$, "
     r"$10:2=5$. Són tres, no quatre.")],
  pistes=["Divideix entre $2$ mentre puguis, i compta quantes vegades ho fas.",
   "$40\\to 20\\to 10\\to 5$: tres vegades el $2$, i queda el $5$."],
  resolucio=[r"$40=2\cdot 20=2\cdot 2\cdot 10=2\cdot 2\cdot 2\cdot 5=2^{3}\cdot 5$"],
  ex_text=E340)
