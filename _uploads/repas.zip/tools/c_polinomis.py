# -*- coding: utf-8 -*-
"""c_polinomis.py — Full 4: Polinomis.

Genera els ítems dels exercicis 62-74, que corresponen a `im4.tex` del
repositori LaTeX font. Organitzats en 4 blocs:
  operacions   (62-64)  suma, resta i producte de polinomis
  divisio      (65-69)  divisió de polinomis i regla de Ruffini
  notables     (70-72)  igualtats notables (completar i factoritzar)
  factor_comu  (73-74)  factor comú i simplificació combinada

Cap resposta s'escriu a mà: cada polinomi resultant es calcula amb SymPy
(Poly/expand/factor) i es renderitza a LaTeX amb el helper propi
poli_tex(), en l'estil del projecte (sense espais sobrers, un terme
independent sempre amb signe explícit).

Recompte: 56 ítems bruts, 59 finals. L'exercici 69 (quatre taules de
Ruffini a completar, a-d) no porta \\begin{apartats} al fitxer font, així
que el recompte automàtic el veu com una sola pregunta; pedagògicament
són quatre activitats independents i es reformulen aquí com a 4 ítems
(69a-69d). És el mateix criteri que a l'exercici 59 del Full 3.
"""
from sympy import symbols, Poly, expand, factor, sqrt
from lib import Q, D, DT, ev, tex, dificultats

# --------------------------------------------------------------------
# Dificultat de cada exercici (1 trivial, 2 directa, 3 encadenada,
# 4 completa). Vegeu l'escala completa i la frontera entre nivells
# a lib.py.
# Full 4 · polinomis
# Vegeu l'escala completa a lib.py. L'itinerari fa servir aquest camp
# per graduar el recorregut, de manera que canviar-hi un número canvia
# l'ordre en què l'alumne es troba els exercicis.
# --------------------------------------------------------------------
dificultats({
     62: 3,  # sumar i restar polinomis donats
     63: 3,  # a l'inrevés: quin polinomi cal sumar per arribar a un altre
     64: 4,  # operar dins del claudàtor i multiplicar després
     65: 3,  # divisió llarga; 66 i 68, Ruffini amb divisor mònic
     66: 3,
     67: 4,  # Ruffini amb divisor no mònic: cal ajustar quocient o residu
     68: 3,
     69: 4,  # reconstruir una taula de Ruffini incompleta
     70: 3,  # completar una igualtat notable
     71: 2,  # reconèixer la igualtat notable; 73, treure factor comú
     72: 4,  # reconèixer el patró amb un bloc sencer fent de terme
     73: 2,
     74: 4,  # combinar factor comú i igualtats notables en la mateixa expressió
})


B1 = "operacions"
B2 = "divisio"
B3 = "notables"
B4 = "factor_comu"

x = symbols("x")


def poli_tex_raw(expr):
    """LaTeX d'un polinomi en x, SENSE embolcallar amb $...$ (per
    incrustar dins d'una cadena LaTeX més gran ja delimitada). Sense
    espais sobrers, signe sempre explícit entre termes, coeficient 1
    implícit. Admet coeficients fraccionaris (\\dfrac)."""
    from fractions import Fraction as F
    p = Poly(expr, x)
    coefs = p.all_coeffs()
    n = len(coefs) - 1
    parts = []
    for i, c in enumerate(coefs):
        if c == 0:
            continue
        grau = n - i
        c = F(int(c.p), int(c.q)) if hasattr(c, "p") else F(c)
        signe = "-" if c < 0 else ("+" if parts else "")
        ac = abs(c)
        ac_str = str(ac.numerator) if ac.denominator == 1 else \
            (r"\dfrac{%d}{%d}" % (ac.numerator, ac.denominator))
        if grau == 0:
            terme = ac_str
        elif grau == 1:
            terme = ("" if ac == 1 else ac_str) + "x"
        else:
            terme = ("" if ac == 1 else ac_str) + ("x^{%d}" % grau)
        parts.append(signe + terme)
    return "".join(parts) if parts else "0"


def poli_tex(expr):
    """LaTeX d'un polinomi en x, embolcallat amb $...$: per fer-lo
    servir directament com a opció (correcta/distractor), ja que
    mathify() (a build.py) no reconeix expressions amb lletres com a
    "matemàtica pura" i no les delimitaria soles."""
    return "$%s$" % poli_tex_raw(expr)


def pol(*coefs_desc):
    """Construeix una expressió SymPy de x a partir dels coeficients de
    major a menor grau: pol(2,-3,0,1) -> 2x^3-3x^2+1."""
    n = len(coefs_desc) - 1
    return sum(c * x ** (n - i) for i, c in enumerate(coefs_desc))


# =====================================================================
# BLOC 1 — OPERACIONS AMB POLINOMIS (exercicis 62-64)
# =====================================================================

P62 = pol(2, -3, 7, -2, 3, -6)   # P(x) = 2x^5-3x^4+7x^3-2x^2+3x-6
Q62 = pol(3, -2, 5, -7, -1)      # Q(x) = 3x^4-2x^3+5x^2-7x-1
R62 = pol(3, -1, 1)              # R(x) = 3x^2-x+1
S62 = pol(2, 3)                  # S(x) = 2x+3

E62 = (r"Donats els polinomis $P(x)=2x^5-3x^4+7x^3-2x^2+3x-6$, "
       r"$Q(x)=3x^4-2x^3+5x^2-7x-1$, $R(x)=3x^2-x+1$ i $S(x)=2x+3$, calcula.")

Q("62a", 62, "a", B1, tipus="A",
  enunciat=r"$P(x)+Q(x)+R(x)+S(x)$",
  correcta=poli_tex(expand(P62 + Q62 + R62 + S62)),
  distractors=[D(poli_tex(expand(P62 - Q62 + R62 + S62)), "SIGNE_TERME_INDEPENDENT",
     "Has restat $Q(x)$ en lloc de sumar-lo: revisa l'enunciat, els quatre "
     "polinomis se sumen."),
   D(poli_tex(expand(P62 + Q62 + R62 - S62)), "TERME_OBLIDAT_OPERACIO",
     "Has restat $S(x)$ en lloc de sumar-lo."),
   D(poli_tex(expand(P62 + Q62 - R62 + S62)), "TERME_OBLIDAT_OPERACIO",
     "Has restat $R(x)$ en lloc de sumar-lo.")],
  pistes=["Suma els quatre polinomis grau a grau: primer els termes de $x^5$, "
   "després els de $x^4$, i així successivament.",
   "Vigila els polinomis que no tenen tots els graus: $R(x)$ no té terme en "
   "$x^5$ ni $x^4$ ni $x^3$, i $S(x)$ només té fins a grau $1$."],
  resolucio=[r"$P(x)+Q(x)+R(x)+S(x)=%s$" % poli_tex_raw(expand(P62 + Q62 + R62 + S62))],
  ex_text=E62)

Q("62b", 62, "b", B1, tipus="A",
  enunciat=r"$P(x)-R(x)+S(x)-Q(x)$",
  correcta=poli_tex(expand(P62 - R62 + S62 - Q62)),
  distractors=[D(poli_tex(expand(P62 - R62 + S62 + Q62)), "PARENTESI_NO_DISTRIBUIT_POLI",
     "Has sumat $Q(x)$ en lloc de restar-lo: revisa l'últim signe de "
     "l'enunciat."),
   D(poli_tex(expand(P62 + R62 + S62 - Q62)), "PARENTESI_NO_DISTRIBUIT_POLI",
     "Has sumat $R(x)$ en lloc de restar-lo."),
   D(poli_tex(expand(P62 - R62 - S62 - Q62)), "TERME_OBLIDAT_OPERACIO",
     "Has restat $S(x)$ en lloc de sumar-lo.")],
  pistes=["Vigila l'ordre dels signes: $P(x)$ i $S(x)$ sumen, $R(x)$ i $Q(x)$ resten.",
   "Resta $R(x)$ de $P(x)$ primer, suma-hi $S(x)$, i finalment resta'n $Q(x)$."],
  resolucio=[r"$P(x)-R(x)+S(x)-Q(x)=%s$" % poli_tex_raw(expand(P62 - R62 + S62 - Q62))],
  ex_text=E62)

Q("62c", 62, "c", B1, tipus="A",
  enunciat=r"$[P(x)+Q(x)]-[R(x)+Q(x)]$",
  correcta=poli_tex(expand((P62 + Q62) - (R62 + Q62))),
  distractors=[D(poli_tex(expand((P62 + Q62) + (R62 + Q62))), "PARENTESI_NO_DISTRIBUIT_POLI",
     "Has sumat els dos claudàtors en lloc de restar-los."),
   D(poli_tex(expand(P62 - R62 - Q62 - Q62)), "PARENTESI_NO_DISTRIBUIT_POLI",
     "En restar el segon claudàtor, has canviat el signe només d'un dels "
     "dos termes: $-[R(x)+Q(x)]=-R(x)-Q(x)$, els dos amb signe menys."),
   D(poli_tex(expand((P62 + Q62) - (R62 - Q62))), "GRAUS_MAL_AGRUPATS",
     "Al segon claudàtor hi ha $R(x)+Q(x)$, no $R(x)-Q(x)$: revisa "
     "l'enunciat.")],
  pistes=["El $Q(x)$ apareix als dos claudàtors: en restar-los, es cancel·la. "
   "El resultat és, en realitat, $P(x)-R(x)$.",
   "$[P(x)+Q(x)]-[R(x)+Q(x)]=P(x)+Q(x)-R(x)-Q(x)=P(x)-R(x)$."],
  resolucio=[r"$[P(x)+Q(x)]-[R(x)+Q(x)]=P(x)-R(x)=%s$"
   % poli_tex_raw(expand((P62 + Q62) - (R62 + Q62)))],
  ex_text=E62,
  # Sense nota: assenyalava que el resultat coincideix amb el d'un altre
  # apartat. Explicar-ho abans de respondre treu la gràcia de notar-ho.
  )

Q("62d", 62, "d", B1, tipus="A",
  enunciat=r"$[P(x)-Q(x)]-[R(x)-Q(x)]$",
  correcta=poli_tex(expand((P62 - Q62) - (R62 - Q62))),
  distractors=[D(poli_tex(expand((P62 - Q62) + (R62 - Q62))), "PARENTESI_NO_DISTRIBUIT_POLI",
     "Has sumat els dos claudàtors en lloc de restar-los."),
   D(poli_tex(expand(P62 - Q62 - R62 - Q62)), "PARENTESI_NO_DISTRIBUIT_POLI",
     "En restar el segon claudàtor, no has canviat el signe del $-Q(x)$ de "
     "dins: $-[R(x)-Q(x)]=-R(x)+Q(x)$."),
   D(poli_tex(expand(P62 - Q62 - R62)), "TERME_OBLIDAT_OPERACIO",
     "T'has deixat pel camí el $+Q(x)$ final: el segon claudàtor és "
     "$-[R(x)-Q(x)]=-R(x)+Q(x)$, no només $-R(x)$.")],
  pistes=["El $Q(x)$ apareix (amb el mateix signe) als dos claudàtors: en "
   "restar-los, es cancel·la igualment.",
   "$[P(x)-Q(x)]-[R(x)-Q(x)]=P(x)-Q(x)-R(x)+Q(x)=P(x)-R(x)$."],
  resolucio=[r"$[P(x)-Q(x)]-[R(x)-Q(x)]=P(x)-R(x)=%s$"
   % poli_tex_raw(expand((P62 - Q62) - (R62 - Q62)))],
  ex_text=E62)


P63 = pol(1, 2, -1)  # P(x) = x^2+2x-1

E63 = (r"Troba quin és el polinomi $Q(x)$ que s'ha de sumar a "
       r"$P(x)=x^2+2x-1$ per obtenir com a resultat $R(x)$.")


def item63(letra, R, enunciat_r):
    """Genera l'ítem 63<letra>: donat R(x), troba Q(x)=R(x)-P(x)."""
    correcta = expand(R - P63)
    return Q("63%s" % letra, 63, letra, B1, tipus="A",
      enunciat=r"$R(x)=%s$" % enunciat_r,
      correcta=poli_tex(correcta),
      distractors=[D(poli_tex(expand(R + P63)), "PARENTESI_NO_DISTRIBUIT_POLI",
         "Has sumat $P(x)$ en lloc de restar-lo: si $P(x)+Q(x)=R(x)$, "
         "aleshores $Q(x)=R(x)-P(x)$."),
       D(poli_tex(expand(P63 - R)), "ORDRE_RESTA",
         "Has restat en l'ordre equivocat: és $R(x)-P(x)$, no $P(x)-R(x)$."),
       D(poli_tex(expand(R - pol(1, 2, 1))), "SIGNE_TERME_INDEPENDENT",
         "Has canviat el signe del terme independent de $P(x)$: és $-1$, "
         "no $+1$.")],
      pistes=["Si $P(x)+Q(x)=R(x)$, aïllant $Q(x)$ queda $Q(x)=R(x)-P(x)$.",
       r"Aquí $Q(x)=(%s)-(x^2+2x-1)$: el menys canvia el signe de tots els "
       r"termes de $P(x)$. Després agrupa per graus." % enunciat_r],
      resolucio=[r"$Q(x)=R(x)-P(x)=%s$" % poli_tex_raw(correcta)],
      ex_text=E63)


item63("a", pol(0, 1, -1), "x-1")
item63("b", pol(2, -1, -6), "2x^2-x-6")
item63("c", pol(5, -1, 1), "5x^2-x+1")
item63("d", pol(-7, -3, 0), "-7x^2-3x")
item63("e", pol(1, 0, -1, 0), "x^3-x")
item63("f", pol(1, -1, 0, 0), "x^3-x^2")


E64 = (r"Donats els polinomis $P(x)=2x^5-3x^4+7x^3-2x^2+3x-6$, "
       r"$Q(x)=3x^4-2x^3+5x^2-7x-1$, $R(x)=3x^2-x+1$ i $S(x)=2x+3$, calcula.")


def item64(letra, dins, ex_txt, dins_txt, correcta_extra_err=None):
    """Genera l'ítem 64<letra>: [dins] * S(x), amb distractors de
    distribució incompleta (només pel terme 2x, o només pel terme 3)."""
    correcta = expand(dins * S62)
    nomes_2x = expand(dins * 2 * x)
    nomes_3 = expand(dins * 3)
    return Q("64%s" % letra, 64, letra, B1, tipus="A",
      enunciat=ex_txt,
      correcta=poli_tex(correcta),
      distractors=[D(poli_tex(nomes_2x), "DISTRIBUCIO_INCOMPLETA",
         "Només has multiplicat pel terme $2x$ de $S(x)$: cal multiplicar "
         "també pel terme $3$."),
       D(poli_tex(nomes_3), "DISTRIBUCIO_INCOMPLETA",
         "Només has multiplicat pel terme $3$ de $S(x)$: cal multiplicar "
         "també pel terme $2x$."),
       D(poli_tex(expand(-dins * S62)), "SIGNE_TERME_INDEPENDENT",
         "El resultat té tots els signes canviats: revisa els signes de "
         "%s abans de multiplicar." % dins_txt)],
      pistes=["Multiplica cada terme de %s per CADA terme de $S(x)=2x+3$: pel "
       "$2x$ i pel $3$." % dins_txt,
       "Un cop distribuït, agrupa els termes del mateix grau i suma'ls."],
      # dins_txt ja ve amb els $ posats, perquè a les pistes i a la retroacció
      # va enmig de text. Aquí, en canvi, tot el pas és una sola expressió:
      # cal treure-los-hi o queden dos $ seguits i el renderitzat es trenca.
      resolucio=[r"$%s\cdot S(x)=%s$" % (dins_txt.strip("$"), poli_tex_raw(correcta))],
      ex_text=E64)


item64("a", P62 - Q62, r"$[P(x)-Q(x)]\cdot S(x)$", "$[P(x)-Q(x)]$")
item64("b", R62 - Q62, r"$[R(x)-Q(x)]\cdot S(x)$", "$[R(x)-Q(x)]$")
item64("c", P62 + Q62 + R62, r"$[P(x)+Q(x)+R(x)]\cdot S(x)$",
       "$[P(x)+Q(x)+R(x)]$")
item64("d", P62 + Q62 - R62, r"$[P(x)+Q(x)-R(x)]\cdot S(x)$",
       "$[P(x)+Q(x)-R(x)]$")


# =====================================================================
# BLOC 2 — DIVISIÓ DE POLINOMIS I REGLA DE RUFFINI (exercicis 65-69)
# =====================================================================

from sympy import div


def r_tex_raw(r):
    """LaTeX (sense $...$) d'un residu: constant o polinomi de grau
    >=1 (divisor no mònic)."""
    r = expand(r)
    if r.is_number:
        return tex(int(r)) if r == int(r) else tex(r)
    return poli_tex_raw(r)


def qr_tex(q, r):
    """LaTeX '$\\text{quocient: ...; residu: ...}$' per a una divisió
    de polinomis, com a opció completa (correcta/distractor)."""
    return r"$\text{quocient: }%s\text{; residu: }%s$" % (
        poli_tex_raw(q), r_tex_raw(r))


E65 = "Divideix."

D65a = pol(7, 4, 3, -5, 2, -1)
d65a = pol(1, 1, 0)
q65a, r65a = div(D65a, d65a, x)

Q("65a", 65, "a", B2, tipus="A",
  enunciat=r"$(7x^5+4x^4+3x^3-5x^2+2x-1):(x^2+x)$",
  correcta=qr_tex(q65a, r65a),
  distractors=[D(qr_tex(q65a, -r65a), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat: revisa l'últim pas de la divisió."),
   D(qr_tex(expand(q65a + 1), r65a), "TERME_OBLIDAT_OPERACIO",
     "El quocient no és correcte: revisa el terme independent del "
     "quocient, sobra un $+1$."),
   D(qr_tex(expand(q65a - x), r65a), "GRAUS_MAL_AGRUPATS",
     "El quocient no és correcte: revisa el terme de grau $1$.")],
  pistes=["Divideix pas a pas: el primer terme del quocient surt de dividir "
   "$7x^5$ entre $x^2$.",
   "Continua restant i baixant termes fins que el residu tingui grau "
   "menor que el divisor (grau $2$)."],
  resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q65a), poli_tex_raw(r65a))],
  ex_text=E65)

D65b = pol(1, -2, 1, -1, 3)
d65b = pol(1, 1, 1)
q65b, r65b = div(D65b, d65b, x)

Q("65b", 65, "b", B2, tipus="A",
  enunciat=r"$(x^4-2x^3+x^2-x+3):(x^2+x+1)$",
  correcta=qr_tex(q65b, r65b),
  distractors=[D(qr_tex(q65b, -r65b), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat: revisa l'últim pas de la divisió."),
   D(qr_tex(expand(q65b + pol(0, 1, 0)), r65b), "TERME_OBLIDAT_OPERACIO",
     "El quocient no és correcte: revisa el terme del mig."),
   D(qr_tex(q65b, 0), "RUFFINI_RESIDU_COM_QUOCIENT",
     "El residu no és $0$: aquesta divisió no és exacta.")],
  pistes=["Divideix pas a pas: el primer terme del quocient surt de dividir "
   "$x^4$ entre $x^2$.",
   "Continua fins que el residu tingui grau menor que el divisor "
   "(grau $2$)."],
  resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q65b), poli_tex_raw(r65b))],
  ex_text=E65)


E66 = "Calcula, aplicant la regla de Ruffini."


def divisor_tex(arrel):
    """LaTeX net del binomi divisor x-arrel: evita el doble signe quan
    arrel és negativa (x-(-2) es mostra com x+2, no x--2)."""
    if arrel >= 0:
        return "x-%d" % arrel if arrel != 0 else "x"
    return "x+%d" % (-arrel)


def item66(letra, coefs, arrel, ex_txt):
    """Genera l'ítem 66<letra>: (dividend):(x-arrel) per Ruffini.
    coefs són els coeficients del dividend de major a menor grau, ja
    reordenats."""
    dividend = pol(*coefs)
    divisor = pol(1, -arrel)
    q, r = div(dividend, divisor, x)
    correcta = qr_tex(q, r)
    dv_txt = divisor_tex(arrel)
    # Distractor 1: signe de l'arrel invertit (baixar multiplicant per
    # -arrel en lloc d'arrel)
    q_mal, r_mal = div(dividend, pol(1, arrel), x)
    d1 = qr_tex(q_mal, r_mal)
    # Distractor 2: residu amb signe canviat
    d2 = qr_tex(q, -r)
    # Distractor 3: quocient amb un grau de més (no s'ha avançat prou,
    # queda un terme de més barrejat)
    d3 = qr_tex(expand(q + x ** (len(coefs) - 2)), r)
    return Q("66%s" % letra, 66, letra, B2, tipus="A",
      enunciat=ex_txt,
      correcta=correcta,
      distractors=[D(d1, "RUFFINI_SIGNE_ARREL",
         "Si el divisor és $%s$, l'arrel amb què es multiplica a "
         "Ruffini és $%d$, no $%d$." % (dv_txt, arrel, -arrel)),
       D(d2, "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
         "El residu té el signe canviat: revisa l'última suma de la "
         "taula."),
       D(d3, "RUFFINI_QUOCIENT_GRAU",
         "El quocient té un grau de més: en dividir per $%s$ (grau "
         "$1$), el quocient ha de tenir un grau menys que el dividend."
         % dv_txt)],
      pistes=["Escriu els coeficients del dividend (amb un $0$ als graus que no "
       "hi surten) i aplica Ruffini amb l'arrel $%d$." % arrel,
       "Baixa el primer coeficient, multiplica'l per $%d$ i suma'l al "
       "següent; repeteix fins al final. L'últim número és el residu."
       % arrel],
      resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q), r_tex_raw(r))],
      ex_text=E66)


item66("a", [1, -1, -1, 1, 3, -7], 2,
       r"$(x^5-x^3+x^2-x^4+3x-7):(x-2)$")
item66("b", [1, 0, 2, -1, -3], -1,
       r"$(x^4+2x^2-x-3):(x+1)$")
item66("c", [2, -1, 0, 1, 3], 3,
       r"$(2x^4-x^3+x+3):(x-3)$")
item66("d", [1, 1, -8, -7], -2,
       r"$(x^3-8x+x^2-7):(x+2)$")
item66("e", [1, -4, 6, -9], -4,
       r"$(x^3-4x^2+6x-9):(x+4)$")


E67 = "Fes les divisions següents mitjançant la regla de Ruffini."

# 67a-c: divisor de la forma x-arrel (mateix patró que l'exercici 66)
item67_ab = item66  # mateixa lògica, reutilitzem el helper (canviant ex)


def item67_simple(letra, coefs, arrel, ex_txt):
    dividend = pol(*coefs)
    divisor = pol(1, -arrel)
    q, r = div(dividend, divisor, x)
    correcta = qr_tex(q, r)
    q_mal, r_mal = div(dividend, pol(1, arrel), x)
    d1 = qr_tex(q_mal, r_mal)
    # Si el residu és 0, canviar-li el signe no dona un distractor
    # diferent: fem servir residu +1 (error d'arrossegar malament l'últim
    # pas) en lloc de canviar-ne el signe.
    d2 = qr_tex(q, -r) if r != 0 else qr_tex(q, r + 1)
    err2 = "DIVISIO_QUOCIENT_RESIDU_CANVIATS" if r != 0 else "RUFFINI_PAS_MAL"
    fb2 = ("El residu té el signe canviat: revisa l'última suma de la "
           "taula.") if r != 0 else (
           "L'última suma de la taula no és correcta: revisa el darrer "
           "pas de Ruffini.")
    d3 = qr_tex(expand(q + x ** (len(coefs) - 2)), r)
    return Q("67%s" % letra, 67, letra, B2, tipus="A",
      enunciat=ex_txt,
      correcta=correcta,
      distractors=[D(d1, "RUFFINI_SIGNE_ARREL",
         "Si el divisor és $x-(%d)$, l'arrel amb què es multiplica a "
         "Ruffini és $%d$, no $%d$." % (arrel, arrel, -arrel)),
       D(d2, err2, fb2),
       D(d3, "RUFFINI_QUOCIENT_GRAU",
         "El quocient té un grau de més: en dividir per un binomi de "
         "grau $1$, el quocient ha de tenir un grau menys que el "
         "dividend.")],
      pistes=["Escriu primer el dividend ordenat de grau més gran a més petit, "
       "amb un $0$ als graus que no hi surten.",
       "Aplica Ruffini amb l'arrel $%d$: baixa, multiplica, suma, i "
       "repeteix." % arrel],
      resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q), r_tex_raw(r))],
      ex_text=E67)


item67_simple("a", [4, 0, 1, 0, -2, 0, 0, 0], -2,
              r"$(4x^7-2x^3+x^5):(x+2)$")
item67_simple("b", [-1, 0, 0, 0, 0, 1], 1,
              r"$(1-x^5):(x-1)$")
item67_simple("c", [6, -1, 0, 0, 2, 3, 0], -1,
              r"$(3x+2x^2-x^5+6x^6):(x+1)$")

# 67d: divisor 3-x, cal reescriure'l com -(x-3) abans d'aplicar Ruffini
D67d = pol(-1, 0, 9)
q67d, r67d = div(D67d, pol(-1, 3), x)

Q("67d", 67, "d", B2, tipus="A",
  enunciat=r"$(9-x^2):(3-x)$",
  correcta=qr_tex(q67d, r67d),
  distractors=[D(qr_tex(-q67d, r67d), "FACTOR_COMU_SIGNE",
     "El divisor és $3-x=-(x-3)$: cal aplicar Ruffini amb l'arrel $3$ "
     "sobre $x^2-9$ (l'oposat del dividend) i després tornar a canviar "
     "el signe del quocient. T'has deixat aquest segon canvi de signe."),
   D(qr_tex(expand(q67d + x), r67d), "RUFFINI_PAS_MAL",
     "El terme de grau $1$ del quocient no és correcte: revisa la "
     "taula de Ruffini pas a pas."),
   D(qr_tex(expand(q67d + 1), r67d), "RUFFINI_SIGNE_ARREL",
     "Has aplicat Ruffini amb l'arrel $-3$ en lloc de $3$: el divisor "
     "$3-x$ equival a $-(x-3)$, amb arrel $3$.")],
  pistes=[r"El divisor $3-x$ no és de la forma $x-a$ directa: reescriu-lo com "
   r"$3-x=-(x-3)$.",
   r"$(9-x^2):(3-x)=(x^2-9):(x-3)$ (el signe es cancel·la a numerador i "
   r"denominador). Aplica Ruffini amb l'arrel $3$."],
  resolucio=[r"$(9-x^2):(3-x)=(x^2-9):(x-3)$, i per Ruffini amb arrel $3$ surt "
   r"quocient $%s$ i residu $%s$" % (poli_tex_raw(q67d), r_tex_raw(r67d))],
  ex_text=E67,
  nota="El divisor $3-x$ té el signe de $x$ canviat respecte a la forma "
       "habitual $x-a$: per fer-lo servir amb Ruffini cal reescriure'l "
       "primer com $-(x-3)$, dividint $9-x^2$ i $3-x$ pel mateix factor "
       "$-1$ (el quocient de la divisió no canvia).")

# 67e: divisor 2x-2 = 2(x-1), coeficient líder != 1
D67e = pol(1, 0, -2, 6)
q67e, r67e = div(D67e, pol(2, -2), x)
# via Ruffini amb (x-1), després dividir el quocient per 2
q_ruffini_e, r_ruffini_e = div(D67e, pol(1, -1), x)

Q("67e", 67, "e", B2, tipus="A",
  enunciat=r"$(x^3-2x+6):(2x-2)$",
  correcta=qr_tex(q67e, r67e),
  distractors=[D(qr_tex(q_ruffini_e, r_ruffini_e), "RUFFINI_DIVISOR_NO_MONIC",
     "Has aplicat Ruffini amb l'arrel $1$ (de $x-1$) però sense tenir en "
     "compte que el divisor és $2x-2=2(x-1)$, no $x-1$: el quocient "
     "final s'ha de dividir per $2$."),
   D(qr_tex(q67e, -r67e), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(expand(q_ruffini_e * -1), r_ruffini_e), "RUFFINI_SIGNE_ARREL",
     "Has aplicat Ruffini amb l'arrel $-1$ en lloc de $1$: el factor és "
     "$(x-1)$, no $(x+1)$.")],
  pistes=[r"El divisor $2x-2=2(x-1)$ no té coeficient líder $1$: treu-ne el "
   r"factor $2$ abans d'aplicar Ruffini.",
   r"Aplica Ruffini a $(x^3-2x+6):(x-1)$ amb arrel $1$, i divideix "
   r"després el quocient obtingut entre $2$ (el residu no canvia)."],
  resolucio=[r"$(x^3-2x+6):(x-1)$ per Ruffini dona quocient $%s$ i residu $%s$; "
   r"com que el divisor real és el doble, $2x-2$, el quocient final es "
   r"divideix entre $2$: $%s$, residu $%s$"
   % (poli_tex_raw(q_ruffini_e), r_tex_raw(r_ruffini_e), poli_tex_raw(q67e), r_tex_raw(r67e))],
  ex_text=E67,
  nota="El divisor $2x-2$ té coeficient líder $2$, no $1$: la regla de "
       "Ruffini \"pura\" només s'aplica directament a divisors $x-a$. "
       "Es resol traient-ne el factor comú, $2x-2=2(x-1)$, aplicant "
       "Ruffini amb $(x-1)$, i dividint el quocient resultant entre "
       "$2$ (el residu es manté igual).")

# 67f: divisor 3x+6 = 3(x+2)
D67f = pol(-1, 0, 3, -1, 1)
q67f, r67f = div(D67f, pol(3, 6), x)
q_ruffini_f, r_ruffini_f = div(D67f, pol(1, 2), x)

Q("67f", 67, "f", B2, tipus="A",
  enunciat=r"$(-x^4+3x^2-x+1):(3x+6)$",
  correcta=qr_tex(q67f, r67f),
  distractors=[D(qr_tex(q_ruffini_f, r_ruffini_f), "RUFFINI_DIVISOR_NO_MONIC",
     "Has aplicat Ruffini amb l'arrel $-2$ (de $x+2$) però el divisor "
     "és $3x+6=3(x+2)$, no $x+2$: el quocient final s'ha de dividir "
     "per $3$."),
   D(qr_tex(q67f, -r67f), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(expand(q_ruffini_f * -1), r_ruffini_f), "RUFFINI_SIGNE_ARREL",
     "Has aplicat Ruffini amb l'arrel $2$ en lloc de $-2$: el factor és "
     "$(x+2)$, no $(x-2)$.")],
  pistes=[r"El divisor $3x+6=3(x+2)$ no té coeficient líder $1$: treu-ne el "
   r"factor $3$ abans d'aplicar Ruffini.",
   r"Aplica Ruffini amb arrel $-2$ i divideix després el quocient entre "
   r"$3$ (el residu no canvia)."],
  resolucio=[r"$(-x^4+3x^2-x+1):(x+2)$ per Ruffini dona quocient $%s$ i residu "
   r"$%s$; dividit el quocient entre $3$ (divisor real $3x+6$): $%s$, "
   r"residu $%s$"
   % (poli_tex_raw(q_ruffini_f), r_tex_raw(r_ruffini_f), poli_tex_raw(q67f), r_tex_raw(r67f))],
  ex_text=E67,
  nota="Igual que a l'apartat e), el divisor $3x+6$ té coeficient líder "
       "$3$: es treu el factor comú, s'aplica Ruffini amb $(x+2)$, i el "
       "quocient final es divideix entre $3$.")


E68 = "Calcula el quocient i el residu de les divisions de polinomis següents."

# 68a: (7x^4-2x+x^3):(x-3), arrel 3
D68a = pol(7, 1, 0, -2, 0)
q68a, r68a = div(D68a, pol(1, -3), x)

Q("68a", 68, "a", B2, tipus="A",
  enunciat=r"$(7x^4-2x+x^3):(x-3)$",
  correcta=qr_tex(q68a, r68a),
  distractors=[D(qr_tex(*div(D68a, pol(1, 3), x)), "RUFFINI_SIGNE_ARREL",
     "Si el divisor és $x-3$, l'arrel per Ruffini és $3$, no $-3$."),
   D(qr_tex(q68a, -r68a), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(expand(q68a - x), r68a), "TERME_OBLIDAT_OPERACIO",
     "Revisa el terme de grau $1$ del quocient.")],
  pistes=["Ordena primer el dividend: $x^4$, $x^3$, $x^2$ (que no hi surt, "
   "coeficient $0$), $x$ i terme independent.",
   "Aplica Ruffini amb l'arrel $3$."],
  resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q68a), r_tex_raw(r68a))],
  ex_text=E68)

# 68b: (-3-x^5):(x+2), arrel -2
D68b = pol(-1, 0, 0, 0, 0, -3)
q68b, r68b = div(D68b, pol(1, 2), x)

Q("68b", 68, "b", B2, tipus="A",
  enunciat=r"$(-3-x^5):(x+2)$",
  correcta=qr_tex(q68b, r68b),
  distractors=[D(qr_tex(*div(D68b, pol(1, -2), x)), "RUFFINI_SIGNE_ARREL",
     "Si el divisor és $x+2$, l'arrel per Ruffini és $-2$, no $2$."),
   D(qr_tex(q68b, -r68b), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(expand(q68b + x ** 3), r68b), "RUFFINI_QUOCIENT_GRAU",
     "El quocient no és correcte: revisa el terme de grau $3$.")],
  pistes=["El dividend $-3-x^5$ té molts coeficients $0$ (no hi ha termes en "
   "$x^4$, $x^3$, $x^2$, $x$): no te'ls saltis a la taula.",
   "Aplica Ruffini amb l'arrel $-2$."],
  resolucio=[r"Quocient $%s$ i residu $%s$" % (poli_tex_raw(q68b), r_tex_raw(r68b))],
  ex_text=E68)

# 68c: (-3x^6+2x^5-x^4):(-x-1), divisor -(x+1)
D68c = pol(-3, 2, -1, 0, 0, 0, 0)
q68c, r68c = div(D68c, pol(-1, -1), x)
q68c_mal, r68c_mal = div(D68c, pol(1, 1), x)  # sense treure el signe -1

Q("68c", 68, "c", B2, tipus="A",
  enunciat=r"$(-3x^6+2x^5-x^4):(-x-1)$",
  correcta=qr_tex(q68c, r68c),
  distractors=[D(qr_tex(q68c_mal, r68c_mal), "FACTOR_COMU_SIGNE",
     "Has aplicat Ruffini directament amb l'arrel $-1$ sense reescriure "
     "abans el divisor $-x-1$ com $-(x+1)$: cal canviar de signe el "
     "dividend i el quocient final."),
   D(qr_tex(q68c, -r68c), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(*div(D68c, pol(-1, 1), x)), "RUFFINI_SIGNE_ARREL",
     "Has fet servir l'arrel $1$ en lloc de $-1$: el divisor $-x-1$ "
     "equival a $-(x+1)$, amb arrel $-1$.")],
  pistes=[r"El divisor $-x-1=-(x+1)$ no és de la forma $x-a$ directa: "
   r"reescriu-lo com $-(x+1)$.",
   r"Divideix $-3x^6+2x^5-x^4$ i $-x-1$ pel mateix factor $-1$: "
   r"$(3x^6-2x^5+x^4):(x+1)$, i aplica Ruffini amb l'arrel $-1$."],
  resolucio=[r"$(-3x^6+2x^5-x^4):(-x-1)=(3x^6-2x^5+x^4):(x+1)$; per Ruffini amb "
   r"arrel $-1$: quocient $%s$ i residu $%s$" % (poli_tex_raw(q68c), r_tex_raw(r68c))],
  ex_text=E68,
  nota="El divisor $-x-1$ té el coeficient de $x$ negatiu: es reescriu "
       "com $-(x+1)$, dividint dividend i divisor pel mateix factor "
       "$-1$, i s'aplica Ruffini amb l'arrel $-1$.")

# 68d: (1+3x^3-6x^6-9x^2):(3-x), divisor 3-x
D68d = pol(-6, 0, 0, 3, -9, 0, 1)
q68d, r68d = div(D68d, pol(-1, 3), x)

Q("68d", 68, "d", B2, tipus="A",
  enunciat=r"$(1+3x^3-6x^6-9x^2):(3-x)$",
  correcta=qr_tex(q68d, r68d),
  distractors=[D(qr_tex(*div(D68d, pol(1, -3), x)), "FACTOR_COMU_SIGNE",
     "El divisor $3-x=-(x-3)$: has dividit directament sense reescriure "
     "el divisor, i t'has deixat el canvi de signe del quocient."),
   D(qr_tex(q68d, -r68d), "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El residu té el signe canviat."),
   D(qr_tex(expand(q68d + x), r68d), "RUFFINI_PAS_MAL",
     "El terme de grau $1$ del quocient no és correcte: revisa el pas "
     "corresponent de la taula de Ruffini.")],
  pistes=[r"El divisor $3-x=-(x-3)$: reescriu-lo abans d'aplicar Ruffini.",
   r"$(1+3x^3-6x^6-9x^2):(3-x)=(6x^6-3x^3+9x^2-1):(x-3)$ (dividend i "
   r"divisor multiplicats per $-1$). Aplica Ruffini amb l'arrel $3$."],
  resolucio=[r"Reescrivint el divisor, $(1+3x^3-6x^6-9x^2):(3-x)$ dona per Ruffini "
   r"quocient $%s$ i residu $%s$" % (poli_tex_raw(q68d), r_tex_raw(r68d))],
  ex_text=E68,
  nota="Igual que a l'apartat c) de l'exercici 67, el divisor $3-x$ té "
       "el signe de $x$ canviat: cal reescriure'l com $-(x-3)$ abans "
       "d'aplicar Ruffini.")


E69 = (r"A la taula de Ruffini següent hi manquen algunes dades "
       r"(marcades amb $\square$). Completa-la i indica el quocient i "
       r"el residu de la divisió corresponent.")


def ruffini_rows(coefs, arrel):
    """Retorna (fila_productes, fila_sumes) d'una taula de Ruffini
    completa, com les de la font r-im4.tex."""
    row_sum = [coefs[0]]
    row_prod = [None]
    for c in coefs[1:]:
        p = row_sum[-1] * arrel
        row_prod.append(p)
        row_sum.append(p + c)
    return row_prod, row_sum


# 69a: dividend 3,4,0,-1, arrel -1 (tot conegut, cal completar la taula)
coefs_a, arrel_a = [3, 4, 0, -1], -1
_, sumes_a = ruffini_rows(coefs_a, arrel_a)
q69a, r69a = sumes_a[:-1], sumes_a[-1]

Q("69a", 69, "a", B2, tipus="A",
  enunciat=(r"Dividend $%s$, divisor $x+1$:" % poli_tex_raw(pol(*coefs_a))),
  correcta=qr_tex(pol(*q69a), r69a),
  distractors=[D(qr_tex(*div(pol(*coefs_a), pol(1, -1), x)), "RUFFINI_SIGNE_ARREL",
     "Has multiplicat per $1$ a cada pas en lloc de per $-1$: si el "
     "divisor és $x+1=x-(-1)$, l'arrel per Ruffini és $-1$."),
   D(qr_tex(pol(*[coefs_a[0], coefs_a[1], q69a[2] + 1]), r69a),
     "RUFFINI_PAS_MAL",
     "Alguna suma intermèdia de la taula no és correcta: revisa el "
     "tercer pas (producte i suma corresponents)."),
   D(qr_tex(pol(3, 1, -1), 1), "RUFFINI_RESIDU_COM_QUOCIENT",
     "El residu no és $1$: la divisió és exacta (residu $0$), ja que "
     "l'últim pas de la taula dona $-1\\cdot(-1)+(-1)=0$.")],
  pistes=[r"Baixa el primer coeficient ($3$), multiplica'l per l'arrel "
   r"($-1$) i suma el resultat al següent coeficient; repeteix fins "
   r"al final.",
   r"L'últim número de la fila inferior és el residu; els altres, en "
   r"ordre, són els coeficients del quocient."],
  resolucio=[r"Amb arrel $-1$: quocient $%s$ i residu $%s$"
   % (poli_tex_raw(pol(*q69a)), r_tex_raw(r69a))],
  ex_text=E69)

# 69b: dividend 4,3,2,1, arrel square; segona casella fila inferior = -1
# 4*a+3=-1 -> a=-1
coefs_b, arrel_b = [4, 3, 2, 1], -1
_, sumes_b = ruffini_rows(coefs_b, arrel_b)
q69b, r69b = sumes_b[:-1], sumes_b[-1]

Q("69b", 69, "b", B2, tipus="A",
  enunciat=(r"Dividend $%s$, arrel $\square$ (divisor desconegut); a la fila "
   r"inferior, la segona casella val $%d$:" % (poli_tex_raw(pol(*coefs_b)), sumes_b[1])),
  correcta=r"$\square=%d$; " % arrel_b + qr_tex(pol(*q69b), r69b),
  distractors=[D(r"$\square=1$; " + qr_tex(*div(pol(*coefs_b), pol(1, -1), x)),
     "RUFFINI_SIGNE_ARREL",
     "Si $4\\cdot\\square+3=-1$, aïllant surt $\\square=-1$, no $1$: "
     "revisa el signe en resoldre l'equació."),
   D(r"$\square=%d$; " % arrel_b + qr_tex(pol(*q69b), -r69b),
     "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El valor de $\\square$ és correcte, però el residu té el signe "
     "canviat."),
   D(r"$\square=%d$; " % arrel_b + qr_tex(pol(q69b[0], q69b[1] + 2, q69b[2]), r69b),
     "RUFFINI_PAS_MAL",
     "El valor de $\\square$ és correcte, però algun pas posterior de "
     "la taula no s'ha completat bé.")],
  pistes=[r"La segona casella de la fila inferior és $4\cdot\square+3$: "
   r"iguala-la a $%d$ i aïlla $\square$." % sumes_b[1],
   r"Amb $\square=%d$, completa la resta de la taula de Ruffini com "
   r"sempre." % arrel_b],
  resolucio=[r"De $4\cdot\square+3=%d$ surt $\square=%d$; amb aquesta arrel, "
   r"quocient $%s$ i residu $%s$"
   % (sumes_b[1], arrel_b, poli_tex_raw(pol(*q69b)), r_tex_raw(r69b))],
  ex_text=E69)

# 69c: dividend 1,0,-1,2, arrel square; residu final = 2 -> r^3-r=0
# r = -1, 0, 1; descartem 0 (divisió trivial); triem r=1 (com la font)
coefs_c, arrel_c = [1, 0, -1, 2], 1
_, sumes_c = ruffini_rows(coefs_c, arrel_c)
q69c, r69c = sumes_c[:-1], sumes_c[-1]

# L'equació de l'arrel té tres solucions (−1, 0 i 1). Abans l'enunciat no
# en triava cap, i □ = −1 i □ = 0, que són correctes, sortien com a errors
# de Ruffini. Ara la condició és a l'enunciat («positiva») i el segon
# distractor és un error de Ruffini de debò: restar en lloc de sumar.
_q69c_resta = [1, -1, 0]       # 1; 0-1·1; -1-(-1)·1 → quocient x²-x, residu 2
Q("69c", 69, "c", B2, tipus="A",
  enunciat=(r"Dividend $%s$, arrel $\square$ positiva (divisor desconegut); el "
   r"residu de la divisió és $%d$:" % (poli_tex_raw(pol(*coefs_c)), r69c)),
  correcta=r"$\square=%d$; " % arrel_c + qr_tex(pol(*q69c), r69c),
  distractors=[D(r"$\square=-1$; " + qr_tex(*div(pol(*coefs_c), pol(1, 1), x)),
     "CONDICIO_ENUNCIAT_IGNORADA",
     "Amb $\\square=-1$ el residu també surt $2$ (comprova-ho), però "
     "l'enunciat demana una arrel positiva."),
   D(r"$\square=%d$; " % arrel_c + qr_tex(pol(*_q69c_resta), r69c),
     "RUFFINI_PAS_MAL",
     "L'arrel és bona, però a cada columna has restat el producte en "
     "lloc de sumar-lo: $0+1\\cdot1=1$, no $0-1=-1$."),
   D(r"$\square=%d$; " % arrel_c + qr_tex(pol(*q69c), -r69c),
     "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El valor de $\\square$ és correcte, però el residu té el signe "
     "canviat.")],
  # Deia «el residu és □³−□, iguala'l a 2», que porta a □³−□−2 = 0, una
  # altra equació: el residu és □³−□+2, i igualat a 2 dona □³−□ = 0.
  pistes=[r"El residu final és $\square^3-\square+%d$ (arrossegant els termes de "
   r"la taula): iguala'l a $%d$ i resol l'equació de tercer grau."
   % (coefs_c[-1], r69c),
   r"$\square^3-\square=\square(\square-1)(\square+1)=0$ té tres "
   r"solucions. Quina és positiva?"],
  resolucio=[r"De $\square^3-\square=0$ surten $\square=-1,0,1$, i l'única "
   r"positiva és $\square=%d$: la taula dona quocient $%s$ i residu $%s$"
   % (arrel_c, poli_tex_raw(pol(*q69c)), r_tex_raw(r69c))],
  ex_text=E69,
  comentari="L'equació $\\square^3-\\square=0$ té tres solucions: $-1$, "
            "$0$ i $1$. Amb $\\square=0$ seria dividir per $x$, un cas "
            "trivial; amb $\\square=-1$ la taula també funciona (quocient "
            "$x^2-x$, residu $2$).")

# 69d: dividend square,0,0,-3, arrel -4; segona casella fila inferior = 8
# square*(-4)=8 -> square=-2
arrel_d = -4
square_d = -2
coefs_d = [square_d, 0, 0, -3]
_, sumes_d = ruffini_rows(coefs_d, arrel_d)
q69d, r69d = sumes_d[:-1], sumes_d[-1]

# Distractor: si s'hagués resolt malament el signe, square=2
_, sumes_d_mal = ruffini_rows([2, 0, 0, -3], arrel_d)
q69d_mal, r69d_mal = sumes_d_mal[:-1], sumes_d_mal[-1]

Q("69d", 69, "d", B2, tipus="A",
  enunciat=(r"Dividend $\square x^3+0x^2+0x-3$, divisor $x+4$; a la fila "
   r"inferior, la segona casella val $%d$:" % sumes_d[1]),
  correcta=r"$\square=%d$; " % square_d + qr_tex(pol(*q69d), r69d),
  distractors=[D(r"$\square=2$; " + qr_tex(pol(*q69d_mal), r69d_mal),
     "RUFFINI_SIGNE_ARREL",
     "Si $\\square\\cdot(-4)=8$, aïllant surt $\\square=-2$, no $2$: "
     "revisa el signe en resoldre l'equació."),
   D(r"$\square=%d$; " % square_d + qr_tex(pol(*q69d), -r69d),
     "DIVISIO_QUOCIENT_RESIDU_CANVIATS",
     "El valor de $\\square$ és correcte, però el residu té el signe "
     "canviat."),
   D(r"$\square=%d$; " % square_d + qr_tex(pol(q69d[0], q69d[1] - 4, q69d[2]), r69d),
     "RUFFINI_PAS_MAL",
     "El valor de $\\square$ és correcte, però algun pas posterior de "
     "la taula no s'ha completat bé.")],
  pistes=[r"La segona casella de la fila inferior és $\square\cdot(-4)$: "
   r"iguala-la a $%d$ i aïlla $\square$." % sumes_d[1],
   r"Amb $\square=%d$, completa la resta de la taula de Ruffini com "
   r"sempre." % square_d],
  resolucio=[r"De $\square\cdot(-4)=%d$ surt $\square=%d$; amb aquesta arrel, "
   r"quocient $%s$ i residu $%s$"
   % (sumes_d[1], square_d, poli_tex_raw(pol(*q69d)), r_tex_raw(r69d))],
  ex_text=E69)


# =====================================================================
# BLOC 3 — IGUALTATS NOTABLES (exercicis 70-72)
# =====================================================================

E70 = (r"Completa les igualtats notables següents, trobant els valors "
       r"que falten (marcats amb $\square$).")

# 70a: (2x+3)^2 = square + 12x + square -> 4x^2 i 9
Q("70a", 70, "a", B3, tipus="A",
  enunciat=r"$(2x+3)^2=\square+12x+\square$",
  correcta=r"$4x^2$ i $9$",
  distractors=[D(r"$2x^2$ i $9$", "IGUALTAT_NOTABLE_DOBLE_OBLIDAT",
     "El primer terme és el quadrat de $2x$, és a dir $(2x)^2=4x^2$, "
     "no $2x^2$."),
   D(r"$4x^2$ i $3$", "QUADRAT_INCOMPLET",
     "El segon terme és el quadrat de $3$, és a dir $3^2=9$, no $3$."),
   D(r"$2x$ i $9$", "IGUALTAT_NOTABLE_DOBLE_OBLIDAT",
     "El primer terme ha de ser el quadrat de $2x$, no $2x$ sense "
     "elevar al quadrat.")],
  pistes=[r"$(2x+3)^2=(2x)^2+2\cdot2x\cdot3+3^2$: el primer $\square$ és "
   r"$(2x)^2$ i el segon és $3^2$.",
   r"Comprova que el terme del mig, $2\cdot2x\cdot3=12x$, coincideix "
   r"amb el que ja hi ha a l'enunciat."],
  resolucio=[r"$(2x+3)^2=4x^2+12x+9$: el primer $\square$ és $4x^2$ i el segon "
   r"és $9$"],
  ex_text=E70)

# 70b: (5-3x)^2 = 25 - square + square x^2 -> 30x i 9
Q("70b", 70, "b", B3, tipus="A",
  enunciat=r"$(5-3x)^2=25-\square+\square x^2$",
  correcta=r"$30x$ i $9$",
  distractors=[D(r"$15x$ i $9$", "IGUALTAT_NOTABLE_DOBLE_OBLIDAT",
     "El terme del mig és el DOBLE producte, $2\\cdot5\\cdot3x=30x$, "
     "no només $5\\cdot3x=15x$."),
   D(r"$30x$ i $3$", "QUADRAT_INCOMPLET",
     "El coeficient de $x^2$ és el quadrat de $3$, és a dir $3^2=9$, "
     "no $3$."),
   D(r"$30x$ i $-9$", "IGUALTAT_NOTABLE_SIGNE",
     "El terme en $x^2$ és sempre positiu (és un quadrat): "
     "$(3x)^2=9x^2$, amb signe $+$.")],
  pistes=[r"$(5-3x)^2=5^2-2\cdot5\cdot3x+(3x)^2$: el primer $\square$ és el "
   r"doble producte i el segon és el coeficient del quadrat de $3x$.",
   r"Recorda que en un quadrat d'una diferència el terme del mig és "
   r"negatiu, però el terme en $x^2$ sempre és positiu."],
  resolucio=[r"$(5-3x)^2=25-30x+9x^2$: el primer $\square$ és $30x$ i el segon "
   r"és $9$"],
  ex_text=E70)

# 70c: (9+7x)(9-7x) = square - square -> 81 i 49x^2
Q("70c", 70, "c", B3, tipus="A",
  enunciat=r"$(9+7x)\cdot(9-7x)=\square-\square$",
  correcta=r"$81$ i $49x^2$",
  distractors=[D(r"$81$ i $7x^2$", "QUADRAT_INCOMPLET",
     "El segon terme és el quadrat de $7x$, és a dir $(7x)^2=49x^2$, "
     "no $7x^2$."),
   D(r"$9$ i $49x^2$", "QUADRAT_INCOMPLET",
     "El primer terme és el quadrat de $9$, és a dir $9^2=81$, no "
     "$9$."),
   D(r"$81$ i $63x$", "SUMA_PER_DIFERENCIA_MAL",
     "En una suma per diferència no queda cap terme en $x$ de grau "
     "$1$: el resultat és directament una resta de quadrats.")],
  pistes=[r"És una suma per diferència: $(a+b)(a-b)=a^2-b^2$, amb $a=9$ i "
   r"$b=7x$.",
   r"$(9+7x)(9-7x)=9^2-(7x)^2$."],
  resolucio=[r"$(9+7x)(9-7x)=81-49x^2$: el primer $\square$ és $81$ i el segon "
   r"és $49x^2$"],
  ex_text=E70)

# 70d: (square+square)^2 = x^4+2x^3+x^2 -> x^2 i x
Q("70d", 70, "d", B3, tipus="A",
  enunciat=r"$(\square+\square)^2=x^4+2x^3+x^2$",
  correcta=r"$x^2$ i $x$",
  distractors=[D(r"$x^2$ i $x^2$", "QUADRAT_INCOMPLET",
     "Amb $(x^2+x^2)^2=(2x^2)^2=4x^4$, no coincideix amb $x^4$: revisa "
     "els dos termes per separat."),
   D(r"$x$ i $x$", "GRAU_PRODUCTE_MAL",
     "Amb $(x+x)^2=(2x)^2=4x^2$, que no té ni grau $4$ ni grau $3$: "
     "el primer terme ha de ser de grau més alt."),
   D(r"$x^3$ i $x$", "GRAU_PRODUCTE_MAL",
     "El quadrat de $x^3$ ja seria $x^6$, de grau massa alt per "
     "encaixar amb $x^4+2x^3+x^2$.")],
  pistes=[r"Busca dos termes $a$ i $b$ tals que $a^2=x^4$, $b^2=x^2$, i "
   r"$2ab=2x^3$.",
   r"Si $a=x^2$ i $b=x$: $a^2=x^4$ ✓, $b^2=x^2$ ✓, $2ab=2x^2\cdot x"
   r"=2x^3$ ✓."],
  resolucio=[r"$x^4+2x^3+x^2=(x^2)^2+2\cdot x^2\cdot x+x^2=(x^2+x)^2$: els dos "
   r"$\square$ són $x^2$ i $x$"],
  ex_text=E70)


E71 = "Factoritza, reconeixent-hi una igualtat notable."


# Pistes de l'exercici 71, apartat per apartat. Abans eren les mateixes per
# als sis, i la segona («un cop identificat el patró, escriu-lo com a
# producte») no hi afegia res. Ara la primera fa reconèixer el patró amb els
# termes d'aquell apartat, i la segona dona l'eina sense fer la substitució.
_DIF_71 = "Són dos termes que es resten: mira si tots dos són quadrats perfectes."
_TRI_71 = "Té tres termes: mira si és el quadrat d'un binomi."
_FORM_71 = ("Una diferència de quadrats es factoritza així: "
            "$a^2-b^2=(a-b)(a+b)$, amb $a$ l'arrel de $%s$ i $b$ la de $%s$.")
_MIG_71 = ("$%s=(%s)^2$ i $%s=(%s)^2$. Comprova si el terme del mig, $%s$, és "
           "el doble producte $2\\cdot %s\\cdot %s$, i fixa't en el seu signe.")
pistes_71 = {
    "a": [_DIF_71 + " Quina és l'arrel quadrada de $16$?",
          _FORM_71 % ("x^2", "16")],
    "b": [_DIF_71 + " Quina expressió, elevada al quadrat, dona $x^4$?",
          _FORM_71 % ("x^4", "36")],
    "c": [_DIF_71 + " Quina expressió, elevada al quadrat, dona $4x^2$?",
          _FORM_71 % ("4x^2", "25")],
    "d": [_TRI_71 + " Els dels extrems, $x^2$ i $4$, són quadrats perfectes?",
          _MIG_71 % ("x^2", "x", "4", "2", "-4x", "x", "2")],
    "e": [_TRI_71 + " Els dels extrems, $16x^2$ i $9y^2$, són quadrats "
          "perfectes?",
          _MIG_71 % ("16x^2", "4x", "9y^2", "3y", "-24xy", "4x", "3y")],
    "f": [_TRI_71 + " Els dels extrems, $16x^4$ i $9$, són quadrats perfectes?",
          _MIG_71 % ("16x^4", "4x^2", "9", "3", "24x^2", "4x^2", "3")],
}


def item71(letra, expr, correcta_txt, dist_txts_amb_tag):
    """Genera l'ítem 71<letra>. dist_txts_amb_tag: llista de (text, tag,
    feedback)."""
    return Q("71%s" % letra, 71, letra, B3, tipus="A",
      enunciat=r"$%s$" % expr,
      correcta=r"$%s$" % correcta_txt,
      distractors=[D(r"$%s$" % t, tag, fb) for (t, tag, fb) in dist_txts_amb_tag],
      pistes=pistes_71[letra],
      resolucio=[r"$%s=%s$" % (expr, correcta_txt)],
      ex_text=E71)


item71("a", "x^2-16", "(x-4)(x+4)",
       [("(x-4)^2", "QUADRAT_INCOMPLET",
         "No és un quadrat perfecte (no hi ha terme en $x$ de grau $1$ "
         "a l'expressió original): és una diferència de quadrats, "
         "$x^2-4^2$."),
        ("(x-8)(x+8)", "DIFERENCIA_QUADRATS_MAL",
         "El segon nombre ha de ser l'arrel quadrada de $16$, que és "
         "$4$, no $8$."),
        ("(x-16)(x+16)", "DIFERENCIA_QUADRATS_MAL",
         "No es factoritza el $16$ tal qual: cal trobar-ne l'arrel "
         "quadrada, $4$.")])

item71("b", "x^4-36", "(x^2-6)(x^2+6)",
       [("(x^2-36)(x^2+36)", "DIFERENCIA_QUADRATS_MAL",
         "El segon nombre ha de ser l'arrel quadrada de $36$, que és "
         "$6$, no $36$."),
        ("(x-6)(x+6)", "GRAU_PRODUCTE_MAL",
         "El primer terme és $x^4=(x^2)^2$, no $x^2$: el primer factor "
         "ha de portar $x^2$, no $x$."),
        ("(x^2-6)^2", "QUADRAT_INCOMPLET",
         "No és un quadrat perfecte, sinó una diferència de quadrats: "
         "no hi ha terme del mig a l'expressió original.")])

item71("c", "4x^2-25", "(2x-5)(2x+5)",
       [("(4x-25)(4x+25)", "DIFERENCIA_QUADRATS_MAL",
         "El primer terme és $4x^2=(2x)^2$, no $(4x)^2$: revisa "
         "l'arrel quadrada de $4x^2$."),
        ("(2x-5)^2", "QUADRAT_INCOMPLET",
         "No és un quadrat perfecte: no hi ha terme del mig a "
         "l'expressió original, és una diferència de quadrats."),
        ("(2x-25)(2x+25)", "DIFERENCIA_QUADRATS_MAL",
         "El segon nombre ha de ser l'arrel quadrada de $25$, que és "
         "$5$, no $25$.")])

item71("d", "x^2-4x+4", "(x-2)^2",
       [("(x+2)^2", "IGUALTAT_NOTABLE_SIGNE",
         "El terme del mig, $-4x$, és negatiu: correspon a $(x-2)^2$, "
         "amb signe $-$ dins del parèntesi."),
        ("(x-4)(x+4)", "GRAUS_MAL_AGRUPATS",
         "Aquesta expressió té terme del mig ($-4x$): no és una "
         "diferència de quadrats, és un quadrat perfecte."),
        ("(x-2)(x+2)", "IGUALTAT_NOTABLE_SIGNE",
         "Els dos factors han de ser iguals (és un quadrat perfecte, "
         "$(x-2)^2$), no un de suma i un de resta.")])

item71("e", "16x^2-24xy+9y^2", "(4x-3y)^2",
       [("(4x+3y)^2", "IGUALTAT_NOTABLE_SIGNE",
         "El terme del mig, $-24xy$, és negatiu: correspon a "
         "$(4x-3y)^2$, amb signe $-$ dins del parèntesi."),
        ("(4x-3y)(4x+3y)", "GRAUS_MAL_AGRUPATS",
         "Aquesta expressió té terme del mig ($-24xy$): no és una "
         "diferència de quadrats, és un quadrat perfecte."),
        ("(4x-9y)^2", "QUADRAT_INCOMPLET",
         "El segon terme del binomi ha de ser l'arrel quadrada de "
         "$9y^2$, que és $3y$, no $9y$.")])

item71("f", "16x^4+24x^2+9", "(4x^2+3)^2",
       [("(4x^2-3)^2", "IGUALTAT_NOTABLE_SIGNE",
         "El terme del mig, $+24x^2$, és positiu: correspon a "
         "$(4x^2+3)^2$, amb signe $+$ dins del parèntesi."),
        ("(4x^2+3)(4x^2-3)", "GRAUS_MAL_AGRUPATS",
         "Aquesta expressió té terme del mig ($+24x^2$): no és una "
         "diferència de quadrats, és un quadrat perfecte."),
        ("(8x^2+3)^2", "QUADRAT_INCOMPLET",
         "El primer terme del binomi ha de ser l'arrel quadrada de "
         "$16x^4$, que és $4x^2$, no $8x^2$.")])


E72 = (r"Segueix el patró $[(x+2)+3]\cdot[(x+2)-3]=(x+2)^2-9$ per "
       r"escriure el producte com una resta de quadrats, sense "
       r"necessitat de desenvolupar-ho tot.")

Q("72a", 72, "a", B3, tipus="A",
  enunciat=r"$[(3x-y)+4]\cdot[(3x-y)-4]$",
  correcta=r"$(3x-y)^2-16$",
  distractors=[D(r"$(3x-y)^2-4$", "QUADRAT_INCOMPLET",
     "El segon terme s'ha d'elevar al quadrat: $4^2=16$, no $4$."),
   D(r"$(3x-y)^2+16$", "SUMA_PER_DIFERENCIA_MAL",
     "En una suma per diferència, el segon quadrat sempre resta, mai "
     "suma: $(a+b)(a-b)=a^2-b^2$."),
   D(r"$9x^2-y^2-16$", "GRAUS_MAL_AGRUPATS",
     "El primer terme s'ha de deixar com el quadrat de tot el binomi "
     "$(3x-y)$, no només de la $x$: $(3x-y)^2\\neq 9x^2-y^2$.")],
  pistes=[r"Identifica el «primer terme» comú als dos factors i el «segon» que "
   r"canvia de signe: aquí són $(3x-y)$ i $4$.",
   r"Segueix el patró de l'enunciat: el primer terme al quadrat menys el "
   r"segon al quadrat. Compte a elevar també el $4$."],
  resolucio=[r"$[(3x-y)+4]\cdot[(3x-y)-4]=(3x-y)^2-16$ (desenvolupat del tot: "
   r"$9x^2-6xy+y^2-16$)"],
  ex_text=E72)

Q("72b", 72, "b", B3, tipus="A",
  enunciat=r"$[(a+b)+c]\cdot[(a+b)-c]$",
  correcta=r"$(a+b)^2-c^2$",
  distractors=[D(r"$(a+b)^2-c$", "QUADRAT_INCOMPLET",
     "El segon terme s'ha d'elevar al quadrat: és $c^2$, no $c$."),
   D(r"$(a+b)^2+c^2$", "SUMA_PER_DIFERENCIA_MAL",
     "En una suma per diferència, el segon quadrat sempre resta, mai "
     "suma."),
   D(r"$a^2+b^2-c^2$", "GRAUS_MAL_AGRUPATS",
     "El primer terme s'ha de deixar com el quadrat de tot el binomi "
     "$(a+b)$, no desenvolupat ni separat.")],
  pistes=[r"Identifica el «primer terme» comú i el «segon» que canvia de "
   r"signe: aquí són $(a+b)$ i $c$.",
   r"Segueix el patró de l'enunciat: el primer terme al quadrat menys el "
   r"segon al quadrat. El primer terme, $(a+b)$, es deixa sencer, sense "
   r"desenvolupar."],
  resolucio=[r"$[(a+b)+c]\cdot[(a+b)-c]=(a+b)^2-c^2$ (desenvolupat del tot: "
   r"$a^2+2ab+b^2-c^2$)"],
  ex_text=E72)


# =====================================================================
# BLOC 4 — FACTOR COMÚ I SIMPLIFICACIÓ (exercicis 73-74)
# =====================================================================

E73 = "Treu factor comú."

Q("73a", 73, "a", B4, tipus="A",
  enunciat=r"$3x^2-4x$",
  correcta=r"$x(3x-4)$",
  distractors=[D(r"$x(3x-4x)$", "FACTOR_COMU_MAL_DIVIDIT",
     "En treure el factor $x$, el segon terme, $-4x$, s'ha de dividir "
     "també per $x$: queda $-4$, no $-4x$."),
   D(r"$3x(x-4)$", "FACTOR_COMU_INCOMPLET",
     "El factor comú dels dos termes és $x$, no $3x$: el $3$ només "
     "apareix al primer terme."),
   D(r"$x(3x^2-4x)$", "FACTOR_COMU_MAL_DIVIDIT",
     "Dins del parèntesi els termes no s'han dividit pel factor comú "
     "$x$: haurien de quedar $3x$ i $-4$.")],
  pistes=["Busca què es repeteix als dos termes, $3x^2$ i $-4x$: el factor "
   "comú és $x$.",
   "Divideix cada terme pel factor comú i escriu el resultat dins del "
   "parèntesi."],
  resolucio=[r"$3x^2-4x=x\cdot(3x-4)$"],
  ex_text=E73)

Q("73b", 73, "b", B4, tipus="A",
  enunciat=r"$(x+1)+3(x+1)$",
  correcta=r"$4(x+1)$",
  distractors=[D(r"$(x+1)(3x+3)$", "DISTRIBUCIO_INCOMPLETA",
     "Els dos termes són $(x+1)$ i $3(x+1)$: el factor comú $(x+1)$ "
     "es treu un sol cop, i queda $1+3=4$ dins de l'altre parèntesi."),
   D(r"$3(x+1)$", "TERME_OBLIDAT_OPERACIO",
     "T'has deixat el primer $(x+1)$ (que compta com $1$ vegada el "
     "binomi): el total és $1+3=4$ vegades $(x+1)$, no $3$."),
   D(r"$4x+1$", "DISTRIBUCIO_INCOMPLETA",
     "El $4$ ha de multiplicar TOT el binomi $(x+1)$, no només la "
     "$x$: és $4(x+1)=4x+4$.")],
  pistes=[r"El binomi $(x+1)$ es repeteix als dos termes: el primer és "
   r"$1\cdot(x+1)$ i el segon $3\cdot(x+1)$.",
   r"Treu $(x+1)$ com a factor comú: queda $(1+3)\cdot(x+1)$."],
  resolucio=[r"$(x+1)+3(x+1)=(1+3)(x+1)=4(x+1)$"],
  ex_text=E73)

Q("73c", 73, "c", B4, tipus="A",
  enunciat=r"$xy-6xyz-5xyzt$",
  correcta=r"$xy(1-6z-5zt)$",
  distractors=[D(r"$xy(1-6zt-5zt)$", "FACTOR_COMU_MAL_DIVIDIT",
     "El segon terme dins del parèntesi ha de quedar $-6z$ (dividint "
     "$-6xyz$ per $xy$), no $-6zt$: revisa quin terme porta la $t$."),
   D(r"$xyz(1-6-5t)$", "FACTOR_COMU_INCOMPLET",
     "El primer terme, $xy$, no té el factor $z$: el factor comú als "
     "tres termes és $xy$, no $xyz$."),
   D(r"$xy(-1-6z-5zt)$", "FACTOR_COMU_SIGNE",
     "El primer terme dins del parèntesi ha de ser $+1$ (dividint "
     "$xy$ per $xy$), no $-1$.")],
  pistes=["Busca el factor que es repeteix als tres termes: $xy$, $-6xyz$ i "
   "$-5xyzt$ tenen en comú $xy$.",
   "Divideix cada terme pel factor comú $xy$: queden $1$, $-6z$ i "
   "$-5zt$."],
  resolucio=[r"$xy-6xyz-5xyzt=xy\cdot(1-6z-5zt)$"],
  ex_text=E73)

Q("73d", 73, "d", B4, tipus="A",
  enunciat=r"$3x-4x^2-6x^3$",
  correcta=r"$x(3-4x-6x^2)$",
  distractors=[D(r"$x(3-4x^2-6x^3)$", "FACTOR_COMU_MAL_DIVIDIT",
     "Els termes de dins del parèntesi s'han de dividir per $x$: "
     "$-4x^2:x=-4x$ i $-6x^3:x=-6x^2$, no es queden igual."),
   D(r"$x^3(3-4x-6x^2)$", "FACTOR_COMU_INCOMPLET",
     "El primer terme, $3x$, només té una $x$: el factor comú és $x$, "
     "no $x^3$."),
   D(r"$x(3x-4x^2-6x^3)$", "FACTOR_COMU_MAL_DIVIDIT",
     "El primer terme dins del parèntesi s'ha de dividir per $x$: "
     "$3x:x=3$, no $3x$.")],
  pistes=["Busca el factor comú als tres termes: $3x$, $-4x^2$ i $-6x^3$ "
   "tenen en comú $x$.",
   "Divideix cada terme per $x$: queden $3$, $-4x$ i $-6x^2$."],
  resolucio=[r"$3x-4x^2-6x^3=x\cdot(3-4x-6x^2)$"],
  ex_text=E73)


# «Factoritza» i no «simplifica»: a l'ESO, «simplificar» un polinomi sovint
# vol dir operar i reduir, i amb aquella paraula el 74h acabava donant per
# bona la forma desenvolupada mentre el 74e i el 74f la donaven per dolenta.
# Els vuit apartats demanen el mateix: deixar-lo com a producte.
E74 = ("Factoritza al màxim, combinant factor comú i igualtats "
       "notables quan calgui.")

Q("74a", 74, "a", B4, tipus="A",
  enunciat=r"$7x^2-14x+7$",
  correcta=r"$7(x-1)^2$",
  distractors=[D(r"$7(x-1)$", "GRAU_PRODUCTE_MAL",
     "Un cop tret el factor $7$, queda $x^2-2x+1$, que és un quadrat "
     "perfecte, $(x-1)^2$: no es pot deixar sense el quadrat."),
   D(r"$7(x+1)^2$", "IGUALTAT_NOTABLE_SIGNE",
     "El terme del mig, $-14x$, és negatiu: correspon a $(x-1)^2$, "
     "amb signe $-$."),
   D(r"$(7x-7)^2$", "FACTOR_COMU_INCOMPLET",
     "El $7$ s'ha de treure com a factor comú abans de reconèixer el "
     "quadrat perfecte, no ficar-lo dins del quadrat.")],
  pistes=["Els tres coeficients ($7$, $-14$ i $7$) són múltiples de $7$: "
   "treu-lo factor comú.",
   "Dins del parèntesi queda $x^2-2x+1$. Mira si és el quadrat d'un "
   "binomi: $a^2-2ab+b^2=(a-b)^2$."],
  resolucio=[r"$7x^2-14x+7=7(x^2-2x+1)=7(x-1)^2$"],
  ex_text=E74)

Q("74b", 74, "b", B4, tipus="A",
  enunciat=r"$16x^2+64x+64$",
  correcta=r"$16(x+2)^2$",
  distractors=[D(r"$16(x+2)$", "GRAU_PRODUCTE_MAL",
     "Un cop tret el factor $16$, queda $x^2+4x+4$, que és un quadrat "
     "perfecte, $(x+2)^2$: no es pot deixar sense el quadrat."),
   D(r"$16(x-2)^2$", "IGUALTAT_NOTABLE_SIGNE",
     "El terme del mig, $+64x$, és positiu: correspon a $(x+2)^2$, "
     "amb signe $+$."),
   D(r"$8(x+2)^2$", "FACTOR_COMU_INCOMPLET",
     "El factor comú de $16$, $64$ i $64$ és $16$, no $8$.")],
  pistes=["Els tres coeficients ($16$, $64$ i $64$) són múltiples de $16$: "
   "treu-lo factor comú.",
   "Dins del parèntesi queda $x^2+4x+4$. Mira si és el quadrat d'un "
   "binomi: $a^2+2ab+b^2=(a+b)^2$."],
  resolucio=[r"$16x^2+64x+64=16(x^2+4x+4)=16(x+2)^2$"],
  ex_text=E74)

Q("74c", 74, "c", B4, tipus="A",
  enunciat=r"$x^3-2x^2+x$",
  correcta=r"$x(x-1)^2$",
  distractors=[D(r"$x(x-1)$", "GRAU_PRODUCTE_MAL",
     "Un cop tret el factor $x$, queda $x^2-2x+1$, que és un quadrat "
     "perfecte, $(x-1)^2$: no es pot deixar sense el quadrat."),
   D(r"$x(x+1)^2$", "IGUALTAT_NOTABLE_SIGNE",
     "El terme del mig, $-2x^2$ (un cop tret el factor $x$, $-2x$), "
     "és negatiu: correspon a $(x-1)^2$, amb signe $-$."),
   D(r"$(x-1)^2$", "FACTOR_COMU_INCOMPLET",
     "T'has deixat el factor comú $x$: els tres termes ($x^3$, "
     "$-2x^2$, $x$) el tenen en comú.")],
  pistes=["Els tres termes porten $x$: treu-la factor comú.",
   "Dins del parèntesi queda $x^2-2x+1$. Mira si és el quadrat d'un "
   "binomi: $a^2-2ab+b^2=(a-b)^2$."],
  resolucio=[r"$x^3-2x^2+x=x(x^2-2x+1)=x(x-1)^2$"],
  ex_text=E74)

Q("74d", 74, "d", B4, tipus="A",
  enunciat=r"$18x^4-12x^2+2$",
  correcta=r"$2(3x^2-1)^2$",
  distractors=[D(r"$2(3x^2-1)$", "GRAU_PRODUCTE_MAL",
     "Un cop tret el factor $2$, queda $9x^4-6x^2+1$, que és un "
     "quadrat perfecte, $(3x^2-1)^2$: no es pot deixar sense el "
     "quadrat."),
   D(r"$2(3x^2+1)^2$", "IGUALTAT_NOTABLE_SIGNE",
     "El terme del mig, $-6x^2$ (un cop tret el $2$), és negatiu: "
     "correspon a $(3x^2-1)^2$, amb signe $-$."),
   D(r"$6(3x^2-1)^2$", "FACTOR_COMU_INCOMPLET",
     "El factor comú de $18$, $-12$ i $2$ és $2$, no $6$.")],
  pistes=["Els tres coeficients ($18$, $-12$ i $2$) són múltiples de $2$: "
   "treu-lo factor comú.",
   "Dins del parèntesi queda $9x^4-6x^2+1$, i $9x^4=(3x^2)^2$. Mira si "
   "és el quadrat d'un binomi: $a^2-2ab+b^2=(a-b)^2$."],
  resolucio=[r"$18x^4-12x^2+2=2(9x^4-6x^2+1)=2(3x^2-1)^2$"],
  ex_text=E74)

Q("74e", 74, "e", B4, tipus="A",
  enunciat=r"$(2x+4)(x-2)$",
  correcta=r"$2(x-2)(x+2)$",
  distractors=[D(r"$2x^2-8$", "FACTORITZACIO_DESFETA",
     "El desenvolupament és correcte, però l'has deixat desenvolupat i es "
     "demana factoritzat: $2x^2-8=2(x^2-4)=2(x-2)(x+2)$."),
   D(r"$(x-2)(x+2)$", "FACTOR_COMU_INCOMPLET",
     "T'has deixat el factor comú $2$: el desenvolupament dona "
     "$2x^2-8=2(x^2-4)$, no $x^2-4$."),
   D(r"$2(x+2)^2$", "DIFERENCIA_QUADRATS_MAL",
     "Un cop desenvolupat i tret el factor $2$, queda $x^2-4$, que és "
     "una DIFERÈNCIA de quadrats, $(x-2)(x+2)$, no un quadrat "
     "perfecte.")],
  pistes=["Desenvolupa primer el producte: "
   "$(2x+4)(x-2)=2x^2-4x+4x-8=2x^2-8$.",
   "Treu el factor comú de $2x^2-8$ i mira què queda dins del "
   "parèntesi: és una diferència de quadrats, $a^2-b^2=(a-b)(a+b)$."],
  resolucio=[r"$(2x+4)(x-2)=2x^2-8=2(x^2-4)=2(x-2)(x+2)$"],
  ex_text=E74)

Q("74f", 74, "f", B4, tipus="A",
  enunciat=r"$(x-5)(x^2+5x)$",
  correcta=r"$x(x-5)(x+5)$",
  distractors=[D(r"$x^3-25x$", "FACTORITZACIO_DESFETA",
     "El desenvolupament és correcte, però l'has deixat desenvolupat i es "
     "demana factoritzat: $x^3-25x=x(x^2-25)=x(x-5)(x+5)$."),
   D(r"$(x-5)(x+5)$", "FACTOR_COMU_INCOMPLET",
     "T'has deixat el factor comú $x$: el desenvolupament dona "
     "$x^3-25x=x(x^2-25)$, no $x^2-25$."),
   D(r"$x(x-5)^2$", "DIFERENCIA_QUADRATS_MAL",
     "Un cop tret el factor $x$, queda $x^2-25$, que és una "
     "DIFERÈNCIA de quadrats, $(x-5)(x+5)$, no un quadrat perfecte.")],
  pistes=["Desenvolupa primer el producte: "
   "$(x-5)(x^2+5x)=x^3+5x^2-5x^2-25x=x^3-25x$.",
   "Treu el factor comú de $x^3-25x$ i mira què queda dins del "
   "parèntesi: és una diferència de quadrats ($25=5^2$)."],
  resolucio=[r"$(x-5)(x^2+5x)=x^3-25x=x(x^2-25)=x(x-5)(x+5)$"],
  ex_text=E74)

Q("74g", 74, "g", B4, tipus="A",
  enunciat=r"$(-x-7)(x-7)$",
  correcta=r"$(7-x)(7+x)$",
  distractors=[D(r"$(x-7)(x+7)$", "IGUALTAT_NOTABLE_SIGNE",
     "El primer factor és $-x-7=-(x+7)$, no $x-7$: el signe global "
     "canvia el resultat final."),
   D(r"$x^2-49$", "IGUALTAT_NOTABLE_SIGNE",
     "El desenvolupament correcte dona $49-x^2$, no $x^2-49$: revisa "
     "el signe global en treure el $-1$ comú del primer factor."),
   D(r"$-(7-x)(7+x)$", "FACTOR_COMU_SIGNE",
     "Hi sobra un signe menys: en treure el $-1$ comú de $-x-7$ i "
     "reordenar-ho a $(7-x)(7+x)$, aquest menys ja s'ha fet servir. "
     "Comprova-ho amb $x=0$: l'expressió original val $+49$.")],
  pistes=[r"Treu primer el signe menys comú del primer factor: "
   r"$-x-7=-(x+7)$.",
   r"Queda $-(x+7)(x-7)$. Desenvolupa la suma per diferència, aplica-hi "
   r"el signe menys i torna a factoritzar el que surti."],
  resolucio=[r"$(-x-7)(x-7)=-(x+7)(x-7)=49-x^2=(7-x)(7+x)$"],
  ex_text=E74)

# La resposta era $x^4-25$ i la forma factoritzada, $(x^2-5)(x^2+5)$, sortia
# com a error: just el contrari que al 74e i al 74f, i amb dues expressions
# iguals. Ara la bona és la factoritzada, com a la resta de l'exercici.
Q("74h", 74, "h", B4, tipus="A",
  enunciat=r"$(-x^2+5)(-x^2-5)$",
  correcta=r"$(x^2-5)(x^2+5)$",
  distractors=[D(r"$x^4-25$", "FACTORITZACIO_DESFETA",
     "És el mateix polinomi, però desenvolupat, i es demana factoritzat. "
     "A més, $x^4-25$ és una diferència de quadrats: $(x^2)^2-5^2$."),
   D(r"$(5-x^2)(5+x^2)$", "FACTOR_COMU_SIGNE",
     "Això val $25-x^4$, i l'expressió de partida val $x^4-25$: comprova-ho "
     "amb $x=0$, que dona $5\\cdot(-5)=-25$. Cada factor porta el seu signe "
     "menys, $-x^2+5=-(x^2-5)$ i $-x^2-5=-(x^2+5)$, i els dos es compensen."),
   D(r"$(x^2-5)^2$", "DIFERENCIA_QUADRATS_MAL",
     "Els dos factors no són iguals: un és $x^2-5$ i l'altre $x^2+5$. "
     "Només seria un quadrat si fossin el mateix.")],
  pistes=[r"Treu el signe menys de cada factor: $-x^2+5=-(x^2-5)$ i "
   r"$-x^2-5=-(x^2+5)$.",
   r"Els dos signes menys es compensen. Mira si el que queda encara es "
   r"pot factoritzar amb nombres enters."],
  resolucio=[r"$(-x^2+5)(-x^2-5)=\big(-(x^2-5)\big)\big(-(x^2+5)\big)=(x^2-5)(x^2+5)$",
   r"$x^2-5$ no és una diferència de quadrats amb enters ($5$ no és un "
   r"quadrat perfecte) i $x^2+5$ és una suma: ja no es pot factoritzar més. "
   r"Desenvolupat, seria $x^4-25$."],
  ex_text=E74)


# =====================================================================
# NIVELL TRIVIAL (exercicis 327-331)
# =====================================================================
# `operacions` obria sumant QUATRE polinomis, un d'ells de grau 5 — el
# primer exercici de tot el Full 4 — i a tot el bloc no hi havia cap suma
# de dos binomis. `divisio` obria amb una divisió llarga de grau 5 entre
# grau 2, i Ruffini no arribava fins al 66.

dificultats({
    327: 1,  # suma i resta de dos binomis
    328: 1,  # un monomi per un parèntesi
    329: 1,  # divisió per un monomi
    330: 1,  # el residu pel teorema del residu, sense dividir
    331: 2,  # Ruffini amb divisor x-1: és un algorisme, encara que curt
})


E327 = "Fes les operacions amb aquests polinomis i simplifica el resultat."

Q("327a", 327, "a", B1, tipus="A",
  enunciat=r"$(3x+2)+(x-5)$",
  correcta="$4x-3$",
  distractors=[D("$4x+7$", "SIGNE_SUMA",
     "Has sumat el $5$ en lloc de restar-lo: el segon parèntesi porta "
     "$-5$, i $2+(-5)=-3$."),
   D("$3x-3$", "TERME_OBLIDAT_OPERACIO",
     "T'has deixat la $x$ del segon parèntesi. Una $x$ sola val $1x$: "
     "$3x+1x=4x$."),
   D("$4x^2-3$", "GRAUS_MAL_AGRUPATS",
     "En sumar termes semblants, els exponents NO se sumen: $3x+x=4x$, no "
     "$4x^2$. El que se sumen són els coeficients.")],
  pistes=["Ajunta les $x$ amb les $x$ i els números amb els números.",
   "$3x+x=4x$ i $2-5=-3$."],
  resolucio=[r"$(3x+2)+(x-5)=3x+x+2-5=4x-3$"],
  ex_text=E327)

Q("327b", 327, "b", B1, tipus="A",
  enunciat=r"$(x^2+4x)+(2x^2-x)$",
  correcta="$3x^2+3x$",
  distractors=[D("$3x^2+5x$", "SIGNE_SUMA",
     "Has sumat la $x$ del segon parèntesi en lloc de restar-la: "
     "$4x-x=3x$."),
   D("$3x^4+3x^2$", "EXPONENTS_SUMATS_QUOCIENT",
     "Els exponents no se sumen en sumar: $x^2+2x^2=3x^2$, i l'exponent es "
     "queda en $2$."),
   D("$6x^3$", "TERMES_NO_REDUITS",
     "Has ajuntat termes que no són semblants. $x^2$ i $x$ són graus "
     "diferents i no es poden sumar entre ells.")],
  pistes=["Només se sumen els termes del MATEIX grau.",
   "Els de grau 2 entre ells ($x^2+2x^2$) i els de grau 1 entre ells "
   "($4x-x$)."],
  resolucio=[r"$(x^2+4x)+(2x^2-x)=(x^2+2x^2)+(4x-x)=3x^2+3x$"],
  ex_text=E327)

Q("327c", 327, "c", B1, tipus="A",
  enunciat=r"$(5x-1)-(2x+3)$",
  correcta="$3x-4$",
  distractors=[DT("$3x+2$", "PARENTESI_NO_DISTRIBUIT_POLI",
      extra="El menys de davant del parèntesi afecta TOTS dos termes: "
            "$-(2x+3)=-2x-3$, de manera que $-1-3=-4$."),
   D("$7x-4$", "SIGNE_SUMA",
     "Has sumat les $x$ en lloc de restar-les: $5x-2x=3x$."),
   D("$3x-2$", "ORDRE_RESTA",
     "Revisa els termes sense $x$: és $-1-3$, que fa $-4$.")],
  pistes=["Un menys davant d'un parèntesi canvia el signe de tot el que hi ha a "
   "dins.",
   "$-(2x+3)=-2x-3$."],
  resolucio=[r"$(5x-1)-(2x+3)=5x-1-2x-3=3x-4$"],
  ex_text=E327)

Q("327d", 327, "d", B1, tipus="A",
  enunciat=r"$(x^2-2)-(x^2+6)$",
  correcta="$-8$",
  distractors=[DT("$4$", "PARENTESI_NO_DISTRIBUIT_POLI",
      extra="El $+6$ es converteix en $-6$ en treure el parèntesi: "
            "$-2-6=-8$."),
   D("$2x^2-8$", "SIGNE_SUMA",
     "Has sumat els $x^2$ en lloc de restar-los. $x^2-x^2=0$, i el terme "
     "desapareix."),
   D("$-4$", "ORDRE_RESTA",
     "Revisa la resta dels números: $-2-6=-8$.")],
  pistes=["Compte: els dos $x^2$ es cancel·len.",
   "$x^2-x^2=0$; només queden els números."],
  resolucio=[r"$(x^2-2)-(x^2+6)=x^2-2-x^2-6=-8$"],
  ex_text=E327,
  # Comentari i no nota: abans de respondre, «la resposta pot no tenir x»
  # descartava el distractor 2x^2-8.
  comentari="Sí, la resposta pot no tenir $x$: quan els termes d'un grau "
            "es cancel·len, aquell grau desapareix del resultat.")


E328 = "Aplica la propietat distributiva i simplifica."

Q("328a", 328, "a", B1, tipus="A",
  enunciat=r"$2x(x+3)$",
  correcta="$2x^2+6x$",
  distractors=[DT("$2x^2+3$", "DISTRIBUCIO_INCOMPLETA",
      extra="El $2x$ ha de multiplicar els DOS termes de dins: també el $3$."),
   D("$2x^2+6$", "DISTRIBUCIO_INCOMPLETA",
     "Has multiplicat bé els números ($2\\cdot 3=6$) però hi has perdut la "
     "$x$: $2x\\cdot 3=6x$."),
   D("$2x+6x$", "GRAU_PRODUCTE_MAL",
     "$2x\\cdot x=2x^2$: en multiplicar dues $x$, els exponents se sumen i "
     "el grau puja.")],
  pistes=["El $2x$ multiplica cada terme de dins del parèntesi.",
   "$2x\\cdot x=2x^2$ i $2x\\cdot 3=6x$."],
  resolucio=[r"$2x(x+3)=2x\cdot x+2x\cdot 3=2x^2+6x$"],
  ex_text=E328)

Q("328b", 328, "b", B1, tipus="A",
  enunciat=r"$-3(x^2-2x)$",
  correcta="$-3x^2+6x$",
  distractors=[D("$-3x^2-6x$", "SIGNE_PRODUCTE",
     "Menys per menys fa més: $-3\\cdot(-2x)=+6x$."),
   DT("$-3x^2+2x$", "DISTRIBUCIO_INCOMPLETA",
      extra="Al segon terme t'ha faltat multiplicar pel $3$: "
            "$-3\\cdot(-2x)=6x$."),
   D("$3x^2-6x$", "SIGNE_FINAL",
     "Has canviat de signe tot el resultat. El primer terme és "
     "$-3\\cdot x^2=-3x^2$, negatiu.")],
  pistes=["El $-3$ multiplica els dos termes, amb el seu signe.",
   "$-3\\cdot x^2=-3x^2$ i $-3\\cdot(-2x)=+6x$."],
  resolucio=[r"$-3(x^2-2x)=-3x^2+6x$"],
  ex_text=E328)


E329 = "Fes la divisió."

Q("329a", 329, "a", B2, tipus="A",
  enunciat=r"$6x^3:2x$",
  correcta="$3x^2$",
  distractors=[D("$3x^3$", "EXPONENT_SENSE_DESPLACAR",
     "Els coeficients van bé ($6:2=3$), però els exponents també es "
     "resten: $x^3:x^1=x^{3-1}=x^2$."),
   D("$3x^4$", "EXPONENTS_SUMATS_QUOCIENT",
     "En dividir, els exponents es RESTEN: $3-1=2$."),
   D("$4x^2$", "COEFICIENT_MAL_TRIAT",
     "Has restat els coeficients ($6-2$). Els coeficients es divideixen: "
     "$6:2=3$. Els que es resten són els exponents.")],
  pistes=["Divideix els coeficients i resta els exponents.",
   "$6:2=3$ i $x^3:x=x^2$."],
  resolucio=[r"$6x^3:2x=\dfrac{6}{2}\,x^{3-1}=3x^2$"],
  ex_text=E329)

Q("329b", 329, "b", B2, tipus="A",
  enunciat=r"$(x^4+x^3):x^2$",
  correcta="$x^2+x$",
  distractors=[D("$x^6+x^5$", "EXPONENTS_SUMATS_QUOCIENT",
     "En dividir, els exponents es resten: $4-2=2$ i $3-2=1$."),
   D("$x^2$", "TERME_OBLIDAT_OPERACIO",
     "Has dividit només el primer terme. Cada terme del dividend s'ha de "
     "dividir pel monomi."),
   D("$x^2+x^3$", "EXPONENT_SENSE_DESPLACAR",
     "Al segon terme no has restat l'exponent: $x^3:x^2=x$.")],
  pistes=["Divideix cada terme del numerador pel monomi.",
   "$x^4:x^2=x^2$ i $x^3:x^2=x$."],
  resolucio=[r"$(x^4+x^3):x^2=\dfrac{x^4}{x^2}+\dfrac{x^3}{x^2}=x^2+x$"],
  ex_text=E329)


E330 = ("Fent servir el teorema del residu, troba quant val el residu "
        "d'aquesta divisió.")

Q("330a", 330, "a", B2, tipus="A",
  enunciat=r"$(x^2-3x+2):(x-1)$",
  correcta="0",
  distractors=[DT("6", "RUFFINI_SIGNE_ARREL",
      extra="Has avaluat a $x=-1$. El divisor és $x-1$, o sigui $a=+1$."),
   DT("2", "TERME_INDEPENDENT_IGNORAT",
      extra="Has donat el terme independent del polinomi sense avaluar-lo."),
   D("1", "RUFFINI_RESIDU_COM_QUOCIENT",
     "L'$1$ és el valor de $a$, no el residu. El residu és $P(1)$.")],
  pistes=["El divisor és $x-1$: el valor que s'ha de substituir és $a=1$.",
   "Calcula $P(1)=1^2-3\\cdot 1+2$."],
  resolucio=[r"$P(1)=1-3+2=0$; el residu és $0$, o sigui que la divisió és exacta"],
  ex_text=E330)

Q("330b", 330, "b", B2, tipus="A",
  enunciat=r"$(x^3+1):(x+1)$",
  correcta="0",
  distractors=[DT("2", "RUFFINI_SIGNE_ARREL",
      extra="Has avaluat a $x=1$. El divisor és $x+1$, que és $x-(-1)$: "
            "$a=-1$."),
   DT("1", "TERME_INDEPENDENT_IGNORAT",
      extra="Has donat el terme independent sense avaluar."),
   D("-1", "RUFFINI_SIGNE_ARREL",
     "El $-1$ és el valor de $a$, no el residu: el residu és $P(-1)$.")],
  pistes=["$x+1$ es llegeix com $x-(-1)$: el valor a substituir és $-1$.",
   "Calcula $P(-1)=(-1)^3+1$."],
  resolucio=[r"$P(-1)=(-1)^3+1=-1+1=0$; la divisió és exacta"],
  ex_text=E330)

Q("330c", 330, "c", B2, tipus="A",
  enunciat=r"$(x^2+x+5):(x-2)$",
  correcta="11",
  distractors=[DT("7", "RUFFINI_SIGNE_ARREL",
      extra="Has avaluat a $x=-2$: $4-2+5=7$. El divisor és $x-2$, o sigui "
            "$a=+2$."),
   DT("5", "TERME_INDEPENDENT_IGNORAT",
      extra="Has donat el terme independent sense avaluar-hi res."),
   D("0", "RUFFINI_RESIDU_COM_QUOCIENT",
     "No totes les divisions són exactes: aquí el residu no és zero. "
     "Calcula $P(2)$ i comprova-ho.")],
  pistes=["El divisor és $x-2$: substitueix $x=2$.",
   "$P(2)=2^2+2+5$."],
  resolucio=[r"$P(2)=4+2+5=11$; el residu és $11$"],
  ex_text=E330,
  nota_interna="El terme en x hi és a posta: amb x^2+5, P(2) i P(-2) valen "
               "igual i el distractor RUFFINI_SIGNE_ARREL no detectaria res. "
               "Mateix criteri que 323c de c_potencies.")


E331 = ("Aplica la regla de Ruffini i digues quin és el polinomi quocient "
        "d'aquesta divisió.")

Q("331a", 331, "a", B2, tipus="A",
  enunciat=r"$(x^2-3x+2):(x-1)$",
  correcta="$x-2$",
  distractors=[DT("$x+2$", "RUFFINI_SIGNE_ARREL",
      extra="Has baixat un $-1$ a la caixa de Ruffini. Amb divisor $x-1$ "
            "hi va $+1$."),
   DT("$x^2-2$", "RUFFINI_QUOCIENT_GRAU",
      extra="El quocient té un grau MENYS que el dividend: de grau 2 es "
            "passa a grau 1."),
   D("$x-3$", "RUFFINI_PAS_MAL",
     "Has copiat el coeficient $-3$ del dividend. A Ruffini, el segon "
     "coeficient del quocient és $-3+1=-2$.")],
  pistes=["Posa els coeficients $1$, $-3$, $2$ a la fila de dalt i, a "
   "l'esquerra, l'arrel del divisor: amb $x-1$, és $1$.",
   "Baixa el primer coeficient, multiplica'l per l'arrel i suma'l al "
   "següent: $-3+1\\cdot1$. Els números de baix, menys l'últim, són els "
   "coeficients del quocient."],
  resolucio=[r"Ruffini amb $a=1$: $1$, $-3+1=-2$, $2+(-2)=0$. "
   r"Quocient $x-2$ i residu $0$."],
  ex_text=E331)


# =====================================================================
# NIVELL TRIVIAL (exercicis 348-349)
# =====================================================================
# «Igualtats notables» obria factoritzant ($x^2-16$), que és anar a
# l'inrevés. «Factor comú» obria amb $3x^2-4x$, on el factor és una $x$.
# Aquí, el desenvolupament directe d'un quadrat amb la fórmula al davant, i
# un factor comú que és un nombre o una sola $x$.

dificultats({
    348: 1,  # desenvolupar (x+a)^2 o (x-a)^2 amb a d'una xifra
    349: 1,  # factor comú d'un binomi amb un factor evident
})


E348 = ("Desenvolupa aquesta igualtat notable. Recorda: "
        r"$(a+b)^2=a^2+2ab+b^2$ i $(a-b)^2=a^2-2ab+b^2$.")

Q("348a", 348, "a", B3, tipus="A",
  enunciat=r"$(x+3)^2$",
  correcta=r"$x^2+6x+9$",
  distractors=[DT(r"$x^2+9$", "QUADRAT_INCOMPLET",
      extra="T'has deixat el terme del mig, el doble producte $2\\cdot x\\cdot3$."),
   DT(r"$x^2+3x+9$", "IGUALTAT_NOTABLE_DOBLE_OBLIDAT"),
   DT(r"$x^2-6x+9$", "IGUALTAT_NOTABLE_SIGNE",
      extra="Aquí és una SUMA: el terme del mig és positiu.")],
  pistes=["Aquí $a=x$ i $b=3$.",
   "$x^2+2\\cdot x\\cdot3+3^2$."],
  resolucio=[r"$(x+3)^2=x^2+2\cdot x\cdot3+3^2=x^2+6x+9$"],
  ex_text=E348)

Q("348b", 348, "b", B3, tipus="A",
  enunciat=r"$(x-5)^2$",
  correcta=r"$x^2-10x+25$",
  distractors=[DT(r"$x^2+10x+25$", "IGUALTAT_NOTABLE_SIGNE"),
   DT(r"$x^2-25$", "QUADRAT_INCOMPLET",
      extra="Has elevat cada terme al quadrat i t'has deixat el doble "
            "producte. A més, $(-5)^2=+25$."),
   DT(r"$x^2-5x+25$", "IGUALTAT_NOTABLE_DOBLE_OBLIDAT")],
  pistes=["Aquí $a=x$ i $b=5$, i és el quadrat d'una RESTA.",
   "$x^2-2\\cdot x\\cdot5+5^2$."],
  resolucio=[r"$(x-5)^2=x^2-2\cdot x\cdot5+5^2=x^2-10x+25$"],
  ex_text=E348)


E349 = ("Treu factor comú en aquesta expressió: escriu-la com el factor "
        "que es repeteix multiplicat per un parèntesi.")

Q("349a", 349, "a", B4, tipus="A",
  enunciat=r"$5x+10$",
  correcta=r"$5(x+2)$",
  distractors=[DT(r"$5(x+10)$", "FACTOR_COMU_MAL_DIVIDIT",
      extra="El $10$ també s'ha de dividir per $5$."),
   D(r"$2(x+5)$", "FACTOR_COMU_MAL_DIVIDIT",
     "Si desfàs el parèntesi, $2(x+5)=2x+10$, que no és $5x+10$. El "
     "factor comú és el $5$."),
   D(r"$15x$", "GRAUS_MAL_AGRUPATS",
     "$5x$ i $10$ no són termes semblants (un porta $x$ i l'altre no): no "
     "es poden sumar.")],
  pistes=["Quin nombre divideix el $5$ i el $10$ alhora?",
   "Divideix cada terme per $5$ i posa el resultat dins del parèntesi."],
  resolucio=[r"$5x=5\cdot x$ i $10=5\cdot2$",
   r"$5x+10=5(x+2)$"],
  ex_text=E349)

Q("349b", 349, "b", B4, tipus="A",
  enunciat=r"$x^2+7x$",
  correcta=r"$x(x+7)$",
  distractors=[DT(r"$x(x^2+7)$", "FACTOR_COMU_MAL_DIVIDIT",
      extra="$x^2$ dividit per $x$ és $x$, no $x^2$."),
   D(r"$x(x+7x)$", "FACTOR_COMU_MAL_DIVIDIT",
     "$7x$ dividit per $x$ és $7$: la $x$ ja és fora del parèntesi."),
   D(r"$8x^3$", "GRAUS_MAL_AGRUPATS",
     "$x^2$ i $7x$ no són termes semblants (tenen graus diferents): no es "
     "poden sumar.")],
  pistes=["Quina lletra es repeteix als dos termes?",
   "Divideix cada terme per $x$ i posa el resultat dins del parèntesi."],
  resolucio=[r"$x^2=x\cdot x$ i $7x=x\cdot7$",
   r"$x^2+7x=x(x+7)$"],
  ex_text=E349)
