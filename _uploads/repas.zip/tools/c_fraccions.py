# -*- coding: utf-8 -*-
"""Bloc C — Fraccions. Exercicis 18–25 del Full 1 (41 ítems)."""

from fractions import Fraction as F
from lib import Q, D, DT, TAX, ev, tex, mcd, dificultats

# --------------------------------------------------------------------
# Dificultat de cada exercici (1 trivial, 2 directa, 3 encadenada,
# 4 completa). Vegeu l'escala completa i la frontera entre nivells
# a lib.py.
# Full 1 · fraccions
# Vegeu l'escala completa a lib.py. L'itinerari fa servir aquest camp
# per graduar el recorregut, de manera que canviar-hi un número canvia
# l'ordre en què l'alumne es troba els exercicis.
# --------------------------------------------------------------------
dificultats({
     18: 2,  # comprovar equivalència; 20, simplificar; 22, enter ± fracció
     19: 3,  # a l'inrevés: quin nombre falta perquè siguin equivalents
     20: 2,
     21: 3,  # parèntesis niats, i 23-25 barregen suma, producte i enters
     22: 2,
     23: 3,
     24: 3,
     25: 3,
})


B = "fraccions"

TAX["CRITERI_FALS"] = (
    "Que dues fraccions es puguin simplificar no vol dir que siguin equivalents: "
    "cal que totes dues simplifiquin a la MATEIXA fracció irreductible.")
TAX["NO_SIMPLIFICABLE"] = (
    "Sí que es pot: encara que el denominador sigui primer, pot ser un factor "
    "del numerador. Comprova sempre si el denominador divideix el numerador.")


def fr(a, b):
    """LaTeX d'una fracció tal com surt al full (sense simplificar)."""
    return r"\dfrac{%d}{%d}" % (a, b)


def FQ(qid, ex, ap, enunciat, expr, parts, variants, pistes, ex_text, final=None):
    """Ítem de càlcul amb fraccions: la resposta i tots els distractors
    surten d'avaluar expressions, mai de teclejar el resultat."""
    c = ev(expr)
    res = []
    if parts:
        res.append("Calculem cada tros: " +
                   r" \quad ".join("$%s = %s$" % (l, tex(ev(p))) for l, p in parts))
    if final:
        res.append(final)
    res.append("Resultat: $%s$" % tex(c))
    Q(qid, ex, ap, B, tipus="A", enunciat=enunciat, correcta=c,
      distractors=[DT(ev(e), t, x) for e, t, x in variants], pistes=pistes, resolucio=res, ex_text=ex_text)


# =============================================================== Exercici 18
E18 = "Digues si són equivalents els parells de fraccions següents."


def item_equiv(qid, ap, a, b, c, d):
    eq = a * d == b * c
    latex = "$%s$ i $%s$" % (fr(a, b), fr(c, d))
    if eq:
        correcta = r"Sí, perquè $%d\cdot %d = %d\cdot %d$." % (a, d, b, c)
        ds = [
            D(r"No, perquè els numeradors i els denominadors no coincideixen.",
              "COMPARA_TERMES", TAX["COMPARA_TERMES"]),
            D(r"No, perquè $%d\cdot %d \ne %d\cdot %d$." % (a, c, b, d),
              "PRODUCTES_MAL_CREUATS", TAX["PRODUCTES_MAL_CREUATS"]),
            D(r"No, perquè no s'hi suma el mateix als dos termes.",
              "RAONAMENT_ADDITIU", TAX["RAONAMENT_ADDITIU"]),
        ]
    else:
        correcta = r"No, perquè $%d\cdot %d \ne %d\cdot %d$." % (a, d, b, c)
        ds = [
            D(r"Sí, perquè els productes creuats donen el mateix.",
              "PRODUCTES_CREUATS",
              r"Comprova-ho: $%d\cdot %d = %d$ i $%d\cdot %d = %d$. No coincideixen."
              % (a, d, a * d, b, c, b * c)),
            D(r"Sí, perquè d'una a l'altra s'hi suma el mateix.",
              "RAONAMENT_ADDITIU", TAX["RAONAMENT_ADDITIU"]),
            D(r"Sí, perquè totes dues es poden simplificar.",
              "CRITERI_FALS", TAX["CRITERI_FALS"]),
        ]
    Q(qid, 18, ap, B, tipus="B", enunciat=latex, correcta=correcta, distractors=ds,
      pistes=["Dues fraccions són equivalents si els productes creuats coincideixen: "
       r"$\dfrac{a}{b} = \dfrac{c}{d}$ quan $a\cdot d = b\cdot c$.",
       r"Aquí compara $%d\cdot %d$ amb $%d\cdot %d$.%s" % (
           a, d, b, c,
           # Si cap no se simplifica (18c, 18f), l'alternativa no ajuda.
           "" if F(a, b).denominator == b and F(c, d).denominator == d else
           " Si et costa, simplifica totes dues fraccions i compara-les.")],
      resolucio=[r"Productes creuats: $%d\cdot %d = %d$ \quad i \quad $%d\cdot %d = %d$"
       % (a, d, a * d, b, c, b * c),
       (r"Coincideixen, o sigui que són equivalents: totes dues valen $%s$."
        % tex(F(a, b))) if eq else
       # «$\dfrac54$ val $\dfrac54$» (18c, 18f): si no se simplifiquen, no
       # hi ha res a dir del que valen.
       (r"No coincideixen, o sigui que no són equivalents%s." % (
           "" if F(a, b).denominator == b and F(c, d).denominator == d else
           r": simplificades, són $%s$ i $%s$" % (tex(F(a, b)), tex(F(c, d)))))],
      ex_text=E18)


item_equiv("18a", "a", 6, 3, 36, 48)
item_equiv("18b", "b", 15, 12, 60, 48)
item_equiv("18c", "c", 5, 4, 15, 8)
item_equiv("18d", "d", 8, 5, 24, 10)
item_equiv("18e", "e", 9, 13, 72, 104)
item_equiv("18f", "f", 72, 25, 123, 115)

# =============================================================== Exercici 19
E19 = "Calcula el nombre que falta perquè les fraccions siguin equivalents."

Q("19a", 19, "a", B, tipus="A", enunciat=r"$\dfrac{6}{\square} = \dfrac{9}{3}$", correcta=2,
  distractors=[DT(ev("9*3/6"), "CREUAMENT_INVERTIT",
      r"De $6\cdot 3 = 9\cdot\square$ surt $\square = \dfrac{6\cdot 3}{9}$."),
   DT(ev("6*3"), "PRODUCTE_MAL", ""),
   DT(3, "COMPARA_TERMES",
      "Has copiat el denominador de l'altra fracció.")],
  pistes=[r"Aplica els productes creuats: $6\cdot 3 = 9\cdot\square$.",
   r"$\dfrac{9}{3}$ val $3$, o sigui que $\dfrac{6}{\square}$ també ha de valer $3$."],
  resolucio=[r"$6\cdot 3 = 9\cdot \square \;\Rightarrow\; 18 = 9\cdot\square$",
   r"$\square = 18 : 9 = 2$",
   r"Comprovació: $\dfrac{6}{2} = 3 = \dfrac{9}{3}$"],
  ex_text=E19)

Q("19b", 19, "b", B, tipus="A", enunciat=r"$\dfrac{4}{5} = \dfrac{\square}{10}$", correcta=8,
  distractors=[DT(9, "RAONAMENT_ADDITIU",
      r"De $5$ a $10$ no s'hi suma $5$: es multiplica per $2$."),
   DT(ev("4*10"), "PRODUCTE_MAL", ""),
   DT(ev("5*10/4"), "CREUAMENT_INVERTIT", "")],
  pistes=[r"De $5$ a $10$, per quant s'ha multiplicat el denominador?",
   "El que facis al denominador, fes-ho al numerador."],
  resolucio=[r"$5\cdot 2 = 10$, o sigui que el numerador també es multiplica per $2$.",
   r"$\square = 4\cdot 2 = 8$",
   r"Comprovació: $\dfrac{8}{10} = \dfrac{4}{5}$"],
  ex_text=E19)

Q("19c", 19, "c", B, tipus="A", enunciat=r"$\dfrac{8}{12} = \dfrac{2}{\square}$", correcta=3,
  distractors=[DT(6, "RAONAMENT_ADDITIU",
      r"De $8$ a $2$ no s'hi resta $6$: es divideix entre $4$."),
   DT(ev("2*12"), "PRODUCTE_MAL", ""),
   DT(ev("8*2/12"), "CREUAMENT_INVERTIT", "")],
  pistes=[r"De $8$ a $2$, per quant s'ha dividit el numerador?",
   "Divideix el denominador pel mateix nombre."],
  resolucio=[r"$8 : 4 = 2$, o sigui que el denominador també es divideix entre $4$.",
   r"$\square = 12 : 4 = 3$",
   r"Comprovació: $\dfrac{2}{3} = \dfrac{8}{12}$"],
  ex_text=E19)

Q("19d", 19, "d", B, tipus="A", enunciat=r"$\dfrac{\square}{9} = \dfrac{8}{18}$", correcta=4,
  distractors=[DT(ev("8*18/9"), "CREUAMENT_INVERTIT",
      r"De $\square\cdot 18 = 9\cdot 8$ surt $\square = \dfrac{9\cdot 8}{18}$."),
   DT(ev("8*9"), "PRODUCTE_MAL", ""),
   DT(ev("9*18/8"), "CREUAMENT_INVERTIT", "")],
  pistes=[r"$18$ és el doble de $9$: què li passa al numerador?",
   r"$\square\cdot 18 = 9\cdot 8$."],
  resolucio=[r"$\square\cdot 18 = 9\cdot 8 = 72$",
   r"$\square = 72 : 18 = 4$",
   r"Comprovació: $\dfrac{4}{9} = \dfrac{8}{18}$"],
  ex_text=E19)

# =============================================================== Exercici 20
E20 = "Calcula la fracció irreductible."

Q("20a", 20, "a", B, tipus="A", enunciat=r"$\dfrac{75}{30}$", correcta=F(5, 2),
  distractors=[DT(r"\dfrac{25}{10}", "SIMPLIFICACIO_INCOMPLETA", "Has dividit només entre $3$."),
   DT(r"\dfrac{15}{6}", "SIMPLIFICACIO_INCOMPLETA", "Has dividit només entre $5$."),
   DT(F(2, 5), "INVERTIDA", "")],
  pistes=[r"Busca el $\operatorname{m.c.d.}(75, 30)$ i divideix-hi els dos termes.",
   r"$75 = 3\cdot 5^{2}$ i $30 = 2\cdot 3\cdot 5$, o sigui que el m.c.d. és $15$."],
  resolucio=[r"$\operatorname{m.c.d.}(75,30) = 15$",
   r"$\dfrac{75:15}{30:15} = \dfrac{5}{2}$"],
  ex_text=E20)

Q("20b", 20, "b", B, tipus="A", enunciat=r"$\dfrac{182}{48}$", correcta=F(91, 24),
  distractors=[DT(F(91, 48), "SIMPLIFICA_NOMES_NUMERADOR", ""),
   DT(F(24, 91), "INVERTIDA", ""),
   DT(F(13, 24), "SIMPLIFICA_NOMES_NUMERADOR",
      r"Has dividit el numerador entre $7$, però $24$ no és múltiple de $7$.")],
  pistes=[r"$182$ i $48$ són parells: quin és el m.c.d.?",
   r"$182 = 2\cdot 7\cdot 13$ i $48 = 2^{4}\cdot 3$: només comparteixen un $2$."],
  resolucio=[r"$\operatorname{m.c.d.}(182,48) = 2$",
   r"$\dfrac{182:2}{48:2} = \dfrac{91}{24}$",
   r"$91 = 7\cdot 13$ i $24 = 2^{3}\cdot 3$ ja no tenen factors comuns."],
  ex_text=E20)

Q("20c", 20, "c", B, tipus="A", enunciat=r"$\dfrac{121}{11}$", correcta=11,
  distractors=[D(r"No es pot simplificar, perquè $11$ és primer.", "NO_SIMPLIFICABLE",
     TAX["NO_SIMPLIFICABLE"] + r" Aquí $121 = 11^{2}$."),
   DT(F(1, 11), "INVERTIDA", ""),
   DT(110, "SIMPLIFICAR_RESTANT",
      r"Has restat $121-11$. Simplificar és DIVIDIR els dos termes pel mateix nombre.")],
  pistes=[r"$121$ és el quadrat d'un nombre: de quin?",
   r"Escriu $121$ com a producte i simplifica el factor que comparteix amb "
   r"el denominador. Si a baix queda un $1$, la fracció és un nombre enter."],
  resolucio=[r"$\dfrac{121}{11} = \dfrac{11\cdot 11}{11} = 11$",
   r"El resultat és un enter: la fracció irreductible és $\dfrac{11}{1} = 11$."],
  ex_text=E20)

# =============================================================== Exercici 21
E21 = "Fes les operacions."
P21 = ["Resol primer cada parèntesi per separat.",
       "Redueix a denominador comú: multiplica cada numerador pel mateix nombre "
       "que el seu denominador."]

FQ("21a", 21, "a",
   r"$\left(\dfrac{1}{2} + \dfrac{3}{6}\right) - \left(\dfrac{4}{5} + \dfrac{7}{3}\right)$",
   "(1/2+3/6) - (4/5+7/3)",
   [(r"\dfrac{1}{2}+\dfrac{3}{6}", "1/2+3/6"), (r"\dfrac{4}{5}+\dfrac{7}{3}", "4/5+7/3")],
   [("(1/2+3/6) - 4/5 + 7/3", "MENYS_PARENTESI", ""),
    ("(1+3)/(2+6) - (4+7)/(5+3)", "SUMA_NUMERADORS", ""),
    ("(4/5+7/3) - (1/2+3/6)", "SIGNE_FINAL", "Has restat a l'inrevés.")],
   P21, E21, final=r"Queda $1 - \dfrac{47}{15}$.")

FQ("21b", 21, "b",
   r"$\left(\dfrac{7}{3} - \dfrac{4}{5}\right) + \left(\dfrac{6}{5} + \dfrac{2}{7}\right)$",
   "(7/3-4/5) + (6/5+2/7)",
   [(r"\dfrac{7}{3}-\dfrac{4}{5}", "7/3-4/5"), (r"\dfrac{6}{5}+\dfrac{2}{7}", "6/5+2/7")],
   [("(7-4)/(3-5) + (6+2)/(5+7)", "SUMA_NUMERADORS", ""),
    ("(23+52)/105", "NUMERADORS_SENSE_AJUSTAR",
     r"Amb denominador $105$: $\dfrac{23}{15} = \dfrac{161}{105}$, no $\dfrac{23}{105}$."),
    ("(7/3-4/5) - (6/5+2/7)", "SIGNE_FINAL", "El segon parèntesi se suma, no es resta.")],
   P21, E21)

FQ("21c", 21, "c",
   r"$2 - \left[\dfrac{4}{3} - \left(\dfrac{1}{2} + \dfrac{2}{5}\right) - \dfrac{1}{3}\right]$",
   "2 - (4/3 - (1/2+2/5) - 1/3)",
   [(r"\dfrac{1}{2}+\dfrac{2}{5}", "1/2+2/5"),
    (r"\dfrac{4}{3}-\dfrac{9}{10}-\dfrac{1}{3}", "4/3-9/10-1/3")],
   [("2 - (4/3 - 1/2 + 2/5 - 1/3)", "MENYS_PARENTESI", ""),
    ("2 - (4/3 - (1+2)/(2+5) - 1/3)", "SUMA_NUMERADORS", ""),
    ("2 + (4/3 - (1/2+2/5) - 1/3)", "SIGNE_FINAL",
     "El claudàtor se suma quan hauria de restar-se.")],
   ["Comença pel parèntesi de més endins.",
    r"$\dfrac{4}{3}$ i $-\dfrac{1}{3}$ es poden ajuntar de seguida."],
   E21, final=r"Queda $2 - \dfrac{1}{10}$.")

FQ("21d", 21, "d",
   r"$\left(\dfrac{5}{4} - \dfrac{1}{5}\right) + \left(\dfrac{-1}{3} + \dfrac{2}{5} - \dfrac{1}{4}\right)$",
   "(5/4-1/5) + (-1/3+2/5-1/4)",
   [(r"\dfrac{5}{4}-\dfrac{1}{5}", "5/4-1/5"),
    (r"\dfrac{-1}{3}+\dfrac{2}{5}-\dfrac{1}{4}", "-1/3+2/5-1/4")],
   [("(21-11)/60", "NUMERADORS_SENSE_AJUSTAR",
     r"Amb denominador $60$: $\dfrac{21}{20} = \dfrac{63}{60}$."),
    ("(5/4-1/5) + (-1/3+2/5+1/4)", "SIGNE_SUMA",
     r"L'últim terme del segon parèntesi és $-\dfrac{1}{4}$."),
    ("(5/4-1/5) + (-1+2-1)/(3+5+4)", "SUMA_NUMERADORS", "")],
   P21, E21)

FQ("21e", 21, "e",
   r"$\left(\dfrac{6}{5} - \dfrac{1}{15}\right) + 2 - \left(\dfrac{1}{2} - \dfrac{1}{3} + \dfrac{5}{6}\right)$",
   "(6/5-1/15) + 2 - (1/2-1/3+5/6)",
   [(r"\dfrac{6}{5}-\dfrac{1}{15}", "6/5-1/15"),
    (r"\dfrac{1}{2}-\dfrac{1}{3}+\dfrac{5}{6}", "1/2-1/3+5/6")],
   [("(6-1)/15 + 2 - (1/2-1/3+5/6)", "NUMERADORS_SENSE_AJUSTAR",
     r"Amb denominador $15$: $\dfrac{6}{5} = \dfrac{18}{15}$."),
    ("(6/5-1/15) + 2 + (1/2-1/3+5/6)", "SIGNE_FINAL",
     "L'últim parèntesi es resta."),
    ("(6/5-1/15) + 2 - (1+1+5)/(2+3+6)", "SUMA_NUMERADORS", "")],
   P21, E21)

FQ("21f", 21, "f",
   r"$\left(\dfrac{1}{3} + \dfrac{2}{5}\right) - \dfrac{1}{4} - \left(\dfrac{5}{6} - \dfrac{7}{6}\right)$",
   "(1/3+2/5) - 1/4 - (5/6-7/6)",
   [(r"\dfrac{1}{3}+\dfrac{2}{5}", "1/3+2/5"), (r"\dfrac{5}{6}-\dfrac{7}{6}", "5/6-7/6")],
   [("(1/3+2/5) - 1/4 - 5/6 - 7/6", "MENYS_PARENTESI", ""),
    ("(1+2)/(3+5) - 1/4 - (5/6-7/6)", "SUMA_NUMERADORS", ""),
    ("(1/3+2/5) - 1/4 + (5/6-7/6)", "SIGNE_FINAL",
     r"L'últim parèntesi val $-\dfrac{1}{3}$ i es resta: $-\left(-\dfrac{1}{3}\right) = +\dfrac{1}{3}$.")],
   ["L'últim parèntesi dóna un nombre negatiu: vigila el doble signe.",
    r"$\dfrac{5}{6}-\dfrac{7}{6} = -\dfrac{1}{3}$, i restar-lo és sumar $\dfrac{1}{3}$."],
   E21)

# =============================================================== Exercici 22
E22 = "Fes aquestes operacions."

FQ("22a", 22, "a", r"$-3 + \dfrac{4}{9}$", "-3 + 4/9", [],
   [("(-3+4)/9", "ENTER_AL_NUMERADOR", ""),
    ("3 - 4/9", "SIGNE_FINAL", ""),
    ("-3 - 4/9", "SIGNE_SUMA", "")],
   [r"Escriu l'enter com una fracció amb el mateix denominador que l'altra: aquí, $9$.",
    r"$-3=-\dfrac{27}{9}$: el signe es manté. Ara suma els numeradors."], E22, final=r"$-3 = -\dfrac{27}{9}$, o sigui $-\dfrac{27}{9} + \dfrac{4}{9}$.")

FQ("22b", 22, "b", r"$8 - \left(-\dfrac{2}{5}\right)$", "8 - (-2/5)", [],
   [("8 - 2/5", "RESTA_NEGATIU", ""),
    ("(8-2)/5", "ENTER_AL_NUMERADOR", ""),
    ("-(8 + 2/5)", "SIGNE_FINAL", "")],
   [r"Primer el doble signe: restar $-\dfrac{2}{5}$ és sumar $\dfrac{2}{5}$.",
    r"Escriu el $8$ amb denominador $5$ i suma els numeradors."], E22, final=r"Restar $-\dfrac{2}{5}$ és sumar $\dfrac{2}{5}$: $\dfrac{40}{5}+\dfrac{2}{5}$.")

FQ("22c", 22, "c", r"$\dfrac{-3}{7} + (-8)$", "-3/7 + (-8)", [],
   [("-3/7 + 8", "SIGNE_SUMA", ""),
    ("(-3-8)/7", "ENTER_AL_NUMERADOR", ""),
    ("3/7 + 8", "SIGNE_FINAL", "")],
   [r"Sumar $(-8)$ és el mateix que restar $8$.",
    r"Escriu el $8$ amb denominador $7$ i opera els numeradors, cadascun amb el seu signe."], E22, final=r"$-8 = -\dfrac{56}{7}$.")

FQ("22d", 22, "d", r"$\dfrac{5}{4} - (-7)$", "5/4 - (-7)", [],
   [("5/4 - 7", "RESTA_NEGATIU", ""),
    ("(5+7)/4", "ENTER_AL_NUMERADOR", ""),
    ("-(5/4 + 7)", "SIGNE_FINAL", "")],
   [r"Primer el doble signe: restar $-7$ és sumar $7$.",
    r"Escriu el $7$ amb denominador $4$ i suma els numeradors."], E22, final=r"$7 = \dfrac{28}{4}$.")

FQ("22e", 22, "e", r"$\dfrac{-4}{3} + (-6)$", "-4/3 + (-6)", [],
   [("-4/3 + 6", "SIGNE_SUMA", ""),
    ("(-4-6)/3", "ENTER_AL_NUMERADOR", ""),
    ("4/3 + 6", "SIGNE_FINAL", "")],
   [r"Sumar $(-6)$ és el mateix que restar $6$.",
    r"Escriu el $6$ amb denominador $3$ i opera els numeradors: tots dos termes són negatius."], E22, final=r"$-6 = -\dfrac{18}{3}$.")

FQ("22f", 22, "f", r"$-\left(\dfrac{-3}{4}\right) - 2$", "-(-3/4) - 2", [],
   [("-3/4 - 2", "DOBLE_NEGATIU", ""),
    ("(3-2)/4", "ENTER_AL_NUMERADOR", ""),
    ("-(3/4) + 2", "SIGNE_FINAL", "")],
   ["Comença desfent el doble signe menys.",
    r"$-\left(-\dfrac{3}{4}\right) = +\dfrac{3}{4}$."],
   E22, final=r"Queda $\dfrac{3}{4} - \dfrac{8}{4}$.")

# =============================================================== Exercici 23
E23 = "Opera."

FQ("23a", 23, "a", r"$\dfrac{1}{3} - 2 - \left(-\dfrac{4}{9}\right)$",
   "1/3 - 2 - (-4/9)", [],
   [("1/3 - 2 - 4/9", "RESTA_NEGATIU", ""),
    ("(1-2+4)/9", "ENTER_AL_NUMERADOR", ""),
    ("-(1/3 - 2 - (-4/9))", "SIGNE_FINAL", "")],
   ["Restar una fracció negativa és sumar-la.",
    r"Denominador comú $9$: $\dfrac{3}{9} - \dfrac{18}{9} + \dfrac{4}{9}$."],
   E23)

FQ("23b", 23, "b", r"$\dfrac{5}{2} - \left(-2 + \dfrac{3}{5}\right)$",
   "5/2 - (-2 + 3/5)", [(r"-2+\dfrac{3}{5}", "-2+3/5")],
   [("5/2 + 2 + 3/5", "MENYS_PARENTESI", ""),
    ("5/2 - 2 + 3/5", "PARENTESI_NO_DISTRIBUIT", ""),
    ("-(5/2 - (-2 + 3/5))", "SIGNE_FINAL", "")],
   ["Resol primer el parèntesi, o distribueix-hi el signe menys.",
    r"$-2+\dfrac{3}{5} = -\dfrac{7}{5}$, i restar-ho és sumar $\dfrac{7}{5}$."],
   E23)

FQ("23c", 23, "c", r"$4 - \left(\dfrac{2}{3} - \dfrac{1}{4}\right)$",
   "4 - (2/3 - 1/4)", [(r"\dfrac{2}{3}-\dfrac{1}{4}", "2/3-1/4")],
   [("4 - 2/3 - 1/4", "MENYS_PARENTESI", ""),
    ("4 - (2-1)/(3-4)", "SUMA_NUMERADORS", ""),
    ("-(4 - (2/3 - 1/4))", "SIGNE_FINAL", "")],
   ["Resol el parèntesi abans de restar-lo a $4$.",
    r"$\dfrac{2}{3}-\dfrac{1}{4} = \dfrac{8-3}{12}$."],
   E23)

FQ("23d", 23, "d", r"$-7 + \left(-\dfrac{3}{2} + \dfrac{1}{7}\right)$",
   "-7 + (-3/2 + 1/7)", [(r"-\dfrac{3}{2}+\dfrac{1}{7}", "-3/2+1/7")],
   [("-7 + 3/2 + 1/7", "SIGNE_SUMA", ""),
    ("-7 - 3/2 - 1/7", "SIGNE_SUMA",
     r"L'últim terme del parèntesi és $+\dfrac{1}{7}$."),
    ("-(-7 + (-3/2 + 1/7))", "SIGNE_FINAL", "")],
   ["El parèntesi va precedit d'un $+$: els signes de dins no canvien.",
    r"Denominador comú $14$."],
   E23)

# =============================================================== Exercici 24
E24 = "Efectua les operacions."

FQ("24a", 24, "a", r"$\dfrac{5}{6} \cdot \dfrac{1}{3} - 2$", "5/6*1/3 - 2",
   [(r"\dfrac{5}{6}\cdot\dfrac{1}{3}", "5/6*1/3")],
   [("5/6*(1/3 - 2)", "JERARQUIA", ""),
    ("(5*3)/(6*1) - 2", "PRODUCTE_CREUAT", ""),
    ("-(5/6*1/3 - 2)", "SIGNE_FINAL", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$\dfrac{5}{6}\cdot\dfrac{1}{3}$: numerador per numerador i denominador per denominador. Després escriu el $2$ amb el mateix denominador."], E24)

FQ("24b", 24, "b", r"$\dfrac{7}{2} - 3 \cdot \dfrac{4}{5}$", "7/2 - 3*4/5",
   [(r"3\cdot\dfrac{4}{5}", "3*4/5")],
   [("(7/2 - 3)*4/5", "JERARQUIA", ""),
    ("7/2 - 12/15", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-(7/2 - 3*4/5)", "SIGNE_FINAL", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$3\cdot\dfrac{4}{5}$: l'enter multiplica només el numerador, no el denominador. Després resta amb denominador comú."], E24)

FQ("24c", 24, "c", r"$4 - \dfrac{3}{2} \cdot \dfrac{7}{9}$", "4 - 3/2*7/9",
   [(r"\dfrac{3}{2}\cdot\dfrac{7}{9}", "3/2*7/9")],
   [("(4 - 3/2)*7/9", "JERARQUIA", ""),
    ("4 - (3*9)/(2*7)", "PRODUCTE_CREUAT", ""),
    ("-(4 - 3/2*7/9)", "SIGNE_FINAL", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$\dfrac{3}{2}\cdot\dfrac{7}{9}$: pots simplificar el $3$ amb el $9$ abans de multiplicar. Després escriu el $4$ amb el mateix denominador."], E24)

FQ("24d", 24, "d", r"$\dfrac{5}{2} - 3 \cdot \dfrac{1}{4}$", "5/2 - 3*1/4",
   [(r"3\cdot\dfrac{1}{4}", "3*1/4")],
   [("(5/2 - 3)*1/4", "JERARQUIA", ""),
    ("5/2 - 3/12", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-(5/2 - 3*1/4)", "SIGNE_FINAL", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$3\cdot\dfrac{1}{4}$: l'enter multiplica només el numerador, no el denominador. Després resta amb denominador comú."], E24)

FQ("24e", 24, "e",
   r"$\dfrac{4}{5} \cdot \dfrac{10}{8} + \left(\dfrac{-3}{2}\right)$",
   "4/5*10/8 + (-3/2)", [(r"\dfrac{4}{5}\cdot\dfrac{10}{8}", "4/5*10/8")],
   [("(4*8)/(5*10) + (-3/2)", "PRODUCTE_CREUAT", ""),
    ("4/5*10/8 + 3/2", "SUMA_EN_LLOC_RESTA", ""),
    ("-(4/5*10/8 + (-3/2))", "SIGNE_FINAL", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$\dfrac{4}{5}\cdot\dfrac{10}{8}$: simplifica abans de multiplicar (el $4$ amb el $8$ i el $10$ amb el $5$). Després suma-hi $-\dfrac{3}{2}$."], E24)

FQ("24f", 24, "f",
   r"$\dfrac{7}{9} \cdot \left(\dfrac{-12}{5}\right) + \left(\dfrac{-3}{4}\right)$",
   "7/9*(-12/5) + (-3/4)", [(r"\dfrac{7}{9}\cdot\dfrac{-12}{5}", "7/9*(-12/5)")],
   [("7/9*(12/5) + (-3/4)", "SIGNE_PRODUCTE", ""),
    ("(7*5)/(9*(-12)) + (-3/4)", "PRODUCTE_CREUAT", ""),
    ("7/9*(-12/5) + 3/4", "SUMA_EN_LLOC_RESTA", "")],
   [r"Primer la multiplicació, després la suma o la resta.",
    r"$\dfrac{7}{9}\cdot\left(-\dfrac{12}{5}\right)$ és negatiu, i pots simplificar el $12$ amb el $9$. Després suma-hi $-\dfrac{3}{4}$ amb denominador comú."], E24)

# =============================================================== Exercici 25
E25 = "Fes les operacions següents."

FQ("25a", 25, "a",
   r"$\dfrac{5}{3} - \left(\dfrac{2}{5} \cdot \dfrac{7}{2}\right) - \dfrac{1}{3}$",
   "5/3 - (2/5*7/2) - 1/3", [(r"\dfrac{2}{5}\cdot\dfrac{7}{2}", "2/5*7/2")],
   [("(5/3 - 2/5)*7/2 - 1/3", "JERARQUIA", ""),
    ("5/3 - (2*2)/(5*7) - 1/3", "PRODUCTE_CREUAT", ""),
    ("-(5/3 - (2/5*7/2) - 1/3)", "SIGNE_FINAL", "")],
   [r"$\dfrac{5}{3}$ i $-\dfrac{1}{3}$ es poden ajuntar directament.",
    r"$\dfrac{2}{5}\cdot\dfrac{7}{2} = \dfrac{7}{5}$."],
   E25)

FQ("25b", 25, "b",
   r"$\dfrac{5}{3} - \left(\dfrac{2}{5} \cdot \dfrac{7}{2} - \dfrac{1}{3}\right)$",
   "5/3 - (2/5*7/2 - 1/3)",
   [(r"\dfrac{2}{5}\cdot\dfrac{7}{2}-\dfrac{1}{3}", "2/5*7/2-1/3")],
   [("5/3 - 2/5*7/2 - 1/3", "MENYS_PARENTESI",
     "Fixa't que aquest és exactament el resultat de l'apartat anterior: "
     "el parèntesi canvia el problema."),
    ("5/3 - (2*2)/(5*7) + 1/3", "PRODUCTE_CREUAT", ""),
    ("-(5/3 - (2/5*7/2 - 1/3))", "SIGNE_FINAL", "")],
   ["Aquí el parèntesi agrupa la multiplicació I la resta: resol tot el "
    "parèntesi primer i després resta'l de $\\dfrac{5}{3}$.",
    r"El parèntesi val $\dfrac{7}{5}-\dfrac{1}{3} = \dfrac{16}{15}$."],
   E25)

FQ("25c", 25, "c",
   r"$\left(\dfrac{2}{3} \cdot 5 - \dfrac{3}{4}\right) \cdot \dfrac{7}{2}$",
   "(2/3*5 - 3/4)*7/2", [(r"\dfrac{2}{3}\cdot 5", "2/3*5"),
                         (r"\dfrac{10}{3}-\dfrac{3}{4}", "10/3-3/4")],
   [("2/3*(5 - 3/4)*7/2", "JERARQUIA", ""),
    ("(2/15 - 3/4)*7/2", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-((2/3*5 - 3/4)*7/2)", "SIGNE_FINAL", "")],
   ["Resol tot el parèntesi abans de multiplicar per la fracció de fora.",
    r"$\dfrac{2}{3}\cdot 5 = \dfrac{10}{3}$."],
   E25)

FQ("25d", 25, "d",
   r"$\left(\dfrac{-7}{3}\right) \cdot \dfrac{4}{5} - 2 \cdot \dfrac{5}{3}$",
   "(-7/3)*4/5 - 2*5/3",
   [(r"\dfrac{-7}{3}\cdot\dfrac{4}{5}", "(-7/3)*4/5"), (r"2\cdot\dfrac{5}{3}", "2*5/3")],
   [("(7/3)*4/5 - 2*5/3", "SIGNE_PRODUCTE", ""),
    ("(-7/3)*4/5 - 10/6", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-((-7/3)*4/5 - 2*5/3)", "SIGNE_FINAL", "")],
   [r"Primer les dues multiplicacions, després la resta.",
    r"$2\cdot\dfrac{5}{3}$: l'enter multiplica només el numerador. Els dos productes tenen denominadors $15$ i $3$: el comú és $15$."], E25)

FQ("25e", 25, "e",
   r"$\left(\dfrac{5}{4} - \dfrac{3}{8} \cdot \dfrac{4}{9}\right) - \dfrac{4}{5} \cdot 2$",
   "(5/4 - 3/8*4/9) - 4/5*2",
   [(r"\dfrac{3}{8}\cdot\dfrac{4}{9}", "3/8*4/9"), (r"\dfrac{4}{5}\cdot 2", "4/5*2")],
   [("(5/4 - 3/8)*4/9 - 4/5*2", "JERARQUIA", ""),
    ("(5/4 - 3/8*4/9) - 8/10", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-((5/4 - 3/8*4/9) - 4/5*2)", "SIGNE_FINAL", "")],
   ["Dins del parèntesi, primer la multiplicació.",
    r"$\dfrac{3}{8}\cdot\dfrac{4}{9} = \dfrac{12}{72} = \dfrac{1}{6}$."],
   E25)

FQ("25f", 25, "f",
   r"$-3 \cdot \dfrac{4}{15} - \left(\dfrac{7}{8} \cdot 5 - 9\right)$",
   "-3*4/15 - (7/8*5 - 9)",
   [(r"-3\cdot\dfrac{4}{15}", "-3*4/15"), (r"\dfrac{7}{8}\cdot 5-9", "7/8*5-9")],
   [("-3*4/15 - 7/8*5 - 9", "MENYS_PARENTESI", ""),
    ("-3*4/15 - (7/40*5 - 9)", "ENTER_MULTIPLICA_DENOMINADOR", ""),
    ("-(-3*4/15 - (7/8*5 - 9))", "SIGNE_FINAL", "")],
   ["El parèntesi dóna un nombre negatiu: restar-lo és sumar-lo.",
    r"$\dfrac{7}{8}\cdot 5 - 9 = \dfrac{35}{8} - \dfrac{72}{8} = -\dfrac{37}{8}$."],
   E25)


# =====================================================================
# NIVELL TRIVIAL (exercici 342)
# =====================================================================
# El bloc obria comprovant equivalències amb productes creuats de
# nombres de dues xifres. Aquí es mira només si l'alumne sap què vol dir
# simplificar: dividir els DOS termes pel MATEIX nombre, amb divisors que
# es veuen de seguida.

dificultats({
    342: 1,  # simplificar una fracció petita: dividir els dos termes
})


E342 = ("Simplifica aquesta fracció fins a la fracció irreductible: divideix "
        "el numerador i el denominador pel mateix nombre.")

Q("342a", 342, "a", B, tipus="A",
  enunciat=r"$\dfrac{6}{8}$",
  correcta=r"$\dfrac{3}{4}$",
  distractors=[D(r"$\dfrac{4}{3}$", "INVERTIDA",
     "Has girat la fracció. El numerador continua a dalt: $6:2=3$ a dalt, "
     "$8:2=4$ a baix."),
   DT(r"$\dfrac{3}{8}$", "SIMPLIFICA_NOMES_NUMERADOR"),
   DT(r"$\dfrac{4}{6}$", "SIMPLIFICAR_RESTANT",
      extra="Has fet $6-2$ i $8-2$.")],
  pistes=["Busca un nombre que divideixi el $6$ i el $8$ alhora.",
   "Tots dos són parells: divideix-los per $2$."],
  resolucio=[r"$\dfrac{6}{8}=\dfrac{6:2}{8:2}=\dfrac{3}{4}$"],
  ex_text=E342)

Q("342b", 342, "b", B, tipus="A",
  enunciat=r"$\dfrac{10}{15}$",
  correcta=r"$\dfrac{2}{3}$",
  distractors=[D(r"$\dfrac{3}{2}$", "INVERTIDA",
     "Has girat la fracció. El numerador continua a dalt: $10:5=2$ a dalt, "
     "$15:5=3$ a baix."),
   DT(r"$\dfrac{2}{15}$", "SIMPLIFICA_NOMES_NUMERADOR"),
   DT(r"$\dfrac{5}{10}$", "SIMPLIFICAR_RESTANT",
      extra="Has fet $10-5$ i $15-5$.")],
  pistes=["Busca un nombre que divideixi el $10$ i el $15$ alhora.",
   "Tots dos acaben en $0$ o en $5$: divideix-los per $5$."],
  resolucio=[r"$\dfrac{10}{15}=\dfrac{10:5}{15:5}=\dfrac{2}{3}$"],
  ex_text=E342)
