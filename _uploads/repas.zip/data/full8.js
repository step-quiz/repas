/* Generat per tools/build.py — no editeu aquest fitxer a mà. */
window.FULL = {
 "full": 8,
 "titol": "Full 8 — Teorema de Tales. Semblança",
 "subtitol": "Teorema de Tales, triangles semblants, escales i aplicacions de la semblança a problemes d'altures i distàncies inaccessibles.",
 "blocs": [
  {
   "id": "tales",
   "titol": "Teorema de Tales",
   "descripcio": "Segments proporcionals entre rectes paral·leles i triangles en posició de Tales.",
   "items": [
    "152a",
    "152b",
    "152c",
    "152e",
    "152f",
    "153a",
    "153b",
    "153c"
   ]
  },
  {
   "id": "semblanca",
   "titol": "Semblança de triangles",
   "descripcio": "Raó de semblança i els tres criteris per determinar si dos triangles són semblants.",
   "items": [
    "154a",
    "154b",
    "154c",
    "154d",
    "155a",
    "155b",
    "155c",
    "155d",
    "155e"
   ]
  },
  {
   "id": "escales",
   "titol": "Escales",
   "descripcio": "Escala numèrica i problemes de mapes i plànols.",
   "items": [
    "156a",
    "156b",
    "158",
    "159",
    "160a",
    "160b"
   ]
  },
  {
   "id": "escales_calcul",
   "titol": "Càlcul amb escales",
   "descripcio": "Del plànol a la realitat i al revés, trobar l'escala, i escales amb canvi d'unitats.",
   "items": [
    "285a",
    "285b",
    "285c",
    "286a",
    "286b",
    "286c",
    "286d",
    "287a",
    "287b",
    "287c",
    "288a",
    "288b",
    "288c",
    "289"
   ]
  },
  {
   "id": "semblanca_arees",
   "titol": "Raó de semblança, àrees i volums",
   "descripcio": "Si les longituds es multipliquen per k, les àrees ho fan per k² i els volums per k³.",
   "items": [
    "290a",
    "290b",
    "290c",
    "291a",
    "291b",
    "291c",
    "292a",
    "292b",
    "293a",
    "293b",
    "294a",
    "294b",
    "294c"
   ]
  },
  {
   "id": "aplicacions",
   "titol": "Aplicacions de la semblança",
   "descripcio": "Ombres, reflexos i alçades o distàncies inaccessibles.",
   "items": [
    "161",
    "162",
    "163",
    "164",
    "165",
    "166",
    "167",
    "168",
    "169"
   ],
   "avancat": true
  }
 ],
 "errors": {
  "ARITMETICA_PAS_INTERMEDI": "El plantejament és bo, però hi ha un error de càlcul en un dels passos del mig. Refes l'operació pas a pas i comprova el resultat substituint-lo a l'enunciat original.",
  "ARREL_MAL_APLICADA": "L'arrel no s'ha aplicat on tocava. Aïlla primer la quantitat que va sota l'arrel i fes-la al final, sobre el valor ja aïllat.",
  "CATET_HIPOTENUSA_CONFOSOS": "Has intercanviat un catet amb la hipotenusa. La hipotenusa és sempre el costat més llarg i va sola a un costat de la igualtat.",
  "CREUAMENT_INVERTIT": "Has creuat els termes al revés en aïllar la incògnita.",
  "CRITERI_SEMBLANCA_INSUFICIENT": "Has dit que falten dades, però el criteri que toca ja es pot aplicar amb el que dona l'enunciat: tres costats, o dos costats i l'angle que formen, o dos angles.",
  "DIVISIO_OBLIDADA": "T'has quedat amb la suma sense dividir-la entre el nombre de dades. La variància és una MITJANA de quadrats, no una suma.",
  "DIVISIO_QUOCIENT_RESIDU_CANVIATS": "Has intercanviat el quocient i el residu: el quocient és el polinomi que queda a la fila de baix (llevat de l'últim terme), i el residu és l'últim número, una constant.",
  "ESCALA_INVERTIDA": "Has fet servir l'escala del revés. A l'escala $a:b$, el primer nombre és el DIBUIX i el segon la REALITAT: si és una reducció, la mesura real sempre surt més gran que la del plànol.",
  "ESCALA_NO_APLICADA": "Has donat la mesura tal com surt al plànol (o a la realitat) sense passar-la per l'escala. Les dues mesures només coincideixen si l'escala és $1:1$.",
  "INVERTIDA": "Has invertit la fracció. Simplificar no canvia quin terme és a dalt i quin a baix.",
  "PAS_INTERMEDI_PER_RESPOSTA": "El valor que has triat és correcte, però és un pas intermedi, no el que et demanen. Torna a llegir la pregunta i mira quina magnitud has d'acabar donant: sovint només falta una operació més.",
  "POTENCIA_10": "El denominador d'un decimal exacte és una potència de $10$ amb tants zeros com xifres decimals hi ha. Torna-les a comptar.",
  "PRODUCTE_MAL": "Has multiplicat els dos nombres que et donaven en comptes d'aïllar la incògnita amb els productes creuats.",
  "PRODUCTE_PER_SUMA": "Has sumat on tocava multiplicar (o al revés). Torna a llegir quina operació es fa sobre les dades.",
  "PROGRESSIO_INVENTADA": "El terme s'ha de calcular seguint estrictament la regla que defineix la successió (el terme general o la relació de recurrència), no un patró aproximat o inventat.",
  "RAONAMENT_ADDITIU": "Has passat d'una fracció a l'altra sumant. Dues fraccions són equivalents quan es passa d'una a l'altra MULTIPLICANT els dos termes pel mateix nombre.",
  "RAO_AL_CUB": "Has fet servir $k^3$ on tocava una altra potència. El cub és per als volums; les àrees van amb $k^2$.",
  "RAO_AL_QUADRAT": "Has fet servir $k^2$ on tocava una altra potència. El quadrat és per a les àrees; les longituds van amb $k$ i els volums amb $k^3$.",
  "RAO_NOMES_UN_COSTAT": "Has comprovat la proporció amb un sol parell de costats. La semblança demana que TOTS els costats corresponents guardin la mateixa raó.",
  "RAO_SENSE_QUADRAT": "Has multiplicat per $k$ una àrea o un volum. Només les LONGITUDS van amb $k$: les àrees van amb $k^2$ i els volums amb $k^3$.",
  "RESTA_PER_QUOCIENT": "Has restat les dues quantitats. Un percentatge i una raó surten d'una DIVISIÓ: diuen quantes vegades, no quant més.",
  "SUMA_EN_LLOC_RESTA": "Sumar un nombre negatiu és restar-lo.",
  "TERME_OBLIDAT_OPERACIO": "T'has deixat algun terme pel camí en combinar els polinomis: revisa'ls tots un per un, grau a grau.",
  "UNITATS_NO_CONVERTIDES": "Has barrejat unitats diferents en la mateixa operació. Passa-ho tot a la mateixa unitat abans de calcular res."
 },
 "items": [
  {
   "id": "152a",
   "ex": 152,
   "ap": "a",
   "bloc": "tales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula el valor de $x$ en aquestes figures de rectes paral·leles tallades per dues rectes secants.",
   "enunciat": "Una secant té segments de $2{,}5$ cm i $2$ cm; l'altra, $x$ i $3$ cm (segments corresponents en el mateix ordre).",
   "opcions": [
    "$2{,}4$ cm",
    "$1{,}67$ cm",
    "$7{,}5$ cm",
    "$3{,}75$ cm"
   ],
   "pistes": [
    "Els segments es corresponen en ordre: el primer d'una secant amb el primer de l'altra, i el segon amb el segon. Aquí el $2{,}5$ va amb la $x$, i el $2$ amb el $3$.",
    "Per Tales, totes dues secants queden dividides en la mateixa proporció: $\\dfrac{2{,}5}{2}=\\dfrac{x}{3}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgbXVudGF0IGxhIHByb3BvcmNpw7MgYW1iIGVscyBzZWdtZW50cyBkZSBjYWRhIHNlY2FudCBpbnRlcmNhbnZpYXRzLiBQbGFudGVqYSAkXFxkZnJhY3syeyx9NX17Mn09XFxkZnJhY3t4fXszfSQsIG5vIGxhIHByb3BvcmNpw7MgaW52ZXJzYS4iLCAiU2VtYmxhIHF1ZSBoYXMgY2FsY3VsYXQgJDI6MnssfTVcXGNkb3QzJCBhbWIgZWxzIHRlcm1lcyBpbnRlcmNhbnZpYXRzOiByZXZpc2EgcXVpbiBzZWdtZW50IGZhIGRlIG51bWVyYWRvciBhIGNhZGEgc2VjYW50LiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSAkMnssfTVcXGNkb3QzJCBzZW5zZSBkaXZpZGlyIHBlciAkMiQ6ICR4PVxcZGZyYWN7MnssfTVcXGNkb3QzfXsyfSQsIG5vIG5vbcOpcyBlbCBudW1lcmFkb3IuIiwgIiJdLCAiZXJyIjogWyJDUkVVQU1FTlRfSU5WRVJUSVQiLCAiRElWSVNJT19RVU9DSUVOVF9SRVNJRFVfQ0FOVklBVFMiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICIiXSwgInJlcyI6IFsiJFxcZGZyYWN7MnssfTV9ezJ9PVxcZGZyYWN7eH17M30gXFw7XFxMb25ncmlnaHRhcnJvd1xcOyB4PVxcZGZyYWN7MnssfTVcXGNkb3QzfXsyfSQiLCAiJHg9M3ssfTc1JCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 240 155\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts x marcats.</title><g transform=\"translate(14.0,73.8)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"211.5\" y2=\"46.9\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"169.2\" y2=\"-37.5\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"84.6\" y1=\"18.8\" x2=\"67.7\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"211.5\" y1=\"46.9\" x2=\"169.2\" y2=\"-37.5\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"2.4\" x2=\"-4.7\" y2=\"21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"17.6\" x2=\"80.7\" y2=\"36.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"12.8\" x2=\"-0.9\" y2=\"22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"211.0\" y1=\"49.3\" x2=\"206.9\" y2=\"67.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"80.7\" y1=\"36.3\" x2=\"207.6\" y2=\"64.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"204.6\" y1=\"59.7\" x2=\"210.7\" y2=\"69.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"-2.4\" x2=\"-4.7\" y2=\"-21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"67.1\" y1=\"-17.4\" x2=\"63.0\" y2=\"-36.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"-17.6\" x2=\"63.8\" y2=\"-32.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"-12.8\" x2=\"-0.9\" y2=\"-22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"60.8\" y1=\"-27.8\" x2=\"66.8\" y2=\"-37.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"67.1\" y1=\"-17.4\" x2=\"63.0\" y2=\"-36.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"168.7\" y1=\"-40.0\" x2=\"164.6\" y2=\"-58.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"63.8\" y1=\"-32.6\" x2=\"165.3\" y2=\"-55.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"60.8\" y1=\"-27.8\" x2=\"66.8\" y2=\"-37.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"162.3\" y1=\"-50.3\" x2=\"168.4\" y2=\"-59.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"25.9\" y=\"38.4\" text-anchor=\"middle\" class=\"fig-etq petita\">2,5 cm</text><text x=\"141.8\" y=\"64.1\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"27.6\" y=\"-32.9\" text-anchor=\"middle\" class=\"fig-etq petita\">2 cm</text><text x=\"112.2\" y=\"-51.6\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text></g></svg>"
  },
  {
   "id": "152b",
   "ex": 152,
   "ap": "b",
   "bloc": "tales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula el valor de $x$ en aquestes figures de rectes paral·leles tallades per dues rectes secants.",
   "enunciat": "Una secant té segments de $2$ cm i $4$ cm; l'altra, $3$ cm i $x$ cm (segments corresponents en el mateix ordre).",
   "opcions": [
    "$1{,}5$ cm",
    "$4$ cm",
    "$6$ cm",
    "$12$ cm"
   ],
   "pistes": [
    "Els segments es corresponen en ordre: el primer d'una secant amb el primer de l'altra, i el segon amb el segon. Aquí el $2$ va amb el $3$, i el $4$ amb la $x$.",
    "Per Tales, totes dues secants queden dividides en la mateixa proporció: $\\dfrac{4}{2}=\\dfrac{x}{3}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgaW50ZXJjYW52aWF0IHF1aW4gc2VnbWVudCBjb3JyZXNwb24gYSBxdWluOiBwbGFudGVqYSAkXFxkZnJhY3s0fXsyfT1cXGRmcmFje3h9ezN9JCwgYW1iIGVsIHNlZ21lbnQgTcOJUyBncmFuIGRlIGxhIHByaW1lcmEgc2VjYW50ICgkNCQpIGNvcnJlc3BvbmVudCBhICR4JC4iLCAiQXF1ZXN0IHZhbG9yIG5vIHN1cnQgZGUgbGEgcHJvcG9yY2nDszogY29tcHJvdmEgJHg9XFxkZnJhY3s0XFxjZG90M317Mn0kIHBhcyBhIHBhcyBlbiBsbG9jIGRlIHJlcGV0aXIgdW4gc2VnbWVudCBxdWUgamEgYXBhcmVpeGlhIGEgbCdlbnVuY2lhdC4iLCAiIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlICQ0XFxjZG90MyQgc2Vuc2UgZGl2aWRpciBwZXIgJDIkOiAkeD1cXGRmcmFjezRcXGNkb3QzfXsyfSQsIG5vIG5vbcOpcyBlbCBudW1lcmFkb3IuIl0sICJlcnIiOiBbIkNSRVVBTUVOVF9JTlZFUlRJVCIsICJQUk9HUkVTU0lPX0lOVkVOVEFEQSIsICIiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyJdLCAicmVzIjogWyIkXFxkZnJhY3s0fXsyfT1cXGRmcmFje3h9ezN9IFxcO1xcTG9uZ3JpZ2h0YXJyb3dcXDsgeD1cXGRmcmFjezRcXGNkb3QzfXsyfSQiLCAiJHg9NiQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 219 143\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts x marcats.</title><g transform=\"translate(14.0,75.7)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"126.9\" y2=\"28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"190.4\" y2=\"-42.2\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"42.3\" y1=\"9.4\" x2=\"63.5\" y2=\"-14.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"126.9\" y1=\"28.1\" x2=\"190.4\" y2=\"-42.2\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"2.4\" x2=\"-4.7\" y2=\"21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"41.8\" y1=\"11.8\" x2=\"37.7\" y2=\"30.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"17.6\" x2=\"38.4\" y2=\"27.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"12.8\" x2=\"-0.9\" y2=\"22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"35.4\" y1=\"22.2\" x2=\"41.4\" y2=\"31.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"41.8\" y1=\"11.8\" x2=\"37.7\" y2=\"30.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"30.6\" x2=\"122.3\" y2=\"49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"38.4\" y1=\"27.0\" x2=\"123.0\" y2=\"45.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"35.4\" y1=\"22.2\" x2=\"41.4\" y2=\"31.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"40.9\" x2=\"126.1\" y2=\"50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"-2.4\" x2=\"-4.7\" y2=\"-21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"62.9\" y1=\"-16.5\" x2=\"58.8\" y2=\"-35.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"-17.6\" x2=\"59.6\" y2=\"-31.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"-12.8\" x2=\"-0.9\" y2=\"-22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"56.5\" y1=\"-26.9\" x2=\"62.6\" y2=\"-36.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"62.9\" y1=\"-16.5\" x2=\"58.8\" y2=\"-35.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"189.8\" y1=\"-44.6\" x2=\"185.7\" y2=\"-63.2\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"59.6\" y1=\"-31.6\" x2=\"186.5\" y2=\"-59.8\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"56.5\" y1=\"-26.9\" x2=\"62.6\" y2=\"-36.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"183.4\" y1=\"-55.0\" x2=\"189.5\" y2=\"-64.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"14.9\" y=\"35.9\" text-anchor=\"middle\" class=\"fig-etq petita\">2 cm</text><text x=\"78.3\" y=\"50\" text-anchor=\"middle\" class=\"fig-etq petita\">4 cm</text><text x=\"25.5\" y=\"-32.4\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text><text x=\"120.6\" y=\"-53.5\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text></g></svg>"
  },
  {
   "id": "152c",
   "ex": 152,
   "ap": "c",
   "bloc": "tales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula el valor de $x$ en aquestes figures de rectes paral·leles tallades per dues rectes secants.",
   "enunciat": "Una secant té segments de $8$ cm i $4$ cm; l'altra, $x$ i $6$ cm (segments corresponents en el mateix ordre).",
   "opcions": [
    "$3$ cm",
    "$4{,}5$ cm",
    "$48$ cm",
    "$12$ cm"
   ],
   "pistes": [
    "Els segments es corresponen en ordre: el primer d'una secant amb el primer de l'altra, i el segon amb el segon. Aquí el $8$ va amb la $x$, i el $4$ amb el $6$.",
    "Per Tales, totes dues secants queden dividides en la mateixa proporció: $\\dfrac{8}{4}=\\dfrac{x}{6}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgaW50ZXJjYW52aWF0IHF1aW4gc2VnbWVudCBjb3JyZXNwb24gYSBxdWluOiBwbGFudGVqYSAkXFxkZnJhY3s4fXs0fT1cXGRmcmFje3h9ezZ9JCwgbm8gbGEgcHJvcG9yY2nDsyBhbWIgZWxzIHRlcm1lcyBpbnZlcnRpdHMuIiwgIlNlbWJsYSBxdWUgaGFzIGNhbGN1bGF0ICQ2XFxjZG90NDo4JCBhbWIgdW4gYWx0cmUgYXBhcmVsbGFtZW50IGRlIHNlZ21lbnRzOiByZXZpc2EgcXVpbnMgZG9zIHNlZ21lbnRzIHPDs24gY29ycmVzcG9uZW50cyBlbnRyZSBsZXMgZHVlcyBzZWNhbnRzLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSAkOFxcY2RvdDYkIHNlbnNlIGRpdmlkaXIgcGVyICQ0JDogJHg9XFxkZnJhY3s4XFxjZG90Nn17NH0kLCBubyBub23DqXMgZWwgbnVtZXJhZG9yLiIsICIiXSwgImVyciI6IFsiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIkRJVklTSU9fUVVPQ0lFTlRfUkVTSURVX0NBTlZJQVRTIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiIl0sICJyZXMiOiBbIiRcXGRmcmFjezh9ezR9PVxcZGZyYWN7eH17Nn0gXFw7XFxMb25ncmlnaHRhcnJvd1xcOyB4PVxcZGZyYWN7OFxcY2RvdDZ9ezR9JCIsICIkeD0xMiQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 219 154\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts x marcats.</title><g transform=\"translate(14.0,82.7)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"126.9\" y2=\"28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"190.4\" y2=\"-42.2\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"84.6\" y1=\"18.8\" x2=\"126.9\" y2=\"-28.1\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line x1=\"126.9\" y1=\"28.1\" x2=\"190.4\" y2=\"-42.2\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"2.4\" x2=\"-4.7\" y2=\"21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"17.6\" x2=\"80.7\" y2=\"36.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"12.8\" x2=\"-0.9\" y2=\"22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"30.6\" x2=\"122.3\" y2=\"49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"80.7\" y1=\"36.3\" x2=\"123.0\" y2=\"45.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"40.9\" x2=\"126.1\" y2=\"50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"-2.4\" x2=\"-4.7\" y2=\"-21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"-30.6\" x2=\"122.3\" y2=\"-49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"-17.6\" x2=\"123.0\" y2=\"-45.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"-12.8\" x2=\"-0.9\" y2=\"-22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"-40.9\" x2=\"126.1\" y2=\"-50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"-30.6\" x2=\"122.3\" y2=\"-49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"189.8\" y1=\"-44.6\" x2=\"185.7\" y2=\"-63.2\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"123.0\" y1=\"-45.7\" x2=\"186.5\" y2=\"-59.8\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"-40.9\" x2=\"126.1\" y2=\"-50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"183.4\" y1=\"-55.0\" x2=\"189.5\" y2=\"-64.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"36\" y=\"40.6\" text-anchor=\"middle\" class=\"fig-etq petita\">8 cm</text><text x=\"99.5\" y=\"54.7\" text-anchor=\"middle\" class=\"fig-etq petita\">4 cm</text><text x=\"57.2\" y=\"-39.4\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"152.4\" y=\"-60.5\" text-anchor=\"middle\" class=\"fig-etq petita\">6 cm</text></g></svg>"
  },
  {
   "id": "152e",
   "ex": 152,
   "ap": "e",
   "bloc": "tales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula el valor de $x$ en aquestes figures de rectes paral·leles tallades per dues rectes secants.",
   "enunciat": "Una secant té segments de $x$ i $10$ cm; l'altra, $5$ cm i $8$ cm (segments corresponents en el mateix ordre).",
   "opcions": [
    "$16$ cm",
    "$6{,}25$ cm",
    "$50$ cm",
    "$4$ cm"
   ],
   "pistes": [
    "Els segments es corresponen en ordre: el primer d'una secant amb el primer de l'altra, i el segon amb el segon. Aquí la $x$ va amb el $5$, i el $10$ amb el $8$.",
    "Per Tales, totes dues secants queden dividides en la mateixa proporció: $\\dfrac{x}{10}=\\dfrac{5}{8}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgaW50ZXJjYW52aWF0IHF1aW5hIGZyYWNjacOzIMOpcyBxdWluYTogcGxhbnRlamEgJFxcZGZyYWN7eH17MTB9PVxcZGZyYWN7NX17OH0kLCBhbWIgJHgkIGNvcnJlc3BvbmVudCBhbCBzZWdtZW50IGRlICQ1JCBjbSwgbm8gYWwgZGUgJDgkIGNtLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJDEwXFxjZG90NSQgc2Vuc2UgZGl2aWRpciBwZXIgJDgkOiAkeD1cXGRmcmFjezEwXFxjZG90NX17OH0kLCBubyBub23DqXMgZWwgbnVtZXJhZG9yLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSAkXFxkZnJhY3s1XFxjZG90OH17MTB9JDogcmV2aXNhIHF1aW4gc2VnbWVudCDDqXMgZWwgcXVlIG11bHRpcGxpY2EgcGVyICQxMCQgaSBxdWluIGhpIGRpdmlkZWl4LiJdLCAiZXJyIjogWyJDUkVVQU1FTlRfSU5WRVJUSVQiLCAiIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiUFJPRFVDVEVfTUFMIl0sICJyZXMiOiBbIiRcXGRmcmFje3h9ezEwfT1cXGRmcmFjezV9ezh9IFxcO1xcTG9uZ3JpZ2h0YXJyb3dcXDsgeD1cXGRmcmFjezEwXFxjZG90NX17OH0kIiwgIiR4PTZ7LH0yNSQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 235 153\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts x marcats.</title><g transform=\"translate(14.0,72.9)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"206.2\" y2=\"45.7\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"165.0\" y2=\"-36.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"79.3\" y1=\"17.6\" x2=\"63.5\" y2=\"-14.1\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line x1=\"206.2\" y1=\"45.7\" x2=\"165.0\" y2=\"-36.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"2.4\" x2=\"-4.7\" y2=\"21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"78.8\" y1=\"20.0\" x2=\"74.7\" y2=\"38.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"17.6\" x2=\"75.4\" y2=\"35.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"12.8\" x2=\"-0.9\" y2=\"22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"72.4\" y1=\"30.4\" x2=\"78.5\" y2=\"39.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"78.8\" y1=\"20.0\" x2=\"74.7\" y2=\"38.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"205.7\" y1=\"48.2\" x2=\"201.6\" y2=\"66.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.4\" y1=\"35.2\" x2=\"202.3\" y2=\"63.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"72.4\" y1=\"30.4\" x2=\"78.5\" y2=\"39.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"199.3\" y1=\"58.5\" x2=\"205.4\" y2=\"68.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"-2.4\" x2=\"-4.7\" y2=\"-21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"62.9\" y1=\"-16.5\" x2=\"58.8\" y2=\"-35.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"-17.6\" x2=\"59.6\" y2=\"-31.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"-12.8\" x2=\"-0.9\" y2=\"-22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"56.5\" y1=\"-26.9\" x2=\"62.6\" y2=\"-36.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"62.9\" y1=\"-16.5\" x2=\"58.8\" y2=\"-35.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"164.5\" y1=\"-39.0\" x2=\"160.3\" y2=\"-57.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"59.6\" y1=\"-31.6\" x2=\"161.1\" y2=\"-54.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"56.5\" y1=\"-26.9\" x2=\"62.6\" y2=\"-36.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"158.1\" y1=\"-49.4\" x2=\"164.1\" y2=\"-58.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"33.4\" y=\"40\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"136.5\" y=\"62.9\" text-anchor=\"middle\" class=\"fig-etq petita\">10 cm</text><text x=\"25.5\" y=\"-32.4\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"107.9\" y=\"-50.7\" text-anchor=\"middle\" class=\"fig-etq petita\">8 cm</text></g></svg>"
  },
  {
   "id": "152f",
   "ex": 152,
   "ap": "f",
   "bloc": "tales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula el valor de $x$ en aquestes figures de rectes paral·leles tallades per dues rectes secants.",
   "enunciat": "Una secant té segments de $4{,}8$ cm i $2$ cm; l'altra, $x$ i $3$ cm (segments corresponents en el mateix ordre).",
   "opcions": [
    "$0{,}83$ cm",
    "$14{,}4$ cm",
    "$7{,}2$ cm",
    "$1{,}25$ cm"
   ],
   "pistes": [
    "Els segments es corresponen en ordre: el primer d'una secant amb el primer de l'altra, i el segon amb el segon. Aquí el $4{,}8$ va amb la $x$, i el $2$ amb el $3$.",
    "Per Tales, totes dues secants queden dividides en la mateixa proporció: $\\dfrac{4{,}8}{2}=\\dfrac{x}{3}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJTZW1ibGEgcXVlIGhhcyBkaXZpZGl0ICQyOjR7LH04XFxjZG90MyQgYW1iIGVscyB0ZXJtZXMgaW50ZXJjYW52aWF0czogcmV2aXNhIHF1aW4gc2VnbWVudCBmYSBkZSBudW1lcmFkb3IgYSBjYWRhIHNlY2FudC4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJDR7LH04XFxjZG90MyQgc2Vuc2UgZGl2aWRpciBwZXIgJDIkOiAkeD1cXGRmcmFjezR7LH04XFxjZG90M317Mn0kLCBubyBub23DqXMgZWwgbnVtZXJhZG9yLiIsICIiLCAiSGFzIG11bnRhdCBsYSBwcm9wb3JjacOzIGFtYiBlbHMgc2VnbWVudHMgZGUgY2FkYSBzZWNhbnQgaW50ZXJjYW52aWF0cy4gUGxhbnRlamEgJFxcZGZyYWN7NHssfTh9ezJ9PVxcZGZyYWN7eH17M30kLCBubyBsYSBwcm9wb3JjacOzIGludmVyc2EuIl0sICJlcnIiOiBbIkRJVklTSU9fUVVPQ0lFTlRfUkVTSURVX0NBTlZJQVRTIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiIiwgIkNSRVVBTUVOVF9JTlZFUlRJVCJdLCAicmVzIjogWyIkXFxkZnJhY3s0eyx9OH17Mn09XFxkZnJhY3t4fXszfSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3s0eyx9OFxcY2RvdDN9ezJ9JCIsICIkeD03eyx9MiQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 152\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts x marcats.</title><g transform=\"translate(14.0,81.6)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"119.9\" y2=\"26.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"179.8\" y2=\"-39.9\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"84.6\" y1=\"18.8\" x2=\"126.9\" y2=\"-28.1\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line x1=\"119.9\" y1=\"26.6\" x2=\"179.8\" y2=\"-39.9\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"2.4\" x2=\"-4.7\" y2=\"21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"17.6\" x2=\"80.7\" y2=\"36.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"12.8\" x2=\"-0.9\" y2=\"22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"84.1\" y1=\"21.2\" x2=\"80.0\" y2=\"39.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"119.3\" y1=\"29.0\" x2=\"115.2\" y2=\"47.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"80.7\" y1=\"36.3\" x2=\"116.0\" y2=\"44.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"77.7\" y1=\"31.6\" x2=\"83.8\" y2=\"41.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"112.9\" y1=\"39.4\" x2=\"119.0\" y2=\"48.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-0.5\" y1=\"-2.4\" x2=\"-4.7\" y2=\"-21.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"-30.6\" x2=\"122.3\" y2=\"-49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-3.9\" y1=\"-17.6\" x2=\"123.0\" y2=\"-45.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-6.9\" y1=\"-12.8\" x2=\"-0.9\" y2=\"-22.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"-40.9\" x2=\"126.1\" y2=\"-50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"126.4\" y1=\"-30.6\" x2=\"122.3\" y2=\"-49.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"179.3\" y1=\"-42.3\" x2=\"175.1\" y2=\"-60.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"123.0\" y1=\"-45.7\" x2=\"175.9\" y2=\"-57.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"-40.9\" x2=\"126.1\" y2=\"-50.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"172.9\" y1=\"-52.7\" x2=\"178.9\" y2=\"-62.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"25.9\" y=\"38.4\" text-anchor=\"middle\" class=\"fig-etq petita\">4,8 cm</text><text x=\"96\" y=\"53.9\" text-anchor=\"middle\" class=\"fig-etq petita\">2 cm</text><text x=\"57.2\" y=\"-39.4\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"147.1\" y=\"-59.4\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text></g></svg>"
  },
  {
   "id": "153a",
   "ex": 153,
   "ap": "a",
   "bloc": "tales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos triangles estan en posició de Tales des del vèrtex $O$, amb els costats $OA$, $OB$ i $OC$ sobre una recta, i $OA'$, $OB'$ i $OC'$ sobre una altra (amb $A,B,C$ i $A',B',C'$ en el mateix ordre a cada recta).",
   "enunciat": "Si $OA=2$ cm, $OB=5$ cm, $OA'=2{,}6$ cm i $OC'=11{,}7$ cm, quant val $BC$?",
   "opcions": [
    "$4$ cm",
    "$9$ cm",
    "$6{,}5$ cm",
    "$3{,}25$ cm"
   ],
   "pistes": [
    "La raó entre els dos triangles és $k=\\dfrac{OA'}{OA}=\\dfrac{2{,}6}{2}=1{,}3$.",
    "Amb aquesta raó, $OC=\\dfrac{OC'}{k}$, i després $BC=OC-OB$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiJDkkIGNtIMOpcyBlbCB2YWxvciBkZSAkT0MkLCBubyBkZSAkQkM9T0MtT0IkOiB1biBjb3AgdGluZ3VpcyAkT0MkLCBlbmNhcmEgaGFzIGRlIHJlc3Rhci1oaSAkT0IkLiIsICIkNnssfTUkIGNtIMOpcyBlbCB2YWxvciBkZSAkT0InJCwgbm8gZGUgJEJDJDogdG9ybmEgYSBtaXJhciBxdWluYSBkaXN0w6BuY2lhIGV0IGRlbWFuYSBsJ2VudW5jaWF0LiIsICJBcXVlc3QgdmFsb3Igc3VydCBkJ2FwbGljYXIgbGEgcmHDsyBkZSBzZW1ibGFuw6dhICRrPVxcZnJhY3tPQSd9e09BfSQgYSAkT0IkIGVuIGxsb2MgZGUgY2FsY3VsYXIgcHJpbWVyICRPQyQgaSBkZXNwcsOpcyByZXN0YXItaGkgJE9CJDogJEJDPU9DLU9CJCwgaSAkT0M9XFxmcmFje09DJ317a30kLiJdLCAiZXJyIjogWyIiLCAiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIl0sICJyZXMiOiBbIiRrPVxcZGZyYWN7T0EnfXtPQX09XFxkZnJhY3syeyx9Nn17Mn09MXssfTMkIiwgIiRPQz1cXGRmcmFje09DJ317a309XFxkZnJhY3sxMXssfTd9ezF7LH0zfT05JCBjbSIsICIkQkM9T0MtT0I9OS01PTQkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 179 107\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts BC marcats.</title><g transform=\"translate(27.7,56.6)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"97.6\" y2=\"21.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"21.7\" y1=\"4.8\" x2=\"28.2\" y2=\"-6.3\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"54.2\" y1=\"12.0\" x2=\"70.5\" y2=\"-15.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"97.6\" y1=\"21.6\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"-10\" y=\"3.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom\">O</text><text x=\"26.9\" y=\"19.7\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A</text><text x=\"59.4\" y=\"26.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B</text><text x=\"101.6\" y=\"33.8\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C</text><text x=\"33.4\" y=\"-15.2\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A'</text><text x=\"75.7\" y=\"-24.6\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B'</text><text x=\"130.9\" y=\"-34.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C'</text></g></svg>"
  },
  {
   "id": "153b",
   "ex": 153,
   "ap": "b",
   "bloc": "tales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos triangles estan en posició de Tales des del vèrtex $O$, amb els costats $OA$, $OB$ i $OC$ sobre una recta, i $OA'$, $OB'$ i $OC'$ sobre una altra (amb $A,B,C$ i $A',B',C'$ en el mateix ordre a cada recta).",
   "enunciat": "Si $OB=9$ cm, $OA'=4$ cm, $OB'=12$ cm i $OC'=18$ cm, quant val $AB$?",
   "opcions": [
    "$6$ cm",
    "$13{,}5$ cm",
    "$3$ cm",
    "$9{,}75$ cm"
   ],
   "pistes": [
    "La raó entre els dos triangles és $k=\\dfrac{OB'}{OB}=\\dfrac{12}{9}=1{,}33\\overline{3}$.",
    "Amb aquesta raó, $OA=\\dfrac{OA'}{k}$, i després $AB=OB-OA$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiJDEzeyx9NSQgY20gw6lzIGVsIHZhbG9yIGRlICRPQyQsIG5vIGRlICRBQiQ6IHRvcm5hIGEgbWlyYXIgcXVpbmEgZGlzdMOgbmNpYSBldCBkZW1hbmEgbCdlbnVuY2lhdC4iLCAiJDMkIGNtIMOpcyBlbCB2YWxvciBkZSAkT0EkLCBubyBkZSAkQUI9T0ItT0EkOiB1biBjb3AgdGluZ3VpcyAkT0EkLCBlbmNhcmEgaGFzIGRlIHJlc3Rhci1sYSBkZSAkT0IkLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkJ2FwbGljYXIgbGEgcmHDsyAkayQgZGlyZWN0YW1lbnQgYSAkT0IkIGVuIGNvbXB0ZXMgZGUgY2FsY3VsYXIgcHJpbWVyICRPQSQgYW1iICRrPVxcZnJhY3tPQid9e09CfSQgaSBkZXNwcsOpcyByZXN0YXItbGEgZGUgJE9CJDogJEFCPU9CLU9BJC4iXSwgImVyciI6IFsiIiwgIlBST0dSRVNTSU9fSU5WRU5UQURBIiwgIlBST0dSRVNTSU9fSU5WRU5UQURBIiwgIkNSRVVBTUVOVF9JTlZFUlRJVCJdLCAicmVzIjogWyIkaz1cXGRmcmFje09CJ317T0J9PVxcZGZyYWN7MTJ9ezl9PVxcZGZyYWN7NH17M30kIiwgIiRPQT1cXGRmcmFje09BJ317a309NFxcY2RvdFxcZGZyYWN7M317NH09MyQgY20iLCAiJEFCPU9CLU9BPTktMz02JCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 179 107\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts AB marcats.</title><g transform=\"translate(27.7,56.6)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"95.2\" y2=\"21.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"21.2\" y1=\"4.7\" x2=\"28.2\" y2=\"-6.3\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"63.5\" y1=\"14.1\" x2=\"84.6\" y2=\"-18.8\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"95.2\" y1=\"21.1\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"-10\" y=\"3.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom\">O</text><text x=\"26.3\" y=\"19.6\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A</text><text x=\"68.6\" y=\"28.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B</text><text x=\"99.2\" y=\"33.2\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C</text><text x=\"33.4\" y=\"-15.2\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A'</text><text x=\"89.8\" y=\"-27.7\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B'</text><text x=\"130.9\" y=\"-34.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C'</text></g></svg>"
  },
  {
   "id": "153c",
   "ex": 153,
   "ap": "c",
   "bloc": "tales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos triangles estan en posició de Tales des del vèrtex $O$, amb els costats $OA$, $OB$ i $OC$ sobre una recta, i $OA'$, $OB'$ i $OC'$ sobre una altra (amb $A,B,C$ i $A',B',C'$ en el mateix ordre a cada recta).",
   "enunciat": "Si $OA=5$ cm, $OC=22{,}5$ cm, $OC'=36$ cm i $OB'=24$ cm, quant val $AB$?",
   "opcions": [
    "$15$ cm",
    "$6{,}25$ cm",
    "$10$ cm",
    "$8$ cm"
   ],
   "pistes": [
    "La raó entre els dos triangles és $k=\\dfrac{OC'}{OC}=\\dfrac{36}{22{,}5}=1{,}6$.",
    "Amb aquesta raó, $OB=\\dfrac{OB'}{k}$, i després $AB=OB-OA$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyIkMTUkIGNtIMOpcyBlbCB2YWxvciBkZSAkT0IkLCBubyBkZSAkQUIkOiBlbmNhcmEgaGFzIGRlIHJlc3Rhci1oaSAkT0E9NSQgY20uIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGQnYXBsaWNhciBsYSByYcOzICRrJCBhICRPQSQgZW4gY29tcHRlcyBkJ3VzYXItbGEgcGVyIHRyb2JhciAkT0IkIGEgcGFydGlyIGRlICRPQickOiAkT0I9XFxmcmFje09CJ317a30kLCBpIGRlc3Byw6lzICRBQj1PQi1PQSQuIiwgIiIsICIkOCQgY20gw6lzIGVsIHZhbG9yIGRlICRPQSckLCBubyBkZSAkQUI9T0ItT0EkOiB1biBjb3AgdGluZ3VpcyAkT0IkLCBlbmNhcmEgbCdoYXMgZGUgY29tcGFyYXIgYW1iICRPQSQsIG5vIGFtYiAkT0EnJC4iXSwgImVyciI6IFsiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIiIsICJQUk9HUkVTU0lPX0lOVkVOVEFEQSJdLCAicmVzIjogWyIkaz1cXGRmcmFje09DJ317T0N9PVxcZGZyYWN7MzZ9ezIyeyx9NX09MXssfTYkIiwgIiRPQj1cXGRmcmFje09CJ317a309XFxkZnJhY3syNH17MXssfTZ9PTE1JCBjbSIsICIkQUI9T0ItT0E9MTUtNT0xMCQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 179 103\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues rectes secants que surten d'un mateix punt O, tallades per un joc de rectes paral·leles, amb els punts AB marcats.</title><g transform=\"translate(27.7,56.6)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"79.3\" y2=\"17.6\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"17.6\" y1=\"3.9\" x2=\"28.2\" y2=\"-6.3\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"52.9\" y1=\"11.7\" x2=\"84.6\" y2=\"-18.8\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"79.3\" y1=\"17.6\" x2=\"126.9\" y2=\"-28.1\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"-10\" y=\"3.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom\">O</text><text x=\"22.8\" y=\"18.8\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A</text><text x=\"58.1\" y=\"26.6\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B</text><text x=\"83.3\" y=\"29.7\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C</text><text x=\"33.4\" y=\"-15.2\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">A'</text><text x=\"89.8\" y=\"-27.7\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">B'</text><text x=\"130.9\" y=\"-34.4\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">C'</text></g></svg>"
  },
  {
   "id": "154a",
   "ex": 154,
   "ap": "a",
   "bloc": "semblanca",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud dels costats desconeguts en aquests parells de triangles semblants.",
   "enunciat": "Triangle petit de costats $3$ cm i $5$ cm; triangle gran de costats $4$ cm (correspon al de $3$ cm) i $x$ (correspon al de $5$ cm).",
   "opcions": [
    "$6$ cm",
    "$20$ cm",
    "$6{,}67$ cm (aproximadament)",
    "$3{,}75$ cm"
   ],
   "pistes": [
    "La raó de semblança és $k=\\dfrac{4}{3}$ (el costat de $4$ cm correspon al de $3$ cm).",
    "Aplica aquesta raó al costat de $5$ cm: $x=5\\cdot k$."
   ],
   "nota": "La correspondència entre costats del triangle petit i el gran s'ha establert seguint la indicació explícita del propi enunciat, que ja diu quins costats es corresponen entre si.",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gc3VydCBkZSBsYSBwcm9wb3JjacOzIGNvcnJlY3RhOiBjYWxjdWxhICQ1XFxjZG90XFxmcmFjezR9ezN9JCBwYXMgYSBwYXMgZW4gbGxvYyBkJ2Fycm9kb25pciAkXFxmcmFjezIwfXszfSQgYSB1biBub21icmUgZW50ZXIuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlICQ1XFxjZG90NCQgc2Vuc2UgZGl2aWRpciBwZXIgJDMkOiBsYSByYcOzIGRlIHNlbWJsYW7Dp2Egw6lzICRcXGZyYWN7NH17M30kLCBpIGNhbCBtdWx0aXBsaWNhci1sYSBwZWwgY29zdGF0LCBubyBub23DqXMgbXVsdGlwbGljYXIgcGVsIG51bWVyYWRvci4iLCAiIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGQnYXBsaWNhciBsYSByYcOzIGludmVydGlkYSAkaz1cXGZyYWN7M317NH0kIGFsIGNvc3RhdCBkZSAkNSQgY207IGxhIHJhw7Mgw6lzICRrPVxcZnJhY3s0fXszfSQgKGRlbCBjb3N0YXQgZ3JhbiBjb25lZ3V0IGFsIHBldGl0IGNvbmVndXQpLCBubyBsYSBpbnZlcnNhLiJdLCAiZXJyIjogWyJQUk9HUkVTU0lPX0lOVkVOVEFEQSIsICJURVJNRV9PQkxJREFUX09QRVJBQ0lPIiwgIiIsICJDUkVVQU1FTlRfSU5WRVJUSVQiXSwgInJlcyI6IFsiJGs9XFxkZnJhY3s0fXszfSQiLCAiJHg9NVxcY2RvdFxcZGZyYWN7NH17M309XFxkZnJhY3syMH17M31cXGFwcHJveDZ7LH02NyQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 281 115\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,84.2)\"><polygon points=\"0.0,0.0 90.0,0.0 37.8,-70.2\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"163.0,0.0 253.0,0.0 200.8,-70.2\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text><text x=\"36.5\" y=\"-22.7\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"208\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">4 cm</text><text x=\"191.6\" y=\"-26.9\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text></g></svg>"
  },
  {
   "id": "154b",
   "ex": 154,
   "ap": "b",
   "bloc": "semblanca",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud dels costats desconeguts en aquests parells de triangles semblants.",
   "enunciat": "Triangle gran de costats $8$ cm, $10$ cm i $7$ cm; triangle petit de costat $6$ cm (correspon al de $8$ cm), amb els altres dos costats desconeguts. Quant valen?",
   "opcions": [
    "$8$ cm i $5$ cm",
    "$7{,}5$ cm i $5{,}25$ cm",
    "$60$ cm i $42$ cm",
    "$13{,}33$ cm i $9{,}33$ cm"
   ],
   "pistes": [
    "La raó de semblança és $k=\\dfrac{6}{8}=0{,}75$ (el costat de $6$ cm correspon al de $8$ cm).",
    "Aplica aquesta raó als costats de $10$ cm i $7$ cm."
   ],
   "nota": "La correspondència entre costats del triangle petit i el gran s'ha establert seguint la indicació explícita del propi enunciat, que ja diu quins costats es corresponen entre si.",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3RzIHZhbG9ycyBubyBzdXJ0ZW4gZGUgbGEgcHJvcG9yY2nDszogY2FsY3VsYSAkMTBcXGNkb3Qweyx9NzUkIGkgJDdcXGNkb3Qweyx9NzUkIHBhcyBhIHBhcyBlbiBsbG9jIGQnYXJyb2RvbmlyIGEgbm9tYnJlcyBlbnRlcnMgcHJvcGVycy4iLCAiIiwgIkFxdWVzdHMgdmFsb3JzIHN1cnRlbiBkZSAkMTBcXGNkb3Q2JCBpICQ3XFxjZG90NiQgc2Vuc2UgZGl2aWRpciBwZXIgJDgkOiBsYSByYcOzIGRlIHNlbWJsYW7Dp2Egw6lzICRcXGZyYWN7Nn17OH0kLCBubyBub23DqXMgZWwgJDYkLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkJ2FwbGljYXIgbGEgcmHDsyBpbnZlcnRpZGEgJGs9XFxmcmFjezh9ezZ9JCBhbHMgY29zdGF0cyBkZSAkMTAkIGkgJDckIGNtOyBsYSByYcOzIMOpcyAkaz1cXGZyYWN7Nn17OH09MHssfTc1JCAoZGVsIGNvc3RhdCBwZXRpdCBjb25lZ3V0IGFsIGdyYW4gY29uZWd1dCksIG5vIGxhIGludmVyc2EuIl0sICJlcnIiOiBbIlBST0dSRVNTSU9fSU5WRU5UQURBIiwgIiIsICJURVJNRV9PQkxJREFUX09QRVJBQ0lPIiwgIkNSRVVBTUVOVF9JTlZFUlRJVCJdLCAicmVzIjogWyIkaz1cXGRmcmFjezZ9ezh9PTB7LH03NSQiLCAiJDEwXFxjZG90MHssfTc1PTd7LH01JCBjbSRcXHFxdWFkIDdcXGNkb3Qweyx9NzU9NXssfTI1JCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 253 119\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,88.6)\"><polygon points=\"0.0,0.0 90.0,0.0 78.0,-74.6\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"159.2,0.0 224.0,0.0 186.4,-50.5\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">8 cm</text><text x=\"52.8\" y=\"-19.9\" text-anchor=\"middle\" class=\"fig-etq petita\">10 cm</text><text x=\"103.8\" y=\"-37.5\" text-anchor=\"middle\" class=\"fig-etq petita\">7 cm</text><text x=\"191.6\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">6 cm</text><text x=\"182.5\" y=\"-17.1\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"214.1\" y=\"-28.9\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text></g></svg>"
  },
  {
   "id": "154c",
   "ex": 154,
   "ap": "c",
   "bloc": "semblanca",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud dels costats desconeguts en aquests parells de triangles semblants.",
   "enunciat": "Triangle gran de costat $6$ cm (desconegut als altres dos); triangle petit de costats $3$ cm, $5$ cm i $4$ cm, on el de $5$ cm (el més llarg) correspon al de $6$ cm. Quant valen els altres dos costats del triangle gran?",
   "opcions": [
    "$3$ cm i $4$ cm",
    "$2{,}5$ cm i $3{,}33$ cm",
    "$18$ cm i $24$ cm",
    "$3{,}6$ cm i $4{,}8$ cm"
   ],
   "pistes": [
    "La raó de semblança és $k=\\dfrac{6}{5}=1{,}2$ (el costat de $6$ cm correspon al de $5$ cm, el més llarg del triangle petit).",
    "Aplica aquesta raó als altres dos costats del triangle petit ($3$ cm i $4$ cm)."
   ],
   "nota": "La correspondència entre costats del triangle petit i el gran s'ha establert seguint la indicació explícita del propi enunciat, que ja diu quins costats es corresponen entre si.",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3RzIHZhbG9ycyBzw7NuIGVscyBjb3N0YXRzIGRlbCB0cmlhbmdsZSBQRVRJVCwgbm8gZWxzIGRlbCB0cmlhbmdsZSBncmFuIHF1ZSBjYWxlbjogZW5jYXJhIGhhcyBkJ2FwbGljYXItaGkgbGEgcmHDsyBkZSBzZW1ibGFuw6dhLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkJ2FwbGljYXIgbGEgcmHDsyBpbnZlcnRpZGEgJGs9XFxmcmFjezV9ezZ9JCBhbHMgY29zdGF0cyBkZSAkMyQgaSAkNCQgY207IGxhIHJhw7Mgw6lzICRrPVxcZnJhY3s2fXs1fT0xeyx9MiQgKGRlbCBjb3N0YXQgY29uZWd1dCBkZWwgdHJpYW5nbGUgZ3JhbiBhbCBkZWwgcGV0aXQpLCBubyBsYSBpbnZlcnNhLiIsICJBcXVlc3RzIHZhbG9ycyBzdXJ0ZW4gZGUgJDNcXGNkb3Q2JCBpICQ0XFxjZG90NiQgc2Vuc2UgZGl2aWRpciBwZXIgJDUkOiBsYSByYcOzIGRlIHNlbWJsYW7Dp2Egw6lzICRcXGZyYWN7Nn17NX0kLCBubyBub23DqXMgZWwgJDYkLiIsICIiXSwgImVyciI6IFsiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiIl0sICJyZXMiOiBbIiRrPVxcZGZyYWN7Nn17NX09MXssfTIkIiwgIiQzXFxjZG90MXssfTI9M3ssfTYkIGNtJFxccXF1YWQgNFxcY2RvdDF7LH0yPTR7LH04JCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 333 150\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,119.3)\"><polygon points=\"0.0,0.0 90.0,0.0 25.3,-62.6\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"169.8,0.0 304.8,0.0 226.4,-105.3\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"31.2\" y=\"-20.8\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text><text x=\"68.1\" y=\"-39.1\" text-anchor=\"middle\" class=\"fig-etq petita\">4 cm</text><text x=\"237.2\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">6 cm</text><text x=\"207.8\" y=\"-44.5\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"274.4\" y=\"-56.3\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text></g></svg>"
  },
  {
   "id": "154d",
   "ex": 154,
   "ap": "d",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 2,
   "encapcalament": "Calcula la longitud dels costats desconeguts en aquests parells de triangles semblants.",
   "enunciat": "Dos triangles isòsceles tenen els costats iguals de $5$ cm cadascun, amb bases respectives de $3{,}2$ cm i $2$ cm. Són semblants?",
   "opcions": [
    "No es pot saber sense conèixer els angles",
    "Sí, perquè els dos triangles són isòsceles",
    "No, perquè la raó entre els costats iguals ($1$) no coincideix amb la raó entre les bases ($1{,}6$)",
    "Sí, perquè els costats iguals mesuren el mateix ($5$ cm als dos triangles)"
   ],
   "pistes": [
    "Per ser semblants, TOTS els costats han de guardar la mateixa raó, no només alguns.",
    "Compara la raó dels costats iguals ($\\frac{5}{5}$) amb la raó de les bases ($\\frac{3{,}2}{2}$)."
   ],
   "nota": "La correspondència entre costats del triangle petit i el gran s'ha establert seguint la indicació explícita del propi enunciat, que ja diu quins costats es corresponen entre si.",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBbWIgZWxzIHRyZXMgY29zdGF0cyBkZSBjYWRhIHRyaWFuZ2xlIGphIG4naGkgaGEgcHJvdSBwZXIgYXBsaWNhciBlbCBjcml0ZXJpIGNvc3RhdC1jb3N0YXQtY29zdGF0OiBubyBjYWxlbiBlbHMgYW5nbGVzIHBlciBkZXNjYXJ0YXIgbGEgc2VtYmxhbsOnYS4iLCAiU2VyIGlzw7JzY2VsZXMgbm9tw6lzIGRpdSBxdWUgaGkgaGEgZG9zIGNvc3RhdHMgaWd1YWxzIGVudHJlIGVsbHMgZGlucyBkZSBDQURBIHRyaWFuZ2xlOyBubyBkaXUgcmVzIHNvYnJlIGxhIHByb3BvcmNpw7MgZW50cmUgZWxzIGRvcyB0cmlhbmdsZXMsIHF1ZSDDqXMgZWwgcXVlIGNhbCBjb21wcm92YXIuIiwgIiIsICJRdWUgdW4gcGFyZWxsIGRlIGNvc3RhdHMgY29pbmNpZGVpeGkgbm8gYmFzdGE6IGNhbCBxdWUgVE9UUyBlbHMgY29zdGF0cyBndWFyZGluIGxhIG1hdGVpeGEgcmHDsy4gQXF1w60gbGVzIGJhc2VzICgkM3ssfTIkIGNtIGkgJDIkIGNtKSBubyBndWFyZGVuIGxhIG1hdGVpeGEgcmHDsyBxdWUgZWxzIGNvc3RhdHMgaWd1YWxzLiJdLCAiZXJyIjogWyJDUklURVJJX1NFTUJMQU5DQV9JTlNVRklDSUVOVCIsICJDUklURVJJX1NFTUJMQU5DQV9JTlNVRklDSUVOVCIsICIiLCAiUkFPX05PTUVTX1VOX0NPU1RBVCJdLCAicmVzIjogWyJSYcOzIGRlbHMgY29zdGF0cyBpZ3VhbHM6ICRcXGRmcmFjezV9ezV9PTEkIiwgIlJhw7MgZGUgbGVzIGJhc2VzOiAkXFxkZnJhY3szeyx9Mn17Mn09MXssfTYkIiwgIkNvbSBxdWUgJDFcXG5lMXssfTYkLCBlbHMgdHJpYW5nbGVzIE5PIHPDs24gc2VtYmxhbnRzLiJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 298 148\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,117.1)\"><polygon points=\"0.0,0.0 90.0,0.0 45.0,-103.1\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"164.3,0.0 263.3,0.0 213.8,-101.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">2 cm</text><text x=\"40.8\" y=\"-40.6\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"85.8\" y=\"-56.6\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"213.8\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">3,2 cm</text><text x=\"207.1\" y=\"-38.8\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"256.6\" y=\"-56.4\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text></g></svg>"
  },
  {
   "id": "155a",
   "ex": 155,
   "ap": "a",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 3,
   "encapcalament": "Determina si aquests parells de triangles són semblants, i quin criteri s'aplica en cada cas.",
   "enunciat": "Triangle de costats $4$ cm i $5$ cm amb angle comprès de $80^\\circ$; triangle de costats $5$ cm i $6$ cm amb angle comprès de $80^\\circ$. Són semblants?",
   "opcions": [
    "Sí, perquè els dos triangles tenen un angle de $80^\\circ$",
    "Sí, perquè tots dos triangles tenen un costat de $5$ cm",
    "No, perquè les raons $\\frac{5}{4}=1{,}25$ i $\\frac{6}{5}=1{,}2$ no coincideixen",
    "No es pot saber sense conèixer el tercer costat"
   ],
   "pistes": [
    "Amb dos costats i l'angle comprès conegut, aplica el criteri costat-angle-costat: compara les raons dels costats que envolten l'angle de $80^\\circ$.",
    "Calcula $\\frac{5}{4}$ i $\\frac{6}{5}$ i compara-les."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJRdWUgbCdhbmdsZSBjb21wcsOocyBjb2luY2lkZWl4aSBubyBiYXN0YSBwZWwgY3JpdGVyaSBjb3N0YXQtYW5nbGUtY29zdGF0OiBjYWwsIGEgbcOpcywgcXVlIGVscyBjb3N0YXRzIHF1ZSBsJ2Vudm9sdGVuIHNpZ3VpbiBwcm9wb3JjaW9uYWxzLCBpIGFxdcOtIG5vIGhvIHPDs24uIiwgIlF1ZSBjb2luY2lkZWl4aSB1biBzb2wgY29zdGF0IG5vIMOpcyBjYXAgZGVscyB0cmVzIGNyaXRlcmlzIGRlIHNlbWJsYW7Dp2EgZGUgdHJpYW5nbGVzOiBjYWwgY29tcGFyYXIgbGEgcHJvcG9yY2nDsyBlbnRyZSBlbHMgRE9TIGNvc3RhdHMgcXVlIGVudm9sdGVuIGwnYW5nbGUgaWd1YWwuIiwgIiIsICJBbWIgZG9zIGNvc3RhdHMgaSBsJ2FuZ2xlIGNvbXByw6hzIGphIG4naGkgaGEgcHJvdSBwZXIgYXBsaWNhciBlbCBjcml0ZXJpIGNvc3RhdC1hbmdsZS1jb3N0YXQ6IG5vIGNhbCBlbCB0ZXJjZXIgY29zdGF0IHBlciBkZXNjYXJ0YXIgbGEgc2VtYmxhbsOnYS4iXSwgImVyciI6IFsiQ1JJVEVSSV9TRU1CTEFOQ0FfSU5TVUZJQ0lFTlQiLCAiUkFPX05PTUVTX1VOX0NPU1RBVCIsICIiLCAiQ1JJVEVSSV9TRU1CTEFOQ0FfSU5TVUZJQ0lFTlQiXSwgInJlcyI6IFsiJFxcZGZyYWN7NX17NH09MXssfTI1IFxccXF1YWQgXFxkZnJhY3s2fXs1fT0xeyx9MiQiLCAiQ29tIHF1ZSAkMXssfTI1XFxuZTF7LH0yJCwgZWxzIHRyaWFuZ2xlcyBOTyBzw7NuIHNlbWJsYW50cy4iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 304 131\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,99.8)\"><polygon points=\"0.0,0.0 90.0,0.0 37.8,-70.2\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"166.0,0.0 276.0,0.0 212.2,-85.8\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 15.00 0.00 A 15.00 15.00 0 0 1 7.11 -13.21\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><path d=\"M 181.00 0.00 A 15.00 15.00 0 0 1 173.11 -13.21\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">4 cm</text><text x=\"36.5\" y=\"-22.7\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"221\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"206.7\" y=\"-30.5\" text-anchor=\"middle\" class=\"fig-etq petita\">6 cm</text></g></svg>"
  },
  {
   "id": "155b",
   "ex": 155,
   "ap": "b",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 3,
   "encapcalament": "Determina si aquests parells de triangles són semblants, i quin criteri s'aplica en cada cas.",
   "enunciat": "Triangle de costats $11$ cm i $9{,}1$ cm amb angle comprès de $65^\\circ$; triangle de costats $9$ cm i $7$ cm amb angle comprès de $65^\\circ$. Són semblants?",
   "opcions": [
    "No, perquè les raons $\\frac{9}{11}\\approx0{,}818$ i $\\frac{7}{9{,}1}\\approx0{,}769$ no coincideixen",
    "No es pot saber sense conèixer el tercer costat",
    "Sí, perquè els costats es corresponen en ordre decreixent de mida",
    "Sí, perquè els dos triangles tenen un angle de $65^\\circ$"
   ],
   "pistes": [
    "Amb dos costats i l'angle comprès conegut, aplica el criteri costat-angle-costat: compara les raons dels costats que envolten l'angle de $65^\\circ$.",
    "Calcula $\\frac{9}{11}$ i $\\frac{7}{9{,}1}$ i compara-les."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQW1iIGRvcyBjb3N0YXRzIGkgbCdhbmdsZSBjb21wcsOocyBjb25lZ3V0IGphIG4naGkgaGEgcHJvdSBwZXIgYXBsaWNhciBlbCBjcml0ZXJpIGNvc3RhdC1hbmdsZS1jb3N0YXQ6IG5vIGNhbCBlbCB0ZXJjZXIgY29zdGF0IHBlciBkZXNjYXJ0YXIgbGEgc2VtYmxhbsOnYS4iLCAiTCdvcmRyZSBkZSBtaWRhIGRlbHMgY29zdGF0cyBubyDDqXMgY2FwIGNyaXRlcmkgZGUgc2VtYmxhbsOnYTogY2FsIGNvbXBhcmFyIGxlcyByYW9ucyBudW3DqHJpcXVlcyBleGFjdGVzIGRlbHMgY29zdGF0cyBjb3JyZXNwb25lbnRzLiIsICJRdWUgbCdhbmdsZSBjb21wcsOocyBjb2luY2lkZWl4aSBubyBiYXN0YSBwZWwgY3JpdGVyaSBjb3N0YXQtYW5nbGUtY29zdGF0OiBjYWwsIGEgbcOpcywgcXVlIGVscyBjb3N0YXRzIHF1ZSBsJ2Vudm9sdGVuIHNpZ3VpbiBwcm9wb3JjaW9uYWxzLCBpIGFxdcOtIG5vIGhvIHPDs24gcHJvdSBhcHJveGltYWRhbWVudC4iXSwgImVyciI6IFsiIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIl0sICJyZXMiOiBbIiRcXGRmcmFjezl9ezExfVxcYXBwcm94MHssfTgxOCBcXHFxdWFkIFxcZGZyYWN7N317OXssfTF9XFxhcHByb3gweyx9NzY5JCIsICJDb20gcXVlICQweyx9ODE4XFxuZTB7LH03NjkkLCBlbHMgdHJpYW5nbGVzIE5PIHPDs24gc2VtYmxhbnRzIHBlbCBjcml0ZXJpIGNvc3RhdC1hbmdsZS1jb3N0YXQuIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 284 115\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(37.2,84.2)\"><polygon points=\"0.0,0.0 90.0,0.0 37.8,-70.2\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"160.2,0.0 231.9,0.0 190.3,-55.9\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 15.00 0.00 A 15.00 15.00 0 0 1 7.11 -13.21\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><path d=\"M 175.25 0.00 A 15.00 15.00 0 0 1 167.36 -13.21\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">11 cm</text><text x=\"-4\" y=\"-44.5\" text-anchor=\"middle\" class=\"fig-etq petita\">9,1 cm</text><text x=\"196.1\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">9 cm</text><text x=\"157.7\" y=\"-34.5\" text-anchor=\"middle\" class=\"fig-etq petita\">7 cm</text></g></svg>"
  },
  {
   "id": "155c",
   "ex": 155,
   "ap": "c",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 3,
   "encapcalament": "Determina si aquests parells de triangles són semblants, i quin criteri s'aplica en cada cas.",
   "enunciat": "Triangle de costats $5$ cm i $7$ cm; triangle de costats $8$ cm i $12{,}8$ cm (sense conèixer cap angle). Es pot assegurar que són semblants?",
   "opcions": [
    "No, perquè les raons $1{,}6$ i $1{,}829$ no coincideixen",
    "Sí, perquè les raons $1{,}6$ i $1{,}829$ són semblants numèricament",
    "No es pot assegurar amb aquestes dades: les raons $\\frac{8}{5}=1{,}6$ i $\\frac{12{,}8}{7}\\approx1{,}829$ no coincideixen, però a més falta un angle o el tercer costat per aplicar un criteri amb seguretat",
    "Sí, perquè tots dos triangles tenen dos costats coneguts"
   ],
   "pistes": [
    "Amb només dos costats de cada triangle, sense conèixer l'angle comprès, no n'hi ha prou per aplicar cap dels tres criteris de semblança amb seguretat.",
    "Calcula igualment les raons $\\frac{8}{5}$ i $\\frac{12{,}8}{7}$ per veure si almenys descarten la semblança pel criteri costat-angle-costat."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBbWIgbm9tw6lzIGRvcyBjb3N0YXRzIGRlIGNhZGEgdHJpYW5nbGUgaSBzZW5zZSBsJ2FuZ2xlIGNvbXByw6hzIG5vIGVzIHBvdCBhcGxpY2FyIGVsIGNyaXRlcmkgY29zdGF0LWFuZ2xlLWNvc3RhdCBhbWIgc2VndXJldGF0OiBmYWx0YSBpbmZvcm1hY2nDsyBwZXIgYWZpcm1hci1obyBPIG5lZ2FyLWhvIGFtYiBhcXVlc3QgY3JpdGVyaS4iLCAiJDF7LH02JCBpICQxeyx9ODI5JCBubyBjb2luY2lkZWl4ZW4sIGkgcGVyIGFwbGljYXIgdW4gY3JpdGVyaSBkZSBzZW1ibGFuw6dhIGNhbGVuIGRhZGVzIHF1ZSBhcXXDrSBmYWx0ZW4gKGwnYW5nbGUgY29tcHLDqHMgbyBlbCB0ZXJjZXIgY29zdGF0KS4iLCAiIiwgIkNvbsOoaXhlciBkb3MgY29zdGF0cyBkZSBjYWRhc2N1biBubyBiYXN0YSBwZXIgYXBsaWNhciBjYXAgZGVscyB0cmVzIGNyaXRlcmlzIGRlIHNlbWJsYW7Dp2E6IGNhbGVuIGVscyB0cmVzIGNvc3RhdHMgKGNyaXRlcmkgY29zdGF0LWNvc3RhdC1jb3N0YXQpIG8gbCdhbmdsZSBjb21wcsOocyAoY3JpdGVyaSBjb3N0YXQtYW5nbGUtY29zdGF0KS4iXSwgImVyciI6IFsiQ1JJVEVSSV9TRU1CTEFOQ0FfSU5TVUZJQ0lFTlQiLCAiQ1JJVEVSSV9TRU1CTEFOQ0FfSU5TVUZJQ0lFTlQiLCAiIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIl0sICJyZXMiOiBbIiRcXGRmcmFjezh9ezV9PTF7LH02IFxccXF1YWQgXFxkZnJhY3sxMnssfTh9ezd9XFxhcHByb3gxeyx9ODI5JCIsICJMZXMgcmFvbnMgbm8gY29pbmNpZGVpeGVuLCBwZXLDsiBhbWIgbm9tw6lzIGFxdWVzdGEgaW5mb3JtYWNpw7Mgbm8gZXMgcG90IGFmaXJtYXIgcXVlIHNpZ3VpbiBzZW1ibGFudHM6IGNhbGVuIGVscyB0cmVzIGNvc3RhdHMgbyB1biBhbmdsZSBjb21wcsOocyBwZXIgYXBsaWNhciBhbWIgc2VndXJldGF0IHVuIGNyaXRlcmkgZGUgc2VtYmxhbsOnYS4iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 357 166\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,135.7)\"><polygon points=\"0.0,0.0 90.0,0.0 37.8,-70.2\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"172.9,0.0 328.9,0.0 238.4,-121.7\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"36.5\" y=\"-22.7\" text-anchor=\"middle\" class=\"fig-etq petita\">7 cm</text><text x=\"250.9\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">8 cm</text><text x=\"228.6\" y=\"-45.6\" text-anchor=\"middle\" class=\"fig-etq petita\">12,8 cm</text></g></svg>"
  },
  {
   "id": "155d",
   "ex": 155,
   "ap": "d",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 3,
   "encapcalament": "Determina si aquests parells de triangles són semblants, i quin criteri s'aplica en cada cas.",
   "enunciat": "Triangle rectangle de catets $3$ cm i $5$ cm; triangle rectangle de catets $10$ cm i $13$ cm. Són semblants?",
   "opcions": [
    "No es pot saber sense calcular les hipotenuses",
    "No, perquè les raons $\\frac{10}{3}\\approx3{,}33$ i $\\frac{13}{5}=2{,}6$ no coincideixen",
    "Sí, perquè tots dos són triangles rectangles",
    "Sí, perquè la hipotenusa és més gran en tots dos casos"
   ],
   "pistes": [
    "En un triangle rectangle, els catets envolten l'angle recte, que és igual als dos triangles: aplica el criteri costat-angle-costat comparant la raó dels catets.",
    "Calcula $\\frac{10}{3}$ i $\\frac{13}{5}$ i compara-les."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJFbHMgY2F0ZXRzIGphIGVudm9sdGVuIGwnYW5nbGUgcmVjdGUgKGwnYW5nbGUgY29tcHLDqHMsIGlndWFsIGFscyBkb3MgdHJpYW5nbGVzKTogYW1iIGxhIHNldmEgcmHDsyBqYSBuJ2hpIGhhIHByb3UgcGVyIGFwbGljYXIgZWwgY3JpdGVyaSBjb3N0YXQtYW5nbGUtY29zdGF0LCBzZW5zZSBjYWxjdWxhciBjYXAgaGlwb3RlbnVzYS4iLCAiIiwgIlNlciByZWN0YW5nbGUgbm9tw6lzIGZpeGEgdW4gYW5nbGUgZGUgJDkwXlxcY2lyYyQgaWd1YWwgYWxzIGRvcyB0cmlhbmdsZXM7IHBlciBhc3NlZ3VyYXIgbGEgc2VtYmxhbsOnYSBjYWwsIGEgbcOpcywgcXVlIGVscyBjYXRldHMgKHF1ZSBlbnZvbHRlbiBhcXVlc3QgYW5nbGUgcmVjdGUpIHNpZ3VpbiBwcm9wb3JjaW9uYWxzLCBpIGFxdcOtIG5vIGhvIHPDs24uIiwgIlF1ZSBsYSBoaXBvdGVudXNhIHNpZ3VpIGVsIGNvc3RhdCBtw6lzIGdyYW4gw6lzIGNlcnQgZW4gcXVhbHNldm9sIHRyaWFuZ2xlIHJlY3RhbmdsZTsgbm8gZGl1IHJlcyBzb2JyZSBzaSBlbHMgZG9zIHRyaWFuZ2xlcyBjb25jcmV0cyBzw7NuIHByb3BvcmNpb25hbHMgZW50cmUgc2kuIl0sICJlcnIiOiBbIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIiIsICJDUklURVJJX1NFTUJMQU5DQV9JTlNVRklDSUVOVCIsICJSQU9fTk9NRVNfVU5fQ09TVEFUIl0sICJyZXMiOiBbIiRcXGRmcmFjezEwfXszfVxcYXBwcm94M3ssfTMzIFxccXF1YWQgXFxkZnJhY3sxM317NX09MnssfTYkIiwgIkNvbSBxdWUgJDN7LH0zM1xcbmUyeyx9NiQsIGVscyB0cmlhbmdsZXMgTk8gc8OzbiBzZW1ibGFudHMgcGVsIGNyaXRlcmkgY29zdGF0LWFuZ2xlLWNvc3RhdCBhbWIgbCdhbmdsZSByZWN0ZSBjb20gYSBhbmdsZSBjb21wcsOocy4iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 476 337\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles amb els costats corresponents marcats.</title><g transform=\"translate(14.0,306.5)\"><polygon points=\"0.0,0.0 90.0,0.0 0.0,-112.5\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"188.3,0.0 447.1,0.0 188.3,-292.5\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 15.00 0.00 A 15.00 15.00 0 0 1 0.00 -15.00\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><path d=\"M 203.31 0.00 A 15.00 15.00 0 0 1 188.31 -15.00\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"45\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">3 cm</text><text x=\"15\" y=\"-53.3\" text-anchor=\"middle\" class=\"fig-etq petita\">5 cm</text><text x=\"317.7\" y=\"13.9\" text-anchor=\"middle\" class=\"fig-etq petita\">10 cm</text><text x=\"208.3\" y=\"-143.3\" text-anchor=\"middle\" class=\"fig-etq petita\">13 cm</text></g></svg>"
  },
  {
   "id": "155e",
   "ex": 155,
   "ap": "e",
   "bloc": "semblanca",
   "tipus": "B",
   "dif": 3,
   "encapcalament": "Determina si aquests parells de triangles són semblants, i quin criteri s'aplica en cada cas.",
   "enunciat": "Triangle rectangle amb un angle agut de $50^\\circ$; triangle rectangle amb un angle agut de $40^\\circ$. Són semblants?",
   "opcions": [
    "Sí, però només si a més els costats són proporcionals",
    "No es pot saber sense conèixer els costats",
    "No, perquè els angles aguts donats ($50^\\circ$ i $40^\\circ$) no coincideixen",
    "Sí, pel criteri angle-angle-angle: els dos triangles tenen els mateixos tres angles ($90^\\circ$, $50^\\circ$ i $40^\\circ$)"
   ],
   "pistes": [
    "Calcula el tercer angle de cada triangle: $180^\\circ-90^\\circ-50^\\circ$ i $180^\\circ-90^\\circ-40^\\circ$.",
    "Compara els tres angles de cada triangle un cop calculats tots dos tercers angles."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJFbCBjcml0ZXJpIGFuZ2xlLWFuZ2xlLWFuZ2xlIMOpcyBzdWZpY2llbnQgcGVyIHNpIHNvbDogc2kgZWxzIHRyZXMgYW5nbGVzIGNvaW5jaWRlaXhlbiwgZWxzIHRyaWFuZ2xlcyBqYSBzw7NuIHNlbWJsYW50cywgc2Vuc2UgbmVjZXNzaXRhdCBkZSBjb21wcm92YXIgZWxzIGNvc3RhdHMgYSBwYXJ0LiIsICJBbWIgZWxzIHRyZXMgYW5nbGVzIGRlIGNhZGEgdHJpYW5nbGUgKHVuIGNvcCBjYWxjdWxhdCBlbCB0ZXJjZXIpIGphIG4naGkgaGEgcHJvdSBwZXIgYXBsaWNhciBlbCBjcml0ZXJpIGFuZ2xlLWFuZ2xlLWFuZ2xlOiBubyBjYWxlbiBlbHMgY29zdGF0cy4iLCAiQ2FsIGNhbGN1bGFyIGVsIFRFUkNFUiBhbmdsZSBkZSBjYWRhIHRyaWFuZ2xlIGFiYW5zIGRlIGNvbmNsb3VyZSByZXM6ICQxODBeXFxjaXJjLTkwXlxcY2lyYy01MF5cXGNpcmM9NDBeXFxjaXJjJCBpICQxODBeXFxjaXJjLTkwXlxcY2lyYy00MF5cXGNpcmM9NTBeXFxjaXJjJCwgYWl4w60gcXVlIGVuIHJlYWxpdGF0IGVscyBkb3MgdHJpYW5nbGVzIHRlbmVuIGVscyBtYXRlaXhvcyB0cmVzIGFuZ2xlcy4iLCAiIl0sICJlcnIiOiBbIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIkNSSVRFUklfU0VNQkxBTkNBX0lOU1VGSUNJRU5UIiwgIiJdLCAicmVzIjogWyJUcmlhbmdsZSBhbWIgYW5nbGUgYWd1dCBkZSAkNTBeXFxjaXJjJDogdMOpIGFuZ2xlcyAkOTBeXFxjaXJjJCwgJDUwXlxcY2lyYyQgaSAkMTgwXlxcY2lyYy05MF5cXGNpcmMtNTBeXFxjaXJjPTQwXlxcY2lyYyQuIiwgIlRyaWFuZ2xlIGFtYiBhbmdsZSBhZ3V0IGRlICQ0MF5cXGNpcmMkOiB0w6kgYW5nbGVzICQ5MF5cXGNpcmMkLCAkNDBeXFxjaXJjJCBpICQxODBeXFxjaXJjLTkwXlxcY2lyYy00MF5cXGNpcmM9NTBeXFxjaXJjJC4iLCAiRWxzIGRvcyB0cmlhbmdsZXMgdGVuZW4gZWxzIG1hdGVpeG9zIHRyZXMgYW5nbGVzOiBTw40gc8OzbiBzZW1ibGFudHMsIHBlbCBjcml0ZXJpIGFuZ2xlLWFuZ2xlLWFuZ2xlLiJdfQ=="
  },
  {
   "id": "156a",
   "ex": 156,
   "ap": "a",
   "bloc": "escales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Expressa mitjançant una escala numèrica (a més de l'escala gràfica, que trobaràs descrita a la resolució).",
   "enunciat": "$1$ cm en el plànol equival a $2$ km en la realitat. Quina és l'escala numèrica?",
   "opcions": [
    "$1:200\\,000$",
    "$1:2$",
    "$200\\,000:1$",
    "$1:20\\,000$"
   ],
   "pistes": [
    "Converteix els $2$ km a la mateixa unitat que el $1$ cm del dibuix: $2\\text{ km}=200\\,000$ cm.",
    "L'escala numèrica és $1:n$, amb $n$ la distància real en centímetres."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRmFsdGEgY29udmVydGlyIGVscyAkMiQga20gYSBjZW50w61tZXRyZXMgcGVycXXDqCBsZXMgZHVlcyBtZXN1cmVzIGRlIGwnZXNjYWxhIGVzdGlndWluIGVuIGxhIG1hdGVpeGEgdW5pdGF0OiAkMlxcdGV4dHsga219PTIwMFxcLDAwMCQgY20uIiwgIkwnZXNjYWxhIG51bcOocmljYSBzJ2VzY3JpdSBhbWIgZWwgZGlidWl4IHByaW1lciBpIGxhIHJlYWxpdGF0IGRlc3Byw6lzOiAkMTpuJCwgbm8gJG46MSQuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIGNvbnZlcnRpciAkMiQga20gYSBtZXRyZXMgKCQyMDAkIG0pIGVuIGNvbXB0ZXMgZGUgYSBjZW50w61tZXRyZXM6IGNhbCAkMlxcdGV4dHsga219PTIwMFxcLDAwMCQgY20sIG5vICQyMFxcLDAwMCQuIl0sICJlcnIiOiBbIiIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIiwgIklOVkVSVElEQSIsICJQUk9EVUNURV9NQUwiXSwgInJlcyI6IFsiJDJcXHRleHR7IGttfT0yMDBcXCwwMDAkIGNtIiwgIkVzY2FsYSBudW3DqHJpY2E6ICQxOjIwMFxcLDAwMCQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 1 cm, representa 2 km de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">1 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">2 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 2 km</text></svg>"
  },
  {
   "id": "156b",
   "ex": 156,
   "ap": "b",
   "bloc": "escales",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Expressa mitjançant una escala numèrica (a més de l'escala gràfica, que trobaràs descrita a la resolució).",
   "enunciat": "$1$ cm en el plànol equival a $50$ km en la realitat. Quina és l'escala numèrica?",
   "opcions": [
    "$5\\,000\\,000:1$",
    "$1:500\\,000$",
    "$1:5\\,000\\,000$",
    "$1:50$"
   ],
   "pistes": [
    "Converteix els $50$ km a la mateixa unitat que el $1$ cm del dibuix: $50\\text{ km}=5\\,000\\,000$ cm.",
    "L'escala numèrica és $1:n$, amb $n$ la distància real en centímetres."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJMJ2VzY2FsYSBudW3DqHJpY2Egcydlc2NyaXUgYW1iIGVsIGRpYnVpeCBwcmltZXIgaSBsYSByZWFsaXRhdCBkZXNwcsOpczogJDE6biQsIG5vICRuOjEkLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSBjb252ZXJ0aXIgJDUwJCBrbSBhIG1ldHJlcyAoJDUwXFwsMDAwJCBtKSBlbiBjb21wdGVzIGRlIGEgY2VudMOtbWV0cmVzOiBjYWwgJDUwXFx0ZXh0eyBrbX09NVxcLDAwMFxcLDAwMCQgY20sIG5vICQ1MDBcXCwwMDAkLiIsICIiLCAiRmFsdGEgY29udmVydGlyIGVscyAkNTAkIGttIGEgY2VudMOtbWV0cmVzIHBlcnF1w6ggbGVzIGR1ZXMgbWVzdXJlcyBkZSBsJ2VzY2FsYSBlc3RpZ3VpbiBlbiBsYSBtYXRlaXhhIHVuaXRhdDogJDUwXFx0ZXh0eyBrbX09NVxcLDAwMFxcLDAwMCQgY20uIl0sICJlcnIiOiBbIklOVkVSVElEQSIsICJQUk9EVUNURV9NQUwiLCAiIiwgIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiXSwgInJlcyI6IFsiJDUwXFx0ZXh0eyBrbX09NVxcLDAwMFxcLDAwMCQgY20iLCAiRXNjYWxhIG51bcOocmljYTogJDE6NVxcLDAwMFxcLDAwMCQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 1 cm, representa 50 km de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">1 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">2 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 50 km</text></svg>"
  },
  {
   "id": "158",
   "ex": 158,
   "ap": "",
   "bloc": "escales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "La distància real entre dues ciutats és de $450$ km. Troba la distància que les separa en un mapa dibuixat a escala $1:1\\,500\\,000$.",
   "opcions": [
    "$3$ cm",
    "$30$ cm",
    "$675\\,000\\,000\\,000$ cm",
    "$0{,}3$ cm"
   ],
   "pistes": [
    "Converteix la distància real a centímetres: $450\\text{ km}=45\\,000\\,000$ cm.",
    "Divideix-la per l'escala: $45\\,000\\,000:1\\,500\\,000$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3QgdmFsb3IgdMOpIHVuIGZhY3RvciAkMTAkIGRlIG1lbnlzOiByZXZpc2EgbGEgY29udmVyc2nDsyAkNDUwXFx0ZXh0eyBrbX09NDVcXCwwMDBcXCwwMDAkIGNtIGFiYW5zIGRlIGRpdmlkaXIgcGVyICQxXFwsNTAwXFwsMDAwJC4iLCAiIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIG11bHRpcGxpY2FyIGxhIGRpc3TDoG5jaWEgcmVhbCBwZXIgbCdlc2NhbGEgZW4gY29tcHRlcyBkZSBkaXZpZGlyLWhpOiBlbiB1bmEgZXNjYWxhICQxOm4kLCBsYSBkaXN0w6BuY2lhIGFsIG1hcGEgw6lzIGxhIGRpc3TDoG5jaWEgcmVhbCBESVZJRElEQSBwZXIgJG4kLiIsICJTZW1ibGEgcXVlIGhhcyBjb252ZXJ0aXQgZWxzICQ0NTAkIGttIGEgbWV0cmVzICgkNDUwXFwsMDAwJCBtKSBpIG5vIGEgY2VudMOtbWV0cmVzOiBjYWwgJDQ1MFxcdGV4dHsga219PTQ1XFwsMDAwXFwsMDAwJCBjbSBhYmFucyBkZSBkaXZpZGlyIHBlciBsJ2VzY2FsYS4iXSwgImVyciI6IFsiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICIiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIlBST0RVQ1RFX01BTCJdLCAicmVzIjogWyIkNDUwXFx0ZXh0eyBrbX09NDVcXCwwMDBcXCwwMDAkIGNtIiwgIiQ0NVxcLDAwMFxcLDAwMDoxXFwsNTAwXFwsMDAwPTMwJCBjbSJdfQ=="
  },
  {
   "id": "159",
   "ex": 159,
   "ap": "",
   "bloc": "escales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "En representar la carretera que uneix dos pobles en un mapa d'escala $1:500\\,000$, té una longitud de $6$ cm. Quina seria la longitud de la carretera si la representem en un plànol d'escala $1:60\\,000$?",
   "opcions": [
    "$0{,}72$ cm",
    "$0{,}00072$ cm",
    "$50$ cm",
    "$720$ cm"
   ],
   "pistes": [
    "Calcula primer la distància real: $6\\text{ cm}\\cdot500\\,000=3\\,000\\,000$ cm.",
    "Divideix aquesta distància real per la segona escala: $3\\,000\\,000:60\\,000$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkJ2FwbGljYXIgbGEgcmHDsyBkZSBsZXMgZXNjYWxlcyBpbnZlcnRpZGEgKCQ2MFxcLDAwMC81MDBcXCwwMDAkIGVubGxvYyBkZSAkNTAwXFwsMDAwLzYwXFwsMDAwJCk6IGEgdW5hIGVzY2FsYSBhbWIgdW4gbm9tYnJlIE3DiVMgUEVUSVQgKG3DqXMgZGV0YWxsYWRhKSBsaSBjb3JyZXNwb24gdW5hIGxvbmdpdHVkIGRpYnVpeGFkYSBNw4lTIEdSQU4sIG5vIG3DqXMgcGV0aXRhLiIsICJBcXVlc3QgcmVzdWx0YXQgw6lzIG1hc3NhIHBldGl0IHBlciBhIHVuYSBlc2NhbGEgbcOpcyBkZXRhbGxhZGE6IHRvcm5hIGEgY2FsY3VsYXIgcHJpbWVyIGxhIGRpc3TDoG5jaWEgcmVhbCAoJDZcXGNkb3Q1MDBcXCwwMDAkIGNtKSBpIGRlc3Byw6lzIGRpdmlkZWl4LWxhIHBlciAkNjBcXCwwMDAkLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHTDqSB1biBmYWN0b3IgJDEwJCBkZSBtw6lzOiByZXZpc2EgZWwgY8OgbGN1bCBkZSBsYSBkaXN0w6BuY2lhIHJlYWwgKCQ2XFxjZG90NTAwXFwsMDAwPTNcXCwwMDBcXCwwMDAkIGNtKSBhYmFucyBkZSBkaXZpZGlyLWxhIHBlciAkNjBcXCwwMDAkLiJdLCAiZXJyIjogWyJDUkVVQU1FTlRfSU5WRVJUSVQiLCAiUFJPRFVDVEVfTUFMIiwgIiIsICJURVJNRV9PQkxJREFUX09QRVJBQ0lPIl0sICJyZXMiOiBbIkRpc3TDoG5jaWEgcmVhbDogJDZcXGNkb3Q1MDBcXCwwMDA9M1xcLDAwMFxcLDAwMCQgY20iLCAiQWwgbm91IHBsw6Bub2w6ICQzXFwsMDAwXFwsMDAwOjYwXFwsMDAwPTUwJCBjbSJdfQ=="
  },
  {
   "id": "160a",
   "ex": 160,
   "ap": "a",
   "bloc": "escales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "El plànol d'un habitatge està dibuixat a escala $1:60$.",
   "enunciat": "Quines dimensions reals té la cuina si en el plànol fa $4$ cm d'ample i $7$ cm de llarg?",
   "opcions": [
    "$0{,}067$ m d'ample i $0{,}117$ m de llarg",
    "$4$ m d'ample i $7$ m de llarg",
    "$2{,}4$ m d'ample i $4{,}2$ m de llarg",
    "$240$ m d'ample i $420$ m de llarg"
   ],
   "pistes": [
    "A l'escala $1:60$, cada centímetre del plànol correspon a $60$ cm reals.",
    "Multiplica les dues mesures del plànol per $60$ i converteix el resultat a metres."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkZSBkaXZpZGlyIHBlciAkNjAkIGVuIGNvbXB0ZXMgZGUgbXVsdGlwbGljYXI6IGEgbCdlc2NhbGEgJDE6NjAkLCBsYSBtZXN1cmEgUkVBTCDDqXMgJDYwJCB2ZWdhZGVzIGxhIG1lc3VyYSBhbCBwbMOgbm9sLCBubyB1bmEgc2VpeGFudGVuYSBwYXJ0LiIsICJObyBoYXMgZmV0IHNlcnZpciBsJ2VzY2FsYTogbGVzIG1lc3VyZXMgZGVsIHBsw6Bub2wgaSBsZXMgcmVhbHMgbm8gY29pbmNpZGVpeGVuIGEgbWVueXMgcXVlIGwnZXNjYWxhIGZvcyAkMToxJC4iLCAiIiwgIkFxdWVzdHMgdmFsb3JzIHRlbmVuIHVuIGZhY3RvciAkMTAwJCBkZSBtw6lzOiAkNFxcY2RvdDYwPTI0MCQgY20sIHF1ZSBjYWwgY29udmVydGlyIGEgbWV0cmVzIGRpdmlkaW50IHBlciAkMTAwJCwgbm8gZGVpeGFyLWhvIHRhbCBxdWFsLiJdLCAiZXJyIjogWyJDUkVVQU1FTlRfSU5WRVJUSVQiLCAiRVNDQUxBX05PX0FQTElDQURBIiwgIiIsICJQUk9EVUNURV9NQUwiXSwgInJlcyI6IFsiQW1wbGU6ICQ0XFxjZG90NjA9MjQwJCBjbSAkPTJ7LH00JCBtIiwgIkxsYXJnOiAkN1xcY2RvdDYwPTQyMCQgY20gJD00eyx9MiQgbSJdfQ=="
  },
  {
   "id": "160b",
   "ex": 160,
   "ap": "b",
   "bloc": "escales",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "El plànol d'un habitatge està dibuixat a escala $1:60$.",
   "enunciat": "El passadís mesura $7{,}5$ m a la realitat. Quant fa de llarg en el plànol?",
   "opcions": [
    "$7{,}5$ cm",
    "$12{,}5$ cm",
    "$1{,}25$ cm",
    "$450$ cm"
   ],
   "pistes": [
    "Converteix els $7{,}5$ m a centímetres: $750$ cm.",
    "Divideix-los per $60$ per passar de la mesura real a la del plànol."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJObyBoYXMgZmV0IHNlcnZpciBsJ2VzY2FsYTogbGVzIG1lc3VyZXMgZGVsIHBsw6Bub2wgaSBsZXMgcmVhbHMgbm8gY29pbmNpZGVpeGVuIGEgbWVueXMgcXVlIGwnZXNjYWxhIGZvcyAkMToxJC4iLCAiIiwgIkFxdWVzdCB2YWxvciB0w6kgdW4gZmFjdG9yICQxMCQgZGUgbWVueXM6IHJldmlzYSBsYSBjb252ZXJzacOzICQ3eyx9NVxcdGV4dHsgbX09NzUwJCBjbSBhYmFucyBkZSBkaXZpZGlyIHBlciAkNjAkLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSBtdWx0aXBsaWNhciBwZXIgJDYwJCBlbiBjb21wdGVzIGRlIGRpdmlkaXItaGk6IGEgbCdlc2NhbGEgJDE6NjAkLCBsYSBtZXN1cmEgQUwgUEzDgE5PTCDDqXMgbGEgbWVzdXJhIHJlYWwgRElWSURJREEgcGVyICQ2MCQsIG5vIG11bHRpcGxpY2FkYS4iXSwgImVyciI6IFsiRVNDQUxBX05PX0FQTElDQURBIiwgIiIsICJQUk9EVUNURV9NQUwiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIl0sICJyZXMiOiBbIiQ3eyx9NVxcdGV4dHsgbX09NzUwJCBjbSIsICIkNzUwOjYwPTEyeyx9NSQgY20iXX0="
  },
  {
   "id": "285a",
   "ex": 285,
   "ap": "a",
   "bloc": "escales_calcul",
   "tipus": "B",
   "dif": 2,
   "encapcalament": "Què vol dir aquesta escala?",
   "enunciat": "Escala $1:50$.",
   "opcions": [
    "$1$ cm al plànol són $50$ m de debò.",
    "$1$ cm al plànol són $50$ cm de debò.",
    "$50$ cm al plànol són $1$ cm de debò.",
    "El dibuix és $50$ vegades més gran que la realitat."
   ],
   "pistes": [
    "A l'escala $a:b$, el primer nombre és el dibuix i el segon, la realitat.",
    "Les dues mesures van en la mateixa unitat."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJMJ2VzY2FsYSByZWxhY2lvbmEgbWVzdXJlcyBlbiBsYSBNQVRFSVhBIHVuaXRhdDogJDEkIGNtIGRlIHBsw6Bub2wgc8OzbiAkNTAkIGNtIGRlIHJlYWxpdGF0LCBxdWUgZGVzcHLDqXMgZXMgcG9kZW4gcGFzc2FyIGEgbWV0cmVzIHNpIGNvbnbDqSAoJDB7LH01JCBtKS4iLCAiIiwgIsOJcyBhbCByZXbDqXMuIEEgbCdlc2NhbGEgJDE6NTAkLCBlbCAkMSQgw6lzIGVsIHF1ZSBoaSBoYSBESUJVSVhBVCBpIGVsICQ1MCQgw6lzIGxhIHJlYWxpdGF0OiBlbCBkaWJ1aXggw6lzIG3DqXMgcGV0aXQgcXVlIGwnb3JpZ2luYWwuIiwgIlVuYSBlc2NhbGEgJDE6NTAkIMOpcyBkZSBSRURVQ0NJw5M6IGVsIGRpYnVpeCDDqXMgbcOpcyBwZXRpdC4gUGVycXXDqCBmb3MgZCdhbXBsaWFjacOzLCBlbCBwcmltZXIgbm9tYnJlIGhhdXJpYSBkZSBzZXIgZWwgbcOpcyBncmFuICgkNTA6MSQpLiJdLCAiZXJyIjogWyJVTklUQVRTX05PX0NPTlZFUlRJREVTIiwgIiIsICJFU0NBTEFfSU5WRVJUSURBIiwgIkVTQ0FMQV9JTlZFUlRJREEiXSwgInJlcyI6IFsiJDE6NTAkIHZvbCBkaXIgcXVlIGNhZGEgJDEkIGNtIGRlbCBkaWJ1aXggY29ycmVzcG9uIGEgJDUwJCBjbSByZWFscyIsICLDiXMgYSBkaXIsICQweyx9NSQgbSBkZSBkZWLDsiJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 1 cm, representa 50 cm de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">1 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">2 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 50 cm</text></svg>"
  },
  {
   "id": "285b",
   "ex": 285,
   "ap": "b",
   "bloc": "escales_calcul",
   "tipus": "B",
   "dif": 2,
   "encapcalament": "Què vol dir aquesta escala?",
   "enunciat": "Escala $1:25\\,000$.",
   "opcions": [
    "$1$ cm al plànol són $25000$ cm de debò.",
    "$25000$ cm al plànol són $1$ cm de debò.",
    "$1$ cm al plànol són $25000$ m de debò.",
    "El dibuix és $25000$ vegades més gran que la realitat."
   ],
   "pistes": [
    "A l'escala $a:b$, el primer nombre és el dibuix i el segon, la realitat.",
    "Les dues mesures van en la mateixa unitat."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiw4lzIGFsIHJldsOpcy4gQSBsJ2VzY2FsYSAkMToyNTAwMCQsIGVsICQxJCDDqXMgZWwgcXVlIGhpIGhhIERJQlVJWEFUIGkgZWwgJDI1MDAwJCDDqXMgbGEgcmVhbGl0YXQ6IGVsIGRpYnVpeCDDqXMgbcOpcyBwZXRpdCBxdWUgbCdvcmlnaW5hbC4iLCAiTCdlc2NhbGEgcmVsYWNpb25hIG1lc3VyZXMgZW4gbGEgTUFURUlYQSB1bml0YXQ6ICQxJCBjbSBkZSBwbMOgbm9sIHPDs24gJDI1MDAwJCBjbSBkZSByZWFsaXRhdCwgcXVlIGRlc3Byw6lzIGVzIHBvZGVuIHBhc3NhciBhIG1ldHJlcyBzaSBjb252w6kgKCQyNTAkIG0pLiIsICJVbmEgZXNjYWxhICQxOjI1MDAwJCDDqXMgZGUgUkVEVUNDScOTOiBlbCBkaWJ1aXggw6lzIG3DqXMgcGV0aXQuIFBlcnF1w6ggZm9zIGQnYW1wbGlhY2nDsywgZWwgcHJpbWVyIG5vbWJyZSBoYXVyaWEgZGUgc2VyIGVsIG3DqXMgZ3JhbiAoJDI1MDAwOjEkKS4iXSwgImVyciI6IFsiIiwgIkVTQ0FMQV9JTlZFUlRJREEiLCAiVU5JVEFUU19OT19DT05WRVJUSURFUyIsICJFU0NBTEFfSU5WRVJUSURBIl0sICJyZXMiOiBbIiQxOjI1MDAwJCB2b2wgZGlyIHF1ZSBjYWRhICQxJCBjbSBkZWwgZGlidWl4IGNvcnJlc3BvbiBhICQyNTAwMCQgY20gcmVhbHMiLCAiw4lzIGEgZGlyLCAkMjUwJCBtIGRlIGRlYsOyIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 1 cm, representa 250 m de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">1 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">2 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 250 m</text></svg>"
  },
  {
   "id": "285c",
   "ex": 285,
   "ap": "c",
   "bloc": "escales_calcul",
   "tipus": "B",
   "dif": 2,
   "encapcalament": "Què vol dir aquesta escala?",
   "enunciat": "Escala $1:200$.",
   "opcions": [
    "$1$ cm al plànol són $200$ m de debò.",
    "$200$ cm al plànol són $1$ cm de debò.",
    "$1$ cm al plànol són $200$ cm de debò.",
    "El dibuix és $200$ vegades més gran que la realitat."
   ],
   "pistes": [
    "A l'escala $a:b$, el primer nombre és el dibuix i el segon, la realitat.",
    "Les dues mesures van en la mateixa unitat."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJMJ2VzY2FsYSByZWxhY2lvbmEgbWVzdXJlcyBlbiBsYSBNQVRFSVhBIHVuaXRhdDogJDEkIGNtIGRlIHBsw6Bub2wgc8OzbiAkMjAwJCBjbSBkZSByZWFsaXRhdCwgcXVlIGRlc3Byw6lzIGVzIHBvZGVuIHBhc3NhciBhIG1ldHJlcyBzaSBjb252w6kgKCQyJCBtKS4iLCAiw4lzIGFsIHJldsOpcy4gQSBsJ2VzY2FsYSAkMToyMDAkLCBlbCAkMSQgw6lzIGVsIHF1ZSBoaSBoYSBESUJVSVhBVCBpIGVsICQyMDAkIMOpcyBsYSByZWFsaXRhdDogZWwgZGlidWl4IMOpcyBtw6lzIHBldGl0IHF1ZSBsJ29yaWdpbmFsLiIsICIiLCAiVW5hIGVzY2FsYSAkMToyMDAkIMOpcyBkZSBSRURVQ0NJw5M6IGVsIGRpYnVpeCDDqXMgbcOpcyBwZXRpdC4gUGVycXXDqCBmb3MgZCdhbXBsaWFjacOzLCBlbCBwcmltZXIgbm9tYnJlIGhhdXJpYSBkZSBzZXIgZWwgbcOpcyBncmFuICgkMjAwOjEkKS4iXSwgImVyciI6IFsiVU5JVEFUU19OT19DT05WRVJUSURFUyIsICJFU0NBTEFfSU5WRVJUSURBIiwgIiIsICJFU0NBTEFfSU5WRVJUSURBIl0sICJyZXMiOiBbIiQxOjIwMCQgdm9sIGRpciBxdWUgY2FkYSAkMSQgY20gZGVsIGRpYnVpeCBjb3JyZXNwb24gYSAkMjAwJCBjbSByZWFscyIsICLDiXMgYSBkaXIsICQyJCBtIGRlIGRlYsOyIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 1 cm, representa 2 m de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">1 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">2 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 2 m</text></svg>"
  },
  {
   "id": "286a",
   "ex": 286,
   "ap": "a",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un plànol està fet a escala $1:25\\,000$. Quina distància real correspon a cada mesura del plànol?",
   "enunciat": "$4$ cm al plànol.",
   "opcions": [
    "$0{,}00016$ km",
    "$0{,}001$ km",
    "$100000$ m",
    "$1$ km"
   ],
   "pistes": [
    "Multiplica la mesura del plànol, $4$ cm, per $25\\,000$: dona centímetres reals.",
    "Per passar de centímetres a quilòmetres, divideix entre $100\\,000$, perquè $1$ km $=100\\,000$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgZGl2aWRpdCBwZXIgbCdlc2NhbGEgZW4gY29tcHRlcyBkZSBtdWx0aXBsaWNhci4gQ29tIHF1ZSBlbCBwbMOgbm9sIMOpcyB1bmEgcmVkdWNjacOzLCBsYSBkaXN0w6BuY2lhIHJlYWwgaGEgZGUgc2VyIE3DiVMgZ3JhbiBxdWUgbGEgZGVsIHBsw6Bub2wuIiwgIkhhcyBkZXNwbGHDp2F0IG1hbGFtZW50IGxhIGNvbWEgZW4gcGFzc2FyIGRlIGNlbnTDrW1ldHJlcyBhIHF1aWzDsm1ldHJlcy4gUmVjb3JkYTogJDEkIGttICQ9MTAwXFwsMDAwJCBjbS4iLCAiQXF1ZXN0IG5vbWJyZSBzw7NuIGNlbnTDrW1ldHJlcywgbm8gbWV0cmVzOiAkMTAwMDAwJCBjbSBzw7NuICQxMDAwJCBtLCBpIGFpeMOyIHPDs24gJDEkIGttLiIsICIiXSwgImVyciI6IFsiRVNDQUxBX0lOVkVSVElEQSIsICJQT1RFTkNJQV8xMCIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIiwgIiJdLCAicmVzIjogWyIkNFxcY2RvdDI1MDAwPTEwMDAwMCQgY20iLCAiJFxcZGZyYWN7MTAwMDAwfXsxMDAwMDB9PTEkIGttIl19"
  },
  {
   "id": "286b",
   "ex": 286,
   "ap": "b",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un plànol està fet a escala $1:25\\,000$. Quina distància real correspon a cada mesura del plànol?",
   "enunciat": "$12$ cm al plànol.",
   "opcions": [
    "$0{,}003$ km",
    "$3$ km",
    "$300000$ m",
    "$0{,}00048$ km"
   ],
   "pistes": [
    "Multiplica la mesura del plànol, $12$ cm, per $25\\,000$: dona centímetres reals.",
    "Per passar de centímetres a quilòmetres, divideix entre $100\\,000$, perquè $1$ km $=100\\,000$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgZGVzcGxhw6dhdCBtYWxhbWVudCBsYSBjb21hIGVuIHBhc3NhciBkZSBjZW50w61tZXRyZXMgYSBxdWlsw7JtZXRyZXMuIFJlY29yZGE6ICQxJCBrbSAkPTEwMFxcLDAwMCQgY20uIiwgIiIsICJBcXVlc3Qgbm9tYnJlIHPDs24gY2VudMOtbWV0cmVzLCBubyBtZXRyZXM6ICQzMDAwMDAkIGNtIHPDs24gJDMwMDAkIG0sIGkgYWl4w7Igc8OzbiAkMyQga20uIiwgIkhhcyBkaXZpZGl0IHBlciBsJ2VzY2FsYSBlbiBjb21wdGVzIGRlIG11bHRpcGxpY2FyLiBDb20gcXVlIGVsIHBsw6Bub2wgw6lzIHVuYSByZWR1Y2Npw7MsIGxhIGRpc3TDoG5jaWEgcmVhbCBoYSBkZSBzZXIgTcOJUyBncmFuIHF1ZSBsYSBkZWwgcGzDoG5vbC4iXSwgImVyciI6IFsiUE9URU5DSUFfMTAiLCAiIiwgIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiLCAiRVNDQUxBX0lOVkVSVElEQSJdLCAicmVzIjogWyIkMTJcXGNkb3QyNTAwMD0zMDAwMDAkIGNtIiwgIiRcXGRmcmFjezMwMDAwMH17MTAwMDAwfT0zJCBrbSJdfQ=="
  },
  {
   "id": "286c",
   "ex": 286,
   "ap": "c",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un plànol està fet a escala $1:25\\,000$. Quina distància real correspon a cada mesura del plànol?",
   "enunciat": "$2{,}5$ cm al plànol.",
   "opcions": [
    "$62500$ m",
    "$0{,}625$ km",
    "$0{,}000625$ km",
    "$0{,}0001$ km"
   ],
   "pistes": [
    "Multiplica la mesura del plànol, $2{,}5$ cm, per $25\\,000$: dona centímetres reals.",
    "Per passar de centímetres a quilòmetres, divideix entre $100\\,000$, perquè $1$ km $=100\\,000$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3Qgbm9tYnJlIHPDs24gY2VudMOtbWV0cmVzLCBubyBtZXRyZXM6ICQ2MjUwMCQgY20gc8OzbiAkNjI1JCBtLCBpIGFpeMOyIHPDs24gJDB7LH02MjUkIGttLiIsICIiLCAiSGFzIGRlc3BsYcOnYXQgbWFsYW1lbnQgbGEgY29tYSBlbiBwYXNzYXIgZGUgY2VudMOtbWV0cmVzIGEgcXVpbMOybWV0cmVzLiBSZWNvcmRhOiAkMSQga20gJD0xMDBcXCwwMDAkIGNtLiIsICJIYXMgZGl2aWRpdCBwZXIgbCdlc2NhbGEgZW4gY29tcHRlcyBkZSBtdWx0aXBsaWNhci4gQ29tIHF1ZSBlbCBwbMOgbm9sIMOpcyB1bmEgcmVkdWNjacOzLCBsYSBkaXN0w6BuY2lhIHJlYWwgaGEgZGUgc2VyIE3DiVMgZ3JhbiBxdWUgbGEgZGVsIHBsw6Bub2wuIl0sICJlcnIiOiBbIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiLCAiIiwgIlBPVEVOQ0lBXzEwIiwgIkVTQ0FMQV9JTlZFUlRJREEiXSwgInJlcyI6IFsiJDJ7LH01XFxjZG90MjUwMDA9NjI1MDAkIGNtIiwgIiRcXGRmcmFjezYyNTAwfXsxMDAwMDB9PTB7LH02MjUkIGttIl19"
  },
  {
   "id": "286d",
   "ex": 286,
   "ap": "d",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un plànol està fet a escala $1:25\\,000$. Quina distància real correspon a cada mesura del plànol?",
   "enunciat": "$30$ cm al plànol.",
   "opcions": [
    "$0{,}0075$ km",
    "$0{,}0012$ km",
    "$750000$ m",
    "$7{,}5$ km"
   ],
   "pistes": [
    "Multiplica la mesura del plànol, $30$ cm, per $25\\,000$: dona centímetres reals.",
    "Per passar de centímetres a quilòmetres, divideix entre $100\\,000$, perquè $1$ km $=100\\,000$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgZGVzcGxhw6dhdCBtYWxhbWVudCBsYSBjb21hIGVuIHBhc3NhciBkZSBjZW50w61tZXRyZXMgYSBxdWlsw7JtZXRyZXMuIFJlY29yZGE6ICQxJCBrbSAkPTEwMFxcLDAwMCQgY20uIiwgIkhhcyBkaXZpZGl0IHBlciBsJ2VzY2FsYSBlbiBjb21wdGVzIGRlIG11bHRpcGxpY2FyLiBDb20gcXVlIGVsIHBsw6Bub2wgw6lzIHVuYSByZWR1Y2Npw7MsIGxhIGRpc3TDoG5jaWEgcmVhbCBoYSBkZSBzZXIgTcOJUyBncmFuIHF1ZSBsYSBkZWwgcGzDoG5vbC4iLCAiQXF1ZXN0IG5vbWJyZSBzw7NuIGNlbnTDrW1ldHJlcywgbm8gbWV0cmVzOiAkNzUwMDAwJCBjbSBzw7NuICQ3NTAwJCBtLCBpIGFpeMOyIHPDs24gJDd7LH01JCBrbS4iLCAiIl0sICJlcnIiOiBbIlBPVEVOQ0lBXzEwIiwgIkVTQ0FMQV9JTlZFUlRJREEiLCAiVU5JVEFUU19OT19DT05WRVJUSURFUyIsICIiXSwgInJlcyI6IFsiJDMwXFxjZG90MjUwMDA9NzUwMDAwJCBjbSIsICIkXFxkZnJhY3s3NTAwMDB9ezEwMDAwMH09N3ssfTUkIGttIl19"
  },
  {
   "id": "287a",
   "ex": 287,
   "ap": "a",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un arquitecte dibuixa un plànol a escala $1:200$. Quina mesura ha de fer servir al plànol?",
   "enunciat": "Una paret de $8$ m.",
   "opcions": [
    "$160000$ cm",
    "$4$ cm",
    "$4$ m",
    "$0{,}04$ cm"
   ],
   "pistes": [
    "Passa els $8$ m a centímetres: $1$ m $=100$ cm.",
    "Al plànol tot es dibuixa $200$ vegades més petit: divideix entre $200$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgbXVsdGlwbGljYXQgcGVyICQyMDAkLiBQZXIgYW5hciBkZSBsYSByZWFsaXRhdCBhbCBwbMOgbm9sIGNhbCBESVZJRElSOiBlbCBkaWJ1aXggw6lzIG3DqXMgcGV0aXQuIiwgIiIsICJFbCBuw7ptZXJvIMOpcyBjb3JyZWN0ZSwgcGVyw7IgbGVzIHVuaXRhdHMgbm86IGFsIHBsw6Bub2wgZXMgZGlidWl4ZW4gY2VudMOtbWV0cmVzLCBubyBtZXRyZXMuIiwgIkhhcyBkaXZpZGl0IGVscyBtZXRyZXMgZGlyZWN0YW1lbnQuIFByaW1lciBjYWwgcGFzc2FyLWxvcyBhIGNlbnTDrW1ldHJlczogJDgkIG0gJD04MDAkIGNtLiJdLCAiZXJyIjogWyJFU0NBTEFfSU5WRVJUSURBIiwgIiIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIiwgIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiXSwgInJlcyI6IFsiJDgkIG0gJD04MDAkIGNtIiwgIiRcXGRmcmFjezgwMH17MjAwfT00JCBjbSJdfQ=="
  },
  {
   "id": "287b",
   "ex": 287,
   "ap": "b",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un arquitecte dibuixa un plànol a escala $1:200$. Quina mesura ha de fer servir al plànol?",
   "enunciat": "Una paret de $14$ m.",
   "opcions": [
    "$7$ m",
    "$0{,}07$ cm",
    "$280000$ cm",
    "$7$ cm"
   ],
   "pistes": [
    "Passa els $14$ m a centímetres: $1$ m $=100$ cm.",
    "Al plànol tot es dibuixa $200$ vegades més petit: divideix entre $200$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJFbCBuw7ptZXJvIMOpcyBjb3JyZWN0ZSwgcGVyw7IgbGVzIHVuaXRhdHMgbm86IGFsIHBsw6Bub2wgZXMgZGlidWl4ZW4gY2VudMOtbWV0cmVzLCBubyBtZXRyZXMuIiwgIkhhcyBkaXZpZGl0IGVscyBtZXRyZXMgZGlyZWN0YW1lbnQuIFByaW1lciBjYWwgcGFzc2FyLWxvcyBhIGNlbnTDrW1ldHJlczogJDE0JCBtICQ9MTQwMCQgY20uIiwgIkhhcyBtdWx0aXBsaWNhdCBwZXIgJDIwMCQuIFBlciBhbmFyIGRlIGxhIHJlYWxpdGF0IGFsIHBsw6Bub2wgY2FsIERJVklESVI6IGVsIGRpYnVpeCDDqXMgbcOpcyBwZXRpdC4iLCAiIl0sICJlcnIiOiBbIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiLCAiVU5JVEFUU19OT19DT05WRVJUSURFUyIsICJFU0NBTEFfSU5WRVJUSURBIiwgIiJdLCAicmVzIjogWyIkMTQkIG0gJD0xNDAwJCBjbSIsICIkXFxkZnJhY3sxNDAwfXsyMDB9PTckIGNtIl19"
  },
  {
   "id": "287c",
   "ex": 287,
   "ap": "c",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Un arquitecte dibuixa un plànol a escala $1:200$. Quina mesura ha de fer servir al plànol?",
   "enunciat": "Una paret de $2{,}4$ m.",
   "opcions": [
    "$1{,}2$ cm",
    "$1{,}2$ m",
    "$48000$ cm",
    "$0{,}012$ cm"
   ],
   "pistes": [
    "Passa els $2{,}4$ m a centímetres: $1$ m $=100$ cm.",
    "Al plànol tot es dibuixa $200$ vegades més petit: divideix entre $200$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRWwgbsO6bWVybyDDqXMgY29ycmVjdGUsIHBlcsOyIGxlcyB1bml0YXRzIG5vOiBhbCBwbMOgbm9sIGVzIGRpYnVpeGVuIGNlbnTDrW1ldHJlcywgbm8gbWV0cmVzLiIsICJIYXMgbXVsdGlwbGljYXQgcGVyICQyMDAkLiBQZXIgYW5hciBkZSBsYSByZWFsaXRhdCBhbCBwbMOgbm9sIGNhbCBESVZJRElSOiBlbCBkaWJ1aXggw6lzIG3DqXMgcGV0aXQuIiwgIkhhcyBkaXZpZGl0IGVscyBtZXRyZXMgZGlyZWN0YW1lbnQuIFByaW1lciBjYWwgcGFzc2FyLWxvcyBhIGNlbnTDrW1ldHJlczogJDJ7LH00JCBtICQ9MjQwJCBjbS4iXSwgImVyciI6IFsiIiwgIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiLCAiRVNDQUxBX0lOVkVSVElEQSIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIl0sICJyZXMiOiBbIiQyeyx9NCQgbSAkPTI0MCQgY20iLCAiJFxcZGZyYWN7MjQwfXsyMDB9PTF7LH0yJCBjbSJdfQ=="
  },
  {
   "id": "288a",
   "ex": 288,
   "ap": "a",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'escala del dibuix.",
   "enunciat": "$4$ cm al dibuix corresponen a $2$ m de debò.",
   "opcions": [
    "$1:50$",
    "$1:200$",
    "$50:1$",
    "$1:0{,}50$"
   ],
   "pistes": [
    "Passa els $2$ m a centímetres, la mateixa unitat que els $4$ cm del dibuix.",
    "Divideix la mesura real entre la del dibuix: aquest quocient és el segon nombre de l'escala $1:\\ldots$"
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0YSDDqXMgbGEgbWVzdXJhIHJlYWwgZW4gY2VudMOtbWV0cmVzLCBubyBsJ2VzY2FsYS4gTCdlc2NhbGEgc3VydCBkZSBkaXZpZGlyLWxhIGVudHJlIGxhIG1lc3VyYSBkZWwgZGlidWl4LiIsICJMJ2hhcyBlc2NyaXRhIGRlbCByZXbDqXMuIEEgbCdlc2NhbGEsIGVsIHByaW1lciBub21icmUgw6lzIGVsIERJQlVJWCAocXVlIGFxdcOtIMOpcyBtw6lzIHBldGl0KSBpIGVsIHNlZ29uLCBsYSByZWFsaXRhdC4iLCAiSGFzIGNvbXBhcmF0ICQ0JCBhbWIgJDIkIHNlbnNlIHBhc3Nhci1obyB0b3QgYSBsYSBtYXRlaXhhIHVuaXRhdC4gJDIkIG0gc8OzbiAkMjAwJCBjbS4iXSwgImVyciI6IFsiIiwgIkRJVklTSU9fT0JMSURBREEiLCAiRVNDQUxBX0lOVkVSVElEQSIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIl0sICJyZXMiOiBbIiQyJCBtICQ9MjAwJCBjbSIsICIkXFxkZnJhY3syMDB9ezR9PTUwJCwgbyBzaWd1aSBlc2NhbGEgJDE6NTAkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 4 cm, representa 2 m de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">4 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">8 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">12 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">16 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 2 m</text></svg>"
  },
  {
   "id": "288b",
   "ex": 288,
   "ap": "b",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'escala del dibuix.",
   "enunciat": "$3$ cm al dibuix corresponen a $12$ m de debò.",
   "opcions": [
    "$1:1200$",
    "$400:1$",
    "$1:400$",
    "$1:4{,}00$"
   ],
   "pistes": [
    "Passa els $12$ m a centímetres, la mateixa unitat que els $3$ cm del dibuix.",
    "Divideix la mesura real entre la del dibuix: aquest quocient és el segon nombre de l'escala $1:\\ldots$"
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3RhIMOpcyBsYSBtZXN1cmEgcmVhbCBlbiBjZW50w61tZXRyZXMsIG5vIGwnZXNjYWxhLiBMJ2VzY2FsYSBzdXJ0IGRlIGRpdmlkaXItbGEgZW50cmUgbGEgbWVzdXJhIGRlbCBkaWJ1aXguIiwgIkwnaGFzIGVzY3JpdGEgZGVsIHJldsOpcy4gQSBsJ2VzY2FsYSwgZWwgcHJpbWVyIG5vbWJyZSDDqXMgZWwgRElCVUlYIChxdWUgYXF1w60gw6lzIG3DqXMgcGV0aXQpIGkgZWwgc2Vnb24sIGxhIHJlYWxpdGF0LiIsICIiLCAiSGFzIGNvbXBhcmF0ICQzJCBhbWIgJDEyJCBzZW5zZSBwYXNzYXItaG8gdG90IGEgbGEgbWF0ZWl4YSB1bml0YXQuICQxMiQgbSBzw7NuICQxMjAwJCBjbS4iXSwgImVyciI6IFsiRElWSVNJT19PQkxJREFEQSIsICJFU0NBTEFfSU5WRVJUSURBIiwgIiIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIl0sICJyZXMiOiBbIiQxMiQgbSAkPTEyMDAkIGNtIiwgIiRcXGRmcmFjezEyMDB9ezN9PTQwMCQsIG8gc2lndWkgZXNjYWxhICQxOjQwMCQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 3 cm, representa 12 m de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">3 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">6 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">9 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">12 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 12 m</text></svg>"
  },
  {
   "id": "288c",
   "ex": 288,
   "ap": "c",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'escala del dibuix.",
   "enunciat": "$8$ cm al dibuix corresponen a $4$ km de debò.",
   "opcions": [
    "$1:50000$",
    "$50000:1$",
    "$1:0{,}50$",
    "$1:400000$"
   ],
   "pistes": [
    "Passa els $4$ km a centímetres, la mateixa unitat que els $8$ cm del dibuix.",
    "Divideix la mesura real entre la del dibuix: aquest quocient és el segon nombre de l'escala $1:\\ldots$"
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiTCdoYXMgZXNjcml0YSBkZWwgcmV2w6lzLiBBIGwnZXNjYWxhLCBlbCBwcmltZXIgbm9tYnJlIMOpcyBlbCBESUJVSVggKHF1ZSBhcXXDrSDDqXMgbcOpcyBwZXRpdCkgaSBlbCBzZWdvbiwgbGEgcmVhbGl0YXQuIiwgIkhhcyBjb21wYXJhdCAkOCQgYW1iICQ0JCBzZW5zZSBwYXNzYXItaG8gdG90IGEgbGEgbWF0ZWl4YSB1bml0YXQuICQ0JCBrbSBzw7NuICQ0MDAwMDAkIGNtLiIsICJBcXVlc3RhIMOpcyBsYSBtZXN1cmEgcmVhbCBlbiBjZW50w61tZXRyZXMsIG5vIGwnZXNjYWxhLiBMJ2VzY2FsYSBzdXJ0IGRlIGRpdmlkaXItbGEgZW50cmUgbGEgbWVzdXJhIGRlbCBkaWJ1aXguIl0sICJlcnIiOiBbIiIsICJFU0NBTEFfSU5WRVJUSURBIiwgIlVOSVRBVFNfTk9fQ09OVkVSVElERVMiLCAiRElWSVNJT19PQkxJREFEQSJdLCAicmVzIjogWyIkNCQga20gJD00MDAwMDAkIGNtIiwgIiRcXGRmcmFjezQwMDAwMH17OH09NTAwMDAkLCBvIHNpZ3VpIGVzY2FsYSAkMTo1MDAwMCQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 216 76\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Regla d'escala gràfica: cada interval del dibuix, de 8 cm, representa 4 km de la realitat.</title><rect x=\"20.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><rect x=\"108.00\" y=\"18.00\" width=\"44.00\" height=\"24.00\" fill=\"var(--fig-plena, #E9F0F6)\"/><line x1=\"20.00\" y1=\"18.00\" x2=\"20.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"64.00\" y1=\"18.00\" x2=\"64.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"108.00\" y1=\"18.00\" x2=\"108.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"152.00\" y1=\"18.00\" x2=\"152.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"196.00\" y1=\"18.00\" x2=\"196.00\" y2=\"42.00\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"20.00\" y1=\"30.00\" x2=\"196.00\" y2=\"30.00\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">0</text><text x=\"64.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">8 cm</text><text x=\"108.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">16 cm</text><text x=\"152.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">24 cm</text><text x=\"196.0\" y=\"60.0\" text-anchor=\"middle\" class=\"fig-etq petita fig-etq-marc\">32 cm</text><text x=\"98\" y=\"8\" text-anchor=\"middle\" class=\"fig-etq petita\">cada interval = 4 km</text></svg>"
  },
  {
   "id": "289",
   "ex": 289,
   "ap": "",
   "bloc": "escales_calcul",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "En un mapa a escala $1:150\\,000$, dues poblacions estan a $6{,}4$ cm. Un ciclista fa el recorregut a $24$ km/h. Quant triga?",
   "opcions": [
    "$2{,}5$ h",
    "$24$ min",
    "$9{,}6$ km",
    "$0{,}4$ h $=4$ min"
   ],
   "pistes": [
    "Troba primer la distància real en quilòmetres.",
    "Després, temps $=\\dfrac{\\text{distància}}{\\text{velocitat}}$, i passa'l a minuts."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgZGl2aWRpdCBhbCByZXbDqXM6IGVsIHRlbXBzIMOpcyAkXFxkZnJhY3tcXHRleHR7ZGlzdMOgbmNpYX19e1xcdGV4dHt2ZWxvY2l0YXR9fSQsIG5vIGEgbCdpbnJldsOpcy4iLCAiIiwgIkFxdWVzdGEgw6lzIGxhIGRpc3TDoG5jaWEgcmVhbCwgcXVlIMOpcyBlbCBwcmltZXIgcGFzLiBFbmNhcmEgZmFsdGEgY2FsY3VsYXIgZWwgdGVtcHM6ICRcXGRmcmFjezl7LH02fXsyNH0kIGguIiwgIkVsIHRlbXBzIGVuIGhvcmVzIMOpcyAkMHssfTQkLCBpICQweyx9NCQgaCBubyBzw7NuICQ0JCBtaW4gc2luw7MgJDB7LH00XFxjZG90NjA9MjQkIG1pbi4iXSwgImVyciI6IFsiSU5WRVJUSURBIiwgIiIsICJQQVNfSU5URVJNRURJX1BFUl9SRVNQT1NUQSIsICJQT1RFTkNJQV8xMCJdLCAicmVzIjogWyIkNnssfTRcXGNkb3QxNTAwMDA9OTYwXFwsMDAwJCBjbSIsICIkOTYwMDAwJCBjbSAkPTl7LH02JCBrbSIsICIkdD1cXGRmcmFjezl7LH02fXsyNH09MHssfTQkIGggJD0weyx9NFxcY2RvdDYwPTI0JCBtaW4iXX0="
  },
  {
   "id": "290a",
   "ex": 290,
   "ap": "a",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Dues figures són semblants. Troba'n la raó de semblança $k$ (de la petita a la gran).",
   "enunciat": "Un costat de la petita fa $3$ cm i el corresponent de la gran, $12$ cm.",
   "opcions": [
    "$k=9$",
    "$k=36$",
    "$k=\\dfrac{1}{4}$",
    "$k=4$"
   ],
   "pistes": [
    "La raó de semblança és el quocient entre dos costats corresponents.",
    "De la petita a la gran: $\\dfrac{12}{3}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgcmVzdGF0IGVscyBkb3MgY29zdGF0cy4gTGEgcmHDsyBkZSBzZW1ibGFuw6dhIMOpcyB1biBRVU9DSUVOVDogZGl1IHF1YW50ZXMgdmVnYWRlcyDDqXMgbcOpcyBncmFuLCBubyBxdWFudCBtw6lzIGdyYW4gw6lzLiIsICJFbHMgaGFzIG11bHRpcGxpY2F0LiBMYSByYcOzIHN1cnQgZGUgZGl2aWRpciBlbCBjb3N0YXQgZGUgbGEgZ3JhbiBlbnRyZSBlbCBkZSBsYSBwZXRpdGEuIiwgIkFxdWVzdGEgw6lzIGxhIHJhw7MgZGUgbGEgZ3JhbiBhIGxhIHBldGl0YS4gQ29tIHF1ZSBlcyBkZW1hbmEgZGUgbGEgcGV0aXRhIGEgbGEgZ3JhbiwgJGskIGhhIGRlIHNlciBtw6lzIGdyYW4gcXVlICQxJC4iLCAiIl0sICJlcnIiOiBbIlJFU1RBX1BFUl9RVU9DSUVOVCIsICJQUk9EVUNURV9QRVJfU1VNQSIsICJJTlZFUlRJREEiLCAiIl0sICJyZXMiOiBbIiRrPVxcZGZyYWN7MTJ9ezN9PTQkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 328 187\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos triangles.</title><g transform=\"translate(14.0,155.6)\"><polygon points=\"0.00,0.00 41.64,0.00 20.82,-35.39\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"133.44,0.00 300.00,0.00 216.72,-141.57\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.8\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"216.7\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "290b",
   "ex": 290,
   "ap": "b",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Dues figures són semblants. Troba'n la raó de semblança $k$ (de la petita a la gran).",
   "enunciat": "Un costat de la petita fa $5$ cm i el corresponent de la gran, $20$ cm.",
   "opcions": [
    "$k=15$",
    "$k=100$",
    "$k=4$",
    "$k=\\dfrac{1}{4}$"
   ],
   "pistes": [
    "La raó de semblança és el quocient entre dos costats corresponents.",
    "De la petita a la gran: $\\dfrac{20}{5}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgcmVzdGF0IGVscyBkb3MgY29zdGF0cy4gTGEgcmHDsyBkZSBzZW1ibGFuw6dhIMOpcyB1biBRVU9DSUVOVDogZGl1IHF1YW50ZXMgdmVnYWRlcyDDqXMgbcOpcyBncmFuLCBubyBxdWFudCBtw6lzIGdyYW4gw6lzLiIsICJFbHMgaGFzIG11bHRpcGxpY2F0LiBMYSByYcOzIHN1cnQgZGUgZGl2aWRpciBlbCBjb3N0YXQgZGUgbGEgZ3JhbiBlbnRyZSBlbCBkZSBsYSBwZXRpdGEuIiwgIiIsICJBcXVlc3RhIMOpcyBsYSByYcOzIGRlIGxhIGdyYW4gYSBsYSBwZXRpdGEuIENvbSBxdWUgZXMgZGVtYW5hIGRlIGxhIHBldGl0YSBhIGxhIGdyYW4sICRrJCBoYSBkZSBzZXIgbcOpcyBncmFuIHF1ZSAkMSQuIl0sICJlcnIiOiBbIlJFU1RBX1BFUl9RVU9DSUVOVCIsICJQUk9EVUNURV9QRVJfU1VNQSIsICIiLCAiSU5WRVJUSURBIl0sICJyZXMiOiBbIiRrPVxcZGZyYWN7MjB9ezV9PTQkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 328 187\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos triangles.</title><g transform=\"translate(14.0,155.6)\"><polygon points=\"0.00,0.00 41.64,0.00 20.82,-35.39\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"133.44,0.00 300.00,0.00 216.72,-141.57\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"20.8\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"216.7\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "290c",
   "ex": 290,
   "ap": "c",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Dues figures són semblants. Troba'n la raó de semblança $k$ (de la petita a la gran).",
   "enunciat": "Un costat de la petita fa $6$ cm i el corresponent de la gran, $9$ cm.",
   "opcions": [
    "$k=54$",
    "$k=3$",
    "$k=\\dfrac{2}{3}$",
    "$k=\\dfrac{3}{2}$"
   ],
   "pistes": [
    "La raó de semblança és el quocient entre dos costats corresponents.",
    "De la petita a la gran: $\\dfrac{9}{6}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJFbHMgaGFzIG11bHRpcGxpY2F0LiBMYSByYcOzIHN1cnQgZGUgZGl2aWRpciBlbCBjb3N0YXQgZGUgbGEgZ3JhbiBlbnRyZSBlbCBkZSBsYSBwZXRpdGEuIiwgIkhhcyByZXN0YXQgZWxzIGRvcyBjb3N0YXRzLiBMYSByYcOzIGRlIHNlbWJsYW7Dp2Egw6lzIHVuIFFVT0NJRU5UOiBkaXUgcXVhbnRlcyB2ZWdhZGVzIMOpcyBtw6lzIGdyYW4sIG5vIHF1YW50IG3DqXMgZ3JhbiDDqXMuIiwgIkFxdWVzdGEgw6lzIGxhIHJhw7MgZGUgbGEgZ3JhbiBhIGxhIHBldGl0YS4gQ29tIHF1ZSBlcyBkZW1hbmEgZGUgbGEgcGV0aXRhIGEgbGEgZ3JhbiwgJGskIGhhIGRlIHNlciBtw6lzIGdyYW4gcXVlICQxJC4iLCAiIl0sICJlcnIiOiBbIlBST0RVQ1RFX1BFUl9TVU1BIiwgIlJFU1RBX1BFUl9RVU9DSUVOVCIsICJJTlZFUlRJREEiLCAiIl0sICJyZXMiOiBbIiRrPVxcZGZyYWN7OX17Nn09XFxkZnJhY3szfXsyfSQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 257 122\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos triangles.</title><g transform=\"translate(14.0,90.5)\"><polygon points=\"0.00,0.00 60.00,0.00 30.00,-51.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"139.00,0.00 229.00,0.00 184.00,-76.50\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"184\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "291a",
   "ex": 291,
   "ap": "a",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos polígons són semblants amb raó $k$. Si l'àrea del petit és la que es diu, quina és la del gran?",
   "enunciat": "$k=2$ i àrea del petit $=15$ cm$^2$.",
   "opcions": [
    "$120$ cm$^2$",
    "$17$ cm$^2$",
    "$60$ cm$^2$",
    "$30$ cm$^2$"
   ],
   "pistes": [
    "Les longituds es multipliquen per $k$; les àrees, per $k^2$.",
    "$k^2=4$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJFbCAka14zJCDDqXMgcGVyIGFscyBWT0xVTVMuIFVuYSDDoHJlYSB0w6kgZHVlcyBkaW1lbnNpb25zLCBpIHBlciBhaXjDsiB2YSBhbWIgJGteMiQuIiwgIkxhIHJhw7MgbXVsdGlwbGljYSwgbm8gc3VtYS4iLCAiIiwgIkhhcyBtdWx0aXBsaWNhdCBsJ8OgcmVhIHBlciAkayQuIExlcyDDoHJlZXMgZXMgbXVsdGlwbGlxdWVuIHBlciAka14yJCwgbm8gcGVyICRrJDogc2kgbGVzIGxvbmdpdHVkcyBlcyBkdXBsaXF1ZW4sIGwnw6ByZWEgZXMgbXVsdGlwbGljYSBwZXIgJDQkLCBubyBwZXIgJDIkLiJdLCAiZXJyIjogWyJSQU9fQUxfQ1VCIiwgIlBST0RVQ1RFX1BFUl9TVU1BIiwgIiIsICJSQU9fU0VOU0VfUVVBRFJBVCJdLCAicmVzIjogWyIka14yPTJeMj00JCIsICLDgHJlYSBncmFuICQ9MTVcXGNkb3Q0PTYwJCBjbSReMiQiXSwgImNvbSI6ICJWYWwgbGEgcGVuYSB2ZXVyZS1obyBhbWIgdW4gcXVhZHJhdDogc2kgZWwgY29zdGF0IHBhc3NhIGRlICQxJCBhICQyJCwgbCfDoHJlYSBwYXNzYSBkJyQxJCBhICQ0JC4gRHVlcyBkaW1lbnNpb25zLCBkb3MgZmFjdG9ycyAkayQuIn0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 294 165\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos quadrats.</title><g transform=\"translate(14.0,134.0)\"><polygon points=\"0.00,0.00 60.00,0.00 60.00,-60.00 0.00,-60.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"145.60,0.00 265.60,0.00 265.60,-120.00 145.60,-120.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"205.6\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "291b",
   "ex": 291,
   "ap": "b",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos polígons són semblants amb raó $k$. Si l'àrea del petit és la que es diu, quina és la del gran?",
   "enunciat": "$k=3$ i àrea del petit $=8$ cm$^2$.",
   "opcions": [
    "$72$ cm$^2$",
    "$216$ cm$^2$",
    "$11$ cm$^2$",
    "$24$ cm$^2$"
   ],
   "pistes": [
    "Les longituds es multipliquen per $k$; les àrees, per $k^2$.",
    "$k^2=9$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRWwgJGteMyQgw6lzIHBlciBhbHMgVk9MVU1TLiBVbmEgw6ByZWEgdMOpIGR1ZXMgZGltZW5zaW9ucywgaSBwZXIgYWl4w7IgdmEgYW1iICRrXjIkLiIsICJMYSByYcOzIG11bHRpcGxpY2EsIG5vIHN1bWEuIiwgIkhhcyBtdWx0aXBsaWNhdCBsJ8OgcmVhIHBlciAkayQuIExlcyDDoHJlZXMgZXMgbXVsdGlwbGlxdWVuIHBlciAka14yJCwgbm8gcGVyICRrJDogc2kgbGVzIGxvbmdpdHVkcyBlcyBkdXBsaXF1ZW4sIGwnw6ByZWEgZXMgbXVsdGlwbGljYSBwZXIgJDQkLCBubyBwZXIgJDIkLiJdLCAiZXJyIjogWyIiLCAiUkFPX0FMX0NVQiIsICJQUk9EVUNURV9QRVJfU1VNQSIsICJSQU9fU0VOU0VfUVVBRFJBVCJdLCAicmVzIjogWyIka14yPTNeMj05JCIsICLDgHJlYSBncmFuICQ9OFxcY2RvdDk9NzIkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 328 202\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos quadrats.</title><g transform=\"translate(14.0,170.1)\"><polygon points=\"0.00,0.00 52.05,0.00 52.05,-52.05 0.00,-52.05\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,0.00 300.00,0.00 300.00,-156.15 143.85,-156.15\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"26\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"221.9\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "291c",
   "ex": 291,
   "ap": "c",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos polígons són semblants amb raó $k$. Si l'àrea del petit és la que es diu, quina és la del gran?",
   "enunciat": "$k=\\dfrac{5}{2}$ i àrea del petit $=12$ cm$^2$.",
   "opcions": [
    "$75$ cm$^2$",
    "$187{,}5$ cm$^2$",
    "$30$ cm$^2$",
    "$14{,}5$ cm$^2$"
   ],
   "pistes": [
    "Les longituds es multipliquen per $k$; les àrees, per $k^2$.",
    "$k^2=\\dfrac{25}{4}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRWwgJGteMyQgw6lzIHBlciBhbHMgVk9MVU1TLiBVbmEgw6ByZWEgdMOpIGR1ZXMgZGltZW5zaW9ucywgaSBwZXIgYWl4w7IgdmEgYW1iICRrXjIkLiIsICJIYXMgbXVsdGlwbGljYXQgbCfDoHJlYSBwZXIgJGskLiBMZXMgw6ByZWVzIGVzIG11bHRpcGxpcXVlbiBwZXIgJGteMiQsIG5vIHBlciAkayQ6IHNpIGxlcyBsb25naXR1ZHMgZXMgZHVwbGlxdWVuLCBsJ8OgcmVhIGVzIG11bHRpcGxpY2EgcGVyICQ0JCwgbm8gcGVyICQyJC4iLCAiTGEgcmHDsyBtdWx0aXBsaWNhLCBubyBzdW1hLiJdLCAiZXJyIjogWyIiLCAiUkFPX0FMX0NVQiIsICJSQU9fU0VOU0VfUVVBRFJBVCIsICJQUk9EVUNURV9QRVJfU1VNQSJdLCAicmVzIjogWyIka14yPVxcbGVmdChcXGRmcmFjezV9ezJ9XFxyaWdodCleMj1cXGRmcmFjezI1fXs0fSQiLCAiw4ByZWEgZ3JhbiAkPTEyXFxjZG90XFxkZnJhY3syNX17NH09NzUkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 328 194\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos quadrats.</title><g transform=\"translate(14.0,162.7)\"><polygon points=\"0.00,0.00 59.48,0.00 59.48,-59.48 0.00,-59.48\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"151.29,0.00 300.00,0.00 300.00,-148.71 151.29,-148.71\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"29.7\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"225.6\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "292a",
   "ex": 292,
   "ap": "a",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos cossos són semblants amb raó $k$. Si el volum del petit és el que es diu, quin és el del gran?",
   "enunciat": "$k=2$ i volum del petit $=30$ cm$^3$.",
   "opcions": [
    "$240$ cm$^3$",
    "$120$ cm$^3$",
    "$38$ cm$^3$",
    "$60$ cm$^3$"
   ],
   "pistes": [
    "Les longituds van amb $k$, les àrees amb $k^2$ i els volums amb $k^3$.",
    "$k^3=8$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRWwgJGteMiQgw6lzIHBlciBhIGxlcyDDgFJFRVMuIEVscyB2b2x1bXMgdmFuIGFtYiAka14zJC4iLCAiTGEgcmHDsyBtdWx0aXBsaWNhIGVsIHZvbHVtLCBubyBzJ2hpIHN1bWEuIiwgIkhhcyBtdWx0aXBsaWNhdCBwZWwgJGskIHRvdCBzb2wuIFVuIHZvbHVtIHTDqSB0cmVzIGRpbWVuc2lvbnM6IHNpIGxlcyBsb25naXR1ZHMgZXMgbXVsdGlwbGlxdWVuIHBlciAkMiQsIGVsIHZvbHVtIGhvIGZhIHBlciAkMl4zPTgkLiJdLCAiZXJyIjogWyIiLCAiUkFPX0FMX1FVQURSQVQiLCAiUFJPRFVDVEVfUEVSX1NVTUEiLCAiUkFPX1NFTlNFX1FVQURSQVQiXSwgInJlcyI6IFsiJGteMz0yXjM9OCQiLCAiVm9sdW0gZ3JhbiAkPTMwXFxjZG90OD0yNDAkIGNtJF4zJCJdLCAiY29tIjogIkFxdWVzdCDDqXMgZWwgcXVlIG3DqXMgc29ycHLDqG46IGRvYmxhciB0b3RlcyBsZXMgbWlkZXMgbXVsdGlwbGljYSBlbCB2b2x1bSBwZXIgJDgkLiDDiXMgZWwgbW90aXUgcGVsIHF1YWwgdW5hIG1hcXVldGEgYSBlc2NhbGEgJDE6MiQgbm8gcGVzYSBsYSBtZWl0YXQsIHNpbsOzIHVuYSB2dWl0ZW5hIHBhcnQuIn0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 335 206\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos cubs.</title><g transform=\"translate(14.0,174.8)\"><polygon points=\"60.00,0.00 60.00,-60.00 80.40,-80.40 80.40,-20.40\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,-60.00 60.00,-60.00 80.40,-80.40 20.40,-80.40\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,0.00 60.00,0.00 60.00,-60.00 0.00,-60.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"265.60,0.00 265.60,-120.00 306.40,-160.80 306.40,-40.80\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"145.60,-120.00 265.60,-120.00 306.40,-160.80 186.40,-160.80\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"145.60,0.00 265.60,0.00 265.60,-120.00 145.60,-120.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"205.6\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "292b",
   "ex": 292,
   "ap": "b",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Dos cossos són semblants amb raó $k$. Si el volum del petit és el que es diu, quin és el del gran?",
   "enunciat": "$k=3$ i volum del petit $=5$ cm$^3$.",
   "opcions": [
    "$45$ cm$^3$",
    "$135$ cm$^3$",
    "$15$ cm$^3$",
    "$32$ cm$^3$"
   ],
   "pistes": [
    "Les longituds van amb $k$, les àrees amb $k^2$ i els volums amb $k^3$.",
    "$k^3=27$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJFbCAka14yJCDDqXMgcGVyIGEgbGVzIMOAUkVFUy4gRWxzIHZvbHVtcyB2YW4gYW1iICRrXjMkLiIsICIiLCAiSGFzIG11bHRpcGxpY2F0IHBlbCAkayQgdG90IHNvbC4gVW4gdm9sdW0gdMOpIHRyZXMgZGltZW5zaW9uczogc2kgbGVzIGxvbmdpdHVkcyBlcyBtdWx0aXBsaXF1ZW4gcGVyICQzJCwgZWwgdm9sdW0gaG8gZmEgcGVyICQzXjM9MjckLiIsICJMYSByYcOzIG11bHRpcGxpY2EgZWwgdm9sdW0sIG5vIHMnaGkgc3VtYS4iXSwgImVyciI6IFsiUkFPX0FMX1FVQURSQVQiLCAiIiwgIlJBT19TRU5TRV9RVUFEUkFUIiwgIlBST0RVQ1RFX1BFUl9TVU1BIl0sICJyZXMiOiBbIiRrXjM9M14zPTI3JCIsICJWb2x1bSBncmFuICQ9NVxcY2RvdDI3PTEzNSQgY20kXjMkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 382 255\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos cubs.</title><g transform=\"translate(14.0,223.2)\"><polygon points=\"52.05,0.00 52.05,-52.05 69.75,-69.75 69.75,-17.70\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,-52.05 52.05,-52.05 69.75,-69.75 17.70,-69.75\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,0.00 52.05,0.00 52.05,-52.05 0.00,-52.05\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"300.00,0.00 300.00,-156.15 353.09,-209.24 353.09,-53.09\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,-156.15 300.00,-156.15 353.09,-209.24 196.94,-209.24\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,0.00 300.00,0.00 300.00,-156.15 143.85,-156.15\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"26\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"221.9\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "293a",
   "ex": 293,
   "ap": "a",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "A l'inrevés: del que saps de les àrees, dedueix la raó de longituds.",
   "enunciat": "Dos triangles semblants tenen àrees de $12$ cm$^2$ i $108$ cm$^2$. Quina és la raó entre els seus costats?",
   "opcions": [
    "$k=96$",
    "$k=3$",
    "$k=9$",
    "$k=\\sqrt{108-12}$"
   ],
   "pistes": [
    "La raó entre les àrees és $k^2$.",
    "Divideix les àrees i fes l'arrel quadrada del resultat."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgcmVzdGF0IGxlcyDDoHJlZXMuIExhIHJhw7Mgw6lzIHVuIHF1b2NpZW50LiIsICIiLCAiRWwgJDkkIMOpcyBsYSByYcOzIGVudHJlIGxlcyDDgFJFRVMgKCQxMDg6MTIkKS4gTGEgcmHDsyBlbnRyZSBlbHMgY29zdGF0cyBuJ8OpcyBsJ2FycmVsIHF1YWRyYWRhOiAkaz1cXHNxcnR7OX09MyQuIiwgIk5pIHJlc3RhIG5pIGFycmVsIGRlIGxhIHJlc3RhOiBwcmltZXIgZXMgZGl2aWRlaXhlbiBsZXMgw6ByZWVzIGkgZGVzcHLDqXMgZXMgZmEgbCdhcnJlbCBkZWwgcXVvY2llbnQuIl0sICJlcnIiOiBbIlJFU1RBX1BFUl9RVU9DSUVOVCIsICIiLCAiUkFPX0FMX1FVQURSQVQiLCAiUkVTVEFfUEVSX1FVT0NJRU5UIl0sICJyZXMiOiBbIiRcXGRmcmFjezEwOH17MTJ9PTkkLCBpIGFpeMOyIMOpcyAka14yJCIsICIkaz1cXHNxcnR7OX09MyQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 328 202\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos quadrats.</title><g transform=\"translate(14.0,170.1)\"><polygon points=\"0.00,0.00 52.05,0.00 52.05,-52.05 0.00,-52.05\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,0.00 300.00,0.00 300.00,-156.15 143.85,-156.15\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"26\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"221.9\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "293b",
   "ex": 293,
   "ap": "b",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "A l'inrevés: del que saps de les àrees, dedueix la raó de longituds.",
   "enunciat": "Dues esferes semblants tenen volums de $8$ cm$^3$ i $216$ cm$^3$. Quina és la raó entre els seus radis?",
   "opcions": [
    "$k=\\sqrt{27}$",
    "$k=27$",
    "$k=3$",
    "$k=208$"
   ],
   "pistes": [
    "La raó entre els volums és $k^3$.",
    "Divideix els volums i fes-ne l'arrel cúbica."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJMJ2FycmVsIHF1YWRyYWRhIHNlcnZpcmlhIHNpIGNvbXBhcsOpc3NpbSDDoHJlZXMuIEFtYiB2b2x1bXMgY2FsIGwnYXJyZWwgY8O6YmljYS4iLCAiRWwgJDI3JCDDqXMgbGEgcmHDsyBlbnRyZSBlbHMgVk9MVU1TICgkMjE2OjgkKS4gTGEgcmHDsyBlbnRyZSBlbHMgcmFkaXMgbifDqXMgbCdhcnJlbCBDw5pCSUNBOiAkaz1cXHNxcnRbM117Mjd9PTMkLiIsICIiLCAiSGFzIHJlc3RhdCBlbHMgdm9sdW1zIGVuIGNvbXB0ZXMgZGUgZGl2aWRpci1sb3MuIl0sICJlcnIiOiBbIkFSUkVMX01BTF9BUExJQ0FEQSIsICJSQU9fQUxfQ1VCIiwgIiIsICJSRVNUQV9QRVJfUVVPQ0lFTlQiXSwgInJlcyI6IFsiJFxcZGZyYWN7MjE2fXs4fT0yNyQsIGkgYWl4w7Igw6lzICRrXjMkIiwgIiRrPVxcc3FydFszXXsyN309MyQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 382 255\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos cubs.</title><g transform=\"translate(14.0,223.2)\"><polygon points=\"52.05,0.00 52.05,-52.05 69.75,-69.75 69.75,-17.70\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,-52.05 52.05,-52.05 69.75,-69.75 17.70,-69.75\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,0.00 52.05,0.00 52.05,-52.05 0.00,-52.05\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"300.00,0.00 300.00,-156.15 353.09,-209.24 353.09,-53.09\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,-156.15 300.00,-156.15 353.09,-209.24 196.94,-209.24\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"143.85,0.00 300.00,0.00 300.00,-156.15 143.85,-156.15\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"26\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><text x=\"221.9\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "294a",
   "ex": 294,
   "ap": "a",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Una maqueta d'un edifici està feta a escala $1:50$. L'edifici de debò fa $30$ m d'alçada, té una façana de $600$ m$^2$ i un volum de $9\\,000$ m$^3$.",
   "enunciat": "Amb l'escala $1:50$, quina alçada fa la maqueta si l'edifici real fa $30$ m?",
   "opcions": [
    "$1\\,500$ m",
    "$60$ m",
    "$0{,}6$ m $=6$ cm",
    "$60$ cm"
   ],
   "pistes": [
    "Divideix l'alçada real entre $50$.",
    "Passa el resultat a centímetres."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgbXVsdGlwbGljYXQgcGVyICQ1MCQuIExhIG1hcXVldGEgw6lzIHVuYSBSRURVQ0NJw5M6IGNhbCBkaXZpZGlyLiIsICJFbCBuw7ptZXJvIMOpcyBjb3JyZWN0ZSBwZXLDsiBsYSB1bml0YXQgbm86ICQweyx9NiQgbSBzw7NuICQ2MCQgY2VudMOtbWV0cmVzLiIsICIkMzA6NTA9MHssfTYkIG0sIGkgJDB7LH02JCBtIHPDs24gJDYwJCBjbSwgbm8gJDYkLiIsICIiXSwgImVyciI6IFsiRVNDQUxBX0lOVkVSVElEQSIsICJVTklUQVRTX05PX0NPTlZFUlRJREVTIiwgIlBPVEVOQ0lBXzEwIiwgIiJdLCAicmVzIjogWyIkXFxkZnJhY3szMH17NTB9PTB7LH02JCBtIiwgIiQweyx9NiQgbSAkPTYwJCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 186 96\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos triangles.</title><g transform=\"translate(14.0,65.0)\"><polygon points=\"0.00,0.00 60.00,0.00 30.00,-51.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"122.50,0.00 137.50,0.00 130.00,-12.75\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><line class=\"fig-crida\" x1=\"130.0\" y1=\"0.0\" x2=\"147.9\" y2=\"6.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"154\" y=\"13.4\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "294b",
   "ex": 294,
   "ap": "b",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Una maqueta d'un edifici està feta a escala $1:50$. L'edifici de debò fa $30$ m d'alçada, té una façana de $600$ m$^2$ i un volum de $9\\,000$ m$^3$.",
   "enunciat": "Amb la mateixa escala $1:50$, quina superfície té la façana de la maqueta, si la de l'edifici real és de $600$ m$^2$?",
   "opcions": [
    "$0{,}24$ m$^2$ (és a dir, $2\\,400$ cm$^2$)",
    "$0{,}0048$ m$^2$",
    "$600$ m$^2$",
    "$12$ m$^2$"
   ],
   "pistes": [
    "La raó de longituds és $\\dfrac{1}{50}$; la d'àrees, $\\left(\\dfrac{1}{50}\\right)^2$.",
    "$50^2=2\\,500$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiSGFzIGRpdmlkaXQgZW50cmUgJDUwXjMkLiBFbCBjdWIgw6lzIHBlciBhbHMgdm9sdW1zOyB1bmEgZmHDp2FuYSDDqXMgdW5hIMOgcmVhIGkgdmEgYW1iIGVsIHF1YWRyYXQuIiwgIkFxdWVzdGEgw6lzIGxhIGZhw6dhbmEgcmVhbCwgbGEgcXVlIGphIGV0IGRvbmF2ZW4uIiwgIkhhcyBkaXZpZGl0IGwnw6ByZWEgZW50cmUgJDUwJC4gTGVzIMOgcmVlcyB2YW4gYW1iICRrXjIkOiBjYWwgZGl2aWRpciBlbnRyZSAkNTBeMj0yXFwsNTAwJC4iXSwgImVyciI6IFsiIiwgIlJBT19BTF9DVUIiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiUkFPX1NFTlNFX1FVQURSQVQiXSwgInJlcyI6IFsiJFxcZGZyYWN7NjAwfXs1MF4yfT1cXGRmcmFjezYwMH17MjUwMH09MHssfTI0JCBtJF4yJCIsICIkMHssfTI0JCBtJF4yPTJcXCw0MDAkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 186 106\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos quadrats.</title><g transform=\"translate(14.0,74.0)\"><polygon points=\"0.00,0.00 60.00,0.00 60.00,-60.00 0.00,-60.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"122.50,0.00 137.50,0.00 137.50,-15.00 122.50,-15.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><line class=\"fig-crida\" x1=\"130.0\" y1=\"0.0\" x2=\"147.4\" y2=\"7.5\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"153.3\" y=\"14.8\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "294c",
   "ex": 294,
   "ap": "c",
   "bloc": "semblanca_arees",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Una maqueta d'un edifici està feta a escala $1:50$. L'edifici de debò fa $30$ m d'alçada, té una façana de $600$ m$^2$ i un volum de $9\\,000$ m$^3$.",
   "enunciat": "Amb la mateixa escala $1:50$, quin volum té la maqueta, si l'edifici real en fa $9\\,000$ m$^3$?",
   "opcions": [
    "$180$ m$^3$",
    "$0{,}072$ m$^3$ (és a dir, $72\\,000$ cm$^3$)",
    "$3{,}6$ m$^3$",
    "$72$ m$^3$"
   ],
   "pistes": [
    "La raó de volums és $\\left(\\dfrac{1}{50}\\right)^3$.",
    "$50^3=125\\,000$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgZGl2aWRpdCBlbnRyZSAkNTAkLiBFbHMgdm9sdW1zIHZhbiBhbWIgJGteMyQ6IGVudHJlICQ1MF4zPTEyNVxcLDAwMCQuIiwgIiIsICJIYXMgZGl2aWRpdCBlbnRyZSAkNTBeMiQuIEVsIHF1YWRyYXQgw6lzIHBlciBhIGxlcyDDoHJlZXMuIiwgIlQnaGFzIGRlc3BsYcOnYXQgdHJlcyBsbG9jczogJFxcZGZyYWN7OTAwMH17MTI1MDAwfT0weyx9MDcyJCwgbm8gJDcyJC4iXSwgImVyciI6IFsiUkFPX1NFTlNFX1FVQURSQVQiLCAiIiwgIlJBT19BTF9RVUFEUkFUIiwgIlBPVEVOQ0lBXzEwIl0sICJyZXMiOiBbIiRcXGRmcmFjezkwMDB9ezUwXjN9PVxcZGZyYWN7OTAwMH17MTI1MDAwfT0weyx9MDcyJCBtJF4zJCIsICIkMHssfTA3MiQgbSReMz03MlxcLDAwMCQgY20kXjMkIiwgIkxhIG1hcXVldGEgw6lzICQ1MCQgdmVnYWRlcyBtw6lzIGN1cnRhLCAkMlxcLDUwMCQgdmVnYWRlcyBtw6lzIHBldGl0YSBkZSBmYcOnYW5hIGkgJDEyNVxcLDAwMCQgdmVnYWRlcyBtw6lzIHBldGl0YSBkZSB2b2x1bSJdLCAiY29tIjogIkVscyB0cmVzIGFwYXJ0YXRzIGp1bnRzIHPDs24gZWwgcmVzdW0gZGVsIGJsb2M6IHVuYSBzb2xhIGVzY2FsYSwgdHJlcyBmYWN0b3JzIGRpZmVyZW50cyBzZWdvbnMgc2kgZWwgcXVlIG1lc3VyZXMgdMOpIHVuYSwgZHVlcyBvIHRyZXMgZGltZW5zaW9ucy4ifQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 184 130\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dues figures semblants, amb la raó entre una longitud i la seva corresponent marcada: dos cubs.</title><g transform=\"translate(14.0,94.4)\"><polygon points=\"60.00,0.00 60.00,-60.00 80.40,-80.40 80.40,-20.40\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,-60.00 60.00,-60.00 80.40,-80.40 20.40,-80.40\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"0.00,0.00 60.00,0.00 60.00,-60.00 0.00,-60.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"137.50,0.00 137.50,-15.00 142.60,-20.10 142.60,-5.10\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"122.50,-15.00 137.50,-15.00 142.60,-20.10 127.60,-20.10\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><polygon points=\"122.50,0.00 137.50,0.00 137.50,-15.00 122.50,-15.00\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><text x=\"30\" y=\"14.4\" text-anchor=\"middle\" class=\"fig-etq\">1</text><line class=\"fig-crida\" x1=\"130.0\" y1=\"0.0\" x2=\"146.0\" y2=\"9.6\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"151.5\" y=\"18.1\" text-anchor=\"middle\" class=\"fig-etq\">k</text></g></svg>"
  },
  {
   "id": "161",
   "ex": 161,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Quant mesura l'ombra projectada per un arbre de $15$ m d'altura, sabent que en aquest mateix moment un altre arbre de $8$ m d'altura projecta una ombra de $10$ m?",
   "opcions": [
    "$16$ m",
    "$8$ m",
    "$12{,}5$ m",
    "$18{,}75$ m"
   ],
   "pistes": [
    "Al mateix moment, l'altura i l'ombra són proporcionals: cada arbre amb la seva ombra. Arbre petit: $8$ m d'altura i $10$ m d'ombra. Arbre gran: $15$ m d'altura i ombra $x$.",
    "$\\dfrac{8}{10}=\\dfrac{15}{x}$. Aïlla $x$: com que l'arbre gran és més alt, la seva ombra ha de sortir més llarga."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkZSAkOFxcY2RvdDIkOiBjb21wcm92YSBlbCBjw6BsY3VsIGNvbXBsZXQgJHg9XFxmcmFjezE1XFxjZG90MTB9ezh9JCBwYXMgYSBwYXMgZW4gbGxvYyBkJ3VuYSBhcHJveGltYWNpw7MuIiwgIiQ4JCBtIMOpcyBsJ2FsdHVyYSBkZWwgcHJpbWVyIGFyYnJlLCBubyBsJ29tYnJhIHF1ZSBlcyBkZW1hbmEgcGVyIGFsIHNlZ29uOiB0b3JuYSBhIHBsYW50ZWphciBsYSBwcm9wb3JjacOzIGRlcyBkZSB6ZXJvLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkJ2ludmVydGlyIGxhIHByb3BvcmNpw7M6IGNvbSBxdWUgZWwgc2Vnb24gYXJicmUgw6lzIE3DiVMgQUxULCBsYSBzZXZhIG9tYnJhIGhhIGRlIHNlciBNw4lTIExMQVJHQSBxdWUgbGEgZGVsIHByaW1lciwgbm8gbcOpcyBjdXJ0YS4gUGxhbnRlamEgJFxcZnJhY3s4fXsxMH09XFxmcmFjezE1fXt4fSQuIiwgIiJdLCAiZXJyIjogWyJQUk9EVUNURV9NQUwiLCAiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIiJdLCAicmVzIjogWyIkXFxkZnJhY3s4fXsxMH09XFxkZnJhY3sxNX17eH0gXFw7XFxMb25ncmlnaHRhcnJvd1xcOyB4PVxcZGZyYWN7MTVcXGNkb3QxMH17OH0kIiwgIiR4PTE4eyx9NzUkIG0iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 268 132\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(53.6,102.0)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-40.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-40.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-88.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-88.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-40.0\" x2=\"-18.5\" y2=\"-40.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-40.0\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-44.0\" x2=\"-19.0\" y2=\"-36.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-88.0\" x2=\"71.5\" y2=\"-88.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-88.0\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-92.0\" x2=\"71.0\" y2=\"-84.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-30\" y=\"-17.1\" text-anchor=\"middle\" class=\"fig-etq petita\">8 m</text><text x=\"37\" y=\"-27.1\" text-anchor=\"middle\" class=\"fig-etq petita\">10 m</text><text x=\"60\" y=\"-41.1\" text-anchor=\"middle\" class=\"fig-etq petita\">15 m</text><text x=\"145\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">arbre petit</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">arbre gran</text></g></svg>"
  },
  {
   "id": "162",
   "ex": 162,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Una antena està subjectada amb dos cables que formen entre ells un angle de $90^\\circ$ i mesuren $8$ i $5$ m, respectivament. A quina altura s'enganxen a l'antena?",
   "opcions": [
    "$13$ m",
    "$6{,}24$ m",
    "$9{,}43$ m (aproximadament)",
    "$40$ m"
   ],
   "pistes": [
    "Com que els dos cables formen un angle de $90^\\circ$ entre ells, són els catets d'un triangle rectangle, i el tram d'antena entre els dos punts d'ancoratge n'és la hipotenusa.",
    "Aplica el teorema de Pitàgores: $h=\\sqrt{8^2+5^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgc3VtYXQgbGVzIGR1ZXMgbG9uZ2l0dWRzICgkOCs1JCkgZW5sbG9jIGQnYXBsaWNhciBlbCB0ZW9yZW1hIGRlIFBpdMOgZ29yZXM6IGNvbSBxdWUgZWxzIGNhYmxlcyBmb3JtZW4gdW4gYW5nbGUgcmVjdGUsIHPDs24gZWxzIGNhdGV0cyBkJ3VuIHRyaWFuZ2xlIHJlY3RhbmdsZSwgaSBjYWwgJGg9XFxzcXJ0ezheMis1XjJ9JC4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJFxcc3FydHs4XjItNV4yfSQsIGNvbSBzaSAkOCQgZm9zIGxhIGhpcG90ZW51c2EgaSAkNSQgdW4gY2F0ZXQ7IGFxdcOtIGVscyBET1MgY2FibGVzIHPDs24gY2F0ZXRzIChmb3JtZW4gbCdhbmdsZSByZWN0ZSBlbnRyZSBlbGxzKSwgaSBsJ2FudGVuYSDDqXMgbGEgaGlwb3RlbnVzYTogY2FsIHN1bWFyIGVscyBxdWFkcmF0cywgbm8gcmVzdGFyLWxvcy4iLCAiIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIG11bHRpcGxpY2FyICQ4XFxjZG90NSQ6IGVsIHRlb3JlbWEgZGUgUGl0w6Bnb3JlcyByZWxhY2lvbmEgZWxzIFFVQURSQVRTIGRlbHMgY2F0ZXRzLCBubyBlbCBzZXUgcHJvZHVjdGUgZGlyZWN0ZS4iXSwgImVyciI6IFsiU1VNQV9FTl9MTE9DX1JFU1RBIiwgIkNBVEVUX0hJUE9URU5VU0FfQ09ORk9TT1MiLCAiIiwgIlBST0RVQ1RFX01BTCJdLCAicmVzIjogWyIkaD1cXHNxcnR7OF4yKzVeMn09XFxzcXJ0ezY0KzI1fT1cXHNxcnR7ODl9JCIsICIkaFxcYXBwcm94OXssfTQzJCBtIl19"
  },
  {
   "id": "163",
   "ex": 163,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un arbre fa $5$ m d'altura i, a una determinada hora del dia, projecta una ombra de $6$ m. Quina altura tindrà un edifici que a la mateixa hora projecta una ombra de $10$ m?",
   "opcions": [
    "$6$ m",
    "$12$ m",
    "$8{,}33$ m (aproximadament)",
    "$9$ m"
   ],
   "pistes": [
    "A la mateixa hora, l'altura i l'ombra són proporcionals: cada objecte amb la seva ombra. Arbre: $5$ m d'altura i $6$ m d'ombra. Edifici: altura $x$ i $10$ m d'ombra.",
    "Ombra entre altura dona el mateix per als dos: $\\dfrac{6}{5}=\\dfrac{10}{x}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyIkNiQgbSDDqXMgbCdvbWJyYSBkZSBsJ2FyYnJlLCBubyBsJ2FsdHVyYSBkZSBsJ2VkaWZpY2kgcXVlIGVzIGRlbWFuYTogdG9ybmEgYSBwbGFudGVqYXIgbGEgcHJvcG9yY2nDsyBkZXMgZGUgemVyby4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZCdpbnZlcnRpciBsYSBwcm9wb3JjacOzOiBwbGFudGVqYSAkXFxmcmFjezZ9ezV9PVxcZnJhY3sxMH17eH0kLCBhbWIgbCdhbHR1cmEgZGUgbCdhcmJyZSBjb3JyZXNwb25lbnQgYSBsYSBzZXZhIHByw7JwaWEgb21icmEsIG5vIGEgbGEgZGUgbCdlZGlmaWNpLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgc3VtYXIgbGEgZGlmZXLDqG5jaWEgZCdvbWJyZXMgKCQxMC02PTQkKSBhIGwnYWx0dXJhIGRlIGwnYXJicmU6IGwnYWx0dXJhIGkgbCdvbWJyYSBzw7NuIFBST1BPUkNJT05BTFMsIG5vIHZhcmllbiBwZXIgdW5hIGRpZmVyw6huY2lhIHN1bWFkYS4iXSwgImVyciI6IFsiUFJPR1JFU1NJT19JTlZFTlRBREEiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIiIsICJSQU9OQU1FTlRfQURESVRJVSJdLCAicmVzIjogWyIkXFxkZnJhY3s2fXs1fT1cXGRmcmFjezEwfXt4fSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3s1XFxjZG90MTB9ezZ9PVxcZGZyYWN7NTB9ezZ9JCIsICIkeFxcYXBwcm94OHssfTMzJCBtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 268 135\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(53.6,105.7)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-41.7\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-41.7\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-91.7\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-91.7\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-41.7\" x2=\"-18.5\" y2=\"-41.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-41.7\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-45.7\" x2=\"-19.0\" y2=\"-37.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-91.7\" x2=\"71.5\" y2=\"-91.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-91.7\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-95.7\" x2=\"71.0\" y2=\"-87.7\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-30\" y=\"-17.9\" text-anchor=\"middle\" class=\"fig-etq petita\">5 m</text><text x=\"37\" y=\"-27.1\" text-anchor=\"middle\" class=\"fig-etq petita\">6 m</text><text x=\"64\" y=\"-42.9\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"145\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">10 m</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">arbre</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">edifici</text></g></svg>"
  },
  {
   "id": "164",
   "ex": 164,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Si un pal mesura $1$ m, i l'ombra que projecta a una determinada hora del dia és d'$1{,}5$ m, quant mesura un edifici que projecta una ombra de $6$ m a la mateixa hora?",
   "opcions": [
    "$6{,}67$ m",
    "$4$ m",
    "$9$ m",
    "$5{,}5$ m"
   ],
   "pistes": [
    "A la mateixa hora, l'altura i l'ombra són proporcionals: cada objecte amb la seva ombra. Pal: $1$ m d'altura i $1{,}5$ m d'ombra. Edifici: altura $x$ i $6$ m d'ombra.",
    "Altura entre ombra dona el mateix per als dos: $\\dfrac{1}{1{,}5}=\\dfrac{x}{6}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkZSAkNjoxeyx9NVxcY2RvdDF7LH02NyQsIGFtYiBlbHMgdGVybWVzIG1hbCBhcGFyZWxsYXRzOiByZXZpc2EgbGEgcHJvcG9yY2nDsyAkXFxmcmFjezF9ezF7LH01fT1cXGZyYWN7eH17Nn0kIHBhcyBhIHBhcy4iLCAiIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGQnaW52ZXJ0aXIgbGEgcHJvcG9yY2nDszogcGxhbnRlamEgJFxcZnJhY3sxfXsxeyx9NX09XFxmcmFje3h9ezZ9JCwgYW1iIGwnYWx0dXJhIGRlbCBwYWwgY29ycmVzcG9uZW50IGEgbGEgc2V2YSBwcsOycGlhIG9tYnJhLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSBzdW1hciBsYSBkaWZlcsOobmNpYSBkJ29tYnJlcyAoJDYtMXssfTU9NHssfTUkKSBhIGwnYWx0dXJhIGRlbCBwYWw6IGwnYWx0dXJhIGkgbCdvbWJyYSBzw7NuIFBST1BPUkNJT05BTFMsIG5vIHZhcmllbiBwZXIgdW5hIGRpZmVyw6huY2lhIHN1bWFkYS4iXSwgImVyciI6IFsiRElWSVNJT19RVU9DSUVOVF9SRVNJRFVfQ0FOVklBVFMiLCAiIiwgIkNSRVVBTUVOVF9JTlZFUlRJVCIsICJSQU9OQU1FTlRfQURESVRJVSJdLCAicmVzIjogWyIkXFxkZnJhY3sxfXsxeyx9NX09XFxkZnJhY3t4fXs2fSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3sxXFxjZG90Nn17MXssfTV9JCIsICIkeD00JCBtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 268 117\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(53.6,87.3)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-33.3\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-33.3\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-73.3\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-73.3\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-33.3\" x2=\"-18.5\" y2=\"-33.3\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-33.3\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-37.3\" x2=\"-19.0\" y2=\"-29.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-73.3\" x2=\"71.5\" y2=\"-73.3\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-73.3\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-77.3\" x2=\"71.0\" y2=\"-69.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-30\" y=\"-13.7\" text-anchor=\"middle\" class=\"fig-etq petita\">1 m</text><text x=\"37\" y=\"-27.1\" text-anchor=\"middle\" class=\"fig-etq petita\">1,5 m</text><text x=\"64\" y=\"-33.7\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"131.8\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">6 m</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">pal</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">edifici</text></g></svg>"
  },
  {
   "id": "165",
   "ex": 165,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un jugador de bàsquet d'$1{,}9$ m, situat a $6{,}25$ m de la cistella, llança la pilota per encistellar (cistella a $3{,}05$ m d'altura). Suposant una trajectòria rectilínia des del llançament fins a la cistella, a quina altura està la pilota quan va per la meitat del recorregut?",
   "opcions": [
    "$1{,}525$ m",
    "$4{,}95$ m",
    "$1{,}575$ m",
    "$2{,}475$ m"
   ],
   "pistes": [
    "A mig recorregut, la pilota ha pujat la meitat de la diferència total d'altura entre el llançament i la cistella.",
    "Calcula primer la diferència d'altures ($3{,}05-1{,}9$) i suma'n la meitat a l'altura inicial."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igw6lzIGxhIG1laXRhdCBkZSAkM3ssfTA1JCBtOiBubyB0w6kgZW4gY29tcHRlIHF1ZSBsYSBwaWxvdGEgamEgcGFydGVpeCBkJ3VuYSBhbHR1cmEgaW5pY2lhbCBkJyQxeyx9OSQgbSwgbm8gZGUgdGVycmEuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIHN1bWFyIGxlcyBkdWVzIGFsdHVyZXMgaSBkaXZpZGlyLWxlcyBlbnRyZSAkMiQ6IGNvbSBxdWUgbGEgcGlsb3RhIHB1amEgZGVzIGQnJDF7LH05JCBtLCBjYWwgc3VtYXItaGkgTk9Nw4lTIGxhIG1laXRhdCBkZSBsYSBkaWZlcsOobmNpYSwgbm8gZmVyIGxhIG1pdGphbmEgYXJpdG3DqHRpY2EgZGlyZWN0YSAocXVlIHBlciBhcXVlc3QgY2FzIGRvbmEgZWwgbWF0ZWl4IHJlc3VsdGF0IHBlcsOyIHBlbCBtb3RpdSBlcXVpdm9jYXQ7IGNvbXByb3ZhLWhvIGFtYiBsYSBkaWZlcsOobmNpYSBkJ2FsdHVyZXMpLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSAkXFxmcmFjezN7LH0wNX17Mn0tXFxmcmFjezF7LH05fXsyfSQ6IGNhbCBwYXJ0aXIgZGUgbCdhbHR1cmEgaW5pY2lhbCAoJDF7LH05JCBtKSBpIHN1bWFyLWhpIGxhIE1FSVRBVCBkZSBsYSBkaWZlcsOobmNpYSBkJ2FsdHVyZXMsIG5vIGNhbGN1bGFyIGxhIG1laXRhdCBkZSBjYWRhIGFsdHVyYSBwZXIgc2VwYXJhdC4iLCAiIl0sICJlcnIiOiBbIlBST0dSRVNTSU9fSU5WRU5UQURBIiwgIlNVTUFfRU5fTExPQ19SRVNUQSIsICJBUklUTUVUSUNBX1BBU19JTlRFUk1FREkiLCAiIl0sICJyZXMiOiBbIkRpZmVyw6huY2lhIGQnYWx0dXJhOiAkM3ssfTA1LTF7LH05PTF7LH0xNSQgbSIsICIkeD0xeyx9OStcXGRmcmFjezF7LH0xNX17Mn09MXssfTkrMHssfTU3NSQiLCAiJHg9MnssfTQ3NSQgbSJdfQ=="
  },
  {
   "id": "166",
   "ex": 166,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "L'Anna està situada a $5$ m de la vora d'un riu i veu reflectida una muntanya a l'aigua. Si l'Anna mesura $1{,}70$ m i el riu està a $3$ km de la muntanya, quina altura té la muntanya?",
   "opcions": [
    "$8{,}82$ m",
    "$5\\,100$ m",
    "$1{,}02$ m",
    "$1\\,020$ m"
   ],
   "pistes": [
    "Converteix els $3$ km a metres: $3\\,000$ m.",
    "L'altura de l'Anna i la seva distància a la vora són proporcionals a l'altura de la muntanya i la seva distància a la vora: $\\dfrac{1{,}70}{5}=\\dfrac{x}{3\\,000}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkJ2ludmVydGlyIGxhIHByb3BvcmNpw7M6IHBsYW50ZWphICRcXGZyYWN7MXssfTcwfXs1fT1cXGZyYWN7eH17M1xcLDAwMH0kLCBhbWIgbCdhbHR1cmEgZGUgbCdBbm5hIGNvcnJlc3BvbmVudCBhIGxhIHNldmEgcHLDsnBpYSBkaXN0w6BuY2lhIGEgbGEgdm9yYS4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJDF7LH03MFxcY2RvdDNcXCwwMDAkIHNlbnNlIGRpdmlkaXIgcGVyICQ1JDogJHg9XFxmcmFjezF7LH03MFxcY2RvdDNcXCwwMDB9ezV9JCwgbm8gbm9tw6lzIGVsIG51bWVyYWRvci4iLCAiQXF1ZXN0IHZhbG9yIGVzdMOgIGVuIG1ldHJlcyBwZXLDsiBsYSB4aWZyYSBjb3JyZXNwb24gYSBxdWlsw7JtZXRyZXM6ICQxXFwsMDIwJCBtIGVxdWl2YWwgYSAkMXssfTAyJCBrbSwgbm8gYSAkMXssfTAyJCBtOyByZXZpc2EgbGEgY29udmVyc2nDsyBkZSAkMyQga20gYSBtZXRyZXMgYWJhbnMgZGUgZGl2aWRpci4iLCAiIl0sICJlcnIiOiBbIkNSRVVBTUVOVF9JTlZFUlRJVCIsICJURVJNRV9PQkxJREFUX09QRVJBQ0lPIiwgIlBST0RVQ1RFX01BTCIsICIiXSwgInJlcyI6IFsiJDNcXHRleHR7IGttfT0zXFwsMDAwJCBtIiwgIiRcXGRmcmFjezF7LH03MH17NX09XFxkZnJhY3t4fXszXFwsMDAwfSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3sxeyx9NzBcXGNkb3QzXFwsMDAwfXs1fSQiLCAiJHg9MVxcLDAyMCQgbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 280 81\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(65.0,51.4)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-17.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-17.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-37.4\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-37.4\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-17.0\" x2=\"-18.5\" y2=\"-17.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-17.0\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-21.0\" x2=\"-19.0\" y2=\"-13.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-37.4\" x2=\"71.5\" y2=\"-37.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-37.4\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-41.4\" x2=\"71.0\" y2=\"-33.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-35\" y=\"-5.6\" text-anchor=\"middle\" class=\"fig-etq petita\">1,7 m</text><text x=\"25\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">5 m</text><text x=\"64\" y=\"-15.8\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"171.4\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">3000 m</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">Anna</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">muntanya</text></g></svg>"
  },
  {
   "id": "167",
   "ex": 167,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Mesurem l'ombra d'un edifici en dos moments del dia, amb angles d'elevació del sol de $60^\\circ$ i $30^\\circ$ respecte al terra. Si la distància entre els extrems de les dues ombres és de $6{,}67$ m, calcula l'altura de l'edifici.",
   "opcions": [
    "$5{,}78$ m (aproximadament)",
    "$3{,}85$ m",
    "$13{,}34$ m",
    "$11{,}55$ m"
   ],
   "pistes": [
    "L'ombra amb el sol a $60^\\circ$ val $\\frac{h}{\\tan60^\\circ}$ i, amb el sol a $30^\\circ$ (més baix, ombra més llarga), val $\\frac{h}{\\tan30^\\circ}$.",
    "La diferència entre totes dues ombres és $6{,}67$ m: $\\frac{h}{\\tan30^\\circ}-\\frac{h}{\\tan60^\\circ}=6{,}67$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgY29uc2lkZXJhciBub23DqXMgbCdvbWJyYSBhbWIgYW5nbGUgZGUgJDYwXlxcY2lyYyQgY29tIHNpIGZvcyB0b3RhIGxhIGRpZmVyw6huY2lhOiBjYWwgcmVzdGFyIGxlcyBEVUVTIG9tYnJlcyAoJFxcZnJhY3tofXtcXHRhbjMwXlxcY2lyY30tXFxmcmFje2h9e1xcdGFuNjBeXFxjaXJjfSQpLCBubyBmZXItbmUgc2VydmlyIG5vbcOpcyB1bmEuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlICQ2eyx9NjdcXGNkb3QyJDogY29tcHJvdmEgZWwgcGxhbnRlamFtZW50IGNvbXBsZXQgYW1iIGxlcyB0YW5nZW50cyBkZWxzIGRvcyBhbmdsZXMgZCdlbGV2YWNpw7MsIG5vIHVuYSBzaW1wbGUgcmVsYWNpw7MgZGlyZWN0YSBhbWIgbGEgZGlzdMOgbmNpYSBlbnRyZSBvbWJyZXMuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlICQ2eyx9NjdcXGNkb3RcXGxlZnQoXFx0YW42MF5cXGNpcmMtXFx0YW4zMF5cXGNpcmNcXHJpZ2h0KSQ6IGxhIGRpZmVyw6huY2lhIGQnb21icmVzIGVzIHBsYW50ZWphIGFtYiBlbHMgSU5WRVJTT1MgZGUgbGVzIHRhbmdlbnRzICgkXFxmcmFjezF9e1xcdGFuMzBeXFxjaXJjfS1cXGZyYWN7MX17XFx0YW42MF5cXGNpcmN9JCksIG5vIGFtYiBsZXMgdGFuZ2VudHMgZGlyZWN0YW1lbnQuIl0sICJlcnIiOiBbIiIsICJDQVRFVF9ISVBPVEVOVVNBX0NPTkZPU09TIiwgIlBST0RVQ1RFX01BTCIsICJQUk9EVUNURV9NQUwiXSwgInJlcyI6IFsiJGhcXGxlZnQoXFxkZnJhY3sxfXtcXHRhbjMwXlxcY2lyY30tXFxkZnJhY3sxfXtcXHRhbjYwXlxcY2lyY31cXHJpZ2h0KT02eyx9NjckIiwgIiRoXFwsKDF7LH03MzIxLTB7LH01Nzc0KT02eyx9NjcgXFw7XFxMb25ncmlnaHRhcnJvd1xcOyBoXFxjZG90MXssfTE1NDc9NnssfTY3JCIsICIkaFxcYXBwcm94NXssfTc4JCBtIl19"
  },
  {
   "id": "168",
   "ex": 168,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "En Pere és a $2$ m d'un precipici i veu alineat un poble amb la vora del precipici. Els seus ulls són a $1{,}6$ m d'altura i el precipici té $450$ m de profunditat. A quina distància horitzontal està el poble del precipici?",
   "opcions": [
    "$562{,}5$ m",
    "$1{,}6$ m",
    "$281{,}25$ m",
    "$720$ m"
   ],
   "pistes": [
    "Hi ha dos triangles semblants amb el vèrtex a la vora del precipici. El petit: l'altura dels ulls ($1{,}6$ m) i la distància d'en Pere a la vora ($2$ m). El gran: la profunditat ($450$ m) i la distància de la vora al poble ($x$).",
    "Vertical amb vertical i horitzontal amb horitzontal: $\\dfrac{1{,}6}{2}=\\dfrac{450}{x}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiJDF7LH02JCBtIMOpcyBsJ2FsdHVyYSBkZWxzIHVsbHMgZCdlbiBQZXJlLCB1bmEgZGFkYSBkZSBsJ2VudW5jaWF0LiBMYSBkaXN0w6BuY2lhIGFsIHBvYmxlIGhhIGRlIHNlciBtb2x0IG3DqXMgZ3JhbjogZWwgdHJpYW5nbGUgZ3JhbiBmYSAkNDUwJCBtIGRlIGZvbmTDoHJpYS4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJFxcZnJhY3s0NTB9ezF7LH02fSQsIHNlbnNlIG11bHRpcGxpY2FyIHBlbHMgJDIkIG06IHJldmlzYSBsYSBwcm9wb3JjacOzICRcXGZyYWN7MXssfTZ9ezJ9PVxcZnJhY3s0NTB9e3h9JCBwYXMgYSBwYXMuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlICQ0NTBcXGNkb3Qxeyx9NiQ6IGhhcyBtdWx0aXBsaWNhdCBlbHMgZG9zIGNvc3RhdHMgdmVydGljYWxzLiBDYWwgJHg9XFxmcmFjezJcXGNkb3Q0NTB9ezF7LH02fSQuIl0sICJlcnIiOiBbIiIsICJDUkVVQU1FTlRfSU5WRVJUSVQiLCAiQ1JFVUFNRU5UX0lOVkVSVElUIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iXSwgInJlcyI6IFsiJFxcZGZyYWN7MXssfTZ9ezJ9PVxcZGZyYWN7NDUwfXt4fSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3syXFxjZG90NDUwfXsxeyx9Nn09XFxkZnJhY3s5MDB9ezF7LH02fSQiLCAiJHg9NTYyeyx9NSQgbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 280 132\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(65.0,102.0)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-40.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-40.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-88.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-88.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-40.0\" x2=\"-18.5\" y2=\"-40.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-40.0\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-44.0\" x2=\"-19.0\" y2=\"-36.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-88.0\" x2=\"71.5\" y2=\"-88.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-88.0\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-92.0\" x2=\"71.0\" y2=\"-84.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-35\" y=\"-17.1\" text-anchor=\"middle\" class=\"fig-etq petita\">1,6 m</text><text x=\"37\" y=\"-27.1\" text-anchor=\"middle\" class=\"fig-etq petita\">2 m</text><text x=\"55\" y=\"-41.1\" text-anchor=\"middle\" class=\"fig-etq petita\">450 m</text><text x=\"145\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">Pere</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">poble</text></g></svg>"
  },
  {
   "id": "169",
   "ex": 169,
   "ap": "",
   "bloc": "aplicacions",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un home que té una alçada d'$1{,}75$ m veu reflectit un edifici de $52{,}5$ m sobre un bassal d'aigua que hi ha a $4$ m d'ell. A quina distància del bassal es troba l'edifici?",
   "opcions": [
    "$30$ m",
    "$1{,}75$ m",
    "$120$ m",
    "$210$ m"
   ],
   "pistes": [
    "El bassal fa de mirall: hi ha dos triangles semblants amb el vèrtex al bassal. El petit: l'alçada de l'home ($1{,}75$ m) i la seva distància al bassal ($4$ m). El gran: l'alçada de l'edifici ($52{,}5$ m) i la seva distància al bassal ($x$).",
    "Alçada entre distància dona el mateix als dos triangles: $\\dfrac{1{,}75}{4}=\\dfrac{52{,}5}{x}$. Aïlla $x$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkZSAkNTJ7LH01OjF7LH03NSQgc2Vuc2UgbXVsdGlwbGljYXIgcGVscyAkNCQgbTogcmV2aXNhIGxhIHByb3BvcmNpw7MgJFxcZnJhY3sxeyx9NzV9ezR9PVxcZnJhY3s1MnssfTV9e3h9JCBwYXMgYSBwYXMuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGQnaW52ZXJ0aXIgbGEgcHJvcG9yY2nDszogcGxhbnRlamEgJFxcZnJhY3sxeyx9NzV9ezR9PVxcZnJhY3s1MnssfTV9e3h9JCwgYW1iIGwnYWzDp2FkYSBkZSBsJ2hvbWUgY29ycmVzcG9uZW50IGEgbGEgc2V2YSBwcsOycGlhIGRpc3TDoG5jaWEgYWwgYmFzc2FsLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgJDRcXGNkb3Q1MnssfTUkIHNlbnNlIGRpdmlkaXIgcGVyICQxeyx9NzUkOiAkeD1cXGZyYWN7NFxcY2RvdDUyeyx9NX17MXssfTc1fSQsIG5vIG5vbcOpcyBlbCBudW1lcmFkb3IuIl0sICJlcnIiOiBbIkRJVklTSU9fUVVPQ0lFTlRfUkVTSURVX0NBTlZJQVRTIiwgIkNSRVVBTUVOVF9JTlZFUlRJVCIsICIiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyJdLCAicmVzIjogWyIkXFxkZnJhY3sxeyx9NzV9ezR9PVxcZGZyYWN7NTJ7LH01fXt4fSBcXDtcXExvbmdyaWdodGFycm93XFw7IHg9XFxkZnJhY3s0XFxjZG90NTJ7LH01fXsxeyx9NzV9JCIsICIkeD0xMjAkIG0iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 289 92\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Dos triangles rectangles semblants, cadascun amb un costat vertical i un costat horitzontal, units per una mateixa línia de referència amb la mateixa inclinació.</title><g transform=\"translate(74.2,62.1)\"><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-21.9\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"-21.9\" x2=\"50.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"90.0\" y2=\"-48.1\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"0.0\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"90.0\" y1=\"-48.1\" x2=\"200.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"2\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"-21.9\" x2=\"-18.5\" y2=\"-21.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-18.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-15.0\" y1=\"-21.9\" x2=\"-15.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-25.9\" x2=\"-19.0\" y2=\"-17.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-11.0\" y1=\"-4.0\" x2=\"-19.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-2.5\" x2=\"0.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"50.0\" y1=\"-2.5\" x2=\"50.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"-15.0\" x2=\"50.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"-11.0\" x2=\"4.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"46.0\" y1=\"-11.0\" x2=\"54.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"-48.1\" x2=\"71.5\" y2=\"-48.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"71.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"75.0\" y1=\"-48.1\" x2=\"75.0\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-52.1\" x2=\"71.0\" y2=\"-44.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"79.0\" y1=\"-4.0\" x2=\"71.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-2.5\" x2=\"90.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"200.0\" y1=\"-2.5\" x2=\"200.0\" y2=\"-18.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"90.0\" y1=\"-15.0\" x2=\"200.0\" y2=\"-15.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"86.0\" y1=\"-11.0\" x2=\"94.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"196.0\" y1=\"-11.0\" x2=\"204.0\" y2=\"-19.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"-41\" y=\"-8\" text-anchor=\"middle\" class=\"fig-etq petita\">1,75 m</text><text x=\"25\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">4 m</text><line class=\"fig-crida\" x1=\"75.0\" y1=\"-24.1\" x2=\"-0.8\" y2=\"-24.1\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"-23\" y=\"-21.1\" text-anchor=\"middle\" class=\"fig-etq petita\">52,5 m</text><text x=\"171.4\" y=\"-23.1\" text-anchor=\"middle\" class=\"fig-etq petita\">x</text><text x=\"25\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">home</text><text x=\"145\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq fig-etq-nom petita\">edifici</text></g></svg>"
  }
 ]
};
