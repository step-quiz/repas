# Setting up the "written exam from practice" workflow — a cold-start guide

You are an AI agent (Claude) meeting this repository for the first time,
tasked with putting a specific real-world workflow into production for one
teacher and their students. This document is self-contained: it tells you
what already exists, what does not exist, and what you need to build or
configure to close the gap. Read it before touching any code.

**Read `README.md` first if you have not.**

> **UPDATE — a second exam mode now exists.** The workflow described below
> (teacher picks one student, picks blocks, prints) is still there and still
> works, but it is now one of *two* modes behind a chooser in the **Prova
> escrita** tab:
>
>   **Both modes default to SHORT exams (2 questions)** since October 2026.
>
> - **Mini-examen estàndard** — the whole class at once. Two (default),
>   three or four questions per student (short / medium / long), drawn ONLY
>   from the LAST 20 exercises (it was the first 20 until October 2026) that
>   student did inside the examined tram (by date of first attempt). THE TRAM
>   IS A FREE DATE RANGE the teacher types into two date inputs (`#lot-ini`,
>   `#lot-fi`): there are no fixed trams and no rest weeks in the analyzer any
>   more, and nothing outside the range can get in. The same tram drives THE
>   ONLY GRADE in the analyzer: the per-tram work grade
>   `min(10, 8·∛(x/10))` where x sums per-exercise values /10 (first try 1,
>   one hint 0.95, two or more hints 0.85, second attempt 0.75, failed 0)
>   over the same last 20 exercises. It is shown only in «Full de respostes ›
>   Per alumne» (and its XLSX/CSV downloads), never in the exam panel; the
>   date range, minimum, maximum and per-state values are single fields
>   mirrored between both screens (`espeja()`), and `calculaTram()` is the
>   only caller of `RE_CODI.notaTram`.
>   EACH TRAM STARTS FROM ZERO: students wipe their progress the day after
>   each exam, so the analyzer keeps one record per (exercise, day of first
>   attempt). An exercise re-done later is separate work with its own date
>   and result, and does not touch the earlier tram; if the chosen range
>   holds the same exercise twice, the first date and result stand (a failed
>   one re-done is upgraded to "second attempt" at most); undated codes
>   (RC1–RC3) count for no tram; and a code submitted late DOES add work to
>   its tram, because the exercise date is what matters, not the submission
>   date.
>   `js/calendari.js` now only holds `FEINA_MINIMA`/`FEINA_MAXIMA` =
>   10/20 (read by the student site and the analyzer) plus sample date ranges
>   for the analyzer's example data and the tests. Output: one
>   printable document with every exam and another with every answer key.
>   No grade in either: grades live only in «Full de respostes».
>   The work grade never counts alone: the teacher validates it with the
>   paper exam (exam below 5, or more than 3 points between work grade and
>   exam grade → only the exam counts). See `GUIA-PROFESSORAT.md`.
> - **Examen personalitzat a un alumne** — what this document describes.
>
> Three things a future agent needs to know before touching it:
>
> 1. **RC4 codes carry the date of first attempt of every exercise done in
>    the last 12 weeks, in order** (`js/codi.js`, DATES block). One code is
>    enough. Legacy RC1-RC3 codes carry no dates and count for no tram: a
>    student who only has those shows up with zero exercises and the reason.
> 2. **There is no course calendar any more.** The teacher picks each exam's
>    tram with two dates, and the student site says nothing about trams,
>    deadlines or rest weeks: the Codi button only reports how many exercises
>    are in the browser (since the last wipe) and that 10–20 are expected per
>    exam. `js/calendari.js` is still injected at build time
>    (`/*__CALENDARI__*/`), but it now holds only `FEINA_MINIMA`/`FEINA_MAXIMA`
>    and nine sample date ranges for the example button and the tests.
> 3. **"Trimestre" now only means what the "Progrés del trimestre" tab means:**
>    a calendar term defined by months. The standard exam mode no longer
>    groups trams into terms.
>
> Tests: `tests/calendari.test.js` plus the four `tests/mini_examen*.test.js`
> batteries, all wired into `tests/executa.sh`. The two that read
> `tools/_taules.json` and `tools/_banc.json` skip with a message when those
> build artefacts are absent.
 It documents the site as a
product. This document only covers the one workflow below, in the order a
teacher would actually run it, and it is more explicit about the pieces a
human would not think to write down.

---

## 0. The workflow, stated precisely

A teacher wants students to be able to request a **paper exam** that only
covers the exercises they have genuinely practised on this site, in
proportion to how much of each topic they did. Five stages, cyclical:

1. **Student practises.** Exercises done in the browser accumulate into a
   record of everything attempted so far.
2. **Student asks for an exam.** They tell the teacher which topics they want
   to be tested on, out of everything they have been practising all year.
3. **Teacher receives the request through a Google Form.** The form is
   supposed to carry a "partial" extract — pulled from the student's full
   accumulated record — containing only the practised exercises the student
   wants examined on.
4. **`analitzador-repas.html` builds an ad-hoc exam** for that student, asking
   about the topics the student declared as prepared.
5. **After the exam, the student returns to step 1.** The teacher grades the
   paper exam by hand, using an answer key.

Steps 1, 4, and 5 already exist, built and working, exactly as described.
Step 2 exists but not in the shape the description above suggests. **Step 3
as described does not exist, and building it as described would be a
mistake** — read §2 before you write anything.

---

## 1. What already exists (do not rebuild this)

### 1.1 The accumulated record (step 1) → the **verification code**, not a file

There is no "file that documents practice." Progress lives in the browser's
`localStorage`, one key per sheet (`js/nucli.js`). What travels *off* the
browser is a **verification code**: a single compact text string (tens to a
few hundred characters, alphabet `0-9A-Z` minus `I`/`L`/`O`/`U`) generated by
`js/codi.js`. It is a complete, self-describing snapshot of every exercise
attempted across all 12 sheets plus the initial diagnostic test — never a
partial one. Format, generation, and reading are documented at the top of
`js/codi.js` and restated in `CODIS.md` and `TECHNICAL-STATE.md` §4.1–4.2.

Key properties you must not break if you touch this system:

- **Cumulative, not a session ticket.** Every code contains the full history
  up to that moment; a new code supersedes the previous one entirely. The
  teacher only ever needs the student's *last* code.
- **One code, always complete.** The floating **Codi** button (top-right, on
  every page a student can work from — `js/codi-ui.js`) always emits the full
  snapshot: all sheets, always. There is no "partial code" and no UI for the
  student to pick a subset before generating one.
- **Self-verifying.** Two trailing check characters (mod-1021 arithmetic,
  documented in `CODIS.md` §3 and `js/codi.js`) catch every single-character
  substitution and every two-character transposition. A code that fails this
  check is treated as untrustworthy everywhere downstream.
- **The mark is derived, never carried.** The grade is computed by the
  analyzer from the per-exercise states and dates (`RE_CODI.notaTram`, per
  tram), not stored inside the code — so there is no pair of numbers that
  could ever contradict each other. `RE_CODI.llegeix()` returns no grade at
  all.

### 1.2 The exam request (step 2) → the **Codi** button, not a topic picker

A student cannot "choose which topics to be examined on" at the point of
generating a code. That control does not exist there, deliberately (see the
"Sis decisions" section of `CODIS.md`, decision under "Quan i on s'ofereix"):
one button, one always-complete snapshot, so the student never has to decide
anything. **The topic selection the workflow needs happens later, on the
teacher's side, in step 4** — see §1.4.

What step 2 actually looks like in practice: the student clicks **Codi**,
sees a summary ("23 exercises done, X net, Y with hints..."), copies the
string, and pastes it somewhere the teacher will see it. Nothing here encodes
which topics they want examined; that is a separate, human conversation ("I
want to be tested on sheets 4 and 6") that happens outside the tool, or is
inferred later from what the code shows they actually practised.

### 1.3 Submission format (step 3, the transport part) → a specific 4-column sheet

`tools/fes-exemple.js` and the example CSV at the repo root
(`exemple-respostes-reals.csv`) show the exact shape a real Google Form
response sheet has. A second, richer fixture is *generated*, not shipped:

```sh
node tools/fes-exemple.js > exemple-respostes.csv
```

(Until 2026-08 that generator emitted valid but **empty** codes — it still
assumed the old block format `[name, first, last]`, while `js/codi-taules.js`
now uses `[name, [indices…]]`, so its loop never ran and no student in the
fixture had a single exercise. Fixed; if you are reading an older checkout,
check that line before trusting the fixture.)

```
Marca de temps;Adreça electrònica;Selecciona la classe;Enganxa aquí el codi que has copiat a step-quiz
9/22/2026 18:40:03;aina.puig@insterrassa.cat;1r BAT A;RC26V-30C2H-G4006-...
```

Four columns: **timestamp** (Google fills this automatically), **email**
(identity — the site itself never asks for a name, by design, so this column
*is* the identity), **class group**, and **the pasted code** (free text). The
column header still says "step-quiz," an old project name; it is cosmetic
and does not affect parsing — `analitzador-repas.html` detects the code
column and the email column by content/header, not by exact position.

**No Google Form template exists anywhere in this repository or its
history.** You must create one from scratch in a real Google account — see
§3.1. There is nothing to import or clone from the repo.

### 1.4 The exam generator (step 4) → already fully built, tab "Prova escrita"

`analitzador-repas.html` is a single self-contained generated file (built
from `tools/analitzador-plantilla.html` by `tools/build_analitzador.py`) that
opens by double-click and needs no server. It sends **no student data**
anywhere, but it is not network-silent: maths rendering pulls KaTeX from
`vendor/katex/` next to the file, falling back to the jsDelivr CDN — see
§3.3, this matters for printing.
It has a **Prova escrita** tab that does exactly what the workflow asks for,
already implemented:

- Pick a student from the loaded response sheet, **or** paste a code
  directly (`#pr-alumne` / `#pr-codi` in `tools/analitzador-plantilla.html`).
- The tool reads that student's *last* code and lists every topic block
  ("bloc") where the student did at least N exercises (default 3, editable —
  `#pr-min-bloc`), each with a checkbox, all checked by default
  (`blocsDisponibles()`, `pintaBlocsCamp()`). **This checkbox list is where
  "the student chooses which topics to be examined on" actually happens** —
  operated by the teacher, informed by what the student asked for and by
  what the code shows they did.
- Exam size: 2 / 3 / 4 questions (`MIDES_PROVA`), distributed across the
  checked blocks proportionally to work done in each (`reparteix()`, largest-
  remainder method), favouring exercises that cost the student more effort
  (`tria()`, weighted toward `fallat` > `pista` > `segon` > `net`), never
  repeating a parent exercise while unused ones remain.
- **A code that fails its own integrity check produces no exam.**
  `motiuBloqueig()` blocks generation and states why. This applies whether
  the code was picked from the dropdown or pasted by hand.
- Output: an open-response exam (statements only, no multiple-choice
  options — the student writes out the solution) and a **separate** answer
  key, with two separate print buttons (`#pr-imprimeix`,
  `#pr-imprimeix-clau`), on purpose — an answer key must never print on the
  same run as the exam.

**Nothing here needs to be written.** If a request seems to ask you to build
"the topic-selection UI" or "the exam-composition logic," check
`tools/analitzador-plantilla.html` lines ~1595–1912 first; it is almost
certainly asking for something that already exists, possibly under a name
you did not expect.

### 1.5 Grading (step 5) → the answer key is already generated, grading itself is manual by design

The "Full de correcció" printed separately in step 4 already carries, per
question: the block, the exercise id, how the student did on it during
practice, the correct answer, and the worked resolution steps
(`pintaProva()` in `tools/analitzador-plantilla.html`, the `#pr-correccio`
block). What the workflow calls "the teacher corrects it by hand, with the
grading key" is literally this printed sheet — there is nothing left to
automate here; open-response grading against a key is intentionally a human
task, and the tool's job stops at handing over a correct, complete key.

The loop closes itself: after the exam, the student keeps practising, their
next **Codi** press produces a new cumulative snapshot, and the cycle repeats
from step 1.

---

## 2. The one real gap: step 3 as described vs. step 3 as built

The user-facing description says the teacher "must receive a 'partial'
document — extracted from the general document that accumulates ALL
exercises done — containing the practised exercises the student wants to be
examined on." **This is not how the system works, and you should not build
it that way.** What actually happens:

- There is no "general document," only the always-complete verification
  code (§1.1).
- There is no extraction step before the Google Form. The student pastes
  their one complete code as-is. Nothing is filtered on their end.
- The filtering by declared topic happens **after** the Form, on the
  teacher's machine, inside the checkbox list in the **Prova escrita** tab
  (§1.4) — informed by whatever the student told the teacher they want to be
  examined on, which is a conversation that happens outside this tool
  entirely (a message, a form field, a verbal request in class).

If you are asked to "make the student able to submit only the topics they
want examined on," the correct response is **not** a new extraction
mechanism. It is either:

(a) explain that this already happens, one step later than expected, in the
    **Prova escrita** checkboxes, driven by the teacher; or
(b) if the actual ask is "the student's topic choice should reach the teacher
    attached to the Form submission," add a free-text field to the Google
    Form itself (§3.1) — e.g. *"Quins temes vols que et pregunti?"* — which
    the teacher reads before opening the analyser and uses to decide which
    checkboxes to leave ticked. This is a one-field Form change, not a code
    change.

Do not add a code path that lets a student generate or submit a code
containing only some blocks. That would break the "one code, always
complete" invariant that the anti-fraud and trimester-progress systems both
depend on (§1.1, and `CODIS.md` "Sis decisions", point 1).

---

## 3. What you actually need to do to make this run for a real class

Everything in §1 is code already in this repository. The remaining work is
**deployment and one piece of external configuration**, not development.

### 3.1 Create the Google Form (does not exist yet, must be built manually)

In a real Google account (the teacher's), create a Form with exactly these
fields, matching the header row parsed by the analyser
(`exemple-respostes.csv`, `tools/fes-exemple.js`):

1. Email — enable "Collect email addresses" so Google stamps it automatically
   (or add it as a required short-answer field if the account type does not
   offer that toggle).
2. "Selecciona la classe" — short answer or dropdown, whatever groups the
   teacher uses.
3. "Enganxa aquí el codi que has copiat" — **long-answer / paragraph** field.
   Codes for a student with heavy history run past 400 characters; a
   short-answer field may truncate or reject that.

Link the Form to a Google Sheet response destination (Form → Responses → the
green Sheets icon). Do not rename the response columns after creation unless
you also confirm the analyser's column-detection still matches — it detects
by content pattern and header text, not by fixed position, but has not been
tested against arbitrary renames.

Optionally, add a free-text field such as *"Quins temes vols que et
pregunti?"* if you are implementing option (b) from §2. This is additive:
existing parsing of the four core columns is unaffected by extra columns.

### 3.2 Give students the two entry points they need

- The site itself (`index.html` onward) — already deployable as static files,
  no build step required to *use* the site, only to *regenerate content*.
- The **Codi** button is already present on every working page automatically
  once the JS files are in place; nothing to wire up.

### 3.3 Give the teacher `analitzador-repas.html`

It is already built and present at the repo root and it embeds `js/codi.js`
and the compiled item bank in its four `<script>` blocks, so all the exam
logic and every question travel inside the file.

**It is not, however, a single self-sufficient file for printing.** 777 of
the 892 items (87 %) carry LaTeX in their statement, and the file renders it
with KaTeX loaded at run time: first `vendor/katex/` relative to itself, then
the jsDelivr CDN, and if neither answers the LaTeX is left raw. A teacher who
gets only the HTML and works offline will print `$3x-4x^2-6x^3$` on the exam
paper. So hand over **two things, kept together**:

- `analitzador-repas.html`
- the `vendor/katex/` folder, in the same directory

`python3 tools/fes-paquet-professorat.py` builds exactly that as a zip, with
the teacher-facing guide (`GUIA-PROFESSORAT.md`) inside. Then they:

1. Open the class Google Form's response Sheet, `Ctrl+A`/`Ctrl+C`.
2. Open `analitzador-repas.html`, tab **Full de respostes**, paste.
3. Switch to tab **Prova escrita**, pick the student (or paste their code
   directly if working from a single request rather than the whole sheet).
4. Adjust exam size / per-block minimum if needed, review/uncheck blocks
   based on what the student actually asked to be tested on, click
   **Genera la prova**.
5. Print the exam and the answer key separately (two distinct buttons).

### 3.4 If you need to regenerate the compiled files at all

Only needed if you are also editing question content, not for the exam
workflow itself. Confirmed to run clean from this zip as-is:

```sh
cd tools
python3 build_tot.py
```

This rebuilds all 12 `data/fullN.js` + `revisio/REVISIO-fullN.html`, then
`js/codi-taules.js` + `tools/_banc.json`, then re-embeds `analitzador-
repas.html`, in that order — order matters, `build_tot.py` exists precisely
so nobody has to remember it by hand (see its docstring). It is
deterministic: unchanged inputs reproduce byte-identical output.

### 3.5 Verifying your own environment before you rely on any of this

```sh
sh tests/executa.sh
```

Confirmed in this sandbox: 200 checks pass clean (173 Python `unittest` +
27 in `tests/codi.test.js`) using only the stdlib and bare Node — no install
required for that subset. A further 92 checks (analyser DOM behaviour 42,
accessibility 35, UX-flow regression 15) need `jsdom` and will report as
skipped, in yellow, not as passed — the script is explicit about this
distinction on purpose (see its comments); do not read a "skipped in yellow"
run as "all green." Total is therefore **292**, not the 291 (and 284) the
script used to print; those three hard-coded totals were off by one and have
been corrected. If your environment has network access:

```sh
npm install --no-save jsdom
sh tests/executa.sh    # now reports the full 292
```

---

## 4. Things that will misdirect you if you skim instead of read

- **`HANDOVER.md` and `TECHNICAL-STATE.md` are architecture/dev-handover
  documents**, written for someone continuing engineering work on the
  question-generation engine, not for someone standing up this specific
  teacher workflow. `TECHNICAL-STATE.md` §4 (in English) is the most useful
  cross-reference for the verification-code system if you want a second
  source on §1.1–1.5 above.
- **The four `revisio/REVISIO-fullN.html`-style and `data/fullN.js`-style files are
  GENERATED.** Never hand-edit them; edit the corresponding
  `tools/c_<tema>.py` and rebuild (§3.4).
- **The Form column header still says "step-quiz."** That is a leftover
  project name, harmless, not a sign you have the wrong file — it appears
  identically in `tools/fes-exemple.js` and in example CSVs. Fixing it is
  cosmetic and optional, not required for the workflow to function.
- **Three claims in the first version of this document were wrong**, and the
  corrections are folded in above: the analyser does reach the network (for
  KaTeX only, §1.4/§3.3), `exemple-respostes.csv` is generated rather than
  shipped and its generator was broken (§1.3), and the check totals were 200
  executed / 92 skipped / 292 total, not 199 / 92 / 291 (§3.5). Everything
  else in §1–§4 was verified against the code and holds.
- **This document is the piece that was missing.** Nothing in the repository
  previously stated, end to end, "here is how a teacher actually runs the
  request-an-exam cycle with a real Google Form for a real class." §1–§3
  above is that missing piece; §2 is the one correction to keep in mind
  before implementing anything a request seems to imply is missing.
