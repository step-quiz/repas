# Codi de verificació per a repàs-ESO

Sistema complet: l'alumne obté un codi, l'envia per un Google Form, i el
professorat l'enganxa a `analitzador-repas.html`.

Està fet a mida de repàs-ESO, no adaptat de cap altre projecte. Les
diferències respecte del que fa `operacions` es justifiquen totes a baix.

---

## Prova-ho en dos minuts

1. Obre `index.html`: a dalt a la dreta hi ha el botó **Codi**, fix i sempre
   visible a totes les pàgines.
2. Fes uns quants exercicis. El botó porta el compte al costat (`Codi 7`).
3. Clica'l: s'obre una finestra amb el resum, el codi i el botó de copiar.
4. Obre `analitzador-repas.html` (doble clic, no cal servidor), pestanya
   **Full de respostes**, i enganxa el codi. O prem **«Posa-hi un exemple»**,
   que en fabrica sis d'alumnes fictícis —un de manipulat i un enviat tard—
   per veure com es comporta.

---

## Què porta el codi

Una fotografia **completa** del progrés: quins exercicis s'han fet i com han
anat, un per un, amb els identificadors reals (`67e`, `216c`, `144b`).

```
RC4 SSS DDD HH MMM  [per cada full: G + grups de 4]  [DIAG]  EEEEEEEEE  [META]  [DATES]  KK

RC4   marca i versió (RC1, RC2 i RC3 es continuen llegint)
SSS   salt aleatori
DDD   dia (dies des de l'1/9/2025)
HH    hora (minuts/2 des de mitjanit)
MMM   màscara: fulls presents + diagnòstic + META + DATES
G     nombre de grups d'aquest full
····  un grup = 7 exercicis en base 7 (base 6 fins a RC3)
DIAG  les 15 destreses del test inicial (si n'hi ha)
EEEE  les 3 etiquetes d'error més repetides, amb el compte
META  com s'ha fet la feina: minuts actius, importacions, exercicis que en
      venen, repeticions, fulls reiniciats i —si hi ha hagut importació—
      l'empremta (dia + salt) del codi d'origen
DATES el dia del primer intent de cada exercici fet a les últimes 12
      setmanes, en l'ordre en què es van fer (per dia: dies enrere + nombre
      d'exercicis; per exercici: full + posició)
KK    dos caràcters de control
```

**Per què hi ha RC4.** El mini-examen de 3 setmanes necessita saber si
l'alumne va obrir una pista o dues, que no penalitzen igual, i quan va fer cada
exercici: l'examen d'un tram només pot sortir de la feina d'aquelles tres
setmanes, i només compten els 20 últims. Fins a RC3 la data es deduïa
comparant enviaments, i un codi enviat tard posava la feina al tram equivocat.
Des que l'alumnat esborra els codis a cada tram, un codi sense dates ja no
compta per a cap.
Set estats caben en quatre caràcters igual que sis (7^7 < 32^4), així que el
sostre de 217 exercicis per full no es mou. El bloc DATES costa uns 3
caràcters per exercici datat; 20 exercicis d'un tram en fan menys de 90.

**Per què hi ha META.** Fins a RC2 el codi deia *què* s'havia fet i no deia res
de *com*. Dues coses molt diferents hi arribaven idèntiques: un trimestre de
feina propi i el codi d'un company importat i continuat des d'allà. L'empremta
del codi d'origen ho desfà: l'analitzador la creua amb els codis que ja té i,
si l'origen era un codi del mateix alumne, calla. Vegeu `DESPLEGAMENT.md`.

Estat de cada exercici: `0` per fer · `1` a la primera · `2` al segon intent ·
`3` amb una pista · `4` fallat · `5` començat sense respondre · `6` amb dues
pistes o més. El registre del navegador segueix desant `pista` en tots dos
casos; el `6` surt del comptador de pistes obertes en fer el codi. Un `pista`
d'un codi RC3 es llegeix com a una sola pista. Un encert al segon intent és
sempre `2`, encara que s'hagin obert pistes.

**Llargada real.** Un full de 71 exercicis fet a mitges: **46 caràcters**.
Els 951 exercicis dels dotze fulls més el diagnòstic: 611. Els grups finals
buits no s'escriuen, de manera que la llargada creix amb la feina feta i no
amb la mida del full.

Aquestes xifres es queden enrere cada vegada que creix el banc, i s'hi han
quedat un parell de vegades. El que no caduca és el RITME: set estats caben
en quatre caràcters base32, o sigui **0,57 caràcters per exercici**, més un
comptador per full. `tests/codi.test.js` comprova el ritme i deriva el sostre
del banc, en lloc de fixar un número que demà no valdrà.

---

## Quan i on s'ofereix

**Un sol botó, flotant, fix a dalt a la dreta, a totes les pàgines** on
l'alumne pot estar treballant: portada, full, exercici, itinerari i resultat
del test inicial. No depèn de l'itinerari ni de cap moment de tancament: està
sempre a mà.

**Un sol codi.** El botó dona sempre la fotografia sencera —tots els fulls més
el test inicial—, no el d'un full concret. Així l'alumne no ha de decidir res.

**El volum es veu de seguida.** El botó porta el compte d'exercicis al costat
(`Codi 23`), i la finestra diu quants n'hi ha i quants se'n demanen per a cada
examen. Per sota de deu, en to d'avís:

> Hi portes **3** exercicis des de l'últim esborrat. Se'n demanen entre 10 i
> 20 per a cada examen, i com més en facis, més nota.

Per sobre de vint diu que per a la nota i l'examen només compten els 20
últims. Els dos números surten de `js/calendari.js` (`FEINA_MINIMA` i
`FEINA_MAXIMA`), que també llegeix l'analitzador.

## Sis decisions, i per què

### 0. El volum ha de ser tan visible com la nota

Fins a l'octubre de 2026 la nota de cada codi era un percentatge (la mitjana
dels valors de tot el que portava), i no sabia res del volum: qui feia **un**
exercici i l'encertava treia un **10**, i qui en feia quaranta, un 6,6. Ara la
nota és la del tram (vegeu §2), i la fórmula ja premia el volum: un exercici a
la primera fa un 3,7, deu fan un 8 i vint, un 10.

Tot i així, a l'analitzador el volum no es pot passar per alt:

- Camp **«feina mínima demanada»** (per defecte 10, de `js/calendari.js`).
  Qui no hi arriba en el tram triat surt amb el número en vermell i una barra
  de progrés.
- **La seva nota es pinta apagada i amb asterisc**, perquè no convidi a
  comparar-la.
- Filtre **«feina insuficient al tram»** per aïllar-los, i un resum a sobre de
  la taula: *«1 de 3 no arriben als 10 exercicis en aquest tram: poc (3)»*.
- El CSV de resum porta les columnes `fets_al_tram`, `compten`, `minim` i
  `arriba`.

Posant el mínim a 0, tot això desapareix.

### 1. El codi és acumulatiu, no un tiquet de sessió

`operacions` són activitats d'una estona amb principi i final. Repàs-ESO és
treball propi durant setmanes, sense sessions. Un codi per estona obligaria
l'alumne a no perdre'n cap i el professorat a sumar-los.

Aquí **cada codi conté tot el que s'ha fet fins llavors i substitueix
l'anterior**. Si l'alumne se n'oblida un, el següent ja ho porta tot;
l'analitzador es queda l'últim de cada alumne i prou.

### 2. La nota no viatja dins del codi

Aquest és el forat clàssic d'aquesta mena de sistemes, i el vostre propi
`PROJECTS-TECHNICAL-REFERENCE.md` el té fitxat com a `P01`: si el codi porta
una nota *i* un detall pregunta a pregunta, i el control només cobreix la
nota, es pot retocar el detall sense trencar res.

Aquí **la nota la calcula l'analitzador a partir del detall**. No hi ha dos
nombres que puguin contradir-se, perquè dins del codi no n'hi ha cap. El forat
no es tapa: no existeix.

I n'hi ha **una de sola**: la **nota de feina d'un tram** (`RE_CODI.notaTram`).
Agafa els exercicis fets per primer cop entre les dues dates que tria el
professor, en queda els 20 últims per ordre de fet, suma els seus valors sobre
10 (x) i dona `min(10, 8·∛(x/10))`: 10 exercicis a la primera fan un 8 i 20,
un 10. Els valors són públics i estan a `js/codi.js` (`PES`): `net` 10, una
pista 9,5, dues pistes o més 8,5, `segon` 7,5, `fallat` 0. `RE_CODI.llegeix()`
ja no dona cap nota (`resum` només porta el recompte), i a l'analitzador
`notaTram` només es crida des d'un lloc, `calculaTram`.

### 3. Dos caràcters de control, amb mòdul primer i pesos

La lletra del DNI és una suma mod 23 pensada per a **8 xifres**. Amb càrregues
de centenars de caràcters falla per dos costats:

- **Sense pesos, una transposició no es detecta mai.** Si en copiar
  s'intercanvien dos caràcters, la suma no es mou. Amb codis llargs això passa.
- **El mòdul ha de ser més gran que l'alfabet.** Amb 32 caràcters i mòdul 31,
  el `0` i la `Z` són congruents i confondre'ls no trencaria res. (Ho vaig
  trobar provant la primera versió: 10 de 837 mutacions d'un caràcter
  passaven, i totes eren `0`↔`Z`.)

La versió final: `K = Σ (i+1)·valor(car_i) mod 1021`, barrejat amb una
transformació afí abans d'escriure'l, en l'esperit de l'alfabet desordenat del
DNI. Mesurat sobre un codi de 208 caràcters:

| Manipulació | Passen el control |
|---|---|
| Substitució d'un caràcter (6.386 casos) | **0** |
| Transposició de dos caràcters (20.304 casos) | **0** |
| Mutació de 2 a 5 caràcters a l'atzar | 0,37 % |

Les dues primeres files són garantia matemàtica, no estadística: 1021 és
primer i més gran que qualsevol valor de caràcter i que la llargada del codi.

### 4. Alfabet sense `I`, `L`, `O` ni `U`

Perquè un codi es pugui llegir a mà, dictar per telèfon o teclejar sense
patir. A més, la lectura normalitza el que enganxa la gent: minúscules,
guions, espais, i les confusions típiques (`O`→`0`, `I`/`L`→`1`). Provat: un
codi passat per minúscules i amb totes les `0` canviades per `O` i les `1` per
`l` es llegeix igualment.

### 5. La posició del codi és un exercici concret

`operacions` genera les preguntes a l'atzar, així que la posició *i* només vol
dir «la i-èsima». A repàs-ESO els exercicis tenen identificadors estables i un
ordre fix, i l'analitzador porta la taula. Per això el professorat no llegeix
«ha fallat la 7a» sinó **«ha fallat el 67e, el 68c i el 69a, tots del bloc de
divisió de polinomis»**.

Això és el que fa que valgui la pena mirar-s'ho.

---

## Progrés del trimestre

> **Ja no dona cap nota.** Fins a l'octubre de 2026 aquesta pestanya en treia
> una «qualificació del trimestre» amb pesos (constància, volum, progrés,
> encert). Ara només en mostra l'**activitat**, i la nota és només la del tram
> (vegeu §2). El que segueix descriu les mètriques, que no han canviat.

Aquesta part es recolza tota en una propietat del format: **com que els codis són acumulatius, la
resta entre dos codis seguits d'un mateix alumne és exactament la feina feta
entremig**, amb el detall de com li ha anat. Sense això només es podria
mesurar l'estat final; amb això es mesura el camí.

L'alumne no dona mai cap dada al lloc; la identitat la posa el Google Form, i
el correu institucional és la primera columna del full.

### Què es mesura

| Component | Com |
|---|---|
| **Constància** | Setmanes amb feina **nova**, sobre les esperades |
| **Volum** | Exercicis fets durant el període, ponderats per dificultat |
| **Millora** | Variació d'encert i de dependència de pistes entre la primera i la segona meitat de la feina |
| **Encert** | Percentatge global d'exercicis resolts |

Quatre decisions que no són òbvies:

1. **Un enviament només compta com a dia de feina si porta exercicis nous.**
   Reenviar el mateix codi vint vegades no és constància, i queda marcat com a
   `1 (+6)` a la columna de dies.
2. **Les dues meitats es parteixen per volum acumulat, no pel calendari.** Si
   un alumne fa 40 exercicis el primer dia i 4 l'últim, partir pel mig del
   trimestre compararia 40 amb 4 i el soroll es menjaria el senyal.
3. **L'encert de la variació s'estandarditza per dificultat.** Es calcula per
   nivell i es recombina amb la barreja global. Sense això, qui passa dels
   exercicis directes als problemes semblaria que empitjora quan només s'ha
   posat amb coses més dures. Provat: un alumne que va de nivell 1 a nivell 3
   amb el mateix encert real surt amb variació 0, i el detall li diu que la
   segona meitat era més difícil.
4. **La feina anterior al trimestre no compta.** La línia de base és l'últim
   codi anterior al període.

Si no hi ha prou dades (menys de 20 exercicis o menys de 2 enviaments amb
feina), la millora surt com a *no mesurable* i el seu pes es reparteix entre
els altres components.

### Les setmanes i els exercicis esperats

Les setmanes esperades i els exercicis esperats es toquen des de la mateixa
pàgina. Els trimestres tenen presets (set–des, gen–març, abril–juny) que
dedueixen l'any de les dades. El CSV que es baixa és el de l'activitat
(`repas-eso-activitat.csv`), sense cap nota.

### Com discriminava la qualificació antiga

Es conserva com a referència de com es comporten les mètriques. Quatre
perfils sintètics sobre un trimestre de 10 setmanes, amb objectiu de 60
exercicis, amb la qualificació que es feia servir fins a l'octubre de 2026:

| Perfil | Dies | Setm. | Exerc. | Encert | Millora | Nota |
|---|---|---|---|---|---|---|
| Regular, 6 exercicis cada setmana, millorant | 10 | 10 | 60 | 92 % | +17 pp · +17 pp | **9,9** |
| 60 exercicis en 3 dies d'una setmana | 3 | 1 | 60 | 100 % | 0 pp | **5,8** |
| Irregular, 3 sessions, sense millora | 3 | 3 | 27 | 67 % | −3 pp | **4,4** |
| 8 exercicis i 6 reenviaments del mateix codi | 1 (+6) | 1 | 8 | 100 % | no mesurable | **2,3** |

El segon perfil és el cas que et preocupava: fa tota la feina i té el 100 %
d'encert, però la fa de cop, i es queda per la meitat de la nota del primer.
A més, el resum de classe el llista a part: *«Feina concentrada en pocs dies
(molt volum, poca constància): bru (1 setmana). Han fet la feina, però de
cop.»*

## L'analitzador

`analitzador-repas.html` és **un sol fitxer**: es desa, s'obre amb doble clic i
funciona sense servidor ni connexió. No envia res enlloc.

Té cinc pestanyes: **Full de respostes**, **Progrés del trimestre**, **Un
sol codi**, **Prova escrita** i **Com funciona**.

**Full de respostes.** Enganxa-hi el Google Sheet (Ctrl+A, Ctrl+C) o obre'n el
CSV. El correu es llegeix de la primera columna, que és on el posa el Google
Form; si no n'hi ha, es busca per capçalera o per la forma. La columna del
codi es detecta sola. Dona:

- **Per alumne** — **l'única nota** de l'analitzador: la nota de feina del
  tram que triïs amb dues dates (els 20 últims exercicis fets entre aquells
  dos dies), amb la feina al tram, els punts de colors dels que compten, els
  exercicis per full i els avisos. **Baixa les notes (XLSX)** dona correu i
  nota de tota la classe; **Baixa el resum (CSV)**, el detall amb els filtres
  aplicats.
- **Enviaments** — una fila per codi, amb la marca d'estat, el temps entre
  generar-lo i enviar-lo, i els punts de colors. Clica-hi i s'obre el detall
  complet: comptes, repartiment per nivell de dificultat, bloc a bloc amb els
  identificadors dels exercicis fallats i dels que han necessitat pista, les
  etiquetes d'error més repetides i el test inicial si el codi el porta.
- **Què falla més** — l'agregat de classe: en quins blocs s'encalla més gent,
  quins exercicis costen més i quins errors es repeteixen. És la vista que
  respon «què he de tornar a explicar dilluns».

**Un sol codi.** Per comprovar-ne un a mà. No toca el full de respostes
carregat (fins a l'octubre de 2026 el substituïa).

**Prova escrita.** El mini-examen estàndard de tota la classe i l'examen
personalitzat d'un alumne; tots dos de 2 preguntes per defecte. Vegeu
`GUIA-PROFESSORAT.md`.

**Marques d'estat:**

| | Vol dir |
|---|---|
| ✓ | Íntegre, i enviat poc després de generar-lo |
| ! | Íntegre, però han passat més de 30 minuts fins a enviar-lo |
| ✗ | El control no quadra: mal copiat o modificat |

L'avís de temps sol ser innocent (l'alumne el va desar i el va enviar més
tard), però és on es veuria un codi passat d'un company.

---

## Com està muntat

```
js/codi.js                    generació I lectura, al mateix fitxer
js/codi-ui.js                 el panell que veu l'alumne
js/codi-taules.js             GENERAT — ordre d'ítems, blocs, dificultats
analitzador-repas.html        GENERAT — eina del professorat, autònoma

tools/build_codi.py           munta les taules des de data/
tools/build_analitzador.py    incrusta taules + js/codi.js a la plantilla
tools/analitzador-plantilla.html
tools/codi-etiquetes.txt      ordre APPEND-ONLY de les etiquetes d'error
tools/build_tot.py            ho encadena tot en l'ordre correcte
```

Dues coses que val la pena saber si un dia s'hi torna:

- **`js/codi.js` porta el generador i el lector al mateix fitxer**, i
  l'analitzador **carrega aquest mateix fitxer** (no una còpia). Si viuen
  separats, tard o d'hora divergeixen, i el símptoma és el pitjor possible:
  codis que es llegeixen malament sense que res avisi.
- **`tools/codi-etiquetes.txt` és append-only.** El codi guarda l'*índex* de
  l'etiqueta d'error, no el nom. Reordenar el fitxer fa il·legibles tots els
  codis ja emesos. `build_codi.py` ho vigila i avisa.

Per recompilar-ho tot en l'ordre bo:

```
cd tools && python3 build_tot.py
```

---

## Una cosa que he decidit i pots voler canviar

**El panell de l'alumne no ensenya la nota.** Diu quants exercicis porta i
quants se'n demanen, i prou. La nota no va dins del codi: la calcula
l'analitzador i la veu el professorat.

El motiu: repàs-ESO és pràctica formativa. Si l'alumne veu una nota cada
vegada que genera un codi, deixarà d'obrir pistes i evitarà els exercicis de
nivell 3 — exactament el contrari del que buscava la graduació per dificultat.
Ensenyar volum i cobertura empeny cap a fer més feina; ensenyar nota empeny
cap a protegir el número.

Si prefereixes que la vegi, és una línia a `js/codi-ui.js`.

---

## Verificació feta

> Recompte del moment en què es va fer el sistema. Les proves d'avui són a
> `tests/` i es passen totes amb `sh tests/executa.sh` (vegeu
> `tests/LLEGEIX-ME.md`).

- 19 comprovacions de l'anàlisi de trimestre amb quatre perfils sintètics
  d'alumne, l'estandardització per dificultat i tots els controls.
- 25 comprovacions de l'analitzador amb un DOM real (jsdom): lectura del TSV,
  detecció d'un codi manipulat entre quatre, avís de temps, taula per alumne,
  detall amb identificadors, agregat de classe, filtres, lectura d'un codi
  solt, botó d'exemple i tot el bloc de feina mínima.
- 22 comprovacions del botó flotant: que hi és a les cinc pàgines amb tots els
  scripts, que es posa sol, que és fix, que compta, que avisa amb poca feina i
  que deixa d'avisar amb prou, i que no ensenya cap nota.
- 13 comprovacions de la integració a l'app: recollida des de `localStorage`,
  anada i tornada del codi amb estats i etiquetes idèntics.
- Anada i tornada exacta amb tot el banc, els 12 fulls i el diagnòstic.
- Les proves de manipulació de la taula de més amunt.
- Compilació determinista: dues passades seguides donen fitxers idèntics.
