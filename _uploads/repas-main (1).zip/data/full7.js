/* Generat per tools/build.py — no editeu aquest fitxer a mà. */
window.FULL = {
 "full": 7,
 "titol": "Full 7 — Teorema de Pitàgores. Àrees",
 "subtitol": "Triangles i teorema de Pitàgores, àrees de triangles, quadrilàters i polígons regulars, i problemes d'aplicació.",
 "blocs": [
  {
   "id": "triangles",
   "titol": "Triangles i teorema de Pitàgores",
   "descripcio": "Angles, desigualtat triangular, triangles rectangles i teorema de Pitàgores en quadrats, rectangles i polígons.",
   "items": [
    "119",
    "120a",
    "120b",
    "120c",
    "123a",
    "123b",
    "123c",
    "123d",
    "121a",
    "121b",
    "121c",
    "121d",
    "122",
    "124a",
    "124b",
    "124c",
    "125",
    "126a",
    "126b",
    "127a",
    "127b",
    "127c",
    "128a",
    "128b",
    "129"
   ]
  },
  {
   "id": "arees_pit",
   "titol": "Àrees amb el teorema de Pitàgores",
   "descripcio": "Àrees de triangles i rectangles combinades amb Pitàgores per trobar un costat, una alçada o una hipotenusa.",
   "items": [
    "332a",
    "332b",
    "332c",
    "131",
    "132",
    "134",
    "135",
    "136",
    "137",
    "138",
    "130",
    "133"
   ]
  },
  {
   "id": "arees_poli",
   "titol": "Àrees de quadrilàters i polígons regulars",
   "descripcio": "Trapezis, hexàgons, octàgons i figures amb superfícies circulars.",
   "items": [
    "333a",
    "333b",
    "333c",
    "333d",
    "140a",
    "140b",
    "140c",
    "140d",
    "141a",
    "141b",
    "142",
    "143a",
    "143b",
    "143c",
    "143d",
    "144a",
    "144b",
    "145c"
   ]
  },
  {
   "id": "problemes",
   "titol": "Problemes d'aplicació",
   "descripcio": "Ombres, escales, camps, senyals, edificis i altres problemes que combinen Pitàgores i àrees.",
   "items": [
    "146",
    "147",
    "148a",
    "148b",
    "149",
    "150",
    "151"
   ],
   "avancat": true
  }
 ],
 "errors": {
  "ARREL_FACTOR_OBLIDAT": "Has arribat al valor de dins de l'arrel però t'has deixat el factor que l'acompanya (sovint un $\\sqrt3$ o un $2$). Escriu la fórmula sencera abans de substituir-hi els números.",
  "ARREL_OBLIDADA": "T'has quedat amb el quadrat (o el cub) de la incògnita. De $x^2=k$ encara falta l'arrel per arribar a $x$: comprova sempre quina de les dues quantitats et demanen.",
  "CATET_MAL_IDENTIFICAT": "El costat que busques no és el que has triat. Fes un dibuix ràpid i marca quin costat coneixes i quin has d'aïllar abans de calcular.",
  "COSTATS_MAL_TRIATS": "El criteri és el bo, però l'has aplicat als costats que no toquen: torna a mirar quins dos costats has de comparar amb quin.",
  "DIMENSIO_EXPONENT_MAL": "L'exponent no correspon a la dimensió: les àrees van al quadrat i els volums, al cub. Comprova també les unitats del resultat.",
  "DIVISIO_REPETIDA": "Has dividit dues vegades pel mateix nombre. Sol passar quan la fórmula ja porta la divisió incorporada i se li torna a aplicar al final: escriu la fórmula sencera i substitueix-hi els valors d'un sol cop.",
  "ES_POT_DETERMINAR": "Has dit que no es pot saber, però amb les dades de l'enunciat n'hi ha prou. Abans de descartar una pregunta, mira si algun teorema o criteri et permet respondre-la amb el que ja tens.",
  "FACTOR_OBLIDAT": "T'has deixat pel camí un dels factors en combinar els exponents.",
  "FORMULA_INVERTIDA": "Has dividit on la fórmula multiplica (o al revés). Escriu la fórmula sencera abans de substituir-hi els valors.",
  "FRACCIO_DE_CERCLE_MAL": "La porció de cercle no és la que toca: mig cercle, un quart, tres quarts... Mira quin angle abasta la figura i quina fracció de $360^\\circ$ representa.",
  "HIPOTENUSA_MAL_IDENTIFICADA": "La hipotenusa és sempre el costat MÉS LLARG del triangle rectangle, i és la que va sola a un costat de la igualtat.",
  "HIPOTENUSA_PER_AREA": "Has calculat la hipotenusa, i el que es demanava era l'àrea. Torna a llegir la pregunta abans de començar: quan un triangle rectangle té els dos catets donats, ja els tens fets de base i altura i no cal cap Pitàgores.",
  "INVERTIDA": "Has invertit la fracció. Simplificar no canvia quin terme és a dalt i quin a baix.",
  "MEITAT_OBLIDADA": "Hi ha un factor $2$ pel mig que t'has deixat: radi i diàmetre, semibase i base, semidiagonal i diagonal. Comprova quina de les dues et demanen.",
  "PARITAT_EXPONENT": "Revisa la paritat de l'exponent: amb exponent parell, una base negativa dóna resultat positiu; amb exponent senar, el resultat es queda negatiu.",
  "PART_PEL_TOT": "Has donat el tot on et demanaven una part, o al revés. Compta quantes peces iguals hi ha a la figura i mira quantes n'entren a la resposta.",
  "PAS_INTERMEDI_PER_RESPOSTA": "El valor que has triat és correcte, però és un pas intermedi, no el que et demanen. Torna a llegir la pregunta i mira quina magnitud has d'acabar donant: sovint només falta una operació més.",
  "PERIMETRE_PER_AREA": "Has sumat els costats: això és el perímetre, no l'àrea. El perímetre és el que fa la vora i es mesura en cm o m; l'àrea és la superfície de dins i es mesura en cm² o m².",
  "POTENCIA_DE_SUMA": "Aquí els dos nombres es MULTIPLIQUEN dins del parèntesi, no se sumen: la potència és d'un producte, $(a\\cdot b)^n$, no d'una suma, $(a+b)^n$.",
  "PROGRESSIO_INVENTADA": "El terme s'ha de calcular seguint estrictament la regla que defineix la successió (el terme general o la relació de recurrència), no un patró aproximat o inventat.",
  "SIMPLIFICACIO_INCOMPLETA": "Encara es pot simplificar més: busca el m.c.d. del numerador i el denominador i divideix-los pel m.c.d. d'un sol cop.",
  "SUMA_CATETS_SENSE_QUADRAT": "Has sumat els costats directament. Pitàgores diu que es sumen els seus QUADRATS, i al final es fa l'arrel del resultat.",
  "SUMA_EN_LLOC_RESTA": "Sumar un nombre negatiu és restar-lo.",
  "TERME_OBLIDAT_OPERACIO": "T'has deixat algun terme pel camí en combinar els polinomis: revisa'ls tots un per un, grau a grau.",
  "VEREDICTE_INVERTIT": "El veredicte (cert/fals, o sí/no) que has triat és l'oposat del correcte: torna a comprovar la condició amb els valors concrets de l'enunciat."
 },
 "items": [
  {
   "id": "119",
   "ex": 119,
   "ap": "",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "",
   "enunciat": "Un triangle isòsceles té l'angle desigual de $50^\\circ$. Quant mesuren els angles iguals?",
   "opcions": [
    "$65^\\circ$ cadascun",
    "$115^\\circ$ cadascun",
    "$130^\\circ$ cadascun",
    "$25^\\circ$ cadascun"
   ],
   "pistes": [
    "La suma dels tres angles d'un triangle sempre val $180^\\circ$.",
    "Resta l'angle desigual dels $180^\\circ$ i reparteix el que quedi entre els dos angles iguals."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IHZhbG9yIG5vIHN1cnQgZGUgJDE4MF5cXGNpcmMtNTBeXFxjaXJjJCByZXBhcnRpdCBlbnRyZSBkb3M6IHJldmlzYSBsYSByZXN0YSBhYmFucyBkZSBkaXZpZGlyLWxhIHBlciAkMiQuIiwgIkFxdWVzdCDDqXMgZWwgcXVlIHN1bWVuIGVudHJlIHRvdHMgZG9zICgkMTgwXlxcY2lyYy01MF5cXGNpcmMkKSwgbm8gZWwgcXVlIHZhbCBjYWRhc2N1bjogZW5jYXJhIGNhbCByZXBhcnRpci1obyBlbnRyZSBlbHMgZG9zIGFuZ2xlcyBpZ3VhbHMuIiwgIlNlbWJsYSBxdWUgaGFzIHJlcGFydGl0IGVscyAkNTBeXFxjaXJjJCBkZSBsJ2FuZ2xlIGRlc2lndWFsIGVudHJlIGRvcywgZW4gbGxvYyBkZSByZXBhcnRpciBlbCBxdWUgcXVlZGEgZGVscyAkMTgwXlxcY2lyYyQgdG90YWxzIHVuIGNvcCB0cmV0IGwnYW5nbGUgZGVzaWd1YWwuIl0sICJlcnIiOiBbIiIsICJTVU1BX0FOR0xFU19NQUwiLCAiUkVQQVJUSU1FTlRfQU5HTEVTX01BTCIsICJTVU1BX0FOR0xFU19NQUwiXSwgInJlcyI6IFsiJDE4MF5cXGNpcmMtNTBeXFxjaXJjPTEzMF5cXGNpcmMkIGVudHJlIGVscyBkb3MgYW5nbGVzIGlndWFscyIsICIkXFxkZnJhY3sxMzBeXFxjaXJjfXsyfT02NV5cXGNpcmMkIGNhZGFzY3VuIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 222 234\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle isòsceles amb l'angle de dalt (entre els costats iguals) de 50° marcat.</title><polygon points=\"26,208.283 196,208.283 111,26\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M101.702,45.9388 A22,22 0 0,0 120.298,45.9388\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"111\" y=\"64\" text-anchor=\"middle\" class=\"fig-etq petita\">50°</text></svg>"
  },
  {
   "id": "120a",
   "ex": 120,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Analitza, en cada cas, les mesures i esbrina amb quines es pot formar un triangle.",
   "enunciat": "$a=8$ cm, $b=7$ cm, $c=1$ cm",
   "opcions": [
    "Sí, perquè cap costat és més llarg que la suma dels altres dos",
    "Sí que es pot formar un triangle",
    "No es pot saber sense conèixer els angles",
    "No es pot formar cap triangle"
   ],
   "pistes": [
    "La condició per formar un triangle és que la suma dels dos costats més curts sigui ESTRICTAMENT més gran que el costat més llarg.",
    "Compara $7+1$ amb $8$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyIkOCQgU8ONIHF1ZSDDqXMgaWd1YWwgKG5vIG1lbm9yKSBhIGxhIHN1bWEgZGVscyBhbHRyZXMgZG9zLCAkNysxPTgkOiBsYSBjb25kaWNpw7MgaGEgZGUgY29tcGxpci1zZSBlbiBlc3RyaWN0ZSwgaSBhcXXDrSBqdXN0IGZhbGxhIHBlciBpZ3VhbHRhdC4iLCAiRWxzIGRvcyBjb3N0YXRzIG3DqXMgY3VydHMgc3VtZW4gZXhhY3RhbWVudCAkNysxPTgkLCBlbCBtYXRlaXggcXVlIGVsIGNvc3RhdCBtw6lzIGxsYXJnOiBsYSBkZXNpZ3VhbHRhdCB0cmlhbmd1bGFyIGV4aWdlaXggcXVlIGxhIHN1bWEgc2lndWkgRVNUUklDVEFNRU5UIG3DqXMgZ3Jhbiwgbm8gaWd1YWwuIEFtYiAkNysxPTgkIGVsIFwidHJpYW5nbGVcIiBxdWVkYXJpYSBjb21wbGV0YW1lbnQgcGxhLiIsICJMYSBkZXNpZ3VhbHRhdCB0cmlhbmd1bGFyIGVzIGNvbXByb3ZhIG5vbcOpcyBhbWIgbGVzIHRyZXMgbG9uZ2l0dWRzLCBzZW5zZSBuZWNlc3NpdGF0IGRlIGNhcCBhbmdsZTogbGEgc3VtYSBkZWxzIGRvcyBjb3N0YXRzIG3DqXMgY3VydHMgaGEgZGUgc3VwZXJhciBlbCBtw6lzIGxsYXJnLiIsICIiXSwgImVyciI6IFsiREVTSUdVQUxUQVRfTk9fRVNUUklDVEEiLCAiREVTSUdVQUxUQVRfTk9fRVNUUklDVEEiLCAiRVNfUE9UX0RFVEVSTUlOQVIiLCAiIl0sICJyZXMiOiBbIkNvc3RhdHMgbcOpcyBjdXJ0czogJDckIGkgJDEkLiAkNysxPTgkLCBxdWUgTk8gw6lzIGVzdHJpY3RhbWVudCBtw6lzIGdyYW4gcXVlICQ4JCAoaGkgw6lzIGlndWFsKTogbm8gZXMgZm9ybWEgY2FwIHRyaWFuZ2xlIl19"
  },
  {
   "id": "120b",
   "ex": 120,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Analitza, en cada cas, les mesures i esbrina amb quines es pot formar un triangle.",
   "enunciat": "$a=6$ cm, $b=6$ cm, $c=13$ cm",
   "opcions": [
    "No es pot formar cap triangle",
    "No es pot saber sense conèixer els angles",
    "Sí que es pot formar un triangle",
    "Sí, perquè dos costats són iguals (és isòsceles)"
   ],
   "pistes": [
    "Compara la suma dels dos costats més curts amb el més llarg.",
    "$6+6$ i $13$: quin és més gran?"
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiTGEgZGVzaWd1YWx0YXQgdHJpYW5ndWxhciBlcyBjb21wcm92YSBub23DqXMgYW1iIGxlcyB0cmVzIGxvbmdpdHVkcyBkb25hZGVzLCBzZW5zZSBjYXAgYW5nbGUuIiwgIkVscyBkb3MgY29zdGF0cyBpZ3VhbHMgc3VtZW4gJDYrNj0xMiQsIHF1ZSDDqXMgTcOJUyBQRVRJVCBxdWUgZWwgdGVyY2VyIGNvc3RhdCAoJDEzJCk6IGxhIGRlc2lndWFsdGF0IHRyaWFuZ3VsYXIgZmFsbGEgY2xhcmFtZW50LCBubyBwZXIgdW4gbWFyZ2UganVzdC4iLCAiUXVlIGRvcyBjb3N0YXRzIHNpZ3VpbiBpZ3VhbHMgbm8gZ2FyYW50ZWl4IHF1ZSBlcyBwdWd1aSBmb3JtYXIgdW4gdHJpYW5nbGU6IGNhbCBjb21wcm92YXIgbGEgZGVzaWd1YWx0YXQgdHJpYW5ndWxhciBpZ3VhbG1lbnQsIGkgYXF1w60gbm8gZXMgY29tcGxlaXguIl0sICJlcnIiOiBbIiIsICJFU19QT1RfREVURVJNSU5BUiIsICJERVNJR1VBTFRBVF9OT19FU1RSSUNUQSIsICJQUk9HUkVTU0lPX0lOVkVOVEFEQSJdLCAicmVzIjogWyJDb3N0YXRzIGlndWFsczogJDYkIGkgJDYkLiAkNis2PTEyPDEzJDogbm8gZXMgcG90IGZvcm1hciBjYXAgdHJpYW5nbGUiXX0="
  },
  {
   "id": "120c",
   "ex": 120,
   "ap": "c",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Analitza, en cada cas, les mesures i esbrina amb quines es pot formar un triangle.",
   "enunciat": "$a=12$ cm, $b=14$ cm, $c=6$ cm",
   "opcions": [
    "No es pot saber sense conèixer els angles",
    "Només es pot saber comparant $12$ amb $14$, no cal mirar el $6$",
    "No es pot formar cap triangle",
    "Sí que es pot formar un triangle"
   ],
   "pistes": [
    "Només cal comprovar-ho amb els dos costats més curts: $12$ i $6$.",
    "Compara $12+6$ amb $14$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJMYSBkZXNpZ3VhbHRhdCB0cmlhbmd1bGFyIGVzIGNvbXByb3ZhIG5vbcOpcyBhbWIgbGVzIHRyZXMgbG9uZ2l0dWRzIGRvbmFkZXMsIHNlbnNlIGNhcCBhbmdsZS4iLCAiQ2FsIGNvbXByb3ZhciBsYSBkZXNpZ3VhbHRhdCBhbWIgZWxzIERPUyBjb3N0YXRzIG3DqXMgY3VydHMgc3VtYXRzICgkMTIrNiQpIGNvbnRyYSBlbCBtw6lzIGxsYXJnICgkMTQkKSwgbm8gY29tcGFyYXIgZG9zIGNvc3RhdHMgcXVhbHNzZXZvbCBlbnRyZSBzaS4iLCAiQ29tcHJvdmEtaG86IGVscyBjb3N0YXRzIG3DqXMgY3VydHMgc3VtZW4gJDEyKzY9MTgkLCBxdWUgU8ONIMOpcyBtw6lzIGdyYW4gcXVlICQxNCQuIExhIGRlc2lndWFsdGF0IHRyaWFuZ3VsYXIgZXMgY29tcGxlaXggZW4gYXF1ZXN0IGNhcy4iLCAiIl0sICJlcnIiOiBbIkVTX1BPVF9ERVRFUk1JTkFSIiwgIkNPU1RBVFNfTUFMX1RSSUFUUyIsICJWRVJFRElDVEVfSU5WRVJUSVQiLCAiIl0sICJyZXMiOiBbIkNvc3RhdHMgbcOpcyBjdXJ0czogJDEyJCBpICQ2JC4gJDEyKzY9MTg+MTQkOiBlcyBjb21wbGVpeCBsYSBkZXNpZ3VhbHRhdCB0cmlhbmd1bGFyLCBlcyBwb3QgZm9ybWFyIHVuIHRyaWFuZ2xlIl19"
  },
  {
   "id": "123a",
   "ex": 123,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud de $x$ en aquestes figures.",
   "enunciat": "Quadrat de costat 4 cm, $x$ és la diagonal.",
   "opcions": [
    "$8$",
    "$4\\sqrt{2}\\approx5{,}66$",
    "$32$",
    "$16$"
   ],
   "pistes": [
    "La diagonal d'un quadrat és la hipotenusa del triangle rectangle format per dos costats consecutius.",
    "Aplica Pitàgores: $x=\\sqrt{4^2+4^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgc3VtYXQgZWxzIGRvcyBjb3N0YXRzIGRpcmVjdGFtZW50ICgkNCs0JCkgZW4gbGxvYyBkJ2FwbGljYXIgUGl0w6Bnb3JlczogY2FsIGVsZXZhci1sb3MgYWwgcXVhZHJhdCwgc3VtYXItbG9zLCBpIGZlciBsJ2FycmVsIHF1YWRyYWRhIGRlbCByZXN1bHRhdC4iLCAiIiwgIkhhcyBjYWxjdWxhdCAkNF4yKzReMj0zMiQgY29ycmVjdGFtZW50LCBwZXLDsiB0J2hhcyBkZWl4YXQgbCdhcnJlbCBxdWFkcmFkYSBmaW5hbDogbGEgZGlhZ29uYWwgw6lzICRcXHNxcnR7MzJ9JCwgbm8gJDMyJC4iLCAiQXF1ZXN0IMOpcyBlbCBwcm9kdWN0ZSBkZWxzIGRvcyBjb3N0YXRzICgkNFxcY2RvdDQkKSwgbm8gbGEgZGlhZ29uYWw6IGNhbCBhcGxpY2FyIFBpdMOgZ29yZXMsICR4PVxcc3FydHs0XjIrNF4yfSQuIl0sICJlcnIiOiBbIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiIiwgIkFSUkVMX09CTElEQURBIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiXSwgInJlcyI6IFsiJHg9XFxzcXJ0ezReMis0XjJ9PVxcc3FydHszMn09NFxcc3FydHsyfVxcYXBwcm94NXssfTY2JCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 148 181\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de costat 4 cm amb la diagonal marcada.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,0.0 120.0,0.0 120.0,120.0 0.0,120.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"120.0\" x2=\"120.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"122.5\" x2=\"0.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"122.5\" x2=\"120.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"136.0\" x2=\"120.0\" y2=\"136.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"132.0\" x2=\"4.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"116.0\" y1=\"132.0\" x2=\"124.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"60\" y=\"150.4\" text-anchor=\"middle\" class=\"fig-etq\">4 cm</text><text x=\"67.8\" y=\"71.1\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "123b",
   "ex": 123,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud de $x$ en aquestes figures.",
   "enunciat": "Quadrat de costat 10 cm, $x$ és la diagonal.",
   "opcions": [
    "$200$",
    "$20$",
    "$100$",
    "$10\\sqrt{2}\\approx14{,}14$"
   ],
   "pistes": [
    "La diagonal d'un quadrat és la hipotenusa del triangle rectangle format per dos costats consecutius.",
    "Aplica Pitàgores: $x=\\sqrt{10^2+10^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgY2FsY3VsYXQgJDEwXjIrMTBeMj0yMDAkIGNvcnJlY3RhbWVudCwgcGVyw7IgdCdoYXMgZGVpeGF0IGwnYXJyZWwgcXVhZHJhZGEgZmluYWwuIiwgIkhhcyBzdW1hdCBlbHMgZG9zIGNvc3RhdHMgZGlyZWN0YW1lbnQgKCQxMCsxMCQpIGVuIGxsb2MgZCdhcGxpY2FyIFBpdMOgZ29yZXMuIiwgIkFxdWVzdCDDqXMgZWwgcHJvZHVjdGUgZGVscyBkb3MgY29zdGF0cyAoJDEwXFxjZG90MTAkKSwgbm8gbGEgZGlhZ29uYWwuIiwgIiJdLCAiZXJyIjogWyJBUlJFTF9PQkxJREFEQSIsICJTVU1BX0NBVEVUU19TRU5TRV9RVUFEUkFUIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiIl0sICJyZXMiOiBbIiR4PVxcc3FydHsxMF4yKzEwXjJ9PVxcc3FydHsyMDB9PTEwXFxzcXJ0ezJ9XFxhcHByb3gxNHssfTE0JCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 148 181\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de costat 10 cm amb la diagonal marcada.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,0.0 120.0,0.0 120.0,120.0 0.0,120.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"120.0\" x2=\"120.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"122.5\" x2=\"0.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"122.5\" x2=\"120.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"136.0\" x2=\"120.0\" y2=\"136.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"132.0\" x2=\"4.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"116.0\" y1=\"132.0\" x2=\"124.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"60\" y=\"150.4\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"67.8\" y=\"71.1\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "123c",
   "ex": 123,
   "ap": "c",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud de $x$ en aquestes figures.",
   "enunciat": "Rectangle de costats 5 cm i 8 cm, $x$ és la diagonal.",
   "opcions": [
    "$40$",
    "$89$",
    "$\\sqrt{89}\\approx9{,}43$",
    "$13$"
   ],
   "pistes": [
    "La diagonal d'un rectangle és la hipotenusa del triangle rectangle format per dos costats consecutius.",
    "Aplica Pitàgores: $x=\\sqrt{5^2+8^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3Qgw6lzIGVsIHByb2R1Y3RlIGRlbHMgZG9zIGNvc3RhdHMgKCQ1XFxjZG90OCQpLCBubyBsYSBkaWFnb25hbC4iLCAiSGFzIGNhbGN1bGF0ICQ1XjIrOF4yPTg5JCBjb3JyZWN0YW1lbnQsIHBlcsOyIHQnaGFzIGRlaXhhdCBsJ2FycmVsIHF1YWRyYWRhIGZpbmFsLiIsICIiLCAiSGFzIHN1bWF0IGVscyBkb3MgY29zdGF0cyBkaXJlY3RhbWVudCAoJDUrOCQpIGVuIGxsb2MgZCdhcGxpY2FyIFBpdMOgZ29yZXMuIl0sICJlcnIiOiBbIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiQVJSRUxfT0JMSURBREEiLCAiIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiXSwgInJlcyI6IFsiJHg9XFxzcXJ0ezVeMis4XjJ9PVxcc3FydHs4OX1cXGFwcHJveDl7LH00MyQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 259 174\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 8 cm per 5 cm amb la diagonal marcada.</title><g transform=\"translate(64.6,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,112.5 0.0,112.5\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"115.0\" x2=\"0.0\" y2=\"132.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"115.0\" x2=\"180.0\" y2=\"132.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"128.5\" x2=\"180.0\" y2=\"128.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"124.5\" x2=\"4.0\" y2=\"132.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"124.5\" x2=\"184.0\" y2=\"132.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"112.5\" x2=\"-19.5\" y2=\"112.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"112.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"108.5\" x2=\"-20.0\" y2=\"116.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"112.5\" x2=\"180.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"90\" y=\"142.9\" text-anchor=\"middle\" class=\"fig-etq\">8 cm</text><text x=\"-36\" y=\"59.6\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text><text x=\"95.8\" y=\"68.9\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "123d",
   "ex": 123,
   "ap": "d",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 2,
   "encapcalament": "Calcula la longitud de $x$ en aquestes figures.",
   "enunciat": "Rectangle de diagonal $\\sqrt{117}$ cm i un costat de 9 cm, $x$ és l'altre costat.",
   "opcions": [
    "$36$ cm",
    "$\\sqrt{117+9^2}\\approx14{,}07$ cm",
    "$6$ cm",
    "$\\sqrt{81}=9$ cm"
   ],
   "pistes": [
    "La diagonal és la hipotenusa: coneixent-la i un costat, l'altre s'aïlla restant, no sumant.",
    "Aïlla l'altre costat: $x=\\sqrt{117-9^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgY2FsY3VsYXQgJDExNy05XjI9MzYkIGNvcnJlY3RhbWVudCwgcGVyw7IgdCdoYXMgZGVpeGF0IGwnYXJyZWwgcXVhZHJhZGEgZmluYWw6IGwnYWx0cmUgY29zdGF0IMOpcyAkXFxzcXJ0ezM2fT02JCBjbSwgbm8gJDM2JCBjbS4iLCAiQ29uZWl4ZW50IGxhIGRpYWdvbmFsIGkgdW4gY29zdGF0LCBsJ2FsdHJlIGNvc3RhdCBzJ29idMOpIFJFU1RBTlQgZWwgcXVhZHJhdCBkZWwgY29zdGF0IGNvbmVndXQgYWwgcXVhZHJhdCBkZSBsYSBkaWFnb25hbCwgbm8gc3VtYW50LWxvOiAkeD1cXHNxcnR7MTE3LTleMn0kLCBubyAkXFxzcXJ0ezExNys5XjJ9JC4iLCAiIiwgIkFxdWVzdCBjb3N0YXQgbm8gcG90IGNvaW5jaWRpciBhbWIgZWwgY29zdGF0IGphIGRvbmF0ICgkOSQgY20pOiBjYWwgYcOvbGxhci1sbyBkZSAkMTE3LTleMiQsIG5vIHJlcGV0aXIgZWwgY29zdGF0IGNvbmVndXQuIl0sICJlcnIiOiBbIkFSUkVMX09CTElEQURBIiwgIlNJR05FX1BJVEFHT1JFUyIsICIiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIl0sICJyZXMiOiBbIiR4PVxcc3FydHsxMTctOV4yfT1cXHNxcnR7MTE3LTgxfT1cXHNxcnR7MzZ9PTYkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 239 181\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 9 cm per x amb la diagonal marcada.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,120.0 0.0,120.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"122.5\" x2=\"0.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"122.5\" x2=\"180.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"136.0\" x2=\"180.0\" y2=\"136.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"132.0\" x2=\"4.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"132.0\" x2=\"184.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"120.0\" x2=\"-19.5\" y2=\"120.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"120.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"116.0\" x2=\"-20.0\" y2=\"124.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"120.0\" x2=\"180.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"90\" y=\"150.4\" text-anchor=\"middle\" class=\"fig-etq\">9 cm</text><text x=\"-27\" y=\"63.4\" text-anchor=\"middle\" class=\"fig-etq\">x</text><text x=\"57.3\" y=\"61.1\" text-anchor=\"middle\" class=\"fig-etq\">√117 cm</text></g></svg>"
  },
  {
   "id": "121a",
   "ex": 121,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina si els triangles són rectangles. En cas afirmatiu, indica la mesura de la seva hipotenusa i dels seus catets.",
   "enunciat": "Triangle de costats 5 cm, 12 cm i 13 cm.",
   "opcions": [
    "No és rectangle",
    "Rectangle, amb hipotenusa $13$ cm i catets $5$ cm i $12$ cm",
    "Rectangle, amb hipotenusa $12$ cm i catets $5$ cm i $13$ cm",
    "Rectangle, amb hipotenusa $13$ cm i catets $5$ cm i $13$ cm"
   ],
   "pistes": [
    "Compara el quadrat del costat més llarg amb la suma dels quadrats dels altres dos.",
    "$5^2+12^2$ i $13^2$: coincideixen?"
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJDb21wcm92YS1obzogJDVeMisxMl4yPTI1KzE0ND0xNjkkLCBpICQxM14yPTE2OSQgdGFtYsOpLiBDb2luY2lkZWl4ZW4sIGFpeMOtIHF1ZSBzw60gcXVlIMOpcyByZWN0YW5nbGUuIiwgIiIsICJMYSBoaXBvdGVudXNhIMOpcyBzZW1wcmUgZWwgY29zdGF0IE3DiVMgTExBUkcgZGVscyB0cmVzLCBxdWUgYXF1w60gw6lzICQxMyQgY20sIG5vICQxMiQgY20uIiwgIkxhIGhpcG90ZW51c2Egbm8gcG90IHJlcGV0aXItc2UgY29tIGEgY2F0ZXQ6IGVscyBjYXRldHMgc8OzbiBlbHMgZG9zIGNvc3RhdHMgcXVlIE5PIHPDs24gZWwgbcOpcyBsbGFyZywgw6lzIGEgZGlyLCAkNSQgaSAkMTIkLiJdLCAiZXJyIjogWyJWRVJFRElDVEVfSU5WRVJUSVQiLCAiIiwgIkhJUE9URU5VU0FfTUFMX0lERU5USUZJQ0FEQSIsICJISVBPVEVOVVNBX01BTF9JREVOVElGSUNBREEiXSwgInJlcyI6IFsiJDVeMisxMl4yPTI1KzE0ND0xNjk9MTNeMiQ6IGNvaW5jaWRlaXgsIMOpcyByZWN0YW5nbGUsIGFtYiBoaXBvdGVudXNhICQxMyQgY20gaSBjYXRldHMgJDUkIGNtIGkgJDEyJCBjbSJdfQ=="
  },
  {
   "id": "121b",
   "ex": 121,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina si els triangles són rectangles. En cas afirmatiu, indica la mesura de la seva hipotenusa i dels seus catets.",
   "enunciat": "Triangle de costats 6 cm, 8 cm i 12 cm.",
   "opcions": [
    "Rectangle, amb hipotenusa $8$ cm i catets $6$ cm i $12$ cm",
    "No es pot saber sense mesurar els angles directament",
    "Rectangle, amb hipotenusa $12$ cm i catets $6$ cm i $8$ cm",
    "No és rectangle"
   ],
   "pistes": [
    "Compara el quadrat del costat més llarg ($12$) amb la suma dels quadrats dels altres dos ($6$ i $8$).",
    "$6^2+8^2$ i $12^2$: coincideixen?"
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJFbmNhcmEgcXVlIGZvcyByZWN0YW5nbGUsIGxhIGhpcG90ZW51c2EgaGF1cmlhIGRlIHNlciBlbCBjb3N0YXQgbcOpcyBsbGFyZyAoJDEyJCBjbSksIG5vIGVsICQ4JCBjbTsgcGVyw7IgZGUgZmV0IGFxdWVzdCB0cmlhbmdsZSBubyDDqXMgcmVjdGFuZ2xlLiIsICJFbCB0ZW9yZW1hIGRlIFBpdMOgZ29yZXMgcGVybWV0IHNhYmVyLWhvIG5vbcOpcyBhbWIgbGVzIHRyZXMgbG9uZ2l0dWRzLCBzZW5zZSBtZXN1cmFyIGNhcCBhbmdsZTogbm9tw6lzIGNhbCBjb21wYXJhciAkNl4yKzheMiQgYW1iICQxMl4yJC4iLCAiQ29tcHJvdmEtaG86ICQ2XjIrOF4yPTM2KzY0PTEwMCQsIHBlcsOyICQxMl4yPTE0NCQuIE5PIGNvaW5jaWRlaXhlbjogYXF1ZXN0IHRyaWFuZ2xlIG5vIMOpcyByZWN0YW5nbGUuIiwgIiJdLCAiZXJyIjogWyJISVBPVEVOVVNBX01BTF9JREVOVElGSUNBREEiLCAiRVNfUE9UX0RFVEVSTUlOQVIiLCAiVkVSRURJQ1RFX0lOVkVSVElUIiwgIiJdLCAicmVzIjogWyIkNl4yKzheMj0zNis2ND0xMDAkLCBwZXLDsiAkMTJeMj0xNDQkOiBOTyBjb2luY2lkZWl4LCBubyDDqXMgcmVjdGFuZ2xlIl19"
  },
  {
   "id": "121c",
   "ex": 121,
   "ap": "c",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina si els triangles són rectangles. En cas afirmatiu, indica la mesura de la seva hipotenusa i dels seus catets.",
   "enunciat": "Triangle de costats 5 cm, 6 cm i $\\sqrt{61}$ cm.",
   "opcions": [
    "No es pot saber perquè un dels costats és una arrel, no un nombre enter",
    "No és rectangle",
    "Rectangle, amb hipotenusa $6$ cm i catets $5$ cm i $\\sqrt{61}$ cm",
    "Rectangle, amb hipotenusa $\\sqrt{61}$ cm i catets $5$ cm i $6$ cm"
   ],
   "pistes": [
    "Identifica primer el costat més llarg: com que $\\sqrt{61}\\approx7{,}81$ cm, és ell qui podria ser la hipotenusa.",
    "Comprova $5^2+6^2$ contra $(\\sqrt{61})^2$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJFbCB0ZW9yZW1hIGRlIFBpdMOgZ29yZXMgZnVuY2lvbmEgaWd1YWwgYW1iIGNvc3RhdHMgaXJyYWNpb25hbHM6IG4naGkgaGEgcHJvdSBkJ2VsZXZhciAkXFxzcXJ0ezYxfSQgYWwgcXVhZHJhdCwgcXVlIGRvbmEgZXhhY3RhbWVudCAkNjEkLiIsICJDb21wcm92YS1obzogJDVeMis2XjI9MjUrMzY9NjEkLCBpICQoXFxzcXJ0ezYxfSleMj02MSQgdGFtYsOpLiBDb2luY2lkZWl4ZW4sIGFpeMOtIHF1ZSBzw60gcXVlIMOpcyByZWN0YW5nbGUuIiwgIkxhIGhpcG90ZW51c2Egw6lzIGVsIGNvc3RhdCBtw6lzIGxsYXJnOiBjb20gcXVlICRcXHNxcnR7NjF9XFxhcHByb3g3eyx9ODEkIGNtLCDDqXMgbcOpcyBsbGFyZyBxdWUgJDYkIGNtLCBpIHBlciB0YW50IMOpcyBlbGwgcXVpIGZhIGQnaGlwb3RlbnVzYSwgbm8gZWwgJDYkLiIsICIiXSwgImVyciI6IFsiRVNfUE9UX0RFVEVSTUlOQVIiLCAiVkVSRURJQ1RFX0lOVkVSVElUIiwgIkhJUE9URU5VU0FfTUFMX0lERU5USUZJQ0FEQSIsICIiXSwgInJlcyI6IFsiJDVeMis2XjI9MjUrMzY9NjE9KFxcc3FydHs2MX0pXjIkOiBjb2luY2lkZWl4LCDDqXMgcmVjdGFuZ2xlLCBhbWIgaGlwb3RlbnVzYSAkXFxzcXJ0ezYxfSQgY20gaSBjYXRldHMgJDUkIGNtIGkgJDYkIGNtIl19"
  },
  {
   "id": "121d",
   "ex": 121,
   "ap": "d",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina si els triangles són rectangles. En cas afirmatiu, indica la mesura de la seva hipotenusa i dels seus catets.",
   "enunciat": "Triangle de costats 7 cm, 24 cm i 25 cm.",
   "opcions": [
    "Rectangle, amb hipotenusa $25$ cm i catets $7$ cm i $7$ cm",
    "Rectangle, amb hipotenusa $25$ cm i catets $7$ cm i $24$ cm",
    "Rectangle, amb hipotenusa $24$ cm i catets $7$ cm i $25$ cm",
    "No és rectangle"
   ],
   "pistes": [
    "Compara el quadrat del costat més llarg amb la suma dels quadrats dels altres dos.",
    "$7^2+24^2$ i $25^2$: coincideixen?"
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJFbHMgZG9zIGNhdGV0cyBzw7NuIGVscyBkb3MgY29zdGF0cyBxdWUgTk8gZmFuIGQnaGlwb3RlbnVzYTogYXF1w60gc8OzbiAkNyQgY20gaSAkMjQkIGNtLCBubyBkdWVzIHZlZ2FkZXMgZWwgbWF0ZWl4IGNvc3RhdC4iLCAiIiwgIkxhIGhpcG90ZW51c2Egw6lzIGVsIGNvc3RhdCBtw6lzIGxsYXJnIGRlbHMgdHJlcywgcXVlIGFxdcOtIMOpcyAkMjUkIGNtLCBubyAkMjQkIGNtLiIsICJDb21wcm92YS1obzogJDdeMisyNF4yPTQ5KzU3Nj02MjUkLCBpICQyNV4yPTYyNSQgdGFtYsOpLiBDb2luY2lkZWl4ZW4sIGFpeMOtIHF1ZSBzw60gcXVlIMOpcyByZWN0YW5nbGUuIl0sICJlcnIiOiBbIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiIiwgIkhJUE9URU5VU0FfTUFMX0lERU5USUZJQ0FEQSIsICJWRVJFRElDVEVfSU5WRVJUSVQiXSwgInJlcyI6IFsiJDdeMisyNF4yPTQ5KzU3Nj02MjU9MjVeMiQ6IGNvaW5jaWRlaXgsIMOpcyByZWN0YW5nbGUsIGFtYiBoaXBvdGVudXNhICQyNSQgY20gaSBjYXRldHMgJDckIGNtIGkgJDI0JCBjbSJdfQ=="
  },
  {
   "id": "122",
   "ex": 122,
   "ap": "",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Classifica en acutangle o obtusangle el triangle de costats 5 cm, 10 cm i 8 cm.",
   "opcions": [
    "No es pot classificar sense mesurar els angles directament",
    "Triangle acutangle",
    "Triangle rectangle",
    "Triangle obtusangle"
   ],
   "pistes": [
    "Compara el quadrat del costat més llarg ($10$) amb la suma dels quadrats dels altres dos ($5$ i $8$).",
    "Si el quadrat del costat més llarg és més gran que la suma dels altres dos quadrats, el triangle és obtusangle; si és més petit, és acutangle; si coincideix, és rectangle."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJDb21wYXJhbnQgZWwgcXVhZHJhdCBkZWwgY29zdGF0IG3DqXMgbGxhcmcgYW1iIGxhIHN1bWEgZGVscyBxdWFkcmF0cyBkZWxzIGFsdHJlcyBkb3MgamEgbidoaSBoYSBwcm91IHBlciBjbGFzc2lmaWNhci1sbywgc2Vuc2UgbmVjZXNzaXRhdCBkZSBtZXN1cmFyIGNhcCBhbmdsZS4iLCAiQ29tcGFyYSAkMTBeMj0xMDAkIGFtYiAkNV4yKzheMj04OSQ6IGNvbSBxdWUgJDEwMD44OSQsIGwnYW5nbGUgb3Bvc2F0IGFsIGNvc3RhdCBtw6lzIGxsYXJnIMOpcyBtw6lzIG9iZXJ0IHF1ZSB1biBhbmdsZSByZWN0ZSwgYWl4w60gcXVlIGVsIHRyaWFuZ2xlIMOpcyBvYnR1c2FuZ2xlLCBubyBhY3V0YW5nbGUuIiwgIiQxMF4yPTEwMCQgaSAkNV4yKzheMj04OSQgTk8gY29pbmNpZGVpeGVuIChzaSBjb2luY2lkaXNzaW4gc2VyaWEgcmVjdGFuZ2xlKTogY29tIHF1ZSAkMTAwJCDDqXMgbcOpcyBncmFuIHF1ZSAkODkkLCBsJ2FuZ2xlIMOpcyBtw6lzIG9iZXJ0IHF1ZSB1biBhbmdsZSByZWN0ZSwgw6lzIGEgZGlyLCBvYnR1c2FuZ2xlLiIsICIiXSwgImVyciI6IFsiRVNfUE9UX0RFVEVSTUlOQVIiLCAiVkVSRURJQ1RFX0lOVkVSVElUIiwgIlBBUklUQVRfRVhQT05FTlQiLCAiIl0sICJyZXMiOiBbIiQxMF4yPTEwMCQsICRcXHF1YWQgNV4yKzheMj0yNSs2ND04OSQiLCAiQ29tIHF1ZSAkMTAwPjg5JCwgZWwgdHJpYW5nbGUgw6lzIG9idHVzYW5nbGUiXX0="
  },
  {
   "id": "124a",
   "ex": 124,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina la longitud de $x$ en aquests triangles.",
   "enunciat": "Triangle equilàter de costat 10 cm; $x$ és l'alçada.",
   "opcions": [
    "$10$",
    "$0$ cm (perquè $10^2-10^2=0$)",
    "$5\\sqrt{3}\\approx8{,}66$",
    "$5$"
   ],
   "pistes": [
    "L'alçada d'un triangle equilàter cau al punt mitjà de la base i forma un triangle rectangle amb la semibase i el costat (com a hipotenusa).",
    "La semibase és $\\dfrac{10}{2}=5$ cm; aplica Pitàgores: $x=\\sqrt{10^2-5^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJMJ2Fsw6dhZGEgZCd1biB0cmlhbmdsZSBlcXVpbMOgdGVyIE5PIGNvaW5jaWRlaXggYW1iIGVsIGNvc3RhdDogY2FsIGFwbGljYXIgUGl0w6Bnb3JlcyBhbWIgbGEgc2VtaWJhc2UgaSBlbCBjb3N0YXQgY29tIGEgaGlwb3RlbnVzYS4iLCAiQXF1ZXN0IHBsYW50ZWphbWVudCBmYSBzZXJ2aXIgZWwgY29zdGF0IHNlbmNlciAoJDEwJCkgY29tIGEgY2F0ZXQgZHVlcyB2ZWdhZGVzLCBubyBsYSBTRU1JQkFTRSAobGEgbWVpdGF0IGRlbCBjb3N0YXQsIGphIHF1ZSBsJ2Fsw6dhZGEgY2F1IGFsIHB1bnQgbWl0asOgIGRlIGxhIGJhc2UpLiIsICIiLCAiQXF1ZXN0YSDDqXMgbGEgc2VtaWJhc2UgKGxhIG1laXRhdCBkZWwgY29zdGF0KSwgbm8gbCdhbMOnYWRhOiBlbmNhcmEgZmFsdGEgYXBsaWNhciBQaXTDoGdvcmVzIGFtYiBhcXVlc3RhIHNlbWliYXNlIGkgZWwgY29zdGF0IGNvbSBhIGhpcG90ZW51c2EuIl0sICJlcnIiOiBbIlBST0dSRVNTSU9fSU5WRU5UQURBIiwgIkNBVEVUX01BTF9JREVOVElGSUNBVCIsICIiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiXSwgInJlcyI6IFsiU2VtaWJhc2U6ICRcXGRmcmFjezEwfXsyfT01JCBjbSIsICIkeD1cXHNxcnR7MTBeMi01XjJ9PVxcc3FydHs3NX09NVxcc3FydHszfVxcYXBwcm94OHssfTY2JCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 198 209\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle equilàter de base 10 cm, costats iguals 10 cm, alçada x.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,147.2 170.0,147.2 85.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"147.2\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 94.0 147.2 L 94.0 138.2 L 85.0 138.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"149.7\" x2=\"0.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"149.7\" x2=\"170.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"163.2\" x2=\"170.0\" y2=\"163.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"159.2\" x2=\"4.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"159.2\" x2=\"174.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"177.6\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"39.4\" y=\"122.3\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"96\" y=\"77\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "124b",
   "ex": 124,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina la longitud de $x$ en aquests triangles.",
   "enunciat": "Triangle isòsceles de base 8 cm i alçada $\\sqrt{48}$ cm; $x$ és la longitud dels costats iguals.",
   "opcions": [
    "$4$ cm",
    "$8$ cm",
    "$\\sqrt{48+4^2}\\approx8{,}25$ cm",
    "$\\sqrt{48+8^2}\\approx10{,}77$ cm"
   ],
   "pistes": [
    "L'alçada divideix la base pel mig: la semibase és $\\dfrac{8}{2}=4$ cm.",
    "El costat igual és la hipotenusa del triangle rectangle de catets $4$ i $\\sqrt{48}$: $x=\\sqrt{4^2+(\\sqrt{48})^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3RhIMOpcyBsYSBzZW1pYmFzZSAobGEgbWVpdGF0IGRlIGxhIGJhc2UpLCBubyBlbCBjb3N0YXQgaWd1YWwgcXVlIGV0IGRlbWFuZW46IGVuY2FyYSBmYWx0YSBhcGxpY2FyIFBpdMOgZ29yZXMuIiwgIiIsICJFbCBjb3N0YXQgaWd1YWwgw6lzIGxhIGhpcG90ZW51c2E6IHMnb2J0w6kgU1VNQU5UIGVscyBxdWFkcmF0cyBkZSBsYSBzZW1pYmFzZSBpIGwnYWzDp2FkYSwgaSBhaXjDsiBzw60gw6lzIGNvcnJlY3RlIGFxdcOtIChubyDDqXMgdW5hIHJlc3RhKTsgY29tcHJvdmEgcXVlIGhhcyBmZXQgc2VydmlyIGxhIHNlbWliYXNlICgkNCQgY20sIGxhIG1laXRhdCBkZSAkOCQpLCBubyBsYSBiYXNlIHNlbmNlcmEuIiwgIkhhcyBmZXQgc2VydmlyIGxhIGJhc2Ugc2VuY2VyYSAoJDgkIGNtKSBjb20gYSBjYXRldCwgZW4gbGxvYyBkZSBsYSBTRU1JQkFTRSAoJDQkIGNtLCBsYSBtZWl0YXQgZGUgbGEgYmFzZSwgamEgcXVlIGwnYWzDp2FkYSBjYXUgYWwgcHVudCBtaXRqw6ApLiJdLCAiZXJyIjogWyJQQVNfSU5URVJNRURJX1BFUl9SRVNQT1NUQSIsICIiLCAiU0lHTkVfUElUQUdPUkVTIiwgIkNBVEVUX01BTF9JREVOVElGSUNBVCJdLCAicmVzIjogWyJTZW1pYmFzZTogJFxcZGZyYWN7OH17Mn09NCQgY20iLCAiJHg9XFxzcXJ0ezReMisoXFxzcXJ0ezQ4fSleMn09XFxzcXJ0ezE2KzQ4fT1cXHNxcnR7NjR9PTgkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 198 209\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle isòsceles de base 8 cm, costats iguals x, alçada √48 cm.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,147.2 170.0,147.2 85.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"147.2\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 94.0 147.2 L 94.0 138.2 L 85.0 138.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"149.7\" x2=\"0.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"149.7\" x2=\"170.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"163.2\" x2=\"170.0\" y2=\"163.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"159.2\" x2=\"4.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"159.2\" x2=\"174.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"177.6\" text-anchor=\"middle\" class=\"fig-etq\">8 cm</text><text x=\"52\" y=\"82.5\" text-anchor=\"middle\" class=\"fig-etq\">x</text><text x=\"111\" y=\"112.3\" text-anchor=\"middle\" class=\"fig-etq\">√48 cm</text></g></svg>"
  },
  {
   "id": "124c",
   "ex": 124,
   "ap": "c",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina la longitud de $x$ en aquests triangles.",
   "enunciat": "Triangle isòsceles de costats iguals 12 cm i base 7 cm; $x$ és l'alçada.",
   "opcions": [
    "$\\sqrt{144-7^2}=\\sqrt{95}\\approx9{,}75$ cm",
    "$131{,}75$ cm",
    "$12-3{,}5=8{,}5$ cm",
    "$\\sqrt{131{,}75}\\approx11{,}48$ cm"
   ],
   "pistes": [
    "La semibase és $\\dfrac{7}{2}=3{,}5$ cm; l'alçada, la semibase i el costat igual (com a hipotenusa) formen un triangle rectangle.",
    "Aplica Pitàgores: $x=\\sqrt{12^2-3{,}5^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgZmV0IHNlcnZpciBsYSBiYXNlIHNlbmNlcmEgKCQ3JCBjbSkgY29tIGEgY2F0ZXQsIGVuIGxsb2MgZGUgbGEgU0VNSUJBU0UgKCQzeyx9NSQgY20sIGxhIG1laXRhdCBkZSAkNyQsIGphIHF1ZSBsJ2Fsw6dhZGEgY2F1IGFsIHB1bnQgbWl0asOgIGRlIGxhIGJhc2UpLiIsICJIYXMgY2FsY3VsYXQgJDEyXjItM3ssfTVeMj0xMzF7LH03NSQgY29ycmVjdGFtZW50LCBwZXLDsiB0J2hhcyBkZWl4YXQgbCdhcnJlbCBxdWFkcmFkYSBmaW5hbC4iLCAiSGFzIHJlc3RhdCBkaXJlY3RhbWVudCBlbCBjb3N0YXQgaSBsYSBzZW1pYmFzZSBlbiBsbG9jIGQnYXBsaWNhciBQaXTDoGdvcmVzOiBjYWwgZWxldmFyLWxvcyBhbCBxdWFkcmF0LCByZXN0YXIsIGkgZmVyIGwnYXJyZWwgcXVhZHJhZGEuIiwgIiJdLCAiZXJyIjogWyJDQVRFVF9NQUxfSURFTlRJRklDQVQiLCAiQVJSRUxfT0JMSURBREEiLCAiU1VNQV9DQVRFVFNfU0VOU0VfUVVBRFJBVCIsICIiXSwgInJlcyI6IFsiU2VtaWJhc2U6ICRcXGRmcmFjezd9ezJ9PTN7LH01JCBjbSIsICIkeD1cXHNxcnR7MTJeMi0zeyx9NV4yfT1cXHNxcnR7MTQ0LTEyeyx9MjV9PVxcc3FydHsxMzF7LH03NX1cXGFwcHJveDExeyx9NDgkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 198 221\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle isòsceles de base 7 cm, costats iguals 12 cm, alçada x.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,160.0 170.0,160.0 85.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"160.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 94.0 160.0 L 94.0 151.0 L 85.0 151.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"162.5\" x2=\"0.0\" y2=\"179.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"162.5\" x2=\"170.0\" y2=\"179.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"176.0\" x2=\"170.0\" y2=\"176.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"172.0\" x2=\"4.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"172.0\" x2=\"174.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"190.4\" text-anchor=\"middle\" class=\"fig-etq\">7 cm</text><text x=\"50\" y=\"111.9\" text-anchor=\"middle\" class=\"fig-etq\">12 cm</text><text x=\"96\" y=\"83.4\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "125",
   "ex": 125,
   "ap": "",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Troba l'altura d'un triangle equilàter de perímetre 48 cm.",
   "opcions": [
    "$8\\sqrt{3}\\approx13{,}86$",
    "$16$",
    "$24\\sqrt{3}\\approx41{,}57$",
    "$192$"
   ],
   "pistes": [
    "Calcula primer el costat: com que el perímetre és $48$ cm i els tres costats són iguals, cada costat val $\\dfrac{48}{3}=16$ cm.",
    "L'alçada, la semibase ($8$ cm) i el costat (com a hipotenusa) formen un triangle rectangle: $h=\\sqrt{16^2-8^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IMOpcyBlbCBjb3N0YXQgZGVsIHRyaWFuZ2xlICgkNDg6MyQpLCBubyBsJ2Fsw6dhZGE6IGVuY2FyYSBjYWwgYXBsaWNhciBQaXTDoGdvcmVzIGFtYiBsYSBzZW1pYmFzZS4iLCAiTm8gaGFzIGNhbGN1bGF0IHByaW1lciBlbCBjb3N0YXQgYSBwYXJ0aXIgZGVsIHBlcsOtbWV0cmUgKCQ0ODozPTE2JCBjbSk6IHNlbWJsYSBxdWUgaGFzIGZldCBzZXJ2aXIgZWwgcGVyw61tZXRyZSBzZW5jZXIgKCQ0OCQpIGNvbSBzaSBmb3MgZWwgY29zdGF0LCBlbiBsbG9jIGRlIGRpdmlkaXItbG8gZW50cmUgMyBwcmltZXIuIiwgIkhhcyBjYWxjdWxhdCAkMTZeMi04XjI9MTkyJCBjb3JyZWN0YW1lbnQsIHBlcsOyIHQnaGFzIGRlaXhhdCBsJ2FycmVsIHF1YWRyYWRhIGZpbmFsLiJdLCAiZXJyIjogWyIiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiQ09TVEFUX05PX0NBTENVTEFUIiwgIkFSUkVMX09CTElEQURBIl0sICJyZXMiOiBbIkNvc3RhdDogJFxcZGZyYWN7NDh9ezN9PTE2JCBjbSIsICIkaD1cXHNxcnR7MTZeMi04XjJ9PVxcc3FydHsxOTJ9PThcXHNxcnR7M31cXGFwcHJveDEzeyx9ODYkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 198 209\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle isòsceles de base 16 cm, costats iguals ?, alçada ?.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,147.2 170.0,147.2 85.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"147.2\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 94.0 147.2 L 94.0 138.2 L 85.0 138.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"149.7\" x2=\"0.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"149.7\" x2=\"170.0\" y2=\"166.7\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"163.2\" x2=\"170.0\" y2=\"163.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"159.2\" x2=\"4.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"159.2\" x2=\"174.0\" y2=\"167.2\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"177.6\" text-anchor=\"middle\" class=\"fig-etq\">16 cm</text><text x=\"52\" y=\"82.5\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"96\" y=\"77\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "126a",
   "ex": 126,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Calcula el perímetre de les figures següents.",
   "enunciat": "Quadrilàter irregular de costats 25 cm, 28 cm, 18 cm i 10 cm.",
   "opcions": [
    "$81$ cm",
    "$630$ cm",
    "$71$ cm",
    "$91$ cm"
   ],
   "pistes": [
    "El perímetre d'un polígon és la suma de les longituds de tots els seus costats.",
    "Suma els quatre costats: $25+28+18+10$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiRWwgcGVyw61tZXRyZSDDqXMgbGEgU1VNQSBkZWxzIGNvc3RhdHMsIG5vIGVsIHNldSBwcm9kdWN0ZTogJDI1XFxjZG90MjhcXGNkb3QxOFxcY2RvdDEwJCBubyB0w6kgc2VudGl0IGFxdcOtLiIsICJBcXVlc3QgdmFsb3Igbm8gaW5jbG91IGFsZ3VuIGRlbHMgcXVhdHJlIGNvc3RhdHM6IHN1bWEnbHMgdG90cyBxdWF0cmUgdW4gcGVyIHVuLiIsICJBcXVlc3QgdmFsb3Igbm8gY29pbmNpZGVpeCBhbWIgbGEgc3VtYSBkZWxzIHF1YXRyZSBjb3N0YXRzIGRvbmF0czogdG9ybmEgYSBzdW1hci1sb3MgYW1iIGNhbG1hLiJdLCAiZXJyIjogWyIiLCAiU1VNQV9FTl9MTE9DX1JFU1RBIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyJdLCAicmVzIjogWyIkMjUrMjgrMTgrMTA9ODEkIGNtIl19"
  },
  {
   "id": "126b",
   "ex": 126,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Calcula el perímetre de les figures següents.",
   "enunciat": "Hexàgon còncau (en forma de fletxa) de costats 12 cm, 14 cm, 28 cm, 7 cm, 16 cm i 5 cm.",
   "opcions": [
    "$77$ cm",
    "$70$ cm",
    "$82$ cm",
    "$41$ cm"
   ],
   "pistes": [
    "El perímetre és la suma de tots els costats, encara que la figura sigui còncava (en forma de fletxa): el criteri no canvia.",
    "Suma els sis costats: $12+14+28+7+16+5$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gaW5jbG91IGFsZ3VuIGRlbHMgc2lzIGNvc3RhdHM6IHN1bWEnbHMgdG90cyBzaXMgdW4gcGVyIHVuLiIsICJBcXVlc3QgdmFsb3Igbm8gY29pbmNpZGVpeCBhbWIgbGEgc3VtYSBkZWxzIHNpcyBjb3N0YXRzIGRvbmF0czogdG9ybmEgYSBzdW1hci1sb3MgYW1iIGNhbG1hLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSBsYSBtZWl0YXQgZGVsIHBlcsOtbWV0cmUgcmVhbDogZWwgcGVyw61tZXRyZSBpbmNsb3UgZWxzIHNpcyBjb3N0YXRzIHNlbmNlcnMsIG5vIGxhIG1laXRhdCBkZSBsYSBzdW1hLiJdLCAiZXJyIjogWyJURVJNRV9PQkxJREFUX09QRVJBQ0lPIiwgIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiIiwgIlBBUlRfUEVMX1RPVCJdLCAicmVzIjogWyIkMTIrMTQrMjgrNysxNis1PTgyJCBjbSJdfQ=="
  },
  {
   "id": "127a",
   "ex": 127,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'apotema d'un hexàgon regular el costat del qual mesura:",
   "enunciat": "10 cm",
   "opcions": [
    "$5$ cm",
    "$30$ cm",
    "$10$ cm",
    "$5\\sqrt{3}\\approx8{,}66$ cm"
   ],
   "pistes": [
    "L'apotema d'un hexàgon regular és l'alçada d'un dels sis triangles equilàters de costat $L$ en què el centre el divideix.",
    "Fes servir la fórmula $a=\\dfrac{L\\sqrt3}{2}$, amb $L=10$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3Qgw6lzIGVsIGNhdGV0IGNvcnJlc3BvbmVudCBhIGxhIG1laXRhdCBkZWwgY29zdGF0LCBwZXLDsiBlbmNhcmEgZmFsdGEgbXVsdGlwbGljYXIgcGVyICRcXHNxcnR7M30kOiBsJ2Fwb3RlbWEgw6lzICRcXGRmcmFje0xcXHNxcnQzfXsyfSQsIG5vIG5vbcOpcyAkXFxkZnJhY3tMfXsyfSQuIiwgIkFxdWVzdCB2YWxvciBubyBzdXJ0IGRlIGxhIGbDs3JtdWxhICRcXGRmcmFje0xcXHNxcnQzfXsyfSQ6IHJldmlzYSBxdWUgaGFzIG11bHRpcGxpY2F0IHBlciAkXFxzcXJ0MyQgKG5vIHBlciAkMyQpIGkgaGFzIGRpdmlkaXQgcGVyICQyJC4iLCAiTCdhcG90ZW1hIGQndW4gaGV4w6Bnb24gcmVndWxhciBOTyBjb2luY2lkZWl4IGFtYiBlbCBjb3N0YXQ6IHMnb2J0w6kgYXBsaWNhbnQgUGl0w6Bnb3JlcyBhIHVuIGRlbHMgc2lzIHRyaWFuZ2xlcyBlcXVpbMOgdGVycyBlbiBxdcOoIGVsIGNlbnRyZSBlbCBkaXZpZGVpeC4iLCAiIl0sICJlcnIiOiBbIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIiwgIlBPVEVOQ0lBX0RFX1NVTUEiLCAiQVBPVEVNQV9DT1NUQVRfQ09ORk9TIiwgIiJdLCAicmVzIjogWyIkYT1cXGRmcmFjezEwXFxzcXJ0M317Mn09NVxcc3FydHszfVxcYXBwcm94OHssfTY2JCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 10 cm, amb l'apotema marcada.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"77.9\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><path d=\"M 9.0 77.9 L 9.0 68.9 L 0.0 68.9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"-11\" y=\"42.3\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "127b",
   "ex": 127,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'apotema d'un hexàgon regular el costat del qual mesura:",
   "enunciat": "16 cm",
   "opcions": [
    "$8$ cm",
    "$16$ cm",
    "$8\\sqrt{3}\\approx13{,}86$ cm",
    "$48$ cm"
   ],
   "pistes": [
    "Fes servir la fórmula $a=\\dfrac{L\\sqrt3}{2}$.",
    "Amb $L=16$ cm: $a=\\dfrac{16\\sqrt3}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3Qgw6lzICRcXGRmcmFje0x9ezJ9JCwgcGVyw7IgZW5jYXJhIGZhbHRhIG11bHRpcGxpY2FyIHBlciAkXFxzcXJ0ezN9JC4iLCAiTCdhcG90ZW1hIGQndW4gaGV4w6Bnb24gcmVndWxhciBubyBjb2luY2lkZWl4IGFtYiBlbCBjb3N0YXQ6IGNhbCBhcGxpY2FyIGxhIGbDs3JtdWxhICRhPVxcZGZyYWN7TFxcc3FydDN9ezJ9JC4iLCAiIiwgIkFxdWVzdCB2YWxvciBubyBzdXJ0IGRlIGxhIGbDs3JtdWxhICRcXGRmcmFje0xcXHNxcnQzfXsyfSQ6IHJldmlzYSBxdWUgaGFzIG11bHRpcGxpY2F0IHBlciAkXFxzcXJ0MyQgKG5vIHBlciAkMyQpIGkgaGFzIGRpdmlkaXQgcGVyICQyJC4iXSwgImVyciI6IFsiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiQVBPVEVNQV9DT1NUQVRfQ09ORk9TIiwgIiIsICJQT1RFTkNJQV9ERV9TVU1BIl0sICJyZXMiOiBbIiRhPVxcZGZyYWN7MTZcXHNxcnQzfXsyfT04XFxzcXJ0Mz04XFxzcXJ0ezN9XFxhcHByb3gxM3ssfTg2JCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 16 cm, amb l'apotema marcada.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"77.9\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><path d=\"M 9.0 77.9 L 9.0 68.9 L 0.0 68.9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">16 cm</text><text x=\"-11\" y=\"42.3\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "127c",
   "ex": 127,
   "ap": "c",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'apotema d'un hexàgon regular el costat del qual mesura:",
   "enunciat": "7 cm",
   "opcions": [
    "$7$ cm",
    "$\\dfrac{7\\sqrt3}{2}\\approx6{,}06$ cm",
    "$\\dfrac{7}{2\\sqrt3}\\approx2{,}02$ cm",
    "$3{,}5$ cm"
   ],
   "pistes": [
    "Fes servir la fórmula $a=\\dfrac{L\\sqrt3}{2}$.",
    "Amb $L=7$ cm: $a=\\dfrac{7\\sqrt3}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJMJ2Fwb3RlbWEgZCd1biBoZXjDoGdvbiByZWd1bGFyIG5vIGNvaW5jaWRlaXggYW1iIGVsIGNvc3RhdDogY2FsIGFwbGljYXIgbGEgZsOzcm11bGEgJGE9XFxkZnJhY3tMXFxzcXJ0M317Mn0kLiIsICIiLCAiSGFzIGludmVydGl0IGxhIHBvc2ljacOzIGRlICRcXHNxcnQzJDogbGEgZsOzcm11bGEgw6lzICRcXGRmcmFje0xcXHNxcnQzfXsyfSQgKG11bHRpcGxpY2FudCksIG5vICRcXGRmcmFje0x9ezJcXHNxcnQzfSQgKGRpdmlkaW50KS4iLCAiQXF1ZXN0IMOpcyAkXFxkZnJhY3tMfXsyfSQsIHBlcsOyIGVuY2FyYSBmYWx0YSBtdWx0aXBsaWNhciBwZXIgJFxcc3FydHszfSQuIl0sICJlcnIiOiBbIkFQT1RFTUFfQ09TVEFUX0NPTkZPUyIsICIiLCAiSU5WRVJUSURBIiwgIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIl0sICJyZXMiOiBbIiRhPVxcZGZyYWN7N1xcc3FydDN9ezJ9XFxhcHByb3g2eyx9MDYkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 7 cm, amb l'apotema marcada.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"77.9\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><path d=\"M 9.0 77.9 L 9.0 68.9 L 0.0 68.9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">7 cm</text><text x=\"-11\" y=\"42.3\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "128a",
   "ex": 128,
   "ap": "a",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un rectangle té base $AB=12$ cm i altura $AC=16$ cm. Un rombe uneix els punts mitjans dels quatre costats del rectangle. Calcula el costat del rombe.",
   "opcions": [
    "$10$ cm",
    "$14$ cm",
    "$100$ cm",
    "$20$ cm"
   ],
   "pistes": [
    "Cada costat del rombe és la hipotenusa d'un triangle rectangle de catets la meitat de la base i la meitat de l'altura del rectangle.",
    "Els catets són $\\dfrac{12}{2}=6$ cm i $\\dfrac{16}{2}=8$ cm; aplica Pitàgores."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiSGFzIHN1bWF0IGRpcmVjdGFtZW50IGxlcyBtZWl0YXRzIGRlIGJhc2UgaSBhbHR1cmEgKCQ2KzgkKSBlbiBsbG9jIGQnYXBsaWNhciBQaXTDoGdvcmVzLiIsICJIYXMgY2FsY3VsYXQgJDZeMis4XjI9MTAwJCBjb3JyZWN0YW1lbnQsIHBlcsOyIHQnaGFzIGRlaXhhdCBsJ2FycmVsIHF1YWRyYWRhIGZpbmFsLiIsICJIYXMgZmV0IHNlcnZpciBsYSBiYXNlIGkgbCdhbHR1cmEgc2VuY2VyZXMgKCQxMiQgaSAkMTYkKSBlbiBsbG9jIGRlIGxlcyBzZXZlcyBNRUlUQVRTICgkNiQgaSAkOCQpOiBlbCBjb3N0YXQgZGVsIHJvbWJlIMOpcyBsYSBoaXBvdGVudXNhIGRlbCB0cmlhbmdsZSBmb3JtYXQgcGVscyBwdW50cyBtaXRqYW5zLCBubyBwZWwgcmVjdGFuZ2xlIHNlbmNlci4iXSwgImVyciI6IFsiIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiQVJSRUxfT0JMSURBREEiLCAiTUVJVEFUX09CTElEQURBIl0sICJyZXMiOiBbIkNhdGV0czogJFxcZGZyYWN7MTJ9ezJ9PTYkIGNtIGkgJFxcZGZyYWN7MTZ9ezJ9PTgkIGNtIiwgIkNvc3RhdCBkZWwgcm9tYmU6ICRcXHNxcnR7Nl4yKzheMn09XFxzcXJ0ezEwMH09MTAkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 248 232\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de AB = 12 cm per AC = 16 cm amb el rombe format unint els punts mitjans dels quatre costats.</title><rect x=\"87\" y=\"26\" width=\"135\" height=\"180\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><polygon points=\"154.5,26 222,116 154.5,206 87,116\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><text x=\"154.5\" y=\"224\" text-anchor=\"middle\" class=\"fig-etq\">AB = 12 cm</text><text x=\"79\" y=\"120\" text-anchor=\"end\" class=\"fig-etq\">AC = 16 cm</text></svg>"
  },
  {
   "id": "128b",
   "ex": 128,
   "ap": "b",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "En un rectangle, dos costats consecutius es diuen $AB=12$ cm (la base) i $AC=16$ cm (l'altura), essent $A$, $B$ i $C$ tres dels vèrtexs del rectangle ($A$ i $B$ a la base, $C$ damunt de $A$). En el triangle rectangle $ABC$, quant valen el catet $AB$, el catet $AC$ i la hipotenusa $BC$?",
   "opcions": [
    "$AB=16$ cm, $AC=12$ cm, $BC=20$ cm",
    "$AB=12$ cm, $AC=16$ cm, $BC=28$ cm",
    "$AB=12$ cm, $AC=16$ cm, $BC=\\sqrt{400}$ cm sense simplificar",
    "$AB=12$ cm, $AC=16$ cm, $BC=20$ cm"
   ],
   "pistes": [
    "Els catets del triangle rectangle $ABC$ són directament els costats donats del rectangle.",
    "La hipotenusa $BC$ s'obté amb Pitàgores: $BC=\\sqrt{AB^2+AC^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgaW50ZXJjYW52aWF0IHF1aW4gY29zdGF0IMOpcyAkQUIkIGkgcXVpbiDDqXMgJEFDJDogbCdlbnVuY2lhdCBkaXUgZXhwbMOtY2l0YW1lbnQgcXVlIGxhIGJhc2UgJEFCJCDDqXMgJDEyJCBjbSBpIGwnYWx0dXJhICRBQyQgw6lzICQxNiQgY20uIiwgIiQyOCQgc3VydCBkZSBzdW1hciAkMTIrMTYkIGRpcmVjdGFtZW50OiBsYSBoaXBvdGVudXNhIHMnb2J0w6kgYXBsaWNhbnQgUGl0w6Bnb3JlcyAoJFxcc3FydHsxMl4yKzE2XjJ9JCksIG5vIHN1bWFudCBlbHMgY2F0ZXRzLiIsICIkXFxzcXJ0ezQwMH0kIFPDjSDDqXMgY29ycmVjdGUgY29tIGEgcGFzIGludGVybWVkaSwgcGVyw7IgZXMgc2ltcGxpZmljYSBleGFjdGFtZW50IGEgJDIwJCBjbSAow6lzIHVuIHF1YWRyYXQgcGVyZmVjdGUpOiBjYWwgYWNhYmFyIGRlIHNpbXBsaWZpY2FyIGwnYXJyZWwuIiwgIiJdLCAiZXJyIjogWyJDQVRFVF9NQUxfSURFTlRJRklDQVQiLCAiU1VNQV9DQVRFVFNfU0VOU0VfUVVBRFJBVCIsICJTSU1QTElGSUNBQ0lPX0lOQ09NUExFVEEiLCAiIl0sICJyZXMiOiBbIiRCQz1cXHNxcnR7MTJeMisxNl4yfT1cXHNxcnR7NDAwfT0yMCQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 257 241\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de AB = 12 cm per AC = 16 cm amb la diagonal marcada.</title><g transform=\"translate(107.6,14.0)\"><polygon points=\"0.0,0.0 135.0,0.0 135.0,180.0 0.0,180.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"182.5\" x2=\"0.0\" y2=\"199.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"135.0\" y1=\"182.5\" x2=\"135.0\" y2=\"199.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"196.0\" x2=\"135.0\" y2=\"196.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"192.0\" x2=\"4.0\" y2=\"200.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"131.0\" y1=\"192.0\" x2=\"139.0\" y2=\"200.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"180.0\" x2=\"-19.5\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"176.0\" x2=\"-20.0\" y2=\"184.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"180.0\" x2=\"135.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"67.5\" y=\"210.4\" text-anchor=\"middle\" class=\"fig-etq\">AB = 12 cm</text><text x=\"-57\" y=\"93.4\" text-anchor=\"middle\" class=\"fig-etq\">AC = 16 cm</text><text x=\"60.1\" y=\"121.6\" text-anchor=\"middle\" class=\"fig-etq\">BC</text></g></svg>"
  },
  {
   "id": "129",
   "ex": 129,
   "ap": "",
   "bloc": "triangles",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un rectangle de costats 15 cm i 20 cm està inscrit en una circumferència. Quant mesura el radi de la circumferència?",
   "opcions": [
    "$12{,}5$ cm",
    "$25$ cm",
    "$625$ cm",
    "$35$ cm"
   ],
   "pistes": [
    "Quan un rectangle està inscrit en una circumferència, la seva diagonal coincideix amb un diàmetre.",
    "Calcula primer la diagonal amb Pitàgores, $d=\\sqrt{15^2+20^2}$, i després divideix-la per $2$ per obtenir el radi."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IMOpcyBlbCBEScOATUVUUkUgZGUgbGEgY2lyY3VtZmVyw6huY2lhIChsYSBkaWFnb25hbCBkZWwgcmVjdGFuZ2xlKSwgbm8gZWwgcmFkaTogZWwgcmFkaSDDqXMgbGEgbWVpdGF0IGRlbCBkacOgbWV0cmUuIiwgIkhhcyBjYWxjdWxhdCAkMTVeMisyMF4yPTYyNSQgY29ycmVjdGFtZW50LCBwZXLDsiB0J2hhcyBkZWl4YXQgbCdhcnJlbCBxdWFkcmFkYSBwZXIgdHJvYmFyIGxhIGRpYWdvbmFsIChpIGVuY2FyYSBmYWx0YXJpYSBkaXZpZGlyIHBlciAkMiQgcGVyIG9idGVuaXIgZWwgcmFkaSkuIiwgIkhhcyBzdW1hdCBkaXJlY3RhbWVudCBlbHMgZG9zIGNvc3RhdHMgKCQxNSsyMCQpIGVuIGxsb2MgZCdhcGxpY2FyIFBpdMOgZ29yZXMgcGVyIHRyb2JhciBsYSBkaWFnb25hbC4iXSwgImVyciI6IFsiIiwgIk1FSVRBVF9PQkxJREFEQSIsICJBUlJFTF9PQkxJREFEQSIsICJTVU1BX0NBVEVUU19TRU5TRV9RVUFEUkFUIl0sICJyZXMiOiBbIkRpYWdvbmFsOiAkXFxzcXJ0ezE1XjIrMjBeMn09XFxzcXJ0ezYyNX09MjUkIiwgIlJhZGk6ICRcXGRmcmFjezI1fXsyfT0xMnssfTUkIGNtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 269 196\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 20 cm per 15 cm amb la diagonal marcada.</title><g transform=\"translate(74.3,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,135.0 0.0,135.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"137.5\" x2=\"0.0\" y2=\"154.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"137.5\" x2=\"180.0\" y2=\"154.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"151.0\" x2=\"180.0\" y2=\"151.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"147.0\" x2=\"4.0\" y2=\"155.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"147.0\" x2=\"184.0\" y2=\"155.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"135.0\" x2=\"-19.5\" y2=\"135.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"135.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"131.0\" x2=\"-20.0\" y2=\"139.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"135.0\" x2=\"180.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"90\" y=\"165.4\" text-anchor=\"middle\" class=\"fig-etq\">20 cm</text><text x=\"-42\" y=\"70.9\" text-anchor=\"middle\" class=\"fig-etq\">15 cm</text><text x=\"96.6\" y=\"79.7\" text-anchor=\"middle\" class=\"fig-etq\">x</text></g></svg>"
  },
  {
   "id": "332a",
   "ex": 332,
   "ap": "a",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquest triangle rectangle.",
   "enunciat": "Els catets fan $3$ cm i $4$ cm.",
   "opcions": [
    "$6$ cm$^2$",
    "$7$ cm$^2$",
    "$12$ cm$^2$",
    "$5$ cm$^2$"
   ],
   "pistes": [
    "En un triangle rectangle, els dos catets ja fan de base i d'altura.",
    "$A=\\dfrac{3\\cdot 4}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiSGFzIHN1bWF0ICQzKzQkLiBIYXMgc3VtYXQgZWxzIGNvc3RhdHMgZGlyZWN0YW1lbnQuIFBpdMOgZ29yZXMgZGl1IHF1ZSBlcyBzdW1lbiBlbHMgc2V1cyBRVUFEUkFUUywgaSBhbCBmaW5hbCBlcyBmYSBsJ2FycmVsIGRlbCByZXN1bHRhdC4iLCAiSGFzIG11bHRpcGxpY2F0IGVscyBjYXRldHMgaSBwcm91OiAkM1xcY2RvdCA0PTEyJC4gSGkgaGEgdW4gZmFjdG9yICQyJCBwZWwgbWlnIHF1ZSB0J2hhcyBkZWl4YXQ6IHJhZGkgaSBkacOgbWV0cmUsIHNlbWliYXNlIGkgYmFzZSwgc2VtaWRpYWdvbmFsIGkgZGlhZ29uYWwuIENvbXByb3ZhIHF1aW5hIGRlIGxlcyBkdWVzIGV0IGRlbWFuZW4uIiwgIkhhcyBjYWxjdWxhdCBsYSBoaXBvdGVudXNhLCBpIGVsIHF1ZSBlcyBkZW1hbmF2YSBlcmEgbCfDoHJlYS4gVG9ybmEgYSBsbGVnaXIgbGEgcHJlZ3VudGEgYWJhbnMgZGUgY29tZW7Dp2FyOiBxdWFuIHVuIHRyaWFuZ2xlIHJlY3RhbmdsZSB0w6kgZWxzIGRvcyBjYXRldHMgZG9uYXRzLCBqYSBlbHMgdGVucyBmZXRzIGRlIGJhc2UgaSBhbHR1cmEgaSBubyBjYWwgY2FwIFBpdMOgZ29yZXMuIl0sICJlcnIiOiBbIiIsICJTVU1BX0NBVEVUU19TRU5TRV9RVUFEUkFUIiwgIk1FSVRBVF9PQkxJREFEQSIsICJISVBPVEVOVVNBX1BFUl9BUkVBIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7YlxcY2RvdCBofXsyfT1cXGRmcmFjezNcXGNkb3QgNH17Mn09NiQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 249 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 3 cm i 4 cm.</title><g transform=\"translate(64.6,14.0)\"><polygon points=\"0.0,170.0 170.0,170.0 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 170.0 L 12.0 158.0 L 0.0 158.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">3 cm</text><text x=\"-36\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">4 cm</text></g></svg>"
  },
  {
   "id": "332b",
   "ex": 332,
   "ap": "b",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquest triangle rectangle.",
   "enunciat": "Els catets fan $6$ m i $8$ m.",
   "opcions": [
    "$10$ m$^2$",
    "$48$ m$^2$",
    "$14$ m$^2$",
    "$24$ m$^2$"
   ],
   "pistes": [
    "Els catets són la base i l'altura.",
    "$A=\\dfrac{6\\cdot 8}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJIYXMgY2FsY3VsYXQgbGEgaGlwb3RlbnVzYSwgaSBlbCBxdWUgZXMgZGVtYW5hdmEgZXJhIGwnw6ByZWEuIFRvcm5hIGEgbGxlZ2lyIGxhIHByZWd1bnRhIGFiYW5zIGRlIGNvbWVuw6dhcjogcXVhbiB1biB0cmlhbmdsZSByZWN0YW5nbGUgdMOpIGVscyBkb3MgY2F0ZXRzIGRvbmF0cywgamEgZWxzIHRlbnMgZmV0cyBkZSBiYXNlIGkgYWx0dXJhIGkgbm8gY2FsIGNhcCBQaXTDoGdvcmVzLiIsICIkNlxcY2RvdCA4PTQ4JCwgaSBlbmNhcmEgZmFsdGEgZGl2aWRpciBwZXIgJDIkLiBIaSBoYSB1biBmYWN0b3IgJDIkIHBlbCBtaWcgcXVlIHQnaGFzIGRlaXhhdDogcmFkaSBpIGRpw6BtZXRyZSwgc2VtaWJhc2UgaSBiYXNlLCBzZW1pZGlhZ29uYWwgaSBkaWFnb25hbC4gQ29tcHJvdmEgcXVpbmEgZGUgbGVzIGR1ZXMgZXQgZGVtYW5lbi4iLCAiSGFzIHN1bWF0ICQ2KzgkLiBIYXMgc3VtYXQgZWxzIGNvc3RhdHMgZGlyZWN0YW1lbnQuIFBpdMOgZ29yZXMgZGl1IHF1ZSBlcyBzdW1lbiBlbHMgc2V1cyBRVUFEUkFUUywgaSBhbCBmaW5hbCBlcyBmYSBsJ2FycmVsIGRlbCByZXN1bHRhdC4iLCAiIl0sICJlcnIiOiBbIkhJUE9URU5VU0FfUEVSX0FSRUEiLCAiTUVJVEFUX09CTElEQURBIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7NlxcY2RvdCA4fXsyfT1cXGRmcmFjezQ4fXsyfT0yNCQgbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 240 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 6 m i 8 m.</title><g transform=\"translate(56.0,14.0)\"><polygon points=\"0.0,170.0 170.0,170.0 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 170.0 L 12.0 158.0 L 0.0 158.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">6 m</text><text x=\"-31\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">8 m</text></g></svg>"
  },
  {
   "id": "332c",
   "ex": 332,
   "ap": "c",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquest triangle rectangle.",
   "enunciat": "Els catets fan $5$ cm i $12$ cm.",
   "opcions": [
    "$30$ cm$^2$",
    "$60$ cm$^2$",
    "$13$ cm$^2$",
    "$17$ cm$^2$"
   ],
   "pistes": [
    "Els catets fan de base i d'altura.",
    "$A=\\dfrac{5\\cdot 12}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiJDVcXGNkb3QgMTI9NjAkOyBmYWx0YSBsYSBtZWl0YXQuIEhpIGhhIHVuIGZhY3RvciAkMiQgcGVsIG1pZyBxdWUgdCdoYXMgZGVpeGF0OiByYWRpIGkgZGnDoG1ldHJlLCBzZW1pYmFzZSBpIGJhc2UsIHNlbWlkaWFnb25hbCBpIGRpYWdvbmFsLiBDb21wcm92YSBxdWluYSBkZSBsZXMgZHVlcyBldCBkZW1hbmVuLiIsICJIYXMgY2FsY3VsYXQgbGEgaGlwb3RlbnVzYSwgaSBlbCBxdWUgZXMgZGVtYW5hdmEgZXJhIGwnw6ByZWEuIFRvcm5hIGEgbGxlZ2lyIGxhIHByZWd1bnRhIGFiYW5zIGRlIGNvbWVuw6dhcjogcXVhbiB1biB0cmlhbmdsZSByZWN0YW5nbGUgdMOpIGVscyBkb3MgY2F0ZXRzIGRvbmF0cywgamEgZWxzIHRlbnMgZmV0cyBkZSBiYXNlIGkgYWx0dXJhIGkgbm8gY2FsIGNhcCBQaXTDoGdvcmVzLiIsICJIYXMgc3VtYXQgJDUrMTIkLiBIYXMgc3VtYXQgZWxzIGNvc3RhdHMgZGlyZWN0YW1lbnQuIFBpdMOgZ29yZXMgZGl1IHF1ZSBlcyBzdW1lbiBlbHMgc2V1cyBRVUFEUkFUUywgaSBhbCBmaW5hbCBlcyBmYSBsJ2FycmVsIGRlbCByZXN1bHRhdC4iXSwgImVyciI6IFsiIiwgIk1FSVRBVF9PQkxJREFEQSIsICJISVBPVEVOVVNBX1BFUl9BUkVBIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiXSwgInJlcyI6IFsiJEE9XFxkZnJhY3s1XFxjZG90IDEyfXsyfT1cXGRmcmFjezYwfXsyfT0zMCQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 259 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 5 cm i 12 cm.</title><g transform=\"translate(74.3,14.0)\"><polygon points=\"0.0,170.0 170.0,170.0 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 170.0 L 12.0 158.0 L 0.0 158.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text><text x=\"-42\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">12 cm</text></g></svg>"
  },
  {
   "id": "131",
   "ex": 131,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "L'àrea d'un triangle rectangle és $12$ cm$^2$ i un dels catets mesura $6$ cm. Calcula la longitud de la hipotenusa.",
   "opcions": [
    "$4$ cm",
    "$2\\sqrt{13}\\approx7{,}21$ cm",
    "10 cm",
    "52 cm"
   ],
   "pistes": [
    "Aïlla primer l'altre catet a partir de l'àrea: $12=\\dfrac{6\\cdot c}{2}$.",
    "Un cop tinguis els dos catets, aplica Pitàgores per trobar la hipotenusa."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3Qgw6lzIGwnYWx0cmUgY2F0ZXQgKG9idGluZ3V0IGRlIGwnw6ByZWEpLCBubyBsYSBoaXBvdGVudXNhIHF1ZSBldCBkZW1hbmVuOiBlbmNhcmEgZmFsdGEgYXBsaWNhciBQaXTDoGdvcmVzLiIsICIiLCAiSGFzIHN1bWF0IGRpcmVjdGFtZW50IGVscyBkb3MgY2F0ZXRzICgkNis0JCkgZW4gbGxvYyBkJ2FwbGljYXIgUGl0w6Bnb3Jlcy4iLCAiSGFzIGNhbGN1bGF0ICQ2XjIrNF4yPTUyJCBjb3JyZWN0YW1lbnQsIHBlcsOyIHQnaGFzIGRlaXhhdCBsJ2FycmVsIHF1YWRyYWRhIGZpbmFsLiJdLCAiZXJyIjogWyJQQVNfSU5URVJNRURJX1BFUl9SRVNQT1NUQSIsICIiLCAiU1VNQV9DQVRFVFNfU0VOU0VfUVVBRFJBVCIsICJBUlJFTF9PQkxJREFEQSJdLCAicmVzIjogWyJBbHRyZSBjYXRldDogJDEyPVxcZGZyYWN7NlxcY2RvdCBjfXsyfVxcUmlnaHRhcnJvdyBjPTQkIGNtIiwgIkhpcG90ZW51c2E6ICRcXHNxcnR7Nl4yKzReMn09XFxzcXJ0ezUyfT0yXFxzcXJ0ezEzfVxcYXBwcm94N3ssfTIxJCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 229 175\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 6 cm i ?.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,113.3 170.0,113.3 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 113.3 L 12.0 101.3 L 0.0 101.3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"115.8\" x2=\"0.0\" y2=\"132.8\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"115.8\" x2=\"170.0\" y2=\"132.8\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"129.3\" x2=\"170.0\" y2=\"129.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"125.3\" x2=\"4.0\" y2=\"133.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"125.3\" x2=\"174.0\" y2=\"133.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"113.3\" x2=\"-19.5\" y2=\"113.3\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"113.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"109.3\" x2=\"-20.0\" y2=\"117.3\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"170.0\" y1=\"113.3\" x2=\"0.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><text x=\"85\" y=\"143.7\" text-anchor=\"middle\" class=\"fig-etq\">6 cm</text><text x=\"-27\" y=\"60\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"91.1\" y=\"50.9\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "132",
   "ex": 132,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Busca l'àrea d'un triangle equilàter de perímetre $90$ cm.",
   "opcions": [
    "$900$ cm$^2$",
    "$30$ cm$^2$",
    "$450$ cm$^2$",
    "$225\\sqrt3\\approx389{,}71$ cm$^2$"
   ],
   "pistes": [
    "Calcula primer el costat: $\\dfrac{90}{3}=30$ cm.",
    "Fes servir la fórmula $A=\\dfrac{L^2\\sqrt3}{4}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gc3VydCBkZSBsYSBmw7NybXVsYSAkQT1cXGRmcmFje0xeMlxcc3FydDN9ezR9JDogcmV2aXNhIHF1ZSBoYXMgZWxldmF0IGVsIGNvc3RhdCBhbCBxdWFkcmF0LCBtdWx0aXBsaWNhdCBwZXIgJFxcc3FydDMkIGkgZGl2aWRpdCBwZXIgJDQkLiIsICJBcXVlc3Qgw6lzIGVsIGNvc3RhdCBkZWwgdHJpYW5nbGUgKCQ5MDozJCksIG5vIGwnw6ByZWE6IGVuY2FyYSBjYWwgYXBsaWNhciBsYSBmw7NybXVsYSBkZSBsJ8OgcmVhIGRlbCB0cmlhbmdsZSBlcXVpbMOgdGVyLiIsICJBcXVlc3QgdmFsb3Igbm8gaW5jbG91IGVsIGZhY3RvciAkXFxzcXJ0MyQgZGUgbGEgZsOzcm11bGEgJEE9XFxkZnJhY3tMXjJcXHNxcnQzfXs0fSQ6IHNlbWJsYSBxdWUgaGFzIGNhbGN1bGF0ICRcXGRmcmFjezMwXjJ9ezJ9JCBlbiBsbG9jIGRlICRcXGRmcmFjezMwXjJcXHNxcnQzfXs0fSQuIiwgIiJdLCAiZXJyIjogWyJQT1RFTkNJQV9ERV9TVU1BIiwgIlBBU19JTlRFUk1FRElfUEVSX1JFU1BPU1RBIiwgIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIiwgIiJdLCAicmVzIjogWyJDb3N0YXQ6ICRcXGRmcmFjezkwfXszfT0zMCQgY20iLCAiJEE9XFxkZnJhY3szMF4yXFxzcXJ0M317NH09XFxkZnJhY3s5MDBcXHNxcnQzfXs0fT0yMjVcXHNxcnQzXFxhcHByb3gzODl7LH03MSQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 184 163\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle equilàter de 3 costats.</title><g transform=\"translate(91.9,104.0)\"><polygon points=\"77.9,45.0 -77.9,45.0 -0.0,-90.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/></g></svg>"
  },
  {
   "id": "134",
   "ex": 134,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Busca l'àrea d'un triangle rectangle d'hipotenusa $13$ cm, si un dels catets mesura $5$ cm.",
   "opcions": [
    "$30$ cm$^2$",
    "$12$ cm$^2$",
    "$60$ cm$^2$",
    "$32{,}5$ cm$^2$"
   ],
   "pistes": [
    "Troba primer l'altre catet amb Pitàgores: $\\sqrt{13^2-5^2}$.",
    "L'àrea d'un triangle rectangle és $\\dfrac{\\text{catet}_1\\cdot\\text{catet}_2}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IMOpcyBsJ2FsdHJlIGNhdGV0IChvYnRpbmd1dCBhbWIgUGl0w6Bnb3JlcyksIG5vIGwnw6ByZWEgcXVlIGV0IGRlbWFuZW46IGVuY2FyYSBmYWx0YSBhcGxpY2FyIGxhIGbDs3JtdWxhIGRlIGwnw6ByZWEgZGVsIHRyaWFuZ2xlLiIsICJBcXVlc3QgdmFsb3Igbm8gZGl2aWRlaXggcGVyICQyJCBlbCBwcm9kdWN0ZSBkZWxzIGNhdGV0czogbCfDoHJlYSBkJ3VuIHRyaWFuZ2xlIMOpcyAkXFxkZnJhY3tcXHRleHR7YmFzZX1cXGNkb3RcXHRleHR7YWzDp2FkYX19ezJ9JCwgbm8gZWwgcHJvZHVjdGUgc2VuY2VyLiIsICJBcXVlc3QgdmFsb3Igc2VtYmxhIGZldCBzZXJ2aXIgbGEgaGlwb3RlbnVzYSAoJDEzJCkgY29tIHNpIGZvcyB1biBjYXRldDogZWwgc2Vnb24gY2F0ZXQgcydoYSBkJ29idGVuaXIgYW1iIFBpdMOgZ29yZXMgYSBwYXJ0aXIgZGUgbGEgaGlwb3RlbnVzYSBpIGVsIGNhdGV0IGRvbmF0LCAkXFxzcXJ0ezEzXjItNV4yfSQuIl0sICJlcnIiOiBbIiIsICJQQVNfSU5URVJNRURJX1BFUl9SRVNQT1NUQSIsICJBUlJFTF9GQUNUT1JfT0JMSURBVCIsICJDQVRFVF9NQUxfSURFTlRJRklDQVQiXSwgInJlcyI6IFsiQWx0cmUgY2F0ZXQ6ICRcXHNxcnR7MTNeMi01XjJ9PVxcc3FydHsxNDR9PTEyJCBjbSIsICLDgHJlYTogJFxcZGZyYWN7NVxcY2RvdDEyfXsyfT0zMCQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 229 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 5 cm i ?.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,170.0 170.0,170.0 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 170.0 L 12.0 158.0 L 0.0 158.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"170.0\" y1=\"170.0\" x2=\"0.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text><text x=\"-27\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"99.1\" y=\"74.2\" text-anchor=\"middle\" class=\"fig-etq\">13 cm</text></g></svg>"
  },
  {
   "id": "135",
   "ex": 135,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Calcula l'àrea d'un quadrat sabent que la seva diagonal mesura $7{,}07$ cm.",
   "opcions": [
    "$3{,}54$ cm$^2$",
    "$24{,}99$ cm$^2$",
    "$49{,}98$ cm$^2$",
    "$14{,}14$ cm$^2$"
   ],
   "pistes": [
    "La diagonal d'un quadrat es relaciona amb l'àrea per $A=\\dfrac{d^2}{2}$ (surt d'aplicar Pitàgores als dos triangles en què la diagonal el divideix).",
    "Calcula $\\dfrac{7{,}07^2}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc2VtYmxhIGxhIG1laXRhdCBkZSBsYSBkaWFnb25hbCwgbm8gbCfDoHJlYTogY2FsIGVsZXZhciBsYSBkaWFnb25hbCBhbCBxdWFkcmF0IGFiYW5zIGRlIGRpdmlkaXIgcGVyICQyJC4iLCAiIiwgIkFxdWVzdCB2YWxvciBubyBkaXZpZGVpeCBwZXIgJDIkOiBsJ8OgcmVhIGQndW4gcXVhZHJhdCBhIHBhcnRpciBkZSBsYSBkaWFnb25hbCDDqXMgJFxcZGZyYWN7ZF4yfXsyfSQsIG5vICRkXjIkIHNlbmNlci4iLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgZHVwbGljYXIgbGEgZGlhZ29uYWwsIG5vIGQnZWxldmFyLWxhIGFsIHF1YWRyYXQgaSBkaXZpZGlyIHBlciAkMiQ6IHJldmlzYSBsYSBmw7NybXVsYSAkQT1cXGRmcmFje2ReMn17Mn0kLiJdLCAiZXJyIjogWyJJTlZFUlRJREEiLCAiIiwgIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIiwgIlNVTUFfRU5fTExPQ19SRVNUQSJdLCAicmVzIjogWyIkQT1cXGRmcmFjezd7LH0wN14yfXsyfT1cXGRmcmFjezQ5eyx9OTg0OX17Mn1cXGFwcHJveDI0eyx9OTkkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 148 181\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de costat ? amb la diagonal marcada.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,0.0 120.0,0.0 120.0,120.0 0.0,120.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"120.0\" x2=\"120.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"122.5\" x2=\"0.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"122.5\" x2=\"120.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"136.0\" x2=\"120.0\" y2=\"136.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"132.0\" x2=\"4.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"116.0\" y1=\"132.0\" x2=\"124.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"60\" y=\"150.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"78.4\" y=\"81.7\" text-anchor=\"middle\" class=\"fig-etq\">7,07 cm</text></g></svg>"
  },
  {
   "id": "136",
   "ex": 136,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Troba l'àrea d'un rectangle de diagonal $\\sqrt{41}$ cm i un dels costats de $4$ cm.",
   "opcions": [
    "$\\sqrt{41}$ cm$^2$",
    "$20$ cm$^2$",
    "$5$ cm$^2$",
    "$9$ cm$^2$"
   ],
   "pistes": [
    "Troba primer l'altre costat amb Pitàgores: $\\sqrt{41-4^2}$.",
    "L'àrea d'un rectangle és el producte dels dos costats."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJMJ8OgcmVhIG5vIMOpcyBsYSBkaWFnb25hbDogY2FsIHRyb2JhciBwcmltZXIgbCdhbHRyZSBjb3N0YXQgYW1iIFBpdMOgZ29yZXMsICRcXHNxcnR7NDEtNF4yfSQsIGkgZGVzcHLDqXMgbXVsdGlwbGljYXItbG8gcGVsIGNvc3RhdCBkZSAkNCQgY20uIiwgIiIsICJBcXVlc3Qgw6lzIGwnYWx0cmUgY29zdGF0IChvYnRpbmd1dCBhbWIgUGl0w6Bnb3JlcyksIG5vIGwnw6ByZWE6IGVuY2FyYSBmYWx0YSBtdWx0aXBsaWNhciBlbHMgZG9zIGNvc3RhdHMuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIHN1bWFyICQ0JCBpIGwnYWx0cmUgY29zdGF0ICgkNCs1JCkgZW4gbGxvYyBkZSBtdWx0aXBsaWNhci1sb3M6IGwnw6ByZWEgZCd1biByZWN0YW5nbGUgw6lzIGVsIFBST0RVQ1RFIGRlbHMgZG9zIGNvc3RhdHMsIG5vIGxhIHNldmEgc3VtYS4iXSwgImVyciI6IFsiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIiIsICJQQVNfSU5URVJNRURJX1BFUl9SRVNQT1NUQSIsICJTVU1BX0VOX0xMT0NfUkVTVEEiXSwgInJlcyI6IFsiQWx0cmUgY29zdGF0OiAkXFxzcXJ0ezQxLTReMn09XFxzcXJ0ezI1fT01JCBjbSIsICLDgHJlYTogJDRcXGNkb3Q1PTIwJCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 203 241\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 4 cm per ? amb la diagonal marcada.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,0.0 144.0,0.0 144.0,180.0 0.0,180.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"182.5\" x2=\"0.0\" y2=\"199.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"144.0\" y1=\"182.5\" x2=\"144.0\" y2=\"199.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"196.0\" x2=\"144.0\" y2=\"196.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"192.0\" x2=\"4.0\" y2=\"200.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"140.0\" y1=\"192.0\" x2=\"148.0\" y2=\"200.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"180.0\" x2=\"-19.5\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"176.0\" x2=\"-20.0\" y2=\"184.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"180.0\" x2=\"144.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"72\" y=\"210.4\" text-anchor=\"middle\" class=\"fig-etq\">4 cm</text><text x=\"-27\" y=\"93.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"92.3\" y=\"109.6\" text-anchor=\"middle\" class=\"fig-etq\">√41 cm</text></g></svg>"
  },
  {
   "id": "137",
   "ex": 137,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Calcula l'àrea d'un rectangle de $10$ cm de base i amb diagonal $\\sqrt{116}$ cm.",
   "opcions": [
    "$40$ cm$^2$",
    "$4$ cm$^2$",
    "$\\sqrt{116}$ cm$^2$",
    "$14$ cm$^2$"
   ],
   "pistes": [
    "Troba primer l'alçada amb Pitàgores: $\\sqrt{116-10^2}$.",
    "L'àrea d'un rectangle és base per alçada."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0YSDDqXMgbCdhbMOnYWRhIChvYnRpbmd1ZGEgYW1iIFBpdMOgZ29yZXMpLCBubyBsJ8OgcmVhOiBlbmNhcmEgZmFsdGEgbXVsdGlwbGljYXItbGEgcGVyIGxhIGJhc2UuIiwgIkwnw6ByZWEgbm8gw6lzIGxhIGRpYWdvbmFsOiBjYWwgdHJvYmFyIHByaW1lciBsJ2Fsw6dhZGEgYW1iIFBpdMOgZ29yZXMsICRcXHNxcnR7MTE2LTEwXjJ9JCwgaSBkZXNwcsOpcyBtdWx0aXBsaWNhci1sYSBwZXIgbGEgYmFzZSBkZSAkMTAkIGNtLiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSBzdW1hciBsYSBiYXNlIGkgbCdhbMOnYWRhICgkMTArNCQpIGVuIGxsb2MgZGUgbXVsdGlwbGljYXItbGVzOiBsJ8OgcmVhIGQndW4gcmVjdGFuZ2xlIMOpcyBlbCBwcm9kdWN0ZSBkZWxzIGRvcyBjb3N0YXRzLiJdLCAiZXJyIjogWyIiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIlNVTUFfRU5fTExPQ19SRVNUQSJdLCAicmVzIjogWyJBbMOnYWRhOiAkXFxzcXJ0ezExNi0xMF4yfT1cXHNxcnR7MTZ9PTQkIGNtIiwgIsOAcmVhOiAkMTBcXGNkb3Q0PTQwJCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 239 133\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 10 cm per ? amb la diagonal marcada.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,72.0 0.0,72.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"74.5\" x2=\"0.0\" y2=\"91.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"74.5\" x2=\"180.0\" y2=\"91.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"88.0\" x2=\"180.0\" y2=\"88.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"84.0\" x2=\"4.0\" y2=\"92.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"84.0\" x2=\"184.0\" y2=\"92.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"72.0\" x2=\"-19.5\" y2=\"72.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"72.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"68.0\" x2=\"-20.0\" y2=\"76.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"72.0\" x2=\"180.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><text x=\"90\" y=\"102.4\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"-27\" y=\"39.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"97.4\" y=\"57.9\" text-anchor=\"middle\" class=\"fig-etq\">√116 cm</text></g></svg>"
  },
  {
   "id": "138",
   "ex": 138,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Determina l'àrea d'un rectangle de base $7$ cm i perímetre $24$ cm.",
   "opcions": [
    "$8{,}5$ cm$^2$",
    "$5$ cm$^2$",
    "$168$ cm$^2$",
    "$35$ cm$^2$"
   ],
   "pistes": [
    "El perímetre és $2(\\text{base}+\\text{alçada})$: aïlla l'alçada.",
    "Amb perímetre $24$ i base $7$: alçada $=\\dfrac{24}{2}-7$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc3VydCBkZSAkXFxkZnJhY3syNH17Mn0tNyQgbWFsYW1lbnQgY2FsY3VsYXQsIG8gZGUgbm8gcmVzdGFyIGxhIGJhc2UgYWJhbnMgZGUgZGl2aWRpcjogZWwgcGVyw61tZXRyZSDDqXMgJDIoXFx0ZXh0e2Jhc2V9K1xcdGV4dHthbMOnYWRhfSkkLCBhaXjDrSBxdWUgJFxcdGV4dHthbMOnYWRhfT1cXGRmcmFjezI0fXsyfS03JC4iLCAiQXF1ZXN0YSDDqXMgbCdhbMOnYWRhIChvYnRpbmd1ZGEgZGVsIHBlcsOtbWV0cmUpLCBubyBsJ8OgcmVhOiBlbmNhcmEgZmFsdGEgbXVsdGlwbGljYXItbGEgcGVyIGxhIGJhc2UuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIG11bHRpcGxpY2FyIGxhIGJhc2UgcGVsIHBlcsOtbWV0cmUgc2VuY2VyICgkN1xcY2RvdDI0JCksIG5vIHBlciBsJ2Fsw6dhZGE6IHByaW1lciBjYWwgYcOvbGxhciBsJ2Fsw6dhZGEgZGVsIHBlcsOtbWV0cmUuIiwgIiJdLCAiZXJyIjogWyJJTlZFUlRJREEiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiU1VNQV9FTl9MTE9DX1JFU1RBIiwgIiJdLCAicmVzIjogWyJBbMOnYWRhOiAkXFxkZnJhY3syNH17Mn0tNz0xMi03PTUkIGNtIiwgIsOAcmVhOiAkN1xcY2RvdDU9MzUkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 239 190\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 7 cm per ?.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,128.6 0.0,128.6\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"131.1\" x2=\"0.0\" y2=\"148.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"131.1\" x2=\"180.0\" y2=\"148.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"144.6\" x2=\"180.0\" y2=\"144.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"140.6\" x2=\"4.0\" y2=\"148.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"140.6\" x2=\"184.0\" y2=\"148.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"128.6\" x2=\"-19.5\" y2=\"128.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"128.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"124.6\" x2=\"-20.0\" y2=\"132.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"90\" y=\"158.9\" text-anchor=\"middle\" class=\"fig-etq\">7 cm</text><text x=\"-27\" y=\"67.6\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "130",
   "ex": 130,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "L'àrea d'un triangle isòsceles és $24$ m$^2$ i el costat desigual (la base) mesura $6$ m. Troba la longitud dels altres dos costats.",
   "opcions": [
    "$\\sqrt{73}\\approx8{,}54$ m",
    "11 m",
    "$8$ m",
    "73 m"
   ],
   "pistes": [
    "Aïlla primer l'alçada a partir de l'àrea: $24=\\dfrac{6\\cdot h}{2}$.",
    "L'alçada, la semibase ($3$ m) i el costat lateral (com a hipotenusa) formen un triangle rectangle: aplica Pitàgores."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiSGFzIHN1bWF0IGRpcmVjdGFtZW50IGxhIHNlbWliYXNlIGkgbCdhbMOnYWRhICgkMys4JCkgZW4gbGxvYyBkJ2FwbGljYXIgUGl0w6Bnb3Jlcy4iLCAiQXF1ZXN0YSDDqXMgbCdhbMOnYWRhIGRlbCB0cmlhbmdsZSAob2J0aW5ndWRhIGRlIGwnw6ByZWEpLCBubyBlbCBjb3N0YXQgbGF0ZXJhbCBxdWUgZXQgZGVtYW5lbjogZW5jYXJhIGZhbHRhIGFwbGljYXIgUGl0w6Bnb3JlcyBhbWIgbGEgc2VtaWJhc2UuIiwgIkhhcyBjYWxjdWxhdCAkM14yKzheMj03MyQgY29ycmVjdGFtZW50LCBwZXLDsiB0J2hhcyBkZWl4YXQgbCdhcnJlbCBxdWFkcmFkYSBmaW5hbC4iXSwgImVyciI6IFsiIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiQVJSRUxfT0JMSURBREEiXSwgInJlcyI6IFsiQWzDp2FkYTogJDI0PVxcZGZyYWN7NlxcY2RvdCBofXsyfVxcUmlnaHRhcnJvdyBoPTgkIG0iLCAiQ29zdGF0IGxhdGVyYWw6ICRcXHNxcnR7M14yKzheMn09XFxzcXJ0ezczfVxcYXBwcm94OHssfTU0JCBtIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 198 221\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle isòsceles de base 6 m, costats iguals ?, alçada ?.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,160.0 170.0,160.0 85.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"160.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 94.0 160.0 L 94.0 151.0 L 85.0 151.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"162.5\" x2=\"0.0\" y2=\"179.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"162.5\" x2=\"170.0\" y2=\"179.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"176.0\" x2=\"170.0\" y2=\"176.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"172.0\" x2=\"4.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"172.0\" x2=\"174.0\" y2=\"180.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"190.4\" text-anchor=\"middle\" class=\"fig-etq\">6 m</text><text x=\"52.2\" y=\"88.5\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"96\" y=\"83.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text></g></svg>"
  },
  {
   "id": "133",
   "ex": 133,
   "ap": "",
   "bloc": "arees_pit",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Si l'àrea d'un triangle equilàter és $30$ cm$^2$, troba la longitud del seu costat.",
   "opcions": [
    "$\\sqrt{120}\\approx10{,}95$ cm",
    "$\\sqrt{40\\sqrt3}\\approx8{,}32$ cm",
    "$\\dfrac{30^2\\sqrt3}{4}$ cm",
    "$40\\sqrt3\\approx69{,}28$ cm"
   ],
   "pistes": [
    "Aïlla $L^2$ de la fórmula $A=\\dfrac{L^2\\sqrt3}{4}$: $L^2=\\dfrac{4A}{\\sqrt3}$.",
    "Amb $A=30$: $L^2=\\dfrac{120}{\\sqrt3}=40\\sqrt3$; després fes l'arrel quadrada."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJFbiBhw69sbGFyICRMXjIkIGRlICQzMD1cXGRmcmFje0xeMlxcc3FydDN9ezR9JCBubyBuJ2hpIGhhIHByb3UgYW1iIG11bHRpcGxpY2FyIHBlciAkNCQgKCRMXjI9MTIwJCk6IGVuY2FyYSBjYWwgZGl2aWRpciBwZXIgJFxcc3FydDMkIGFiYW5zIGRlIGZlciBsJ2FycmVsLiIsICIiLCAiQXF1ZXN0YSBleHByZXNzacOzIGNvcnJlc3BvbiBhIGwnw4BSRUEgYSBwYXJ0aXIgZGVsIGNvc3RhdCAobGEgZsOzcm11bGEgb3JpZ2luYWwpLCBubyBhbCBjb3N0YXQgYSBwYXJ0aXIgZGUgbCfDoHJlYTogY2FsIGHDr2xsYXIgJEwkIGRlIGxhIGbDs3JtdWxhLCBubyBhcGxpY2FyLWxhIHRhbCBxdWFsIGFtYiAkMzAkIGNvbSBzaSBmb3MgZWwgY29zdGF0LiIsICJBcXVlc3Qgw6lzIGVsIHZhbG9yIGRlICRMXjIkIChlbmNhcmEgYWwgcXVhZHJhdCksIG5vIGRlICRMJDogZXQgZmFsdGEgZmVyIGwnYXJyZWwgcXVhZHJhZGEgZmluYWwuIl0sICJlcnIiOiBbIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIiwgIiIsICJJTlZFUlRJREEiLCAiQVJSRUxfT0JMSURBREEiXSwgInJlcyI6IFsiJExeMj1cXGRmcmFjezRcXGNkb3QzMH17XFxzcXJ0M309XFxkZnJhY3sxMjB9e1xcc3FydDN9PTQwXFxzcXJ0MyQiLCAiJEw9XFxzcXJ0ezQwXFxzcXJ0M31cXGFwcHJveDh7LH0zMiQgY20iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 184 163\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle equilàter de 3 costats.</title><g transform=\"translate(91.9,104.0)\"><polygon points=\"77.9,45.0 -77.9,45.0 -0.0,-90.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/></g></svg>"
  },
  {
   "id": "333a",
   "ex": 333,
   "ap": "a",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquesta figura.",
   "enunciat": "Rectangle de $7$ cm de base i $4$ cm d'altura.",
   "opcions": [
    "$11$ cm$^2$",
    "$14$ cm$^2$",
    "$28$ cm$^2$",
    "$22$ cm$^2$"
   ],
   "pistes": [
    "L'àrea del rectangle és base per altura.",
    "$A=7\\cdot 4$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgc3VtYXQgJDcrNCQgZW4gbGxvYyBkZSBtdWx0aXBsaWNhci4gSGFzIHN1bWF0IGVscyBjb3N0YXRzIGRpcmVjdGFtZW50LiBQaXTDoGdvcmVzIGRpdSBxdWUgZXMgc3VtZW4gZWxzIHNldXMgUVVBRFJBVFMsIGkgYWwgZmluYWwgZXMgZmEgbCdhcnJlbCBkZWwgcmVzdWx0YXQuIiwgIkhhcyBkaXZpZGl0IHBlciAkMiQuIEVsIG1pZyDDqXMgZGUgbGEgZsOzcm11bGEgZGVsIHRyaWFuZ2xlOyBlbCByZWN0YW5nbGUgbm8gZW4gcG9ydGEuIEhhcyBkaXZpZGl0IG9uIGxhIGbDs3JtdWxhIG11bHRpcGxpY2EgKG8gYWwgcmV2w6lzKS4gRXNjcml1IGxhIGbDs3JtdWxhIHNlbmNlcmEgYWJhbnMgZGUgc3Vic3RpdHVpci1oaSBlbHMgdmFsb3JzLiIsICIiLCAiJDcrNCs3KzQ9MjIkIMOpcyBsYSB2b3JhLCBubyBsYSBzdXBlcmbDrWNpZS4gSGFzIHN1bWF0IGVscyBjb3N0YXRzOiBhaXjDsiDDqXMgZWwgcGVyw61tZXRyZSwgbm8gbCfDoHJlYS4gRWwgcGVyw61tZXRyZSDDqXMgZWwgcXVlIGZhIGxhIHZvcmEgaSBlcyBtZXN1cmEgZW4gY20gbyBtOyBsJ8OgcmVhIMOpcyBsYSBzdXBlcmbDrWNpZSBkZSBkaW5zIGkgZXMgbWVzdXJhIGVuIGNtwrIgbyBtwrIuIl0sICJlcnIiOiBbIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiRk9STVVMQV9JTlZFUlRJREEiLCAiIiwgIlBFUklNRVRSRV9QRVJfQVJFQSJdLCAicmVzIjogWyIkQT1iXFxjZG90IGg9N1xcY2RvdCA0PTI4JCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 259 164\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rectangle de 7 cm per 4 cm.</title><g transform=\"translate(64.6,14.0)\"><polygon points=\"0.0,0.0 180.0,0.0 180.0,102.9 0.0,102.9\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"105.4\" x2=\"0.0\" y2=\"122.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"180.0\" y1=\"105.4\" x2=\"180.0\" y2=\"122.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"118.9\" x2=\"180.0\" y2=\"118.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"114.9\" x2=\"4.0\" y2=\"122.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"176.0\" y1=\"114.9\" x2=\"184.0\" y2=\"122.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"102.9\" x2=\"-19.5\" y2=\"102.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"102.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"98.9\" x2=\"-20.0\" y2=\"106.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"90\" y=\"133.2\" text-anchor=\"middle\" class=\"fig-etq\">7 cm</text><text x=\"-36\" y=\"54.8\" text-anchor=\"middle\" class=\"fig-etq\">4 cm</text></g></svg>"
  },
  {
   "id": "333b",
   "ex": 333,
   "ap": "b",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquesta figura.",
   "enunciat": "Quadrat de $9$ m de costat.",
   "opcions": [
    "$40{,}5$ m$^2$",
    "$36$ m$^2$",
    "$81$ m$^2$",
    "$18$ m$^2$"
   ],
   "pistes": [
    "Un quadrat és un rectangle amb la base i l'altura iguals.",
    "$A=9\\cdot 9=9^2$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJIYXMgZGl2aWRpdCBwZXIgJDIkLCBpIGxhIGbDs3JtdWxhIGRlbCBxdWFkcmF0IG5vIGhvIHBvcnRhLiBIYXMgZGl2aWRpdCBvbiBsYSBmw7NybXVsYSBtdWx0aXBsaWNhIChvIGFsIHJldsOpcykuIEVzY3JpdSBsYSBmw7NybXVsYSBzZW5jZXJhIGFiYW5zIGRlIHN1YnN0aXR1aXItaGkgZWxzIHZhbG9ycy4iLCAiJDRcXGNkb3QgOT0zNiQgw6lzIGVsIHBlcsOtbWV0cmUuIEhhcyBzdW1hdCBlbHMgY29zdGF0czogYWl4w7Igw6lzIGVsIHBlcsOtbWV0cmUsIG5vIGwnw6ByZWEuIEVsIHBlcsOtbWV0cmUgw6lzIGVsIHF1ZSBmYSBsYSB2b3JhIGkgZXMgbWVzdXJhIGVuIGNtIG8gbTsgbCfDoHJlYSDDqXMgbGEgc3VwZXJmw61jaWUgZGUgZGlucyBpIGVzIG1lc3VyYSBlbiBjbcKyIG8gbcKyLiIsICIiLCAiSGFzIGNhbGN1bGF0ICQyXFxjZG90IDkkLiBFbCBxdWFkcmF0IGRlbCBjb3N0YXQgw6lzICQ5XFxjZG90IDkkLCBubyAkOSs5JC4gTCdleHBvbmVudCBubyBjb3JyZXNwb24gYSBsYSBkaW1lbnNpw7M6IGxlcyDDoHJlZXMgdmFuIGFsIHF1YWRyYXQgaSBlbHMgdm9sdW1zLCBhbCBjdWIuIENvbXByb3ZhIHRhbWLDqSBsZXMgdW5pdGF0cyBkZWwgcmVzdWx0YXQuIl0sICJlcnIiOiBbIkZPUk1VTEFfSU5WRVJUSURBIiwgIlBFUklNRVRSRV9QRVJfQVJFQSIsICIiLCAiRElNRU5TSU9fRVhQT05FTlRfTUFMIl0sICJyZXMiOiBbIiRBPUxeMj05XjI9ODEkIG0kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 168 201\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de costat 9 m.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,0.0 140.0,0.0 140.0,140.0 0.0,140.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"142.5\" x2=\"0.0\" y2=\"159.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"140.0\" y1=\"142.5\" x2=\"140.0\" y2=\"159.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"156.0\" x2=\"140.0\" y2=\"156.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"152.0\" x2=\"4.0\" y2=\"160.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"136.0\" y1=\"152.0\" x2=\"144.0\" y2=\"160.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"70\" y=\"170.4\" text-anchor=\"middle\" class=\"fig-etq\">9 m</text></g></svg>"
  },
  {
   "id": "333c",
   "ex": 333,
   "ap": "c",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquesta figura.",
   "enunciat": "Romboide de $10$ cm de base i $3$ cm d'altura.",
   "opcions": [
    "$15$ cm$^2$",
    "$13$ cm$^2$",
    "$26$ cm$^2$",
    "$30$ cm$^2$"
   ],
   "pistes": [
    "El romboide es converteix en un rectangle movent el triangle d'un costat a l'altre: l'àrea és base per altura.",
    "L'altura és el segment perpendicular de puntets, no el costat inclinat. $A=10\\cdot 3$."
   ],
   "nota": "L'altura d'un romboide és el segment perpendicular a la base (el de puntets), no el costat inclinat.",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXXDrSBwYXNzYSBhbCBjb250cmFyaSBkZWwgcXVlIMOpcyBoYWJpdHVhbDogaGFzIGRpdmlkaXQgcGVyICQyJCBxdWFuIE5PIHRvY2F2YS4gRWwgbWlnIMOpcyBkZSBsYSBmw7NybXVsYSBkZWwgdHJpYW5nbGU7IGVsIHJvbWJvaWRlLCBjb20gZWwgcmVjdGFuZ2xlLCDDqXMgYmFzZSBwZXIgYWx0dXJhLiBIaSBoYSB1biBmYWN0b3IgJDIkIHBlbCBtaWcgcXVlIHQnaGFzIGRlaXhhdDogcmFkaSBpIGRpw6BtZXRyZSwgc2VtaWJhc2UgaSBiYXNlLCBzZW1pZGlhZ29uYWwgaSBkaWFnb25hbC4gQ29tcHJvdmEgcXVpbmEgZGUgbGVzIGR1ZXMgZXQgZGVtYW5lbi4iLCAiSGFzIHN1bWF0ICQxMCszJCBlbiBsbG9jIGRlIG11bHRpcGxpY2FyLiBIYXMgc3VtYXQgZWxzIGNvc3RhdHMgZGlyZWN0YW1lbnQuIFBpdMOgZ29yZXMgZGl1IHF1ZSBlcyBzdW1lbiBlbHMgc2V1cyBRVUFEUkFUUywgaSBhbCBmaW5hbCBlcyBmYSBsJ2FycmVsIGRlbCByZXN1bHRhdC4iLCAiSGFzIHN1bWF0IGNvc3RhdHMuIEhhcyBzdW1hdCBlbHMgY29zdGF0czogYWl4w7Igw6lzIGVsIHBlcsOtbWV0cmUsIG5vIGwnw6ByZWEuIEVsIHBlcsOtbWV0cmUgw6lzIGVsIHF1ZSBmYSBsYSB2b3JhIGkgZXMgbWVzdXJhIGVuIGNtIG8gbTsgbCfDoHJlYSDDqXMgbGEgc3VwZXJmw61jaWUgZGUgZGlucyBpIGVzIG1lc3VyYSBlbiBjbcKyIG8gbcKyLiIsICIiXSwgImVyciI6IFsiTUVJVEFUX09CTElEQURBIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiUEVSSU1FVFJFX1BFUl9BUkVBIiwgIiJdLCAicmVzIjogWyIkQT1iXFxjZG90IGg9MTBcXGNkb3QgMz0zMCQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 196 116\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Romboide de base 10 cm i altura 3 cm. L'altura es dibuixa com un segment perpendicular a la base, no com el costat inclinat.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,55.0 150.0,55.0 167.6,0.0 17.6,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"17.6\" y1=\"0.0\" x2=\"17.6\" y2=\"55.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.6\" stroke-dasharray=\"4 3\"/><path d=\"M 26.6 55.0 L 26.6 46.0 L 17.6 46.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"57.5\" x2=\"0.0\" y2=\"74.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"150.0\" y1=\"57.5\" x2=\"150.0\" y2=\"74.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"71.0\" x2=\"150.0\" y2=\"71.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"67.0\" x2=\"4.0\" y2=\"75.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"146.0\" y1=\"67.0\" x2=\"154.0\" y2=\"75.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"75\" y=\"85.4\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"37.6\" y=\"30.9\" text-anchor=\"middle\" class=\"fig-etq\">3 cm</text></g></svg>"
  },
  {
   "id": "333d",
   "ex": 333,
   "ap": "d",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 1,
   "encapcalament": "Calcula l'àrea d'aquesta figura.",
   "enunciat": "Rombe de diagonals $8$ cm i $6$ cm.",
   "opcions": [
    "$48$ cm$^2$",
    "$28$ cm$^2$",
    "$14$ cm$^2$",
    "$24$ cm$^2$"
   ],
   "pistes": [
    "L'àrea del rombe és el producte de les diagonals partit per dos.",
    "$A=\\dfrac{8\\cdot 6}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyIkOFxcY2RvdCA2PTQ4JDsgbGEgZsOzcm11bGEgZGVsIHJvbWJlIHPDrSBxdWUgcG9ydGEgZWwgbWlnLiBIaSBoYSB1biBmYWN0b3IgJDIkIHBlbCBtaWcgcXVlIHQnaGFzIGRlaXhhdDogcmFkaSBpIGRpw6BtZXRyZSwgc2VtaWJhc2UgaSBiYXNlLCBzZW1pZGlhZ29uYWwgaSBkaWFnb25hbC4gQ29tcHJvdmEgcXVpbmEgZGUgbGVzIGR1ZXMgZXQgZGVtYW5lbi4iLCAiSGFzIGNvbmbDs3MgbGVzIGRpYWdvbmFscyBhbWIgZWxzIGNvc3RhdHMuIEhhcyBzdW1hdCBlbHMgY29zdGF0czogYWl4w7Igw6lzIGVsIHBlcsOtbWV0cmUsIG5vIGwnw6ByZWEuIEVsIHBlcsOtbWV0cmUgw6lzIGVsIHF1ZSBmYSBsYSB2b3JhIGkgZXMgbWVzdXJhIGVuIGNtIG8gbTsgbCfDoHJlYSDDqXMgbGEgc3VwZXJmw61jaWUgZGUgZGlucyBpIGVzIG1lc3VyYSBlbiBjbcKyIG8gbcKyLiIsICJIYXMgc3VtYXQgbGVzIGRpYWdvbmFscy4gSGFzIHN1bWF0IGVscyBjb3N0YXRzIGRpcmVjdGFtZW50LiBQaXTDoGdvcmVzIGRpdSBxdWUgZXMgc3VtZW4gZWxzIHNldXMgUVVBRFJBVFMsIGkgYWwgZmluYWwgZXMgZmEgbCdhcnJlbCBkZWwgcmVzdWx0YXQuIiwgIiJdLCAiZXJyIjogWyJNRUlUQVRfT0JMSURBREEiLCAiUEVSSU1FVFJFX1BFUl9BUkVBIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7RFxcY2RvdCBkfXsyfT1cXGRmcmFjezhcXGNkb3QgNn17Mn09XFxkZnJhY3s0OH17Mn09MjQkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 251 191\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Rombe amb les diagonals de 8 cm i 6 cm dibuixades.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,63.8 85.0,0.0 170.0,63.8 85.0,127.5\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"63.8\" x2=\"170.0\" y2=\"63.8\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.6\" stroke-dasharray=\"4 3\"/><line x1=\"85.0\" y1=\"0.0\" x2=\"85.0\" y2=\"127.5\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.6\" stroke-dasharray=\"4 3\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"66.2\" x2=\"0.0\" y2=\"149.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"66.2\" x2=\"170.0\" y2=\"149.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"145.5\" x2=\"170.0\" y2=\"145.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"141.5\" x2=\"4.0\" y2=\"149.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"141.5\" x2=\"174.0\" y2=\"149.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"0.0\" x2=\"191.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"87.5\" y1=\"127.5\" x2=\"191.5\" y2=\"127.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"188.0\" y1=\"0.0\" x2=\"188.0\" y2=\"127.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"184.0\" y1=\"-4.0\" x2=\"192.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"184.0\" y1=\"123.5\" x2=\"192.0\" y2=\"131.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"159.9\" text-anchor=\"middle\" class=\"fig-etq\">8 cm</text><text x=\"208\" y=\"67.1\" text-anchor=\"middle\" class=\"fig-etq\">6 cm</text></g></svg>"
  },
  {
   "id": "140a",
   "ex": 140,
   "ap": "a",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'àrea d'aquests trapezis isòsceles.",
   "enunciat": "Bases de $3$ cm i $10$ cm, alçada de $6$ cm.",
   "opcions": [
    "$39$ cm$^2$",
    "$78$ cm$^2$",
    "$19$ cm$^2$",
    "$60$ cm$^2$"
   ],
   "pistes": [
    "L'àrea d'un trapezi és $\\dfrac{(B+b)\\cdot h}{2}$, on $B$ i $b$ són les dues bases i $h$ l'alçada.",
    "Calcula $\\dfrac{(3+10)\\cdot6}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IGwnw6ByZWEgZCd1biB0cmFwZXppIMOpcyAkXFxkZnJhY3soQitiKVxcY2RvdCBofXsyfSQsIG5vICQoQitiKVxcY2RvdCBoJCBzZW5jZXIuIiwgIkFxdWVzdCB2YWxvciBzZW1ibGEgZGl2aWRpciBwZXIgJDIkIGR1ZXMgdmVnYWRlczogcmV2aXNhIHF1ZSBoYXMgY2FsY3VsYXQgJCgzKzEwKVxcY2RvdDYkIGFiYW5zIGRlIGRpdmlkaXIgcGVyICQyJCwgbm8gJCgzKzEwKSQgZGl2aWRpdCBwZXIgJDIkIGkgZGVzcHLDqXMgbXVsdGlwbGljYXQgcGVyICQ2JCBkaXZpZGl0IHBlciAkMiQuIiwgIkFxdWVzdCB2YWxvciBzdXJ0IGRlIG11bHRpcGxpY2FyIG5vbcOpcyBsYSBiYXNlIGdyYW4gcGVyIGwnYWzDp2FkYSAoJDEwXFxjZG90NiQpLCBzZW5zZSB0ZW5pciBlbiBjb21wdGUgbGEgYmFzZSBwZXRpdGEuIl0sICJlcnIiOiBbIiIsICJBUlJFTF9GQUNUT1JfT0JMSURBVCIsICJESVZJU0lPX1JFUEVUSURBIiwgIlNVTUFfRU5fTExPQ19SRVNUQSJdLCAicmVzIjogWyIkQT1cXGRmcmFjeygzKzEwKVxcY2RvdDZ9ezJ9PVxcZGZyYWN7Nzh9ezJ9PTM5JCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 218 208\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Trapezi isòsceles de bases 10 cm i 3 cm, alçada 6 cm.</title><g transform=\"translate(14.0,47.0)\"><polygon points=\"0.0,114.0 190.0,114.0 123.5,0.0 66.5,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"66.5\" y1=\"0.0\" x2=\"66.5\" y2=\"114.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 75.5 114.0 L 75.5 105.0 L 66.5 105.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"116.5\" x2=\"0.0\" y2=\"133.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"190.0\" y1=\"116.5\" x2=\"190.0\" y2=\"133.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"130.0\" x2=\"190.0\" y2=\"130.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"126.0\" x2=\"4.0\" y2=\"134.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"186.0\" y1=\"126.0\" x2=\"194.0\" y2=\"134.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"66.5\" y1=\"-2.5\" x2=\"66.5\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"123.5\" y1=\"-2.5\" x2=\"123.5\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"66.5\" y1=\"-16.0\" x2=\"123.5\" y2=\"-16.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"62.5\" y1=\"-12.0\" x2=\"70.5\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"119.5\" y1=\"-12.0\" x2=\"127.5\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"95\" y=\"144.4\" text-anchor=\"middle\" class=\"fig-etq\">10 cm</text><text x=\"95\" y=\"-23.6\" text-anchor=\"middle\" class=\"fig-etq\">3 cm</text><text x=\"86.5\" y=\"60.4\" text-anchor=\"middle\" class=\"fig-etq\">6 cm</text></g></svg>"
  },
  {
   "id": "140b",
   "ex": 140,
   "ap": "b",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'àrea d'aquests trapezis isòsceles.",
   "enunciat": "Bases de $16$ m i $24$ m, alçada de $\\sqrt{164}$ m.",
   "opcions": [
    "$\\sqrt{164}$ m$^2$",
    "$164$ m$^2$",
    "$40\\sqrt{41}\\approx256{,}12$ m$^2$",
    "$20\\sqrt{41}\\approx128{,}06$ m$^2$"
   ],
   "pistes": [
    "L'àrea d'un trapezi és $\\dfrac{(B+b)\\cdot h}{2}$.",
    "Calcula $\\dfrac{(16+24)\\cdot\\sqrt{164}}{2}$; simplifica $\\sqrt{164}=2\\sqrt{41}$ abans de multiplicar si vols."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3RhIMOpcyBub23DqXMgbCdhbMOnYWRhLCBubyBsJ8OgcmVhOiBlbmNhcmEgZmFsdGEgbXVsdGlwbGljYXIgcGVyIGxhIHN1bWEgZGUgbGVzIGJhc2VzIGkgZGl2aWRpciBwZXIgJDIkLiIsICJBcXVlc3QgdmFsb3IgY29uZm9uICRcXHNxcnR7MTY0fSQgKGwnYWzDp2FkYSkgYW1iICQxNjQkIChlbCBub21icmUgc290YSBsJ2FycmVsKSwgaSBubyBmYSBzZXJ2aXIgbGVzIGJhc2VzIHBlciByZXM6IHJldmlzYSBsYSBmw7NybXVsYSBkZSBsJ8OgcmVhIGRlbCB0cmFwZXppLiIsICIiLCAiQXF1ZXN0IHZhbG9yIGRpdmlkZWl4IHBlciAkMiQgdW5hIHZlZ2FkYSBkZSBtw6lzOiBsJ8OgcmVhIMOpcyAkXFxkZnJhY3soMTYrMjQpXFxjZG90XFxzcXJ0ezE2NH19ezJ9JCwgaSAkXFxkZnJhY3s0MH17Mn09MjAkIGphIMOpcyBlbCByZXN1bHRhdCBjb3JyZWN0ZSBkZSBsYSBwcmltZXJhIGRpdmlzacOzLCBubyBjYWwgdG9ybmFyLWxhIGEgZGl2aWRpci4iXSwgImVyciI6IFsiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIiIsICJBUlJFTF9GQUNUT1JfT0JMSURBVCJdLCAicmVzIjogWyIkQT1cXGRmcmFjeygxNisyNClcXGNkb3RcXHNxcnR7MTY0fX17Mn09XFxkZnJhY3s0MFxcY2RvdDJcXHNxcnR7NDF9fXsyfT00MFxcc3FydHs0MX1cXGFwcHJveDI1NnssfTEyJCBtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 218 196\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Trapezi isòsceles de bases 24 m i 16 m, alçada √164 m.</title><g transform=\"translate(14.0,47.0)\"><polygon points=\"0.0,101.4 190.0,101.4 158.3,0.0 31.7,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"31.7\" y1=\"0.0\" x2=\"31.7\" y2=\"101.4\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 40.7 101.4 L 40.7 92.4 L 31.7 92.4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"103.9\" x2=\"0.0\" y2=\"120.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"190.0\" y1=\"103.9\" x2=\"190.0\" y2=\"120.9\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"117.4\" x2=\"190.0\" y2=\"117.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"113.4\" x2=\"4.0\" y2=\"121.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"186.0\" y1=\"113.4\" x2=\"194.0\" y2=\"121.4\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"31.7\" y1=\"-2.5\" x2=\"31.7\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"158.3\" y1=\"-2.5\" x2=\"158.3\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"31.7\" y1=\"-16.0\" x2=\"158.3\" y2=\"-16.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"27.7\" y1=\"-12.0\" x2=\"35.7\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"154.3\" y1=\"-12.0\" x2=\"162.3\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"95\" y=\"131.7\" text-anchor=\"middle\" class=\"fig-etq\">24 m</text><text x=\"95\" y=\"-23.6\" text-anchor=\"middle\" class=\"fig-etq\">16 m</text><text x=\"57.7\" y=\"54.1\" text-anchor=\"middle\" class=\"fig-etq\">√164 m</text></g></svg>"
  },
  {
   "id": "140c",
   "ex": 140,
   "ap": "c",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'àrea d'aquests trapezis isòsceles.",
   "enunciat": "Bases de $3{,}5$ m i $4{,}13$ m, alçada de $7$ m.",
   "opcions": [
    "$29{,}75$ m$^2$",
    "$53{,}41$ m$^2$",
    "$5{,}345$ m$^2$",
    "$26{,}705$ m$^2$"
   ],
   "pistes": [
    "L'àrea d'un trapezi és $\\dfrac{(B+b)\\cdot h}{2}$.",
    "Calcula $\\dfrac{(3{,}5+4{,}13)\\cdot7}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc2VtYmxhIGZldCBzZXJ2aXIgbm9tw6lzIHVuYSBkZSBsZXMgZHVlcyBiYXNlcyAobGEgZ3JhbikgYW1iIGwnYWzDp2FkYSwgaSBkZXNwcsOpcyBkaXZpZGl0IHBlciAkMiQ6IGNhbCBzdW1hciBsZXMgRFVFUyBiYXNlcyBhYmFucyBkZSBtdWx0aXBsaWNhciBwZXIgbCdhbMOnYWRhLiIsICJBcXVlc3QgdmFsb3Igbm8gZGl2aWRlaXggcGVyICQyJDogbCfDoHJlYSBkJ3VuIHRyYXBlemkgw6lzICRcXGRmcmFjeyhCK2IpXFxjZG90IGh9ezJ9JC4iLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSBsYSBzdW1hIGRlIGxlcyBiYXNlcyBkaXZpZGlkYSBwZXIgbCdhbMOnYWRhLCBlbiBsbG9jIGRlIG11bHRpcGxpY2FkYTogcmV2aXNhIGxhIGbDs3JtdWxhICRcXGRmcmFjeyhCK2IpXFxjZG90IGh9ezJ9JC4iLCAiIl0sICJlcnIiOiBbIlRFUk1FX09CTElEQVRfT1BFUkFDSU8iLCAiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiRk9STVVMQV9JTlZFUlRJREEiLCAiIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7KDN7LH01KzR7LH0xMylcXGNkb3Q3fXsyfT1cXGRmcmFjezUzeyx9NDF9ezJ9PTI2eyx9NzA1JCBtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 218 244\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Trapezi isòsceles de bases 4,13 m i 3,5 m, alçada 7 m.</title><g transform=\"translate(14.0,47.0)\"><polygon points=\"0.0,150.0 190.0,150.0 175.5,0.0 14.5,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"14.5\" y1=\"0.0\" x2=\"14.5\" y2=\"150.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 23.5 150.0 L 23.5 141.0 L 14.5 141.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"152.5\" x2=\"0.0\" y2=\"169.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"190.0\" y1=\"152.5\" x2=\"190.0\" y2=\"169.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"166.0\" x2=\"190.0\" y2=\"166.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"162.0\" x2=\"4.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"186.0\" y1=\"162.0\" x2=\"194.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"14.5\" y1=\"-2.5\" x2=\"14.5\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"175.5\" y1=\"-2.5\" x2=\"175.5\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"14.5\" y1=\"-16.0\" x2=\"175.5\" y2=\"-16.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"10.5\" y1=\"-12.0\" x2=\"18.5\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"171.5\" y1=\"-12.0\" x2=\"179.5\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"95\" y=\"180.4\" text-anchor=\"middle\" class=\"fig-etq\">4,13 m</text><text x=\"95\" y=\"-23.6\" text-anchor=\"middle\" class=\"fig-etq\">3,5 m</text><text x=\"29.5\" y=\"78.4\" text-anchor=\"middle\" class=\"fig-etq\">7 m</text></g></svg>"
  },
  {
   "id": "140d",
   "ex": 140,
   "ap": "d",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Troba l'àrea d'aquests trapezis isòsceles.",
   "enunciat": "Bases de $4$ m i $14$ m, alçada de $3$ m.",
   "opcions": [
    "$54$ m$^2$",
    "$21$ m$^2$",
    "$27$ m$^2$",
    "$42$ m$^2$"
   ],
   "pistes": [
    "L'àrea d'un trapezi és $\\dfrac{(B+b)\\cdot h}{2}$.",
    "Calcula $\\dfrac{(4+14)\\cdot3}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gZGl2aWRlaXggcGVyICQyJDogbCfDoHJlYSBkJ3VuIHRyYXBlemkgw6lzICRcXGRmcmFjeyhCK2IpXFxjZG90IGh9ezJ9JC4iLCAiQXF1ZXN0IHZhbG9yIG5vIGNvaW5jaWRlaXggYW1iICRcXGRmcmFjeyg0KzE0KVxcY2RvdDN9ezJ9JDogdG9ybmEgYSBjb21wcm92YXIgbGEgc3VtYSBkZSBsZXMgYmFzZXMgYWJhbnMgZGUgbXVsdGlwbGljYXIuIiwgIiIsICJBcXVlc3QgdmFsb3Igc3VydCBkZSBtdWx0aXBsaWNhciBub23DqXMgbGEgYmFzZSBncmFuIHBlciBsJ2Fsw6dhZGEgKCQxNFxcY2RvdDMkKSwgc2Vuc2UgdGVuaXIgZW4gY29tcHRlIGxhIGJhc2UgcGV0aXRhIG5pIGRpdmlkaXIgcGVyICQyJC4iXSwgImVyciI6IFsiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICIiLCAiU1VNQV9FTl9MTE9DX1JFU1RBIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7KDQrMTQpXFxjZG90M317Mn09XFxkZnJhY3s1NH17Mn09MjckIG0kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 218 139\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Trapezi isòsceles de bases 14 m i 4 m, alçada 3 m.</title><g transform=\"translate(14.0,47.0)\"><polygon points=\"0.0,45.0 190.0,45.0 122.1,0.0 67.9,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"67.9\" y1=\"0.0\" x2=\"67.9\" y2=\"45.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><path d=\"M 76.9 45.0 L 76.9 36.0 L 67.9 36.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"47.5\" x2=\"0.0\" y2=\"64.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"190.0\" y1=\"47.5\" x2=\"190.0\" y2=\"64.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"61.0\" x2=\"190.0\" y2=\"61.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"57.0\" x2=\"4.0\" y2=\"65.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"186.0\" y1=\"57.0\" x2=\"194.0\" y2=\"65.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"67.9\" y1=\"-2.5\" x2=\"67.9\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"122.1\" y1=\"-2.5\" x2=\"122.1\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"67.9\" y1=\"-16.0\" x2=\"122.1\" y2=\"-16.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"63.9\" y1=\"-12.0\" x2=\"71.9\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"118.1\" y1=\"-12.0\" x2=\"126.1\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"95\" y=\"75.4\" text-anchor=\"middle\" class=\"fig-etq\">14 m</text><text x=\"95\" y=\"-23.6\" text-anchor=\"middle\" class=\"fig-etq\">4 m</text><text x=\"82.9\" y=\"25.9\" text-anchor=\"middle\" class=\"fig-etq\">3 m</text></g></svg>"
  },
  {
   "id": "141a",
   "ex": 141,
   "ap": "a",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Calcula l'àrea de:",
   "enunciat": "Un hexàgon regular de costat $2$ cm.",
   "opcions": [
    "$12$ cm$^2$",
    "$24\\sqrt3\\approx41{,}57$ cm$^2$",
    "$2\\sqrt3\\approx3{,}46$ cm$^2$",
    "$6\\sqrt3\\approx10{,}39$ cm$^2$"
   ],
   "pistes": [
    "Calcula primer l'apotema: $a=\\dfrac{L\\sqrt3}{2}=\\sqrt3$ cm (amb $L=2$).",
    "L'àrea d'un polígon regular és $\\dfrac{\\text{perímetre}\\cdot\\text{apotema}}{2}$, amb perímetre $=6\\cdot2=12$ cm."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gaW5jbG91IGVsIGZhY3RvciAkXFxzcXJ0MyQgcXVlIGRvbmEgbCdhcG90ZW1hOiBsJ8OgcmVhIGQndW4gaGV4w6Bnb24gcmVndWxhciDDqXMgJFxcZGZyYWN7XFx0ZXh0e3BlcsOtbWV0cmV9XFxjZG90XFx0ZXh0e2Fwb3RlbWF9fXsyfSQsIGkgbCdhcG90ZW1hIGFxdcOtIHZhbCAkXFxzcXJ0MyQsIG5vICQxJC4iLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IHJldmlzYSBsYSBmw7NybXVsYSAkXFxkZnJhY3tcXHRleHR7cGVyw61tZXRyZX1cXGNkb3RcXHRleHR7YXBvdGVtYX19ezJ9JC4iLCAiQXF1ZXN0IHZhbG9yIMOpcyBsJ2Fwb3RlbWEsIG5vIGwnw6ByZWE6IGVuY2FyYSBmYWx0YSBtdWx0aXBsaWNhciBwZWwgcGVyw61tZXRyZSBpIGRpdmlkaXIgcGVyICQyJC4iLCAiIl0sICJlcnIiOiBbIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIiwgIlBPVEVOQ0lBX0RFX1NVTUEiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiIl0sICJyZXMiOiBbIkFwb3RlbWE6ICRhPVxcZGZyYWN7Mlxcc3FydDN9ezJ9PVxcc3FydDMkIGNtIiwgIlBlcsOtbWV0cmU6ICQ2XFxjZG90Mj0xMiQgY20iLCAiw4ByZWE6ICRcXGRmcmFjezEyXFxjZG90XFxzcXJ0M317Mn09Nlxcc3FydDNcXGFwcHJveDEweyx9MzkkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 2 cm.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">2 cm</text></g></svg>"
  },
  {
   "id": "141b",
   "ex": 141,
   "ap": "b",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Calcula l'àrea de:",
   "enunciat": "Un octàgon regular de perímetre $48$ cm.",
   "opcions": [
    "$6$ cm",
    "$144(1+\\sqrt2)\\approx347{,}64$ cm$^2$",
    "$288$ cm$^2$",
    "$72(1+\\sqrt2)\\approx173{,}82$ cm$^2$"
   ],
   "pistes": [
    "Calcula primer el costat: $\\dfrac{48}{8}=6$ cm.",
    "L'apotema d'un octàgon regular de costat $L$ és $\\dfrac{L}{2}(1+\\sqrt2)$; aplica després $\\dfrac{\\text{perímetre}\\cdot\\text{apotema}}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3Qgw6lzIGVsIGNvc3RhdCBkZSBsJ29jdMOgZ29uICgkNDg6OCQpLCBubyBsJ8OgcmVhOiBlbmNhcmEgY2FsIGNhbGN1bGFyIGwnYXBvdGVtYSBpIGFwbGljYXIgbGEgZsOzcm11bGEgZGUgbCfDoHJlYS4iLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IHJldmlzYSBsYSBmw7NybXVsYSAkXFxkZnJhY3tcXHRleHR7cGVyw61tZXRyZX1cXGNkb3RcXHRleHR7YXBvdGVtYX19ezJ9JC4iLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSBmZXQgJFxcZGZyYWN7NDhcXGNkb3QxMn17Mn0kIGFtYiB1bmEgYXBvdGVtYSBpbnZlbnRhZGEgZGUgJDEyJDogbCdhcG90ZW1hIGQndW4gb2N0w6Bnb24gcmVndWxhciBkZSBjb3N0YXQgJDYkIGNtIMOpcyAkMygxK1xcc3FydDIpXFxhcHByb3g3eyx9MjQkIGNtLCBubyAkMTIkIGNtLiIsICIiXSwgImVyciI6IFsiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiUE9URU5DSUFfREVfU1VNQSIsICJBUlJFTF9GQUNUT1JfT0JMSURBVCIsICIiXSwgInJlcyI6IFsiQ29zdGF0OiAkXFxkZnJhY3s0OH17OH09NiQgY20iLCAiQXBvdGVtYTogJFxcZGZyYWN7Nn17Mn0oMStcXHNxcnQyKT0zKDErXFxzcXJ0MilcXGFwcHJveDd7LH0yNCQgY20iLCAiw4ByZWE6ICRcXGRmcmFjezQ4XFxjZG90MygxK1xcc3FydDIpfXsyfT03MigxK1xcc3FydDIpXFxhcHByb3gxNzN7LH04MiQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 195 195\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Octàgon regular de 8 costats.</title><g transform=\"translate(97.1,97.1)\"><polygon points=\"34.4,83.1 -34.4,83.1 -83.1,34.4 -83.1,-34.4 -34.4,-83.1 34.4,-83.1 83.1,-34.4 83.1,34.4\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/></g></svg>"
  },
  {
   "id": "142",
   "ex": 142,
   "ap": "",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "",
   "enunciat": "Un hexàgon regular té el costat de $6$ cm. Troba la longitud de la diagonal que passa pel centre (la que uneix dos vèrtexs oposats).",
   "opcions": [
    "$6\\sqrt3\\approx10{,}39$ cm",
    "$12$ cm",
    "$3$ cm",
    "$6$ cm"
   ],
   "pistes": [
    "En un hexàgon regular, el centre equidista de tots els vèrtexs una distància igual al costat (l'hexàgon es descompon en 6 triangles equilàters).",
    "La diagonal que passa pel centre uneix dos vèrtexs oposats, i és per tant el doble del costat: $2\\cdot6$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3QgdmFsb3IgY29ycmVzcG9uIGEgdW5hIGFsdHJhIGRpYWdvbmFsIGRlIGwnaGV4w6Bnb24gKGxhIHF1ZSB1bmVpeCBkb3MgdsOocnRleHMgbm8gb3Bvc2F0cyksIG5vIGEgbGEgcXVlIHBhc3NhIHBlbCBjZW50cmUgdW5pbnQgZG9zIHbDqHJ0ZXhzIG9wb3NhdHMuIiwgIiIsICJBcXVlc3QgdmFsb3Igw6lzIGxhIG1laXRhdCBkZWwgY29zdGF0LCBubyBlbCBkb2JsZTogbGEgZGlhZ29uYWwgcXVlIHBhc3NhIHBlbCBjZW50cmUgZCd1biBoZXjDoGdvbiByZWd1bGFyIHZhbCAkMlxcY2RvdCBMJCwgbm8gJFxcZGZyYWN7TH17Mn0kLiIsICJBcXVlc3Qgw6lzIGVsIGNvc3RhdCBkZSBsJ2hleMOgZ29uLCBubyBsYSBkaWFnb25hbCBxdWUgcGFzc2EgcGVsIGNlbnRyZTogZW4gdW4gaGV4w6Bnb24gcmVndWxhciwgYXF1ZXN0YSBkaWFnb25hbCB2YWwgZWwgRE9CTEUgZGVsIGNvc3RhdC4iXSwgImVyciI6IFsiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIiIsICJJTlZFUlRJREEiLCAiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiXSwgInJlcyI6IFsiRW4gdW4gaGV4w6Bnb24gcmVndWxhciwgbGEgZGlzdMOgbmNpYSBkZWwgY2VudHJlIGEgY2FkYSB2w6hydGV4IGNvaW5jaWRlaXggYW1iIGVsIGNvc3RhdCAoJDYkIGNtKSwgcGVycXXDqCBlbCBwb2zDrWdvbiBlcyBkZXNjb21wb24gZW4gJDYkIHRyaWFuZ2xlcyBlcXVpbMOgdGVycyIsICJMYSBkaWFnb25hbCBxdWUgcGFzc2EgcGVsIGNlbnRyZSDDqXMgJDJcXGNkb3Q2PTEyJCBjbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 6 cm, amb la diagonal que passa pel centre marcada.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"45.0\" y1=\"77.9\" x2=\"-45.0\" y2=\"-77.9\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">6 cm</text></g></svg>"
  },
  {
   "id": "143a",
   "ex": 143,
   "ap": "a",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina l'àrea dels triangles descrits a continuació.",
   "enunciat": "Un quadrat de costat $5$ cm queda dividit en dos triangles iguals per una diagonal. Quina és l'àrea d'un d'aquests triangles?",
   "opcions": [
    "$5$ cm$^2$",
    "$25$ cm$^2$",
    "$50$ cm$^2$",
    "$12{,}5$ cm$^2$"
   ],
   "pistes": [
    "Una diagonal divideix un quadrat en dos triangles iguals: cada triangle és la meitat de l'àrea total del quadrat.",
    "Àrea del quadrat: $5^2=25$ cm$^2$; divideix-la per $2$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gZWxldmEgZWwgY29zdGF0IGFsIHF1YWRyYXQ6IGwnw6ByZWEgZGVsIHF1YWRyYXQgw6lzICQ1XjI9MjUkIGNtJF4yJCwgaSBlbCB0cmlhbmdsZSBuJ8OpcyBsYSBtZWl0YXQuIiwgIkFxdWVzdGEgw6lzIGwnw6ByZWEgZGVsIFFVQURSQVQgc2VuY2VyLCBubyBkJ3VuIGRlbHMgZG9zIHRyaWFuZ2xlcyAobGEgbWVpdGF0KTogZW5jYXJhIGZhbHRhIGRpdmlkaXIgcGVyICQyJC4iLCAiQXF1ZXN0IHZhbG9yIGR1cGxpY2EgbCfDoHJlYSBkZWwgcXVhZHJhdCBlbiBsbG9jIGRlIGRpdmlkaXItbGEgcGVyICQyJDogZWwgdHJpYW5nbGUgw6lzIGxhIE1FSVRBVCBkZWwgcXVhZHJhdCwgbm8gZWwgZG9ibGUuIiwgIiJdLCAiZXJyIjogWyJBUlJFTF9GQUNUT1JfT0JMSURBVCIsICJQQVJUX1BFTF9UT1QiLCAiUE9URU5DSUFfREVfU1VNQSIsICIiXSwgInJlcyI6IFsiw4ByZWEgZGVsIHF1YWRyYXQ6ICQ1XjI9MjUkIGNtJF4yJCIsICLDgHJlYSBkZWwgdHJpYW5nbGU6ICRcXGRmcmFjezI1fXsyfT0xMnssfTUkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 148 181\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de costat 5 cm amb la diagonal marcada.</title><g transform=\"translate(14.0,14.0)\"><polygon points=\"0.0,0.0 120.0,0.0 120.0,120.0 0.0,120.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"120.0\" x2=\"120.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"122.5\" x2=\"0.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"120.0\" y1=\"122.5\" x2=\"120.0\" y2=\"139.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"136.0\" x2=\"120.0\" y2=\"136.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"132.0\" x2=\"4.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"116.0\" y1=\"132.0\" x2=\"124.0\" y2=\"140.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"60\" y=\"150.4\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text></g></svg>"
  },
  {
   "id": "143b",
   "ex": 143,
   "ap": "b",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina l'àrea dels triangles descrits a continuació.",
   "enunciat": "Un pentàgon regular de costat $4$ cm i apotema $a\\approx2{,}75$ cm queda dividit en cinc triangles iguals unint el centre amb cada vèrtex. Quina és l'àrea d'un d'aquests triangles?",
   "opcions": [
    "$27{,}5$ cm$^2$",
    "$1{,}375$ cm$^2$",
    "$11$ cm$^2$",
    "$5{,}5$ cm$^2$"
   ],
   "pistes": [
    "Cada triangle té com a base el costat del pentàgon i com a alçada l'apotema.",
    "Àrea del triangle: $\\dfrac{4\\cdot2{,}75}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3RhIMOpcyBsJ8OgcmVhIGRlbCBQRU5Uw4BHT04gc2VuY2VyIChlbHMgJDUkIHRyaWFuZ2xlcyBqdW50cyksIG5vIGQndW4gc29sIHRyaWFuZ2xlOiBkaXZpZGVpeCBwZXIgJDUkLiIsICJBcXVlc3QgdmFsb3Igc2VtYmxhIGRpdmlkaXIgcGVyICQyJCBkdWVzIHZlZ2FkZXM6IGNvbXByb3ZhIHF1ZSBoYXMgY2FsY3VsYXQgJDRcXGNkb3Qyeyx9NzUkIGFiYW5zIGRlIGRpdmlkaXIgcGVyICQyJCwgbm8gJDJcXGNkb3Qxeyx9Mzc1JC4iLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IGwnw6ByZWEgZCd1biBkZWxzIHRyaWFuZ2xlcyDDqXMgJFxcZGZyYWN7XFx0ZXh0e2Nvc3RhdH1cXGNkb3RcXHRleHR7YXBvdGVtYX19ezJ9JCwgbm8gZWwgcHJvZHVjdGUgc2VuY2VyLiIsICIiXSwgImVyciI6IFsiUEFSVF9QRUxfVE9UIiwgIkRJVklTSU9fUkVQRVRJREEiLCAiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7NFxcY2RvdDJ7LH03NX17Mn09XFxkZnJhY3sxMX17Mn09NXssfTUkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 200 224\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Pentàgon regular, costat 4 cm, dividit en 5 triangles unint el centre amb cada vèrtex, un d'ells ombrejat.</title><g transform=\"translate(99.6,104.0)\"><polygon points=\"52.9,72.8 -52.9,72.8 -85.6,-27.8 -0.0,-90.0 85.6,-27.8\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0\" y1=\"0\" x2=\"52.9007\" y2=\"72.8115\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-52.9007\" y2=\"72.8115\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-85.5951\" y2=\"-27.8115\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-1.65327e-14\" y2=\"-90\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"85.5951\" y2=\"-27.8115\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><polygon points=\"0.0,0.0 52.9,72.8 -52.9,72.8\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"52.9\" y1=\"75.3\" x2=\"52.9\" y2=\"92.3\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-52.9\" y1=\"75.3\" x2=\"-52.9\" y2=\"92.3\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"52.9\" y1=\"88.8\" x2=\"-52.9\" y2=\"88.8\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"56.9\" y1=\"84.8\" x2=\"48.9\" y2=\"92.8\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-48.9\" y1=\"84.8\" x2=\"-56.9\" y2=\"92.8\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"103.2\" text-anchor=\"middle\" class=\"fig-etq\">4 cm</text></g></svg>"
  },
  {
   "id": "143c",
   "ex": 143,
   "ap": "c",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina l'àrea dels triangles descrits a continuació.",
   "enunciat": "Un hexàgon regular de costat $3$ cm queda dividit en sis triangles equilàters iguals unint el centre amb cada vèrtex. Quina és l'àrea d'un d'aquests triangles?",
   "opcions": [
    "$\\dfrac{27\\sqrt3}{2}\\approx23{,}38$ cm$^2$",
    "$\\dfrac{9\\sqrt3}{4}\\approx3{,}90$ cm$^2$",
    "$4{,}5$ cm$^2$",
    "$9\\sqrt3\\approx15{,}59$ cm$^2$"
   ],
   "pistes": [
    "Els sis triangles en què el centre divideix un hexàgon regular són EQUILÀTERS de costat igual al de l'hexàgon.",
    "Àrea d'un triangle equilàter de costat $L$: $\\dfrac{L^2\\sqrt3}{4}$, amb $L=3$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJBcXVlc3RhIMOpcyBsJ8OgcmVhIGRlIGwnSEVYw4BHT04gc2VuY2VyIChlbHMgJDYkIHRyaWFuZ2xlcyBqdW50cyksIG5vIGQndW4gc29sIHRyaWFuZ2xlOiBkaXZpZGVpeC1sYSBwZXIgJDYkLiIsICIiLCAiQXF1ZXN0IHZhbG9yIG5vIGluY2xvdSBlbCBmYWN0b3IgJFxcc3FydDMkOiBlbiB1biB0cmlhbmdsZSBlcXVpbMOgdGVyLCBsJ8OgcmVhIG5vIMOpcyAkXFxkZnJhY3tMXjJ9ezJ9JC4iLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkNCQ6IGNhZGEgdHJpYW5nbGUgZXF1aWzDoHRlciBkZSBjb3N0YXQgJEwkIHTDqSDDoHJlYSAkXFxkZnJhY3tMXjJcXHNxcnQzfXs0fSQsIG5vICRMXjJcXHNxcnQzJC4iXSwgImVyciI6IFsiUEFSVF9QRUxfVE9UIiwgIiIsICJQT1RFTkNJQV9ERV9TVU1BIiwgIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7M14yXFxzcXJ0M317NH09XFxkZnJhY3s5XFxzcXJ0M317NH1cXGFwcHJveDN7LH05MCQgY20kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 3 cm, dividit en 6 triangles unint el centre amb cada vèrtex, un d'ells ombrejat.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0\" y1=\"0\" x2=\"45\" y2=\"77.9423\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-45\" y2=\"77.9423\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-90\" y2=\"1.10218e-14\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-45\" y2=\"-77.9423\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"45\" y2=\"-77.9423\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"90\" y2=\"-2.20436e-14\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><polygon points=\"0.0,0.0 45.0,77.9 -45.0,77.9\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">3 cm</text></g></svg>"
  },
  {
   "id": "143d",
   "ex": 143,
   "ap": "d",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 3,
   "encapcalament": "Determina l'àrea dels triangles descrits a continuació.",
   "enunciat": "Un octàgon regular de costat $3$ cm i apotema $3{,}62$ cm queda dividit en vuit triangles iguals unint el centre amb cada vèrtex. Quina és l'àrea d'un d'aquests triangles?",
   "opcions": [
    "$2{,}715$ cm$^2$",
    "$10{,}86$ cm$^2$",
    "$43{,}44$ cm$^2$",
    "$5{,}43$ cm$^2$"
   ],
   "pistes": [
    "Cada triangle té com a base el costat de l'octàgon i com a alçada l'apotema.",
    "Àrea del triangle: $\\dfrac{3\\cdot3{,}62}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igc2VtYmxhIGRpdmlkaXIgcGVyICQyJCBkdWVzIHZlZ2FkZXM6IGNvbXByb3ZhIHF1ZSBoYXMgY2FsY3VsYXQgJDNcXGNkb3Qzeyx9NjIkIGFiYW5zIGRlIGRpdmlkaXIgcGVyICQyJC4iLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IGwnw6ByZWEgZCd1biBkZWxzIHRyaWFuZ2xlcyDDqXMgJFxcZGZyYWN7XFx0ZXh0e2Nvc3RhdH1cXGNkb3RcXHRleHR7YXBvdGVtYX19ezJ9JCwgbm8gZWwgcHJvZHVjdGUgc2VuY2VyLiIsICJBcXVlc3RhIMOpcyBsJ8OgcmVhIGRlIGwnT0NUw4BHT04gc2VuY2VyIChlbHMgJDgkIHRyaWFuZ2xlcyBqdW50cyksIG5vIGQndW4gc29sIHRyaWFuZ2xlOiBkaXZpZGVpeC1sYSBwZXIgJDgkLiIsICIiXSwgImVyciI6IFsiRElWSVNJT19SRVBFVElEQSIsICJBUlJFTF9GQUNUT1JfT0JMSURBVCIsICJQQVJUX1BFTF9UT1QiLCAiIl0sICJyZXMiOiBbIiRBPVxcZGZyYWN7M1xcY2RvdDN7LH02Mn17Mn09XFxkZnJhY3sxMHssfTg2fXsyfT01eyx9NDMkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 195 228\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Octàgon regular, costat 3 cm, dividit en 8 triangles unint el centre amb cada vèrtex, un d'ells ombrejat.</title><g transform=\"translate(97.1,97.1)\"><polygon points=\"34.4,83.1 -34.4,83.1 -83.1,34.4 -83.1,-34.4 -34.4,-83.1 34.4,-83.1 83.1,-34.4 83.1,34.4\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0\" y1=\"0\" x2=\"34.4415\" y2=\"83.1492\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-34.4415\" y2=\"83.1492\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-83.1492\" y2=\"34.4415\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-83.1492\" y2=\"-34.4415\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"-34.4415\" y2=\"-83.1492\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"34.4415\" y2=\"-83.1492\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"83.1492\" y2=\"-34.4415\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><line x1=\"0\" y1=\"0\" x2=\"83.1492\" y2=\"34.4415\" stroke=\"currentColor\" stroke-width=\"0.75\" stroke-opacity=\"0.45\"/><polygon points=\"0.0,0.0 34.4,83.1 -34.4,83.1\" fill=\"none\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"34.4\" y1=\"85.6\" x2=\"34.4\" y2=\"102.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-34.4\" y1=\"85.6\" x2=\"-34.4\" y2=\"102.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"34.4\" y1=\"99.1\" x2=\"-34.4\" y2=\"99.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"38.4\" y1=\"95.1\" x2=\"30.4\" y2=\"103.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-30.4\" y1=\"95.1\" x2=\"-38.4\" y2=\"103.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"113.5\" text-anchor=\"middle\" class=\"fig-etq\">3 cm</text></g></svg>"
  },
  {
   "id": "144a",
   "ex": 144,
   "ap": "a",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Calcula l'àrea de les figures següents.",
   "enunciat": "Una figura en forma de mitja lluna és la diferència entre un semicercle de $12$ cm de diàmetre i un semicercle interior de $6$ cm de diàmetre. Quina és la seva àrea?",
   "opcions": [
    "$\\dfrac{27\\pi}{2}\\approx42{,}41$ cm$^2$",
    "$18\\pi\\approx56{,}55$ cm$^2$",
    "$45\\pi\\approx141{,}37$ cm$^2$",
    "$4{,}5\\pi\\approx14{,}14$ cm$^2$"
   ],
   "pistes": [
    "L'àrea d'un semicercle de radi $r$ és $\\dfrac{\\pi r^2}{2}$.",
    "Resta l'àrea del semicercle petit (radi $3$ cm) de la del gran (radi $6$ cm)."
   ],
   "nota": "La figura de partida no deixa clar el diàmetre de l'arc interior; aquí es pren $6$ cm, que és la meitat de l'exterior.",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IHZhbG9yIG5vIGRpdmlkZWl4IHBlciAkMiQ6IGNhbCBjYWxjdWxhciBsJ8OgcmVhIGRlIENBREFTQ1VOIGRlbHMgZG9zIHNlbWljZXJjbGVzIChqYSBkaXZpZGlkYSBwZXIgJDIkIHJlc3BlY3RlIGRlbCBjZXJjbGUgY29tcGxldCksIG5vIGxhIGRpZmVyw6huY2lhIGRlbHMgY2VyY2xlcyBjb21wbGV0cy4iLCAiQXF1ZXN0IHZhbG9yIFNVTUEgbGVzIMOgcmVlcyBkZWxzIGRvcyBzZW1pY2VyY2xlcyBlbiBsbG9jIGRlIHJlc3Rhci1sZXM6IGxhIG1pdGphIGxsdW5hIMOpcyBsYSBkaWZlcsOobmNpYSBlbnRyZSBlbCBzZW1pY2VyY2xlIGdyYW4gaSBlbCBwZXRpdCwgbm8gbGEgc3VtYS4iLCAiQXF1ZXN0IHZhbG9yIG5vIGZhIHNlcnZpciBlbHMgcmFkaXMgY29ycmVjdGVzOiBjb21wcm92YSBxdWUgaGFzIHVzYXQgcmFkaSAkNiQgY20gKHNlbWljZXJjbGUgZ3JhbiwgZGnDoG1ldHJlICQxMiQpIGkgcmFkaSAkMyQgY20gKHNlbWljZXJjbGUgcGV0aXQsIGRpw6BtZXRyZSAkNiQpLCBubyBlbHMgZGnDoG1ldHJlcyBkaXJlY3RhbWVudC4iXSwgImVyciI6IFsiIiwgIkZSQUNDSU9fREVfQ0VSQ0xFX01BTCIsICJTVU1BX0VOX0xMT0NfUkVTVEEiLCAiQVJSRUxfRkFDVE9SX09CTElEQVQiXSwgInJlcyI6IFsiU2VtaWNlcmNsZSBncmFuOiAkXFxkZnJhY3tcXHBpXFxjZG90Nl4yfXsyfT0xOFxccGkkIGNtJF4yJCIsICJTZW1pY2VyY2xlIHBldGl0OiAkXFxkZnJhY3tcXHBpXFxjZG90M14yfXsyfT00eyx9NVxccGkkIGNtJF4yJCIsICJEaWZlcsOobmNpYTogJDE4XFxwaS00eyx9NVxccGk9MTN7LH01XFxwaT1cXGRmcmFjezI3XFxwaX17Mn1cXGFwcHJveDQyeyx9NDEkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 188 143\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Mitja lluna: semicercle exterior de diàmetre 12 cm, semicercle interior de diàmetre 6 cm.</title><g transform=\"translate(94.0,113.2)\"><path d=\"M-80,0 A80,80 0 0,1 80,0 L40,0 A40,40 0 0,0 -40,0 Z\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linejoin=\"round\"/><line class=\"fig-cota\" x1=\"-40.0\" y1=\"-2.5\" x2=\"-40.0\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"40.0\" y1=\"-2.5\" x2=\"40.0\" y2=\"-19.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-40.0\" y1=\"-16.0\" x2=\"40.0\" y2=\"-16.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-44.0\" y1=\"-12.0\" x2=\"-36.0\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"36.0\" y1=\"-12.0\" x2=\"44.0\" y2=\"-20.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-80.0\" y1=\"-2.5\" x2=\"-80.0\" y2=\"-47.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"80.0\" y1=\"-2.5\" x2=\"80.0\" y2=\"-47.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-80.0\" y1=\"-44.0\" x2=\"80.0\" y2=\"-44.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-84.0\" y1=\"-40.0\" x2=\"-76.0\" y2=\"-48.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"76.0\" y1=\"-40.0\" x2=\"84.0\" y2=\"-48.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-crida\" x1=\"0.0\" y1=\"-16.0\" x2=\"0.0\" y2=\"1.8\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"0\" y=\"12.9\" text-anchor=\"middle\" class=\"fig-etq petita\">diàm. int. 6 cm</text><line class=\"fig-crida\" x1=\"0.0\" y1=\"-44.0\" x2=\"0.0\" y2=\"-85.8\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"0\" y=\"-91.1\" text-anchor=\"middle\" class=\"fig-etq petita\">diàm. ext. 12 cm</text></g></svg>"
  },
  {
   "id": "144b",
   "ex": 144,
   "ap": "b",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Calcula l'àrea de les figures següents.",
   "enunciat": "D'un cercle de $4$ cm de diàmetre es retalla un sector de $90^\\circ$ (una quarta part, tipus \"Pac-Man\"). Quina és l'àrea de la part que queda?",
   "opcions": [
    "$2\\pi\\approx6{,}28$ cm$^2$",
    "$4\\pi\\approx12{,}57$ cm$^2$",
    "$3\\pi\\approx9{,}42$ cm$^2$",
    "$\\pi\\approx3{,}14$ cm$^2$"
   ],
   "pistes": [
    "El cercle complet, de radi $2$ cm, té àrea $\\pi\\cdot2^2=4\\pi$ cm$^2$.",
    "Un sector de $90^\\circ$ és $\\dfrac{90}{360}=\\dfrac14$ del cercle: la figura és les tres quartes parts restants."
   ],
   "nota": "La figura de partida no deixa clar quin angle abasta el sector retallat; aquí es pren un quart de volta ($90^\\circ$), que és el que ja diu l'enunciat.",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3IgY29ycmVzcG9uIGEgbGEgbWVpdGF0IGRlbCBjZXJjbGUsIG5vIGEgbGVzIHRyZXMgcXVhcnRlcyBwYXJ0cyBxdWUgcXVlZGVuIGRlc3Byw6lzIGRlIHJldGFsbGFyIHVuIHNlY3RvciBkZSAkOTBeXFxjaXJjJCAodW4gcXVhcnQgZGUgdm9sdGEpLiIsICJBcXVlc3RhIMOpcyBsJ8OgcmVhIGRlbCBjZXJjbGUgY29tcGxldCwgc2Vuc2UgcmV0YWxsYXIgZWwgc2VjdG9yOiByZWNvcmRhIHJlc3RhciBsYSBwb3JjacOzIHJldGFsbGFkYS4iLCAiIiwgIkFxdWVzdCB2YWxvciDDqXMgZWwgc2VjdG9yIFJFVEFMTEFUIChsYSBxdWFydGEgcGFydCksIG5vIGVsIHF1ZSBxdWVkYSBkZSBsYSBmaWd1cmE6IGxhIGZpZ3VyYSDDqXMgbGEgcmVzdGEgZGVsIGNlcmNsZSB1biBjb3AgdHJldCBhcXVlc3Qgc2VjdG9yLiJdLCAiZXJyIjogWyJGUkFDQ0lPX0RFX0NFUkNMRV9NQUwiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICIiLCAiRlJBQ0NJT19ERV9DRVJDTEVfTUFMIl0sICJyZXMiOiBbIkNlcmNsZSBjb21wbGV0OiAkXFxwaVxcY2RvdDJeMj00XFxwaSQgY20kXjIkIiwgIsOAcmVhIGZpbmFsICh0cmVzIHF1YXJ0cyBkZWwgY2VyY2xlKTogJFxcZGZyYWMzNFxcY2RvdDRcXHBpPTNcXHBpXFxhcHByb3g5eyx9NDIkIGNtJF4yJCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 188 188\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Cercle de radi 2 cm, amb un sector de 90° retallat (la resta, 270°, queda marcada).</title><g transform=\"translate(94.0,94.0)\"><circle cx=\"0\" cy=\"0\" r=\"80\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M0,0 L4.89859e-15,-80 A80,80 0 1,1 -80,9.79717e-15 Z\" fill=\"var(--fig-marca, #B3453C)\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linejoin=\"round\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"-80.0\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-dasharray=\"4 3\"/><text x=\"15\" y=\"-37.1\" text-anchor=\"middle\" class=\"fig-etq petita\">2 cm</text></g></svg>"
  },
  {
   "id": "145c",
   "ex": 145,
   "ap": "c",
   "bloc": "arees_poli",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "Determina l'àrea de la figura descrita.",
   "enunciat": "Un quadrat de costat $5$ cm té un forat circular de $2$ cm de diàmetre. Quina és l'àrea que queda un cop tret el forat?",
   "opcions": [
    "$25-2\\pi\\approx18{,}72$ cm$^2$",
    "$25-\\pi\\approx21{,}86$ cm$^2$",
    "$25-4\\pi\\approx12{,}43$ cm$^2$",
    "$23$ cm$^2$"
   ],
   "pistes": [
    "L'àrea de la figura és l'àrea del quadrat menys l'àrea del cercle del forat.",
    "El radi del forat és la meitat del diàmetre: $\\dfrac{2}{2}=1$ cm; àrea del quadrat $5^2=25$ cm$^2$."
   ],
   "nota": "D'aquest exercici només hi ha l'apartat c: els altres tres eren figures esglaonades en forma de L i de T que no es poden descriure sense el dibuix.",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgZmV0IHNlcnZpciBlbCBkacOgbWV0cmUgKCQyJCBjbSkgY29tIHNpIGZvcyBlbCByYWRpIGEgbCdob3JhIGRlIGNhbGN1bGFyIGwnw6ByZWEgZGVsIGZvcmF0OiBlbCByYWRpIMOpcyBsYSBNRUlUQVQgZGVsIGRpw6BtZXRyZSwgw6lzIGEgZGlyLCAkMSQgY20sIGkgbCfDoHJlYSBkZWwgY2VyY2xlIMOpcyAkXFxwaVxcY2RvdDFeMj1cXHBpJCwgbm8gJFxccGlcXGNkb3QyJC4iLCAiIiwgIkhhcyBmZXQgc2VydmlyIGVsIGRpw6BtZXRyZSAoJDIkIGNtKSBkaXJlY3RhbWVudCBjb20gYSByYWRpIGFsIHF1YWRyYXQ6IGwnw6ByZWEgZGVsIGNlcmNsZSDDqXMgJFxccGlcXGNkb3Qgcl4yJCBhbWIgJHI9MSQgY20gKGxhIG1laXRhdCBkZWwgZGnDoG1ldHJlKSwgw6lzIGEgZGlyLCAkXFxwaSQsIG5vICRcXHBpXFxjZG90Ml4yJC4iLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSByZXN0YXIgZWwgZGnDoG1ldHJlIGRpcmVjdGFtZW50ICgkNV4yLTIkKSBlbiBsbG9jIGRlIHJlc3RhciBsJ8OgcmVhIGRlbCBjZXJjbGU6IGNhbCBjYWxjdWxhciBwcmltZXIgbCfDoHJlYSBkZWwgZm9yYXQgY2lyY3VsYXIgKCRcXHBpXFxjZG90IHJeMiQpLCBubyByZXN0YXItbmUgbm9tw6lzIGxhIGxvbmdpdHVkIGRlbCBkacOgbWV0cmUuIl0sICJlcnIiOiBbIkNBVEVUX01BTF9JREVOVElGSUNBVCIsICIiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIkFSUkVMX0ZBQ1RPUl9PQkxJREFUIl0sICJyZXMiOiBbIsOAcmVhIGRlbCBxdWFkcmF0OiAkNV4yPTI1JCBjbSReMiQiLCAiUmFkaSBkZWwgZm9yYXQ6ICRcXGRmcmFjezJ9ezJ9PTEkIGNtOyDDoHJlYSBkZWwgZm9yYXQ6ICRcXHBpXFxjZG90MV4yPVxccGkkIGNtJF4yJCIsICLDgHJlYSBkZSBsYSBmaWd1cmE6ICQyNS1cXHBpXFxhcHByb3gyMXssfTg2JCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 249 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de 5 cm per 5 cm amb un forat circular de diàmetre 2 cm.</title><g transform=\"translate(64.6,14.0)\"><path d=\"M0,0 h170 v170 h-170 Z M85,85 m-34,0 a34,34 0 1,0 68,0 a34,34 0 1,0 -68,0\" fill-rule=\"evenodd\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"51.0\" y1=\"85.0\" x2=\"119.0\" y2=\"85.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text><text x=\"-36\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">5 cm</text><line class=\"fig-crida\" x1=\"85.0\" y1=\"85.0\" x2=\"85.0\" y2=\"126.8\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"85\" y=\"137.9\" text-anchor=\"middle\" class=\"fig-etq petita\">diàmetre 2 cm</text></g></svg>"
  },
  {
   "id": "146",
   "ex": 146,
   "ap": "",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Una torre fa 150 m d'alçada i la seva ombra s'estén 200 m pel terra pla. Quina distància hi ha des del punt més alt de la torre fins a l'extrem de l'ombra?",
   "opcions": [
    "350 m",
    "$250$ m",
    "50 m",
    "62500 m"
   ],
   "pistes": [
    "L'alçada de la torre i l'ombra total formen els dos catets d'un triangle rectangle; la distància demanada n'és la hipotenusa.",
    "Aplica Pitàgores: $\\sqrt{150^2+200^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgc3VtYXQgZGlyZWN0YW1lbnQgbCdhbMOnYWRhIGkgbCdvbWJyYSAoJDE1MCsyMDAkKSBlbiBsbG9jIGQnYXBsaWNhciBQaXTDoGdvcmVzOiBsYSBkaXN0w6BuY2lhIGRlbWFuYWRhIMOpcyBsYSBoaXBvdGVudXNhIGQndW4gdHJpYW5nbGUgcmVjdGFuZ2xlLCBubyBsYSBzdW1hIGRlbHMgY2F0ZXRzLiIsICIiLCAiQXF1ZXN0IHZhbG9yIHN1cnQgZGUgcmVzdGFyIGwnb21icmEgaSBsJ2Fsw6dhZGEgZGlyZWN0YW1lbnQsIHNlbnNlIGVsZXZhci1sZXMgYWwgcXVhZHJhdCBuaSBmZXIgbCdhcnJlbDogY2FsIGFwbGljYXIgUGl0w6Bnb3JlcyBhbWIgZWxzIGRvcyBjYXRldHMsIG5vIHJlc3Rhci1sb3MuIiwgIkhhcyBjYWxjdWxhdCAkMTUwXjIrMjAwXjI9NjJcXCw1MDAkIGNvcnJlY3RhbWVudCwgcGVyw7IgdCdoYXMgZGVpeGF0IGwnYXJyZWwgcXVhZHJhZGEgZmluYWwuIl0sICJlcnIiOiBbIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiIiwgIlNJR05FX1BJVEFHT1JFUyIsICJBUlJFTF9PQkxJREFEQSJdLCAicmVzIjogWyIkXFxzcXJ0ezE1MF4yKzIwMF4yfT1cXHNxcnR7NjI1MDB9PTI1MCQgbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 259 189\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 200 m i 150 m.</title><g transform=\"translate(74.3,14.0)\"><polygon points=\"0.0,127.5 170.0,127.5 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 127.5 L 12.0 115.5 L 0.0 115.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"130.0\" x2=\"0.0\" y2=\"147.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"130.0\" x2=\"170.0\" y2=\"147.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"143.5\" x2=\"170.0\" y2=\"143.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"139.5\" x2=\"4.0\" y2=\"147.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"139.5\" x2=\"174.0\" y2=\"147.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"127.5\" x2=\"-19.5\" y2=\"127.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"127.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"123.5\" x2=\"-20.0\" y2=\"131.5\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"85\" y=\"157.9\" text-anchor=\"middle\" class=\"fig-etq\">200 m</text><text x=\"-42\" y=\"67.1\" text-anchor=\"middle\" class=\"fig-etq\">150 m</text></g></svg>"
  },
  {
   "id": "147",
   "ex": 147,
   "ap": "",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Una escala de 10 m de longitud està recolzada sobre una paret. El peu de l'escala dista 6 m de la paret. A quina altura arriba l'escala sobre la paret?",
   "opcions": [
    "64 m",
    "$8$ m",
    "16 m",
    "136 m"
   ],
   "pistes": [
    "L'escala fa d'hipotenusa; la distància del peu a la paret i l'altura on arriba són els dos catets.",
    "Aplica Pitàgores: $\\sqrt{10^2-6^2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDEsICJkaWFnIjogWyJIYXMgY2FsY3VsYXQgJDEwXjItNl4yPTY0JCBjb3JyZWN0YW1lbnQsIHBlcsOyIHQnaGFzIGRlaXhhdCBsJ2FycmVsIHF1YWRyYWRhIGZpbmFsLiIsICIiLCAiSGFzIHN1bWF0IGRpcmVjdGFtZW50IGwnZXNjYWxhIGkgbGEgZGlzdMOgbmNpYSBhbCBwZXUgKCQxMCs2JCkgZW4gbGxvYyBkJ2FwbGljYXIgUGl0w6Bnb3Jlcy4iLCAiTCdlc2NhbGEgKGxhIGxvbmdpdHVkIHRvdGFsKSBmYSBkJ2hpcG90ZW51c2EsIGkgbGEgZGlzdMOgbmNpYSBkZWwgcGV1IGEgbGEgcGFyZXQgw6lzIHVuIGNhdGV0OiBjYWwgUkVTVEFSIGVscyBzZXVzIHF1YWRyYXRzIHBlciB0cm9iYXIgbCdhbHR1cmEsIG5vIHN1bWFyLWxvcy4iXSwgImVyciI6IFsiQVJSRUxfT0JMSURBREEiLCAiIiwgIlNVTUFfQ0FURVRTX1NFTlNFX1FVQURSQVQiLCAiU0lHTkVfUElUQUdPUkVTIl0sICJyZXMiOiBbIiRcXHNxcnR7MTBeMi02XjJ9PVxcc3FydHs2NH09OCQgbSJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 229 231\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Triangle rectangle de catets 6 m i ?.</title><g transform=\"translate(44.7,14.0)\"><polygon points=\"0.0,170.0 170.0,170.0 0.0,0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M 12.0 170.0 L 12.0 158.0 L 0.0 158.0\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"172.5\" x2=\"0.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"170.0\" y1=\"172.5\" x2=\"170.0\" y2=\"189.5\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"0.0\" y1=\"186.0\" x2=\"170.0\" y2=\"186.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-4.0\" y1=\"182.0\" x2=\"4.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"166.0\" y1=\"182.0\" x2=\"174.0\" y2=\"190.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"0.0\" x2=\"-19.5\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-2.5\" y1=\"170.0\" x2=\"-19.5\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-16.0\" y1=\"0.0\" x2=\"-16.0\" y2=\"170.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"-4.0\" x2=\"-20.0\" y2=\"4.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-12.0\" y1=\"166.0\" x2=\"-20.0\" y2=\"174.0\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"170.0\" y1=\"170.0\" x2=\"0.0\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><text x=\"85\" y=\"200.4\" text-anchor=\"middle\" class=\"fig-etq\">6 m</text><text x=\"-27\" y=\"88.4\" text-anchor=\"middle\" class=\"fig-etq\">?</text><text x=\"136.4\" y=\"118.6\" text-anchor=\"middle\" class=\"fig-etq\">10 m</text></g></svg>"
  },
  {
   "id": "148a",
   "ex": 148,
   "ap": "a",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Als costats d'un camp quadrangular s'han plantat 32 arbres, separats 5 m entre ells. Quant mesura el costat del camp?",
   "opcions": [
    "$40$ m",
    "$32$ m",
    "$160$ m",
    "$5$ m"
   ],
   "pistes": [
    "Cada arbre marca una separació de $5$ m al voltant de tot el perímetre: perímetre $=32\\times5$.",
    "El camp és quadrangular (quadrat): costat $=\\dfrac{\\text{perímetre}}{4}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IMOpcyBlbCBub21icmUgZCdhcmJyZXMsIG5vIGVsIGNvc3RhdDogcHJpbWVyIGNhbCB0cm9iYXIgZWwgcGVyw61tZXRyZSB0b3RhbCAoJDMyJCBhcmJyZXMgJFxcdGltZXM1JCBtIGRlIHNlcGFyYWNpw7MpIGkgZGVzcHLDqXMgZGl2aWRpci1sbyBlbnRyZSBlbHMgJDQkIGNvc3RhdHMuIiwgIkFxdWVzdCDDqXMgZWwgUEVSw41NRVRSRSBkZWwgY2FtcCAoJDMyXFx0aW1lczUkKSwgbm8gZWwgY29zdGF0OiBlbmNhcmEgZmFsdGEgZGl2aWRpci1sbyBlbnRyZSBlbHMgJDQkIGNvc3RhdHMuIiwgIkFxdWVzdGEgw6lzIGxhIHNlcGFyYWNpw7MgZW50cmUgYXJicmVzLCBubyBlbCBjb3N0YXQgZGVsIGNhbXA6IGVuY2FyYSBmYWx0YSBjYWxjdWxhciBlbCBwZXLDrW1ldHJlIHRvdGFsIGkgZGl2aWRpciBlbnRyZSA0LiJdLCAiZXJyIjogWyIiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIlBBU19JTlRFUk1FRElfUEVSX1JFU1BPU1RBIiwgIlBBU19JTlRFUk1FRElfUEVSX1JFU1BPU1RBIl0sICJyZXMiOiBbIlBlcsOtbWV0cmU6ICQzMlxcdGltZXM1PTE2MCQgbSIsICJDb3N0YXQ6ICRcXGRmcmFjezE2MH17NH09NDAkIG0iXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 156 156\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat de 4 costats.</title><g transform=\"translate(77.6,77.6)\"><polygon points=\"63.6,63.6 -63.6,63.6 -63.6,-63.6 63.6,-63.6\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/></g></svg>"
  },
  {
   "id": "148b",
   "ex": 148,
   "ap": "b",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Amb les mateixes dades de l'apartat anterior (32 arbres, separats 5 m, camp quadrangular): quina és l'àrea del camp?",
   "opcions": [
    "$80$ m$^2$",
    "$6\\,400$ m$^2$",
    "$160$ m$^2$",
    "$1\\,600$ m$^2$"
   ],
   "pistes": [
    "El costat del camp és $40$ m (perímetre $160$ m entre $4$).",
    "L'àrea d'un quadrat és costat al quadrat: $40^2$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igbm8gZWxldmEgZWwgY29zdGF0IGFsIHF1YWRyYXQ6IGwnw6ByZWEgZCd1biBxdWFkcmF0IGRlIGNvc3RhdCAkTCQgw6lzICRMXjIkLCBubyAkMkwkLiIsICJBcXVlc3QgdmFsb3IgZWxldmEgZWwgcGVyw61tZXRyZSBhbCBxdWFkcmF0ICgkMTYwXjIkKSBlbiBsbG9jIGRlbCBjb3N0YXQ6IHByaW1lciBjYWwgdHJvYmFyIGVsIGNvc3RhdCAoJDE2MDo0PTQwJCkgaSBkZXNwcsOpcyBlbGV2YXItbG8gYWwgcXVhZHJhdC4iLCAiQXF1ZXN0IMOpcyBlbCBwZXLDrW1ldHJlIGRlbCBjYW1wLCBubyBsJ8OgcmVhOiBlbmNhcmEgZmFsdGEgZWxldmFyIGVsIGNvc3RhdCBhbCBxdWFkcmF0LiIsICIiXSwgImVyciI6IFsiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIiwgIlBBU19JTlRFUk1FRElfUEVSX1JFU1BPU1RBIiwgIiJdLCAicmVzIjogWyJDb3N0YXQ6ICRcXGRmcmFjezE2MH17NH09NDAkIG0iLCAiw4ByZWE6ICQ0MF4yPTFcXCw2MDAkIG0kXjIkIl19",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 156 189\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Quadrat, costat 40 m.</title><g transform=\"translate(77.6,77.6)\"><polygon points=\"63.6,63.6 -63.6,63.6 -63.6,-63.6 63.6,-63.6\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"63.6\" y1=\"66.1\" x2=\"63.6\" y2=\"83.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-63.6\" y1=\"66.1\" x2=\"-63.6\" y2=\"83.1\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"63.6\" y1=\"79.6\" x2=\"-63.6\" y2=\"79.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"67.6\" y1=\"75.6\" x2=\"59.6\" y2=\"83.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-59.6\" y1=\"75.6\" x2=\"-67.6\" y2=\"83.6\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"94\" text-anchor=\"middle\" class=\"fig-etq\">40 m</text></g></svg>"
  },
  {
   "id": "149",
   "ex": 149,
   "ap": "",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un senyal de trànsit d'STOP té forma d'octàgon regular, amb una altura de 90 cm (distància entre costats oposats) i un costat de 37 cm. Quina és la seva àrea?",
   "opcions": [
    "$3\\,330$ cm$^2$",
    "$1\\,665$ cm$^2$",
    "$6\\,660$ cm$^2$",
    "$16\\,650$ cm$^2$"
   ],
   "pistes": [
    "L'apotema d'un octàgon regular és la meitat de l'alçada (la distància entre dos costats oposats): $\\dfrac{90}{2}=45$ cm.",
    "Perímetre: $8\\times37$; àrea: $\\dfrac{\\text{perímetre}\\cdot\\text{apotema}}{2}$."
   ],
   "nota": "",
   "clau": "eyJvayI6IDIsICJkaWFnIjogWyJBcXVlc3QgdmFsb3IgZGl2aWRlaXggcGVyICQyJCB1bmEgdmVnYWRhIGRlIG3DqXM6IHVuIGNvcCB0ZW5zIGVsIHBlcsOtbWV0cmUgaSBsJ2Fwb3RlbWEsIGwnw6ByZWEgw6lzICRcXGRmcmFje1xcdGV4dHtwZXLDrW1ldHJlfVxcY2RvdFxcdGV4dHthcG90ZW1hfX17Mn0kLCBpIGphIGhhcyBhcGxpY2F0IGFxdWVzdGEgZGl2aXNpw7Mgc2kgaGFzIGZldCAkXFxkZnJhY3syOTZcXGNkb3Q0NX17Mn0kIGNvcnJlY3RhbWVudCDigJQgY29tcHJvdmEgcXVlIG5vIGwnaGFzIHRvcm5hdCBhIGRpdmlkaXIgcGVyICQyJC4iLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSBkaXZpZGlyIHBlciAkMiQgZHVlcyB2ZWdhZGVzIG3DqXMgZGVsIGNvbXB0ZTogcmV2aXNhIGVsIGPDoGxjdWwgJFxcZGZyYWN7Mjk2XFxjZG90NDV9ezJ9JCBwYXMgYSBwYXMuIiwgIiIsICJBcXVlc3QgdmFsb3Igc2VtYmxhIGZldCBzZXJ2aXIgbCdhbMOnYWRhIHNlbmNlcmEgKCQ5MCQgY20pIGNvbSBzaSBmb3MgbCdhcG90ZW1hLCBlbiBsbG9jIGRlIGxhIHNldmEgbWVpdGF0ICgkNDUkIGNtKTogZW4gdW4gb2N0w6Bnb24gcmVndWxhciwgbCdhbMOnYWRhIChkaXN0w6BuY2lhIGVudHJlIGNvc3RhdHMgb3Bvc2F0cykgw6lzIGVsIERPQkxFIGRlIGwnYXBvdGVtYS4iXSwgImVyciI6IFsiQVJSRUxfRkFDVE9SX09CTElEQVQiLCAiRElWSVNJT19SRVBFVElEQSIsICIiLCAiQ0FURVRfTUFMX0lERU5USUZJQ0FUIl0sICJyZXMiOiBbIkFwb3RlbWE6ICRcXGRmcmFjezkwfXsyfT00NSQgY20iLCAiUGVyw61tZXRyZTogJDhcXHRpbWVzMzc9Mjk2JCBjbSIsICLDgHJlYTogJFxcZGZyYWN7Mjk2XFx0aW1lczQ1fXsyfT02XFwsNjYwJCBjbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 195 228\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Octàgon regular, costat 37 cm, amb l'apotema marcada.</title><g transform=\"translate(97.1,97.1)\"><polygon points=\"34.4,83.1 -34.4,83.1 -83.1,34.4 -83.1,-34.4 -34.4,-83.1 34.4,-83.1 83.1,-34.4 83.1,34.4\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"34.4\" y1=\"85.6\" x2=\"34.4\" y2=\"102.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-34.4\" y1=\"85.6\" x2=\"-34.4\" y2=\"102.6\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"34.4\" y1=\"99.1\" x2=\"-34.4\" y2=\"99.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"38.4\" y1=\"95.1\" x2=\"30.4\" y2=\"103.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-30.4\" y1=\"95.1\" x2=\"-38.4\" y2=\"103.1\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"0.0\" y2=\"83.1\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2.5\"/><path d=\"M 9.0 83.1 L 9.0 74.1 L 0.0 74.1\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\"/><text x=\"0\" y=\"113.5\" text-anchor=\"middle\" class=\"fig-etq\">37 cm</text><text x=\"-26\" y=\"44.9\" text-anchor=\"middle\" class=\"fig-etq\">45 cm</text></g></svg>"
  },
  {
   "id": "150",
   "ex": 150,
   "ap": "",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Cada un dels 50 pisos d'un edifici té la planta d'un hexàgon regular de costat 30 m. Si el terra té una moqueta que costa 20 €/m$^2$, calcula el preu total pagat per la moqueta de l'edifici.",
   "opcions": [
    "$1\\,350\\sqrt3\\approx2\\,338{,}27$ €",
    "$116\\,913{,}43$ €",
    "$46\\,765{,}37$ €",
    "$2\\,338\\,268{,}59$ €"
   ],
   "pistes": [
    "Calcula primer l'àrea d'un pis (hexàgon regular de costat 30 m): $A=\\dfrac{3L^2\\sqrt3}{2}$.",
    "Multiplica l'àrea d'un pis pel preu del m$^2$ i pels $50$ pisos de l'edifici."
   ],
   "nota": "",
   "clau": "eyJvayI6IDMsICJkaWFnIjogWyJBcXVlc3QgdmFsb3Igw6lzIGwnw6ByZWEgKGVuIG0kXjIkKSBkJ3VuIHNvbCBwaXMsIHNlbnNlIG11bHRpcGxpY2FyLWxhIG5pIHBlbCBwcmV1IGRlbCBtJF4yJCBuaSBwZWxzICQ1MCQgcGlzb3MuIiwgIkFxdWVzdCB2YWxvciDDqXMgZWwgY29zdCB0b3RhbCBkZSBsYSBtb3F1ZXRhIGQndW4gU09MIHBpcyAoJDIwJCDigqwvbSReMiQgaW5jbG9zb3MpLCBzZW5zZSBtdWx0aXBsaWNhciBwZWxzICQ1MCQgcGlzb3MgZGUgbCdlZGlmaWNpLiIsICJBcXVlc3QgdmFsb3Igc2VtYmxhIGVsIGNvc3QgZCd1biBzb2wgcGlzICjDoHJlYSAkXFx0aW1lczIwJCDigqwpLCBzZW5zZSBtdWx0aXBsaWNhciBwZWxzICQ1MCQgcGlzb3MgZGUgbCdlZGlmaWNpLiIsICIiXSwgImVyciI6IFsiUEFTX0lOVEVSTUVESV9QRVJfUkVTUE9TVEEiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICJURVJNRV9PQkxJREFUX09QRVJBQ0lPIiwgIiJdLCAicmVzIjogWyLDgHJlYSBkJ3VuIHBpczogJFxcZGZyYWN7M1xcY2RvdDMwXjJcXHNxcnQzfXsyfT0xXFwsMzUwXFxzcXJ0M1xcYXBwcm94MlxcLDMzOHssfTI3JCBtJF4yJCIsICJDb3N0IGQndW4gcGlzOiAkMlxcLDMzOHssfTI3XFx0aW1lczIwXFxhcHByb3g0NlxcLDc2NXssfTM3JCDigqwiLCAiQ29zdCB0b3RhbCAoJDUwJCBwaXNvcyk6ICQ0NlxcLDc2NXssfTM3XFx0aW1lczUwXFxhcHByb3gyXFwsMzM4XFwsMjY4eyx9NTkkIOKCrCJdfQ==",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 208 217\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Hexàgon regular, costat 30 m.</title><g transform=\"translate(104.0,91.9)\"><polygon points=\"45.0,77.9 -45.0,77.9 -90.0,0.0 -45.0,-77.9 45.0,-77.9 90.0,-0.0\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"80.4\" x2=\"45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"-45.0\" y1=\"80.4\" x2=\"-45.0\" y2=\"97.4\" stroke=\"currentColor\" stroke-width=\"0.9\" stroke-opacity=\"0.65\"/><line class=\"fig-cota\" x1=\"45.0\" y1=\"93.9\" x2=\"-45.0\" y2=\"93.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"49.0\" y1=\"89.9\" x2=\"41.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><line class=\"fig-cota\" x1=\"-41.0\" y1=\"89.9\" x2=\"-49.0\" y2=\"97.9\" stroke=\"currentColor\" stroke-width=\"1.1\"/><text x=\"0\" y=\"108.3\" text-anchor=\"middle\" class=\"fig-etq\">30 m</text></g></svg>"
  },
  {
   "id": "151",
   "ex": 151,
   "ap": "",
   "bloc": "problemes",
   "tipus": "A",
   "dif": 4,
   "encapcalament": "",
   "enunciat": "Un pastisser ha cobert de sucre la part superior de 200 rosquilles: cadascuna té diàmetre exterior 6 cm i un forat central de diàmetre 5 cm. Si ha fet servir 5 kg de sucre, quants grams de sucre fan falta per cobrir cada centímetre quadrat de rosquilla?",
   "opcions": [
    "$\\approx2{,}89$ g/cm$^2$",
    "$\\approx0{,}91$ g/cm$^2$",
    "$\\approx28{,}94$ g/cm$^2$",
    "$\\approx1{,}45$ g/cm$^2$"
   ],
   "pistes": [
    "L'àrea de la part superior d'una rosquilla és una corona circular: àrea del cercle exterior (radi $3$ cm) menys la del forat (radi $2{,}5$ cm).",
    "Multiplica l'àrea d'una rosquilla per les $200$ unitats, i divideix els $5\\,000$ g de sucre entre aquesta àrea total."
   ],
   "nota": "La \"rosquilla\" es tracta com una corona circular plana (només la cara de dalt, que és la que es cobreix de sucre), no com un cos de tres dimensions: els $6$ cm i els $5$ cm són diàmetres, l'exterior i el del forat.",
   "clau": "eyJvayI6IDAsICJkaWFnIjogWyIiLCAiQXF1ZXN0IHZhbG9yIHNlbWJsYSBkaXZpZGlyIGVscyAkNVxcLDAwMCQgZyBlbnRyZSBsJ8OgcmVhIGQnVU5BIHNvbGEgcm9zcXVpbGxhLCBubyBlbnRyZSBsJ8OgcmVhIHRvdGFsIGRlIGxlcyAkMjAwJCByb3NxdWlsbGVzLiIsICJBcXVlc3QgdmFsb3Igbm8gbXVsdGlwbGljYSBsJ8OgcmVhIGQndW5hIHJvc3F1aWxsYSBwZXIgbGVzICQyMDAkIHVuaXRhdHMgYWJhbnMgZGUgZGl2aWRpciBlbCBzdWNyZTogcmV2aXNhIHF1ZSBoYXMgY2FsY3VsYXQgbCfDoHJlYSBUT1RBTCwgbm8gbGEgZCd1bmEgc29sYSByb3NxdWlsbGEuIiwgIkFxdWVzdCB2YWxvciBzZW1ibGEgZmV0IHNlcnZpciBlbHMgZGnDoG1ldHJlcyBkaXJlY3RhbWVudCBjb20gYSByYWRpcyBlbiBjYWxjdWxhciBsJ8OgcmVhIGRlIGxhIGNvcm9uYSBjaXJjdWxhcjogZWwgcmFkaSDDqXMgbGEgTUVJVEFUIGRlbCBkacOgbWV0cmUgKCQzJCBjbSBpICQyeyx9NSQgY20pLCBubyBlbCBkacOgbWV0cmUgc2VuY2VyICgkNiQgY20gaSAkNSQgY20pLiJdLCAiZXJyIjogWyIiLCAiRkFDVE9SX09CTElEQVQiLCAiVEVSTUVfT0JMSURBVF9PUEVSQUNJTyIsICJDQVRFVF9NQUxfSURFTlRJRklDQVQiXSwgInJlcyI6IFsiw4ByZWEgZCd1bmEgcm9zcXVpbGxhOiAkXFxwaVxcY2RvdDNeMi1cXHBpXFxjZG90MnssfTVeMj04eyx9NjQkIGNtJF4yJCIsICLDgHJlYSB0b3RhbCAoJDIwMCQgcm9zcXVpbGxlcyk6ICQ4eyx9NjRcXHRpbWVzMjAwPTFcXCw3Mjd7LH04OCQgY20kXjIkIiwgIlN1Y3JlIHBlciBjbSReMiQ6ICRcXGRmcmFjezVcXCwwMDB9ezFcXCw3Mjd7LH04OH1cXGFwcHJveDJ7LH04OSQgZy9jbSReMiQiXX0=",
   "figura": "<svg class=\"figura\" viewBox=\"0 0 267 188\" role=\"img\" xmlns=\"http://www.w3.org/2000/svg\"><title>Corona circular: radi exterior 3 cm, radi interior 2,5 cm.</title><g transform=\"translate(94.0,94.0)\"><path d=\"M0,0 m-80,0 a80,80 0 1,0 160,0 a80,80 0 1,0 -160,0 M0,0 m-66.6667,0 a66.6667,66.6667 0 1,0 133.333,0 a66.6667,66.6667 0 1,0 -133.333,0\" fill-rule=\"evenodd\" fill=\"var(--fig-plena, #E9F0F6)\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"66.7\" y2=\"0.0\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line x1=\"0.0\" y1=\"0.0\" x2=\"-56.6\" y2=\"-56.6\" stroke=\"var(--fig-marca, #B3453C)\" stroke-width=\"2\"/><line class=\"fig-crida\" x1=\"33.3\" y1=\"0.0\" x2=\"85.1\" y2=\"0.0\" stroke=\"currentColor\" stroke-width=\"1\" stroke-opacity=\"0.55\"/><text x=\"123.3\" y=\"2.9\" text-anchor=\"middle\" class=\"fig-etq petita\">int. 2,5 cm</text><text x=\"-3.1\" y=\"-36.9\" text-anchor=\"middle\" class=\"fig-etq petita\">ext. 3 cm</text></g></svg>"
  }
 ]
};
