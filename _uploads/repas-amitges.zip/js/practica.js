/* practica.js — el cicle de quatre passos: enunciat, pistes, resposta, resolució.
   Genèric per a qualsevol full: llegeix window.FULL, que full.html/practica.html
   omplen carregant el data/fullN.js que indica el paràmetre ?full=N.

   Amb ?origen=itinerari a la URL, tota la navegació de sortida (Següent,
   Anterior i l'enllaç de tornada) va a itinerari.html en lloc de seguir
   l'ordre del full; sense aquest paràmetre el comportament és el normal. */
(function () {
  "use strict";
  if (!window.FULL) return;   /* practica.html ja mostra "aquest full encara no està preparat" */

  var D = window.FULL, $ = function (s) { return document.querySelector(s); };
  var ids = D.items.map(function (i) { return i.id; });
  var params = new URLSearchParams(location.search);
  var qid = params.get("q") || ids[0];
  var deLitinerari = params.get("origen") === "itinerari";
  /* Un ?q= que no existeix en aquest full queia en silenci al primer
     exercici: qui seguia un enllaç antic (o d'un altre full) es trobava el
     140 convertit en l'1 sense saber per què, i el registre li anotava un
     "vist" d'un exercici que no havia demanat. */
  var idx = ids.indexOf(qid);
  if (idx < 0) {
    document.getElementById("main").innerHTML =
      '<div class="barra-sup"><a href="full.html?full=' + D.full +
      '" class="petit">← ' + D.titol + "</a></div>" +
      "<h1>Aquest exercici no és en aquest full</h1>" +
      '<p class="apagat" style="margin:.6rem 0 1.4rem">L\'enllaç demana ' +
      "l'exercici <strong>" + String(qid).replace(/[<&]/g, "") +
      "</strong>, i el full " + D.full + " no en té cap amb aquest codi. " +
      "Potser és d'un altre full o d'una versió anterior.</p>" +
      '<a class="btn" href="full.html?full=' + D.full + '">Torna al full</a>';
    return;
  }
  var item = D.items[idx], k = RE.clau(item);

  var ordre = [0, 1, 2, 3];                       /* barreja per sessió */
  for (var i = 3; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1)), t = ordre[i];
    ordre[i] = ordre[j]; ordre[j] = t;
  }
  var LLETRES = ["A", "B", "C", "D"];

  /* L'estat de l'exercici NO comença de zero a cada càrrega de pàgina: es
     llegeix del registre. Si en una visita anterior s'havia fallat un intent
     o s'havien obert pistes, això segueix comptant ara. Recarregar deixa de
     ser una manera de tornar a començar. */
  var reg = RE.item(D.full, item.id);
  var pistes = reg.npis || 0;            /* pistes ja obertes, de sempre */
  var mostrades = 0;                     /* pistes visibles en aquesta pàgina */
  var intents = reg.nint || 0;           /* intents ja gastats, de sempre */
  var triada = -1;
  var repas = !!reg.tancat;              /* ja té estat definitiu: això és repàs */
  var tancat = false;                    /* aquesta pantalla ja ha donat veredicte */
  var intentsPagina = 0;

  /* Si s'ha arribat des de l'itinerari (?origen=itinerari), TOTA la
     navegació de sortida (Següent, Anterior, i el "← Full X" de dalt) torna
     a itinerari.html en lloc de continuar amb l'ordre normal del full:
     l'itinerari és una llista de passos, no una seqüència que es navegui
     endavant/enrere des de dins l'exercici — allà l'alumne ja veu tot el
     recorregut i tria on continuar. */
  function ves(n) {
    if (deLitinerari) { surt("itinerari.html"); return; }
    if (n < 0 || n >= ids.length) { surt("full.html?full=" + D.full); return; }
    surt("practica.html?full=" + D.full + "&q=" + ids[n]);
  }

  /* ---- sortir d'un exercici a mitges ----

     Si l'alumne marxa d'un exercici que ha treballat però no ha respost, se
     li diu UNA vegada, dins de la targeta i sense bloquejar res: el segon
     «Següent» (o «Deixa'l per a més tard») ja marxa. No és un confirm() del
     navegador a posta: en una tauleta aquell diàleg tapa la pantalla, no diu
     res de l'exercici i s'aprèn a acceptar-lo sense llegir.

     Qui només fulleja (menys de RE.LLINDAR segons, sense pistes ni opcions)
     no veu res. Qui acaba de fallar el primer intent tampoc: el veredicte que
     té a la vista ja li diu que si marxa l'exercici queda fallat. */
  var avisat = false;
  function calAvisar() {
    if (avisat || tancat || repas || intentsPagina > 0) return false;
    if (triada >= 0) return true;                       /* triada i no comprovada */
    crono.desa();                  /* el temps d'ara, no el de l'últim interval */
    return RE.esAMitges(RE.item(D.full, item.id));
  }

  function surt(desti) {
    if (!calAvisar()) { location.href = desti; return; }
    avisat = true;
    mostraAvisSortida(desti);
  }

  function mostraAvisSortida(desti) {
    var caixa = $("#avis-sortida");
    if (!caixa) { location.href = desti; return; }
    var reg2 = RE.item(D.full, item.id);
    var motiu = triada >= 0
      ? "Has triat la <strong>" + LLETRES[triada] + "</strong>, però encara no l'has comprovada."
      : (reg2.estat === "fallat"
        ? "Vas fallar el primer intent i encara et queda el segon."
        : "Si ja el tens resolt a la llibreta, mostra les opcions i comprova la resposta: només així queda anotat.");
    caixa.innerHTML =
      '<h2 id="avis-sortida-titol">Encara no has respost aquest exercici</h2>' +
      "<p>" + motiu + "</p>" +
      '<p class="petit apagat">Si el deixes ara, el trobaràs a la portada, a ' +
      "<strong>«Tens exercicis a mitges»</strong>. Apunta't el codi " +
      '<span class="codi">' + item.id + "</span> a la llibreta.</p>" +
      '<div class="accions">' +
        '<button type="button" class="btn" id="avis-respon">Respon ara</button>' +
        '<button type="button" class="btn buit" id="avis-marxa">Deixa\'l per a més tard →</button>' +
      "</div>";
    caixa.hidden = false;
    $("#avis-respon").onclick = function () {
      caixa.hidden = true;
      if ($("#zona-resposta").hidden) {
        $("#mostra").click();
      } else {
        var op = $("#opcions");
        if (op.scrollIntoView) op.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      /* El focus va on toca seguir: a «Comprova» si ja hi ha opció triada,
         a la primera opció viva si no. Sense això, amb teclat el focus es
         quedaria en un botó que acaba de desaparèixer. */
      var desti2 = triada >= 0 ? $("#comprova")
        : Array.prototype.filter.call($("#opcions").children, function (c) { return !c.disabled; })[0];
      if (desti2 && desti2.focus) desti2.focus({ preventScroll: true });
    };
    $("#avis-marxa").onclick = function () { location.href = desti; };
    if (caixa.scrollIntoView) caixa.scrollIntoView({ behavior: "smooth", block: "center" });
    var b = $("#avis-respon");
    if (b && b.focus) b.focus({ preventScroll: true });
  }

  /* ---- capçalera ---- */
  var bloc = D.blocs.filter(function (b) { return b.id === item.bloc; })[0];
  $("#tornar").textContent = deLitinerari ? "← El teu itinerari" : "← " + D.titol;
  $("#tornar").href = deLitinerari ? "itinerari.html" : "full.html?full=" + D.full;
  /* L'enllaç de dalt també és una sortida. Amb Ctrl/Cmd/clic del mig
     s'obre en una pestanya nova i l'exercici es queda obert: llavors no cal
     cap avís. */
  $("#tornar").addEventListener("click", function (e) {
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1) return;
    if (!calAvisar()) return;
    e.preventDefault();
    surt($("#tornar").href);
  });
  $("#codi").textContent = item.id;
  $("#situacio").textContent = bloc.titol + " · " + (idx + 1) + " de " + ids.length;
  $("#encap").textContent = item.encapcalament;
  $("#enunciat").innerHTML = item.enunciat;
  /* La figura va DESPRÉS de l'enunciat, no al lloc: l'enunciat ha de poder
     resoldre's tot sol amb un lector de pantalla, i el dibuix hi és per
     entendre-ho més de pressa. Si no n'hi ha, el contenidor queda amagat i no
     deixa cap forat. */
  if (item.figura) {
    $("#figura").innerHTML = item.figura;
    $("#figura").hidden = false;
  } else {
    $("#figura").innerHTML = "";
    $("#figura").hidden = true;
  }
  if (item.nota) { $("#nota").innerHTML = "<strong>Nota:</strong> " + item.nota; $("#nota").hidden = false; }
  /* La icona de teoria, si aquest exercici en té de mapada. Va a la
     capçalera, al costat del codi: qui no la necessita no l'ha de veure
     enmig de l'enunciat. */
  /* Se li passa el full perquè els noms de bloc no són únics entre fulls
     (vegeu `js/teoria.js`).

     Va dins d'un try: la icona de teoria és una decoració, i una decoració
     no pot tombar el cicle de l'exercici. Aquest `mostra()` és a dalt de la
     IIFE, i quan `teoria.js` va llançar un error sincrònic (li faltava
     `fetch`) se'n va endur tot el que ve a continuació: les quatre opcions
     no es construïen i la pàgina quedava sense res per respondre. Que la
     causa concreta ja estigui arreglada no treu que el lloc no hagi de ser
     així: el que hi ha per sota d'aquesta línia és l'exercici. */
  if (window.RE_TEORIA) {
    try {
      window.RE_TEORIA.mostra($("#teoria"),
        { id: item.id, ex: item.ex, bloc: item.bloc, full: D.full });
    } catch (e) { /* sense icona de teoria; l'exercici continua */ }
  }
  RE.mat(document.body);
  /* `visita` posa "vist" si encara no hi havia res (com abans) i renova
     `tvis`, l'última visita. El rellotge compta el temps actiu d'aquest
     exercici: és el que fa que, l'endemà, surti a «Tens exercicis a mitges». */
  RE.visita(D.full, item.id);
  RE.rellotge();
  var crono = RE.cronoExercici(D.full, item.id);

  /* Si l'exercici ja té estat definitiu, o si en una visita anterior es va
     deixar a mitges després d'un error, cal dir-ho abans que l'alumne
     respongui: el que passi ara no val el mateix que la primera vegada, i
     amagar-ho seria convidar-lo a jugar-hi. */
  function avisEstat(txt) {
    var d = document.createElement("p");
    d.className = "petit apagat";
    d.style.margin = ".2rem 0 .6rem";
    d.innerHTML = txt;
    var enc = $("#encap");
    if (enc && enc.parentNode) enc.parentNode.insertBefore(d, enc.nextSibling);
  }
  if (repas) {
    avisEstat("Aquest exercici ja el vas <strong>" + (RE.ETIQ[reg.estat] || "fer") +
      "</strong>. Tornar-hi va molt bé, però el registre ja no canvia: "
      + "el que queda anotat és com et va anar la primera vegada.");
  } else if (intents || pistes) {
    avisEstat("D'una estona anterior en aquest exercici ja portes " +
      (intents ? intents + (intents === 1 ? " intent" : " intents") : "") +
      (intents && pistes ? " i " : "") +
      (pistes ? pistes + (pistes === 1 ? " pista" : " pistes") : "") +
      ". Compten igual que si no haguessis marxat.");
  } else if (RE.esAMitges(reg)) {
    /* Hi havia estat treballant però no va respondre: és just el cas que
       l'alumne busca. Se li diu, i on és el botó, sense fer-ho per ell. */
    avisEstat("L'última vegada hi vas estar " + durada(reg.tact || 0) +
      " i no el vas respondre. Si ja el tens resolt a la llibreta, prem "
      + "<strong>«Ja ho tinc, mostra'm les opcions»</strong> i comprova la resposta.");
  }

  function durada(seg) {
    if (seg < 60) return "una estona";
    var m = Math.round(seg / 60);
    if (m < 60) return m + " min";
    return Math.floor(m / 60) + " h " + (m % 60) + " min";
  }

  /* ---- pistes ---- */
  $("#pista").onclick = function () {
    if (mostrades >= item.pistes.length) return;
    var d = document.createElement("div");
    d.className = "pista-txt";
    d.innerHTML = "<strong>Pista " + (mostrades + 1) + ".</strong> " + item.pistes[mostrades];
    $("#pistes").appendChild(d);
    RE.mat(d);
    mostrades++;
    /* Es desa el NOMBRE de pistes obertes, no un increment: qui ja n'havia
       obert dues i torna a la pàgina pot rellegir-les sense que el comptador
       es dispari, i tampoc no el pot posar a zero recarregant. */
    if (!repas) pistes = RE.pista(D.full, item.id, mostrades);
    if (mostrades >= item.pistes.length) {
      $("#pista").disabled = true;
      $("#pista").textContent = "No queden més pistes";
    }
  };

  /* ---- opcions ----
     Les quatre opcions formen un radiogroup ARIA: una sola es pot triar, i
     cal que s'anunciï com a tal. `aria-checked` porta l'estat; el roving
     tabindex (només la triada, o la primera si encara no n'hi ha cap, és
     tabulable) és el patró estàndard perquè Tab entri i surti del grup d'un
     sol pas i les fletxes es moguin per dins. */
  var caixa = $("#opcions");
  /* Roving tabindex: només UN botó del grup és tabulable.

     Amb `pos = -1` (cap opció triada) el tabindex se'n va a la primera opció
     que encara es pugui prémer. Sense això, en fallar el primer intent l'única
     opció amb tabIndex 0 era la que s'acabava de desactivar, i com que un botó
     `disabled` no és focusable el grup sencer quedava fora de l'abast del
     tabulador: amb teclat era impossible tornar-hi per fer el segon intent. */
  function marca(pos) {
    var fill = Array.prototype.slice.call(caixa.children);
    var tab = pos;
    if (tab < 0 || fill[tab].disabled) {
      tab = fill.findIndex(function (c) { return !c.disabled; });
    }
    fill.forEach(function (c, i) {
      c.setAttribute("aria-checked", i === pos && !c.disabled ? "true" : "false");
      c.tabIndex = i === tab ? 0 : -1;
    });
  }
  ordre.forEach(function (orig, pos) {
    var b = document.createElement("button");
    b.className = "opcio";
    b.type = "button";
    b.dataset.orig = orig;
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", "false");
    b.tabIndex = pos === 0 ? 0 : -1;
    b.innerHTML = '<span class="lletra">' + LLETRES[pos] + "</span><span>" +
      item.opcions[orig] + "</span>";
    b.onclick = function () {
      if (tancat) return;
      Array.prototype.forEach.call(caixa.children, function (c) { c.classList.remove("tria"); });
      b.classList.add("tria");
      triada = pos;
      marca(pos);
      $("#comprova").disabled = false;
    };
    caixa.appendChild(b);
  });
  RE.mat(caixa);

  /* Fletxes amunt/avall i esquerra/dreta mouen el focus (i la tria de
     tabindex) dins del grup, sense activar la selecció — el patró habitual
     de radiogroup és moure't lliurement i deixar que Space/Enter (natius a
     <button>) confirmin. S'atura la propagació perquè aquestes mateixes
     fletxes no arribin també al listener de navegació d'exercici de més
     avall: dins del grup, primer són seves. */
  caixa.addEventListener("keydown", function (e) {
    if (tancat) return;
    var n = caixa.children.length;
    var actual = Array.prototype.indexOf.call(caixa.children, document.activeElement);
    if (actual < 0) return;
    var seguent = -1;
    if (e.key === "ArrowDown" || e.key === "ArrowRight") seguent = (actual + 1) % n;
    else if (e.key === "ArrowUp" || e.key === "ArrowLeft") seguent = (actual - 1 + n) % n;
    else if (e.key === "Home") seguent = 0;
    else if (e.key === "End") seguent = n - 1;
    else return;
    e.preventDefault();
    e.stopPropagation();
    caixa.children[actual].tabIndex = -1;
    var el = caixa.children[seguent];
    el.tabIndex = 0;
    el.focus();
  });

  $("#mostra").onclick = function () {
    $("#mostra").hidden = true;
    $("#zona-resposta").hidden = false;
    if (!repas) RE.marcaOpcions(D.full, item.id);
    var op = $("#opcions");
    if (op.scrollIntoView) op.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  /* ---- comprovació ---- */
  $("#comprova").onclick = function () {
    if (triada < 0 || tancat) return;
    intentsPagina++;
    var orig = ordre[triada], encert = orig === k.ok;
    var btn = caixa.children[triada];
    var v = $("#veredicte");

    /* Qui decideix l'estat és nucli.js a partir dels comptadors acumulats de
       l'ítem, no aquesta pantalla a partir del que ha passat des que s'ha
       carregat. Aquí només es pinta el resultat. */
    if (!encert) RE.apuntaError(D.full, item.id, k.err[orig]);
    var r = RE.intent(D.full, item.id, encert);
    intents = (RE.item(D.full, item.id).nint) || intents + 1;
    /* Queda un segon intent si el registre encara no s'ha tancat I aquesta
       pantalla tampoc no ha gastat els dos intents. La segona condició no és
       redundant: si el navegador no deixa desar res (mode privat estricte,
       quota plena, política del centre), el registre torna buit a cada
       lectura i sense això l'exercici no es tancaria mai. Amb magatzem, mana
       el registre; sense, almenys la pantalla es comporta bé. */
    var quedaIntent = intentsPagina < 2 && (repas || !r.tancat);

    if (encert) {
      tancat = true;
      btn.classList.remove("tria"); btn.classList.add("bona");
      btn.setAttribute("aria-describedby", "veredicte");
      v.className = "veredicte be";
      v.innerHTML = "<h2>Correcte</h2>" + (
        r.repas ? "Repàs fet. Al registre hi continua constant com et va anar la "
                  + "primera vegada (<strong>" + (RE.ETIQ[r.estat] || "?") + "</strong>), "
                  + "que és el que té sentit que hi consti."
        : r.estat === "pista" ? "Ho has resolt amb ajuda. Torna-hi d'aquí a uns dies sense demanar pistes."
        : r.estat === "segon" ? "Bé al segon intent: el primer error ja saps quin era."
        : "A la primera i sense pistes.");
    } else {
      btn.classList.remove("tria"); btn.classList.add("dolenta");
      btn.disabled = true;
      v.className = "veredicte malament";
      if (quedaIntent) {
        btn.setAttribute("aria-describedby", "veredicte");
        v.innerHTML = "<h2>Encara no</h2>" + k.diag[orig] +
          "<p class='petit apagat' style='margin:.4rem 0 0'>Tens un intent més." +
          (repas ? "" : " Aquest error ja ha quedat anotat: si te'n vas ara, "
            + "l'exercici es queda com a fallat.") + "</p>";
        triada = -1;
        marca(-1);          /* torna el focus tabulable a una opció encara viva */
        $("#comprova").disabled = true;
      } else {
        /* L'estat "fallat" ja el va desar RE.intent() al PRIMER error: aquí
           no cal tornar-hi, i sobretot no cal que aquesta pantalla decideixi
           res sobre el registre. */
        tancat = true;
        var btnOk = caixa.children[ordre.indexOf(k.ok)];
        btnOk.classList.add("bona");
        btnOk.setAttribute("aria-describedby", "veredicte");
        v.innerHTML = "<h2>La resposta correcta és la " +
          LLETRES[ordre.indexOf(k.ok)] + "</h2>" + k.diag[orig] +
          "<p style='margin:.4rem 0 0'>Mira't la resolució amb calma.</p>";
      }
    }
    RE.mat(v);
    if (tancat) {
      Array.prototype.forEach.call(caixa.children, function (c) { c.disabled = true; });
      $("#comprova").hidden = true;
      $("#pista").hidden = true;
      /* La resolució NO es mostra mai tota sola, encertis o fallis: és
         l'alumne qui l'ha de demanar prement aquest botó, igual que demanar
         una pista és decisió seva. Abans hi havia un
         `if (!encert) $("#veure").click()` que la mostrava d'ofici quan
         s'esgotaven els dos intents, i això té dos problemes: converteix
         "mirar la resolució" en una cosa que li PASSA a l'alumne en lloc
         d'una cosa que ell fa, i trenca la simetria amb el cas d'encert
         (si respons bé, ningú et clica el botó per tu). El botó es queda
         sempre visible i sempre per prémer; mai premut per l'aplicació. */
      $("#veure").hidden = false;
    }
  };

  /* ---- resolució ---- */
  $("#veure").onclick = function () {
    /* La visibilitat del botó (`hidden`) ja hauria de bastar per impedir
       que això es premi abans d'hora, però ha quedat demostrat que un sol
       punt de control és fràgil (vegeu la regla `[hidden]` a estil.css):
       una classe amb `display` propi n'hi va haver prou per fer-lo visible
       i clicable des del principi. Aquesta comprovació és el segon punt de
       control, independent del render: encara que algú tornés a amagar
       accidentalment aquest botó només amb CSS, o el disparés per una via
       que no sigui un clic normal (consola, extensió, etc.), la resolució
       només es construeix quan l'exercici ja està `tancat`. */
    if (!tancat && !repas) return;
    $("#veure").hidden = true;
    var r = $("#resolucio");
    /* El comentari («Per recordar») és la idea que cal endur-se'n un cop
       resolt: el parany del bloc, el cas que sorprèn. Viatja dins de la clau,
       com la resolució, perquè abans de respondre regalaria la resposta: la nota
       que surt amb l'enunciat no pot dir res que acosti a la resposta. */
    r.innerHTML = "<h2>Resolució</h2><ol>" +
      k.res.map(function (p) { return "<li>" + p + "</li>"; }).join("") + "</ol>" +
      (k.com ? '<p class="comentari"><strong>Per recordar.</strong> ' + k.com + "</p>" : "");
    RE.mat(r);
    if (r.scrollIntoView) r.scrollIntoView({ behavior: "smooth", block: "nearest" });
  };

  /* "Següent" és sempre disponible, hagi respost l'alumne o no: avançar
     d'exercici no s'ha de bloquejar per obligar-lo a contestar. És diferent
     de #veure ("Mostra la resolució"), que sí que ha de restar amagat fins
     que `tancat` — veure la solució abans d'hora buida l'exercici de sentit,
     saltar-se'l no. */
  /* Si l'exercici ja està tancat al registre, la resolució ja se l'ha
     guanyada: el botó hi és des del principi. No és cap regal —l'estat ja no
     pot canviar— i evita que hagi de tornar a respondre per llegir-la. */
  if (repas) $("#veure").hidden = false;

  $("#seguent").onclick = function () { ves(idx + 1); };
  $("#anterior").onclick = function () { ves(idx - 1); };
  /* Les fletxes canvien d'exercici, però NO mentre s'escriu: el camp
     «Recupera la teva feina» del panell del codi és en aquesta mateixa
     pàgina, i qui hi enganxava un codi i premia ← per moure el cursor anava
     a parar a l'exercici anterior i perdia el que havia enganxat. Amb Alt,
     Ctrl o Cmd la fletxa és del navegador (Alt+← és «enrere»). */
  document.addEventListener("keydown", function (e) {
    var t = e.target, etiqueta = t && t.tagName;
    if (etiqueta === "INPUT" || etiqueta === "TEXTAREA" || etiqueta === "SELECT"
        || (t && t.isContentEditable)) return;
    if (e.altKey || e.ctrlKey || e.metaKey) return;
    if (e.key === "ArrowRight") ves(idx + 1);
    if (e.key === "ArrowLeft") ves(idx - 1);
  });
})();
