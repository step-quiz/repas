/* hub.js — pàgina d'un full (Nivell 1): botó "continua", resum d'errors,
   blocs i mapa de llacunes complet (plegat per defecte). Genèric per a
   qualsevol full: llegeix window.FULL, no cap full concret.

   Amb ?bloc=<id> a la URL, aquell bloc surt destacat i la pàgina hi fa
   scroll: és com hi arriba l'alumne des d'una recomanació del tutor. */
(function () {
  "use strict";
  if (!window.FULL) return;   /* full.html ja mostra "aquest full encara no està preparat" */

  var D = window.FULL, $ = function (s) { return document.querySelector(s); };
  var blocDestacat = new URLSearchParams(location.search).get("bloc");

  document.title = D.titol + " — Repàs d'ESO";
  $("#titol-full").textContent = D.titol;
  $("#subtitol-full").textContent = D.subtitol;
  if ($("#etiqueta-full")) $("#etiqueta-full").textContent = "Full " + D.full;

  function ves(id) {
    location.href = "practica.html?full=" + D.full + "&q=" + encodeURIComponent(id);
  }

  function primerPendent(ids) {
    for (var i = 0; i < ids.length; i++) {
      var e = RE.estat(D.full, ids[i]);
      if (e !== "net" && e !== "pista" && e !== "segon") return ids[i];
    }
    return ids[0];
  }

  function comptes() {
    var p = RE.llegeix(D.full).items;
    var n = { net: 0, pista: 0, segon: 0, fallat: 0, vist: 0, amitges: 0 };
    D.items.forEach(function (it) {
      var e = (p[it.id] || {}).estat;
      if (e === "vist" && RE.esAMitges(p[it.id])) n.amitges++;
      else if (e) n[e]++;
    });
    return n;
  }

  /* «Continua on ho vas deixar» ha de fer el que diu. Abans portava al
     PRIMER exercici no resolt segons l'ordre del full, que no té per què ser
     on l'alumne era: qui havia fet del 1 al 30 i s'havia saltat el 4 tornava
     al 4. Ara, si hi ha algun exercici a mitges, va al més recent; si no,
     al primer pendent, com abans. */
  function onContinuar() {
    var ult = RE.aMitges(D.full)[0];
    if (ult) return { id: ult.id, aMitges: ult };
    return { id: primerPendent(D.items.map(function (i) { return i.id; })) };
  }

  function pintaOberts() {
    var det = $("#oberts");
    if (!det) return;
    var ll = RE.nomesOberts(D.full);
    if (!ll.length) { det.hidden = true; return; }
    det.hidden = false;
    $("#oberts-titol").textContent = "Oberts sense respondre (" + ll.length + ")";
    $("#oberts-llista").innerHTML = ll.map(function (e) {
      var q = RE_MITGES.quan(e.quan);
      return '<a class="xip" href="' + RE_MITGES.url(e) + '"' +
        (q ? ' title="Obert ' + q + '"' : "") + ">" + e.id + "</a>";
    }).join("");
  }

  function pintaBlocs() {
    var p = RE.llegeix(D.full).items;
    var cont = $("#blocs");
    cont.innerHTML = "";
    D.blocs.forEach(function (b, i) {
      var ok = b.items.filter(function (id) {
        var e = (p[id] || {}).estat;
        return e === "net" || e === "pista" || e === "segon";
      }).length;
      var el = document.createElement("button");
      el.className = "bloc" + (b.id === blocDestacat ? " destacat" : "")
                   + (b.avancat ? " avancat" : "");
      el.type = "button";
      /* Els blocs on TOTS els exercicis són del nivell més alt es diuen. No
         és un avís de perill: és informació que evita que l'alumne entri a
         un bloc de problemes creient que serà com el primer del full, no
         se'n surti i en tregui la conclusió que el tema no el sap. Que
         sàpiga on és li deixa triar si hi entra ara o més tard. */
      el.innerHTML =
        '<span class="num">' + (i + 1) + "</span>" +
        '<span class="cos">' +
          '<span class="tit">' + b.titol +
            (b.avancat ? ' <span class="marca-avancat">nivell avançat</span>' : "") +
          "</span>" +
          '<div class="petit apagat">' + b.descripcio +
            (b.avancat ? " Tot el bloc són problemes de diversos passos: "
                       + "va bé deixar-lo per al final." : "") +
          "</div>" +
          '<div class="barra"><i style="width:' + Math.round(100 * ok / b.items.length) + '%"></i></div>' +
        "</span>" +
        '<span class="petit apagat">' + ok + "/" + b.items.length + "</span>";
      el.setAttribute("aria-label", b.titol
        + (b.avancat ? " (nivell avançat)" : "")
        + ": " + ok + " de " + b.items.length + " resoltes");
      el.onclick = function () { ves(primerPendent(b.items)); };
      cont.appendChild(el);
    });
    if (blocDestacat) {
      var elDestacat = cont.querySelector(".destacat");
      if (elDestacat && elDestacat.scrollIntoView) {
        elDestacat.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }

  function pintaErrors() {
    var cont = $("#errades");
    if (!cont) return;   /* secció retirada de la interfície; es manté la lògica per si es recupera */
    var p = RE.llegeix(D.full).items, tally = {}, mostra = {};
    Object.keys(p).forEach(function (id) {
      /* Historial sencer: un error rectificat al segon intent segueix comptant
         (vegeu RE.apuntaError a nucli.js). `err` només per al format antic. */
      var it = p[id];
      var errs = it.errs && it.errs.length ? it.errs : (it.err ? [it.err] : []);
      errs.forEach(function (e) {
        tally[e] = (tally[e] || 0) + 1;
        if (!mostra[e]) mostra[e] = id;     /* un ítem real on ha passat */
      });
    });
    var tops = Object.keys(tally).sort(function (a, b) { return tally[b] - tally[a]; });
    if (!tops.length) { cont.hidden = true; return; }

    /* D'on surt el text.

       Abans es donava sempre prioritat a la descripció genèrica del catàleg
       (D.errors). El problema és que unes quantes etiquetes TAX s'han acabat
       fent servir de calaix de sastre en blocs molt allunyats: per exemple
       TERME_OBLIDAT_OPERACIO ("revisa els polinomis grau a grau") etiqueta
       també l'oblit de les dues bases d'un cilindre al Full 9. L'alumne que
       s'equivocava comptant cares llegia un consell sobre polinomis.

       Regla nova: el text genèric només s'utilitza si aquella etiqueta viu en
       UN sol bloc d'aquest full -- llavors sí que descriu el malentès. Si es
       fa servir en més d'un bloc, no és una descripció fiable del cas concret
       i es mostra el diagnòstic de l'exercici real on l'alumne ha fallat, amb
       el bloc indicat perquè sàpiga on tornar. Sempre és cert, mai genèric de
       més. */
    var diagPerItem = {}, blocsPerEtiqueta = {}, titolBloc = {};
    (D.blocs || []).forEach(function (b) { titolBloc[b.id] = b.titol; });
    D.items.forEach(function (it) {
      var k = RE.clau(it);
      k.err.forEach(function (e, i) {
        if (!e) return;
        (blocsPerEtiqueta[e] = blocsPerEtiqueta[e] || {})[it.bloc] = true;
        (diagPerItem[e] = diagPerItem[e] || {})[it.id] = { text: k.diag[i], bloc: it.bloc };
      });
    });

    function textDe(e) {
      var blocs = Object.keys(blocsPerEtiqueta[e] || {});
      var generic = (D.errors || {})[e];
      if (generic && blocs.length <= 1) return generic;
      var perItem = diagPerItem[e] || {};
      var d = perItem[mostra[e]] || perItem[Object.keys(perItem)[0]];
      if (!d) return generic || e;
      var on = titolBloc[d.bloc];
      return d.text + (on ? ' <span class="petit apagat">(' + on + ")</span>" : "");
    }

    cont.hidden = false;
    cont.innerHTML = "<h2>Els errors que repeteixes</h2>" +
      tops.slice(0, 4).map(function (e) {
        return '<div class="errada"><strong>' + tally[e] + " vegad" + (tally[e] > 1 ? "es" : "a") +
          ":</strong> " + textDe(e) + "</div>";
      }).join("");
    RE.mat(cont);
  }

  function pinta() {
    var n = comptes(), fets = n.net + n.pista + n.segon;
    if ($("#comptador-linia")) {
      $("#comptador-linia").innerHTML = "<strong>" + fets + " de " + D.items.length + "</strong> resoltes";
    }
    var trossos = [];
    if (n.fallat) trossos.push(n.fallat + " per revisar");
    if (n.amitges) trossos.push(n.amitges + " a mitges");
    if (n.vist) trossos.push(n.vist + " només obertes");
    $("#detall").textContent = trossos.length
      ? trossos.join(" · ")
      : "Cada quadret és un apartat. Toca'n un per anar-hi directament.";

    RE.mapa($("#mapa"), D, ves);
    pintaBlocs();
    pintaErrors();
    if (window.RE_MITGES) {
      RE_MITGES.pinta($("#amitges"), { full: D.full, canvi: function () { pintaContinua(); RE.mapa($("#mapa"), D, ves); pintaOberts(); } });
      pintaOberts();
    }
    pintaContinua();
  }

  function pintaContinua() {
    var on = onContinuar(), nota = $("#continua-nota");
    if (nota) {
      if (on.aMitges) {
        nota.innerHTML = "Et porta al <strong>" + on.id + "</strong>, que vas deixar a mitges " +
          (window.RE_MITGES ? RE_MITGES.quan(on.aMitges.quan) : "") + ".";
        nota.hidden = false;
      } else {
        nota.hidden = true;
      }
    }
    $("#continua").onclick = function () { ves(on.id); };
  }

  if ($("#reinicia")) {
    $("#reinicia").onclick = function () {
      if (confirm("Vols esborrar el teu progrés d'aquest full? Els altres fulls no "
                + "es toquen.\n\nEl codi que enviïs al professorat dirà que has "
                + "reiniciat un full: reiniciar per tornar a practicar està bé, "
                + "reiniciar per fer desaparèixer com et va anar no.")) {
        RE.esborra(D.full);
        pinta();
      }
    };
  }

  pinta();
})();
